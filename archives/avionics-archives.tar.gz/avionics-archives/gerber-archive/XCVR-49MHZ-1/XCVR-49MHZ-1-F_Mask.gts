%TF.GenerationSoftware,KiCad,Pcbnew,9.0.2+dfsg-1*%
%TF.CreationDate,2026-05-31T10:32:43-04:00*%
%TF.ProjectId,XCVR-49MHZ-1,58435652-2d34-4394-9d48-5a2d312e6b69,A-STUB*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.2+dfsg-1) date 2026-05-31 10:32:43*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 APERTURE END LIST*
M02*
