# Commo — EMI-Hardened 49 MHz AX.25 Transceiver

**Author:** Steve Griffing, PE(CSE), CISSP-ISSEP, CPP
**License:** CERN-OHL-W 2.0 (hardware design); status notes/prose in this file are CC BY-SA 4.0 —
see `docs/attribution_and_licensing.md`
**Revision:** S1 (Rev S baseline + schematic-first reconciliation 2026-07-04)
**Date:** 2026-07-04
**Status:** Schematic-first reconciliation COMPLETE — `Commo.kicad_sch` authored from the
as-placed PCB (`gen_commo_sch.py`), PCB transformed to match (`mod_commo_pcb.py`); sch↔pcb
parity exact (74 refs / 104 nets / 0 pin-count mismatches), ERC 0 errors. J1 (JST-GH-6P)
DROPPED — modem UART now rides the PB2-P1 rails (`UART_49MHZ_XCVR_RX`/`_TX`); PTT_N and a new
on-board `RSSI_DCD` carrier-detect ride presence-gated PB2-P2 payload GPIOs. Open (TODO.md
§1.2b): manual placement/routing of the 4 new RSSI parts (parked off-board), `RSSI_CMP`
part/pinout datasheet vetting, PTT/RSSI pinmux firmware sign-off, and 3 pre-existing
in-circuit stubs the schematic surfaced (`RF_ANT_SW`, `PA_EMIT`, `DDS_FSYNC`).

**Status update (2026-09-21, S. Griffing / Claude Sonnet 5) — RADIO SWAP, everything below this
note describing "LoRa (RFM95W)" as this board's radio is superseded:** Per the fleet radio
relocation decision (`avionics/WBS.md` §1.2a "APPROVED DIRECTION"), **Commo's LoRa (RFM95W)
module was removed and replaced with the SiK modem (RFD900ux-SMT) relocated from XO/TACCO**,
which gave up SiK in exchange for an mLRS radio on a Seeed Wio-E5 module (see
`avionics/kicad/TACCO/TACCO.md`'s matching status note for that side of the swap). New refs:
`SIK`, `C-SIK1/2`, `C-SIK-SH1/2`, `L-SIK-SER`, `D-ANT-SIK`, `J-ANT-SIK`. The 3 pre-existing
in-circuit stubs flagged above are now **resolved**, not open: `RF_ANT_SW` was merged onto the
already-working `ANT` antenna filter chain (adjacent-row naming mismatch); `PA_EMIT`'s emitter-
degeneration resistor was back in circuit after fixing the PA transistor's emitter pin, which had
been wired straight to GND, bypassing it; `DDS_FSYNC` (the MCP4921 TX DAC's SPI chip-select) was
wired to PB2-P1 pin 26, the exact pin freed by the LoRa->SiK swap (owner's explicit call, not
guessed). `kicad-cli sch erc` = **0 violations**. `Commo.kicad_pcb` was synced to match: old
RFM95W footprint removed, the 8 new SIK-chain footprints added with nets matched 1:1 against the
schematic. Along the way, a real pad-pitch/axis bug in the shared `RFDesign_RFD900ux_SMT`
footprint (used by both boards) was found and fixed against the OEM datasheet's land-pattern
table. **Known residual:** this board's existing hand-placed layout has no contiguous free area
for the 21x29mm SIK module without touching `ETH-PHY`/`T-ETH` — a real floorplan pass, not a
netlist-sync task, is still needed before fab. Full detail: `avionics/WBS.md` §1.2a.

> **Note:** the "As-Built" tables below predate the 2026-07-04 reconciliation and still
> list J1 "TACCO IF" as present; J1 has since been removed and the modem UART moved to the
> PB2 rails. `Commo.kicad_sch` (not these tables) is now the source of truth.

---

## Purpose

Commo is an electromagnetic-environment-hardened variant of XCVR-49MHZ-1. The
board is a 49 MHz AX.25 KISS modem operating under 47 CFR Part 15 §15.235 (an unlicensed
intentional-radiator rule, not Part 95 RCRS — see REFERENCES.md REF-FCC-003); the -2 variant
adds conducted and radiated immunity measures to handle the EDF motor and ESC switching
environment inside the Serenity UAV nacelles.

All Phase 1 IC selections (Si5351A-B-GT DDS, MMBT2222A + 2N3866 PA, MCP4921 DAC,
LM393 comparator, MGA-82563 LNA, PE4259-63 T/R switch) are unchanged. The regulatory
constraints from XCVR-49MHZ-1 apply unchanged.

---

## Changes from XCVR-49MHZ-1

### 1. J1 host interface — EMI filter and protection

The 6-pin 2.54 mm pitch header J1 that connects to XO's XCVR-49MHZ port is the
primary EMI ingress path. Any high-frequency conducted noise arriving on the UART and
PTT lines from the TACCO harness routes directly to the Si5351A logic interface
and MCP4921 SPI port. Commo adds a three-tier protection network:

## Tier 1 — Common-mode choke (CM5)

- Bourns SRF2012-100Y on the UART_TX/UART_RX pair (CM5)
- Placed between J1 and the Si5351A / MCU I²C interface
- Attenuates CM RF currents at the 49 MHz band and EDF switching harmonics (20–100 kHz)

## Tier 2 — Series ferrite beads

- Würth 742792510 (600 Ω @ 100 MHz, 100 mA, 0402) on UART_TX, UART_RX, and PTT_N,

  placed after CM5 toward the on-board circuitry

- Suppresses conducted EMI above 50 MHz that passes through the CMC

## Tier 3 — TVS protection array (TVS6)

- PRTR5V0U2X (NXP, dual-channel, 5.5 V clamp, SOT-363) on UART_TX and UART_RX
- Placed before CM5, immediately at J1 pin 3 and pin 4
- Clamps ESD / cable-injected transients to 5.5 V before they can reach any IC

## RSSI analog output (J1 pin 6)

- 1 nF C0G capacitor to GND, placed at J1 pin 6
- Filters HF noise on the analog output without distorting the DC–3 kHz RSSI signal

## +5V supply at J1 (pin 1)

- 10 µF MLCC + 100 nF 0402, placed immediately at J1 pin 1
- These are in addition to the existing AMS1117 / MCP1703 input capacitors

### 2. LDO upgrade: AMS1117-3.3 → MCP1703T-3302E/CB

| Parameter | XCVR-49MHZ-1 | Commo |
| --- | --- | --- |
| Part | AMS1117-3.3 (SOT-223) | MCP1703T-3302E/CB (SOT-23A-5) |
| PSRR (100 kHz) | 40 dB | 72 dB |
| PSRR (1 MHz) | 15 dB (typical) | 45 dB |
| Noise (10 Hz–100 kHz) | 50 µV RMS (typ) | 30 µV RMS (typ) |
| Dropout voltage | 1.2 V @ 800 mA | 425 mV @ 250 mA |
| Quiescent current | 5 mA | 55 µA |

The MCP1703T's superior PSRR at 100 kHz and above prevents EDF PWM ripple on the +5V
supply rail from modulating the 3.3 V reference voltage that feeds the Si5351A and
MCP4921 DAC. Supply noise on the Si5351A reference input translates directly to phase
noise on the 49 MHz carrier; better PSRR reduces incidental FM, which is particularly
important for the 1200-baud AFSK modulation scheme.

> **DigiKey:** MCP1703T-3302ECB-ND · $0.57 ea.

### 3. Enhanced supply bypass cascade

The original AMS1117 output had a single 10 µF + 100 nF bypass pair. Commo
adds a four-capacitor cascade to address both low-frequency (EDF PWM) and high-frequency
(RF pickup) ripple:

```text

+5V_J1 ── FB2 ── +5V_F ── MCP1703T ── +3V3_F
|  |
                 C21                      C23  C24  C25  C26
                (100µF)             (100µF)(10µF)(100nF)(10nF)

```

| Reference | Value / Type | Placed at |
| --- | --- | --- |
| FB2 | Würth 742792512 (600 Ω @ 100 MHz, 2 A) | +5V input, before LDO |
| C21 | 100 µF / 10 V MLCC X5R 1210 | +5V, input bulk |
| C22 | 100 nF / 10 V MLCC X7R 0402 | +5V, HF bypass |
| C23 | 100 µF / 10 V MLCC X5R 1210 | +3V3, output bulk |
| C24 | 10 µF / 10 V MLCC X5R 0805 | +3V3, mid-frequency |
| C25 | 100 nF / 10 V MLCC X7R 0402 | +3V3, HF bypass |
| C26 | 10 nF / 10 V MLCC C0G 0402 | +3V3, VHF bypass |

C26 (C0G 10 nF) specifically targets the 49 MHz fundamental and its harmonics.
C0G dielectric has no piezoelectric effect and maintains capacity within 1% across
temperature, preventing resonance shifts in the decoupling network.

### 4. Improved low-pass filter: 6-element Chebyshev

XCVR-49MHZ-1 specified a 5-element Chebyshev LPF (FL1) with fc = 75 MHz and
≥ 40 dBc attenuation at the 2nd harmonic (98 MHz). Commo upgrades to a
6-element design to add one additional pole, targeting ≥ 50 dBc at 98 MHz and
≥ 60 dBc at 147 MHz (3rd harmonic):

| Element | Value (6-element Chebyshev, 0.5 dB ripple, Zin/Zout = 50 Ω) | Component |
| --- | --- | --- |
| L1 | 100 nH | Coilcraft 0805HQ-101JLBC (shielded ferrite) |
| C1 | 120 pF | C0G 0402 |
| L2 | 180 nH | Coilcraft 0805HQ-181JLBC |
| C2 | 180 pF | C0G 0402 |
| L3 | 180 nH | Coilcraft 0805HQ-181JLBC |
| C3 | 120 pF | C0G 0402 |

> **SPICE/QUCS-S verification** required in Phase 4 per XCVR-49MHZ-1 design notes.
> The 6-element network is specifically designed to ensure ≥ 60 dBc at 147 MHz
> (3rd harmonic of 49 MHz), to meet the out-of-band emission limits of 47 CFR §15.209
> applied via §15.235(b) (REF-FCC-003) — not Part 95 §95.655, which does not apply to
> this band.

### 5. Chassis ground (PGND) and shielding

## Board-level chassis ground

A PGND copper pour ring (3 mm wide, all four board edges) connects to:

- The RP-SMA J2 connector shell (shield contact, outer conductor)
- All four M3 corner mounting holes
- The PE4259-63 T/R switch body GND pad (RF section, In1.Cu)
- TVS-SMA (SMAJ5.0A, see §6)

PGND-to-GND single-point connection: 0 Ω solder-selectable link at J1 GND (pin 2),
so the board shares chassis ground with the TACCO host when plugged in. If RF isolation
from the host ground is preferred, the link is left open.

## EMI shield can footprint

The RF section (Si5351A, PA stage, LPF, T/R switch, LNA — right 25 mm of board) has a
metal EMI shield can footprint (Laird / Würth snap-on or soldered lid, 25 × 30 mm).
Tin-plated steel (Laird MSA030020T or equivalent). Soldering tabs connect to PGND.
The shield can:

- Prevents RF leakage from the PA from coupling into the digital UART/I²C section
- Provides >30 dB additional shielding against external E-field at 49 MHz

### 6. Antenna port TVS protection

A SMAJ5.0A bidirectional TVS is placed on the RP-SMA J2 antenna port center conductor,
clamping any cable-injected transients to ±5 V before the PE4259-63 T/R switch.
The TVS is a SOD-123FL package, placed within 2 mm of J2, with the cathode to PGND.

> **Note:** The SMAJ5.0A is a protective device against cable-injected ESD/lightning
> — it does NOT attenuate the 49 MHz signal (insertion loss < 0.1 dB at 49 MHz at
> 100 mW output level). The device does affect VSWR above 500 MHz, which is acceptable
> since the LPF already provides ≥ 40 dBc attenuation at those frequencies.

### 7. PCB layout — additional constraints beyond XCVR-49MHZ-1

- **PGND pour:** In1.Cu GND plane is divided at the midpoint between digital and RF

  sections; the RF side pour is labeled PGND and connects to the RP-SMA shell. The
  digital side is plain GND. The moat is bridged by a 10 nF C0G capacitor (C27)
  for RF, referencing PGND on one side and GND on the other.

- **Shield can wall clearance:** All components inside the EMI can footprint shall be

  at least 0.5 mm from the can footprint outline to allow the snap-on lid.

- **MCP1703T placement:** The LDO shall be outside the shield can (digital section),

  with its output traces entering the RF section through a ferrite bead (FB2 or
  dedicated 0402 bead). This prevents LDO switching noise from contaminating the
  RF supply path.

- **J1 filter placement:** CM5 common-mode choke and TVS6 array shall be within 3 mm

  of J1 and outside the shield can.

- **RP-SMA TVS placement:** TVS-SMA (SMAJ5.0A) shall be within 2 mm of J2 on the board

  edge side, outside the shield can.

### 8. PCB DRC Fixes — Corrected Net Assignments

The following component pad-to-net assignments were incorrect and have been corrected.
All changes address either shorted components (both pads on the same net) or
functionally wrong connections.

| Component | Ref | Pad | Old Net | New Net | Issue |
| --- | --- | --- | --- | --- | --- |
| UART CMC | CM5 | all | L_0402 2-pin | SRF2012_2012Metric 4-pin | Wrong footprint; SRF2012-100Y is 4-pin 2.0×1.25 mm CMC, not 2-pin 0402 inductor |
| UART CMC | CM5 | 3 | UART_RX_F | UART_RX_MUX | Pad 3 is MUX output; net name updated to reflect SBUS circuit addition |
| TX Bead | FB-TX | 1 | UART_TX | UART_TX_F | Bead pad 1 should carry the filtered signal, not the raw UART_TX net |
| RX Bead | FB-RX | 1 | UART_RX | UART_RX_F | Bead pad 1 should carry the filtered signal |
| PA Re | R_E | 1 | GND | PA_EMIT | Emitter-degeneration resistor shorted GND-GND; pad 1 is emitter node |
| Th Lo | R_TH_LO | 1 | GND | COMP_IN | Threshold divider lower resistor shorted GND-GND; pad 1 is comparator input |
| PA Cb1 | C_B1 | 2 | DDS_RF | PA_INT | Coupling capacitor both pads on DDS_RF; pad 2 is PA collector input |
| AFSK Cp | C_AF | 2 | AFSK_OUT | AFSK_IN | Audio coupling capacitor both pads on AFSK_OUT; pad 2 is comparator input |

**Silk reference label relocations:**

| Component | Old position | New position | Reason |
| --- | --- | --- | --- |
| Th Lo | (0, +6.5) | (0, −1.17) | Label placed 6.5 mm below component body, outside any safe region |
| RSSI Lo | (+2, +3.5) | (0, −1.17) | Label offset 2 mm right and 3.5 mm below component body |

**New internal nets added to net table:**

| Net # | Name | Description |
| --- | --- | --- |
| 27 | UART_TX_F | UART TX after CMC winding 1 (Tier-2 bead input) |
| 28 | UART_RX_F | UART RX after CMC winding 2 (INV1 and MUX1 A0 inputs) |
| 29 | PA_EMIT | PA emitter node (emitter-degeneration resistor junction) |
| 30 | SBUS_OUT | Inverted UART_RX_F produced by INV1 (SBUS logic polarity) |
| 31 | MODE_SEL | UART/SBUS mode select: LOW = UART, HIGH = SBUS |
| 32 | UART_RX_MUX | MUX1 output routed to CMC pad 3; carries either UART_RX_F or SBUS_OUT |

---

### 9. SBUS Receiver Mode — Hardware-Select Inverter and MUX

SBUS (used by RC receivers and autopilots) operates at 100000 baud with **inverted
logic polarity** relative to standard UART. The 49 MHz channels are legal SBUS
carrier frequencies under 47 CFR Part 15 §15.235 (not Part 95 Subpart D, which does not
cover this band); adding hardware inversion and a
mode-select switch allows the transceiver to serve as an SBUS receiver input to the
flight-control SBCs without requiring firmware changes to the UART peripheral.

#### Circuit topology

```text
UART_RX_F ──┬──────────────────── A0  (MUX1 pin 1)
             │
             └── INV1 ──── SBUS_OUT ── A1  (MUX1 pin 6)
                                       │
S1 ─── MODE_SEL ──┬── R_MODE (10 kΩ, GND) ── S (MUX1 pin 5)
                  │
                  └── S1 pad 2 ── +3V3 (S1 pad 1)

MUX1 Y (pin 3) ── UART_RX_MUX ── CMC pad 3 ── UART_RX (host)
```

- **S1 OPEN** (default): R_MODE pulls MODE_SEL LOW → MUX1 S=0 → Y = A0 = UART_RX_F
  (standard UART mode, non-inverted)
- **S1 CLOSED**: +3V3 overrides R_MODE → MUX1 S=1 → Y = A1 = SBUS_OUT
  (SBUS mode, inverted 100 kbaud signal)

The output UART_RX_MUX passes through CMC winding 2 before reaching the host
connector J1, providing the same EMI filtering in both modes.

#### Component details

| Reference | Part | Package | Net connections | Placement (PCB coords) |
| --- | --- | --- | --- | --- |
| INV1 | SN74LVC1G04 (TI DBV) | SOT-23-5 | A=UART_RX_F, Y=SBUS_OUT, VCC=+3V3, GND | (109.5, 125) |
| MUX1 | SN74LVC1G157 (TI DCT) | SC-70-6 (SOT-363) | A0=UART_RX_F, A1=SBUS_OUT, S=MODE_SEL, Y=UART_RX_MUX, VCC=+3V3 | (113.5, 125) |
| S1 | SPST SMD slide switch | Custom 2-pad, 1.5 mm pitch | pad1=+3V3, pad2=MODE_SEL | (109.5, 128.5) |
| C_INV | 100 nF C0G 0402 | C_0402_1005Metric | VCC bypass for INV1: +3V3→GND | (112.5, 128.5) |
| C_MUX | 100 nF C0G 0402 | C_0402_1005Metric | VCC bypass for MUX1: +3V3→GND | (115.5, 128.5) |
| R_MODE | 10 kΩ 0402 | R_0402_1005Metric | MODE_SEL pull-down to GND | (116.5, 125) |

All six components are placed in the digital section lower-left area
(x: 107–118, y: 124–130), clear of all existing component courtyards by ≥ 0.4 mm.

#### Protocol note — SBUS timing

SBUS: 100000 baud, 8E2 (8 data bits, even parity, 2 stop bits), **inverted logic**,
25 ms frame period. The SN74LVC1G04 propagation delay is ≤ 5 ns (worst case at 3.3 V),
negligible vs. the 10 µs SBUS bit period. No additional filtering is required on the
inverted path because the UART_RX_F net is already filtered by the CMC and series bead.

---

### 10. Silk Label De-overlap Pass

The F.SilkS reference labels were audited against component positions; 13 overlapping
pairs were found and corrected by repositioning the `(at dx dy)` local offset in the
`property "Reference"` entry for each affected footprint.

| Ref | Old offset | New offset | Action |
| --- | --- | --- | --- |
| 49M DDS | (0, −2.45) | (0, +3.0) | Moved below chip body; cleared U1 ByA / U1 ByB cluster above |
| 1.2k R | (0, −1.17) | (0, +1.17) | Moved below; cleared Th Hi cluster at y ≈ 123.3 |
| 2.2k R | (0, −1.17) | (0, +1.17) | Moved below; cleared 1.2k C gap at same row |
| +3V 10u | (0, −1.68) | (0, −2.8) | Moved further above; cleared +3V 100n at y ≈ 121.3 |
| +3V 10n | (0, −1.16) | (+1.13, 0) | Moved right of component; cleared +3V 100n pair |
| PA By | (0, −0.36) | (−1.0, 0) | Moved left; cleared PA Rb2 same-X stacked overlap |
| PA Rb2 | (0, −1.17) | (0, +1.17) | Moved below; cleared PA By same-X label |
| PA Drvr | (0, −2.40) | (+3.5, 0) | Moved right; cleared PA Cb1 above-row cluster |
| PA Cb2 | (0, −1.16) | (+1.5, 0) | Moved right; cleared PA By / PA By2 cluster |
| RSSI Lo | (0, −1.17) | (0, +1.17) | Moved below; cleared RSSI Hi same-Y pair |

### 11. Via Repositioning — x = 130 Fence Column

The GND via fence at x = 130 (14 vias at 2.5 mm pitch) was shifted −1.25 mm in Y so
that no via falls on the board edge and all vias are at least 1.25 mm from both
horizontal edges. New Y range: 101.25 → 133.75 mm.

### 12. Via Conflict Fixes — PA Section and LNA

Four vias in the RF section were found to overlap component courtyards or pads, causing
DRC violations. All four were repositioned to clear positions with > 0.1 mm gap.

| Via old pos | Net | Conflict | Via new pos | Min gap |
| --- | --- | --- | --- | --- |
| (132, 109.5) | +5V_FILT | PA Rc1 courtyard (−0.33 mm gap) | (131.5, 109.5) | +0.37 mm |
| (136, 109.5) | PA_INT | PA Rb2 courtyard (−0.40 mm; dead-center) | (136, 107) | +0.63 mm |
| (140, 109.5) | GND | PA By2 courtyard (−0.35 mm gap) | (140.5, 109.5) | +0.54 mm |
| (143, 124.5) | GND | LNA pad 3 RF_RX (cross-net short; −0.17 mm gap) | (143, 125.5) | +0.75 mm |

The via at (136, 109.5) was dead-centered on the PA Rb2 courtyard because the via
sits between PA Rb2 (PA_INT both pads) and PA Cb2 (PA_INT pad 1) — the same net, but
the courtyard boundary still flags a DRC error. No trace segments connect to any of
these four vias; they connect through copper pours or the inner GND/+5V planes.

The via at (143, 124.5) was the only cross-net overlap (GND via touching LNA RF_RX
pad 3), which constitutes a real short-circuit risk and shall be corrected.

---

## Updated Bill of Materials (delta from XCVR-49MHZ-1)

### Removed

| Reference | Part |
| --- | --- |
| U6 | AMS1117-3.3 LDO |
| FL1 | 5-element Chebyshev LPF (replaced by 6-element) |

### Added / changed

| Reference | Part | Function |
| --- | --- | --- |
| U6 | MCP1703T-3302E/CB (SOT-23A-5) | Upgraded LDO, 72 dB PSRR at 100 kHz |
| CM5 | Bourns SRF2012-100Y | Common-mode choke on J1 UART pair |
| TVS6 | PRTR5V0U2X (SOT-363) | Dual TVS on J1 UART_TX/RX |
| TVS-SMA | SMAJ5.0A (SOD-123FL) | Antenna port transient clamp |
| FB2 | Würth 742792512 | +5V input ferrite bead |
| FB-TX | Würth 742792510 × 3 | Series beads: UART_TX, UART_RX, PTT_N |
| C21 | 100 µF / 10 V MLCC 1210 | +5V input bulk |
| C22 | 100 nF 0402 | +5V HF bypass |
| C23 | 100 µF / 10 V MLCC 1210 | +3V3 output bulk |
| C24 | 10 µF 0805 | +3V3 mid-frequency |
| C25 | 100 nF 0402 | +3V3 HF bypass |
| C26 | 10 nF C0G 0402 | +3V3 VHF (49 MHz) bypass |
| C27 | 10 nF C0G 0402 | GND–PGND moat bridge |
| Shield | Laird MSA030020T (or equiv) | RF section EMI shield can |
| INV1 | SN74LVC1G04DBVR (TI, SOT-23-5) | UART_RX_F → SBUS_OUT signal inverter |
| MUX1 | SN74LVC1G157DCKR (TI, SC-70-6) | 2:1 MUX; selects UART or SBUS polarity |
| S1 | SPST SMD slide switch, 1.5 mm pitch | UART / SBUS mode selector |
| C_INV | 100 nF C0G 0402 | INV1 VCC bypass |
| C_MUX | 100 nF C0G 0402 | MUX1 VCC bypass |
| R_MODE | 10 kΩ 0402 | MODE_SEL pull-down (default UART) |
| FL1_L1 | 100 nH (Coilcraft 0805HQ-101J) | 6-element LPF element 1 |
| FL1_C1 | 120 pF C0G 0402 | 6-element LPF element 2 |
| FL1_L2 | 180 nH (Coilcraft 0805HQ-181J) | 6-element LPF element 3 |
| FL1_C2 | 180 pF C0G 0402 | 6-element LPF element 4 |
| FL1_L3 | 180 nH (Coilcraft 0805HQ-181J) | 6-element LPF element 5 |
| FL1_C3 | 120 pF C0G 0402 | 6-element LPF element 6 |

---

## As-Built Full Component List (PCB Source of Truth, 2026-06-20)

The BOM delta tables above only cover the §1–§9 changes from XCVR-49MHZ-1. They do not
itemize the Phase 1 carryover circuitry (DDS, PA chain, LPF, T/R switch, LNA, AFSK
modem) or the Rev R1 Ethernet/LoRa additions, none of which had ever been fully
captured in this document. The table below is generated directly from
`Commo.kicad_pcb`'s footprint list (the as-placed source of truth) so it cannot drift
from the actual board the way a hand-maintained BOM can.

| Ref | Value / Part | Footprint | Function |
|---|---|---|---|
| **DDS / TCXO** | | | |
| 49M DDS | Si5351A-B-GT | MSOP-10 | I²C DDS synthesizer, 49 MHz carrier |
| TCXO 25M | TG2520SMN ±0.5 ppm | Oscillator SMD 4-pin | 25 MHz reference for the DDS |
| OSC By | 100 nF | C 0402 | TCXO +3V3 bypass |
| U1 ByA, U1 ByB | 100 nF ×2 | C 0402 | Si5351A VDDA/VDD bypass |
| **PA chain** | | | |
| PA Drvr | MMBT2222A | SOT-23 | Class-A driver stage |
| PA 100mW | 2N3866 | SOT-89-3 | Class-AB final, 100 mW |
| PA Rb1, PA Rc1, PA Rb2, PA Re | 10k / 100R / 1k / 10R | R 0402 | Driver/final bias network |
| PA Cb1, PA Cb2, PA By, PA By2 | 100 pF / 100 pF / 100 nF / 1 nF | C 0402 | Interstage coupling + bypass |
| **6-element LPF** | | | |
| L1 100n, L2 180n, L3 180n | Coilcraft 0805HQ series | L 0805 | LPF series elements |
| C1 120p, C2 180p, C3 120p | C0G 0402 | C 0402 | LPF shunt elements |
| **T/R switch, LNA, antenna** | | | |
| T/R Sw | PE4259-63 | SOT-363 | SPDT TX/RX switch, ≥35 dB isolation |
| LNA | MGA-82563 | SOT-363 | 2.4 dB NF LNA, 50–6000 MHz |
| LNA By | 100 nF | C 0402 | LNA +3V3 bypass |
| ANT CMC | SRF2012-100Y | Bourns SRF2012 | Antenna line CMC |
| ANT TVS | PRTR5V0U2X | SOT-363 | Antenna ESD |
| SMA ESD | SMAJ5.0A | SOD-123F | §6 antenna port TVS |
| GND X2Y | 4.7 nF X2Y C0G | C 0402 | GND–PGND moat bridge (RF side) |
| ANT RPSMA | Amphenol 132289RP | SMA edge mount | J2, §15.203-compliant RP-SMA |
| **RSSI / AFSK demod (RX)** | | | |
| RX Demod | LM393 | SOT-23-5 | AFSK comparator demodulator |
| Th Hi, Th Lo | 10k / 10k | R 0402 | LM393 threshold divider |
| RSSI Hi, RSSI Lo | 10k / 10k | R 0402 | RSSI scale divider |
| 1.2k R/C, 2.2k R/C | RC bandpass | R/C 0402 | 1200/2200 Hz AFSK tone filters |
| **AFSK / TX DAC** | | | |
| TX DAC | MCP4921 | SOT-23-8 | 12-bit SPI DAC, TX-AFSK audio |
| AFSK Cp | 1 µF | C 0402 | DAC→PA audio coupling |
| **UART / SBUS digital chain** | | | |
| UART CMC | SRF2012-100Y | SRF2012 | UART TX/RX pair CMC (Tier 1, §1) |
| UART TVS | PRTR5V0U2X | SOT-363 | UART TX/RX ESD (Tier 3, §1) |
| TX Bead, RX Bead, PTT Bead | 742792510 ×3 | L 0402 | Series ferrite beads (Tier 2, §1) |
| INV1 | SN74LVC1G04 | SOT-23-5 | UART_RX_F → SBUS_OUT inverter (§9) |
| MUX1 | SN74LVC1G157 | SC-70-6 | UART/SBUS select mux (§9) |
| S1 | SPST SMD | 2-pin slide | UART/SBUS mode switch (§9) |
| R_MODE | 10k | R 0402 | MODE_SEL pull-down, default UART |
| C_INV, C_MUX | 100 nF ×2 | C 0402 | INV1/MUX1 VCC bypass |
| **Power supply** | | | |
| LDO 3V3 | MCP1703T-3302E | SOT-23A-5 | §2 LDO upgrade |
| LDO By | 100 nF | C 0402 | LDO bypass |
| +5V Bead | 742792512 | C 0805 footprint (bead) | +5V input ferrite |
| +5V 100u, +5V 100n | 100 µF / 100 nF | C 1210 / C 0402 | §3 +5V bypass cascade |
| +3V 100u, +3V 10n, +3V 100n, +3V 10u | 100 µF / 10 nF / 100 nF / 10 µF | C 1210/0402/0402/0805 | §3 +3V3 bypass cascade |
| CMP By, DAC By, SW By | 100 nF ×3 | C 0402 | Local +3V3 bypass at U2B/U2A/U5 |
| PGND 10n | 10 nF C0G | C 0402 | §7 GND–PGND moat bridge (digital side ref) |
| **Connectors** | | | |
| TACCO IF | JST-GH-6P (custom) | JST_GH_6P | Host UART/PTT/RSSI/+3V3 interface |
| PB2-P1, PB2-P2 | PB2I 2×18 sockets | 2x18 socket | Rev R1 PocketBeagle2 header rails |
| **Ethernet (Rev R1 addition — see TODO.md §1.2b)** | | | |
| ETH-PHY | ADIN1300BCPZ | QFN-48, B.Cu | Second Ethernet PHY, gives Commo (and the XO stack it plugs into) a 2nd port matching Pilot's 2-PHY config; also lets Commo run Ethernet standalone outside Serenity |
| T-ETH | Würth 749010012A | ETH_XFMR_8P, B.Cu | RMII-side isolation transformer; secondary (`*_ETH2`/`GND2_ETH`/`VCC2_ETH`) is a galvanically isolated domain — **shall not be bridged to the main GND/+5V planes** |
| J-ETH | JST-GH-4P (custom) | JST_GH_4P | Isolated-side Ethernet line connector |
| **LoRa (Rev R1 addition — see TODO.md §1.2b, REF-RFMOD-001)** | | | |
| LoRa | RFM95W | HOPERF_RFM9XW_SMD, B.Cu | 915 MHz LoRa module. Pin mapping corrected 2026-06-20 against the verified HopeRF datasheet; ANT/3V3/DIO0–5 still unassigned and footprint pad geometry/position still need correction — see TODO.md |
| **Mechanical** | | | |
| (4×, unlabeled) | M2.5 mounting hole | MountingHole_2.7mm_M2.5 | Corner mounts |

**Note on net names referencing "U1"/"U2A"/"U2B"/"U3"/"U3A"/"U3B"/"U4"/"U5"/"U6" in
component values** (e.g. "U1 ByA", "PA By (U3 PA VCC Bypass)"): these are internal
designator shorthands from the original schematic capture (U1 = 49M DDS, U2A/U2B =
RX Demod's two comparator stages, U3A/U3B = PA Drvr/PA 100mW, U4 = LNA, U5 = T/R Sw,
U6 = LDO 3V3) and predate the present flat reference-designator scheme; they are
preserved in the `Value` field as placed and should not be read as separate components.

---

## Board Size and Stackup

**Board size:** 55 × 35 mm — unchanged from XCVR-49MHZ-1.

The EMI shield can footprint fits within the existing RF section keep-out area (right
25 mm × 30 mm). The new filter components (CM5, TVS6, FB2, bypass caps) occupy the
vacated AMS1117 SOT-223 pad area plus a 5 × 8 mm strip adjacent to J1.

**Layer stackup:** 4-layer, identical to XCVR-49MHZ-1.

**Corner profile:** The four corners of the Edge.Cuts outline are rounded with
R = 2.5 mm quarter-circle arcs, centered on the M2.5 corner mounting holes
(which are placed 2.5 mm from each edge). This eliminates the sharp right-angle
corners that are prone to chipping during depanelization and handling, and matches
the corner profile applied to Pilot, Pilot, XCVR-49MHZ-1 (also updated),
and the existing TACCO/B-2 boards (which already carried this profile).

---

## Regulatory Constraints

Unchanged from XCVR-49MHZ-1. The 6-element LPF provides additional margin vs. the
5-element version, improving compliance margin for the 47 CFR §15.209 out-of-band
emission limits applied via §15.235(b) (REF-FCC-003) — not Part 95 §95.655, which does
not apply to this band.  Note: the PA chain (MMBT2222A + 2N3866) is sized for ~100 mW
output, which exceeds the §15.235 field-strength-equivalent EIRP ceiling of ≈ 30 µW by
roughly 35 dB; firmware shall limit conducted output to ≈ −13 dBm (≈ 48 µW) for
compliance — see `gcs/skipper/hardware/docs/skipper_antenna_spec.md` Link 4 and
`TODO.md` §0.1.

**Antenna connector — §15.203 violation resolved in design (2026-06-20):** the board
previously used a standard SMA edge jack (Amphenol 132289). §15.203 states "the use of a
standard antenna jack or electrical connector is prohibited," and that obligation binds the
manufacturer/responsible party directly — being the manufacturer (Griffing Technology LLC)
creates no self-authorization exception, since the manufacturer is exactly who bears the
§2.803/§15.19 equipment-authorization burden. §15.203's exceptions for carrier-current
devices and professionally-installed, on-site-measured radiators do not apply to this board.
J2 is now specified as Amphenol **132289RP**, the reverse-polarity (RP-SMA) counterpart of
132289 — same PCB footprint, mating gender reversed so generic standard-SMA antennas/cables
cannot connect, satisfying §15.203's "unique coupling" provision. See `REFERENCES.md`
"Open Standards Verification Items" and `TODO.md` §0.1 for status; physical board re-spin
to populate 132289RP in place of 132289 is the remaining fabrication step.

> *"That sounds like the Alliance. Unite all the planets under one rule so that everybody
> can be interfered with or ignored equally."* — Skipper, *Firefly*, "The Train Job" (2002)

---

## Security Notes

**Updated 2026-07-26:** Commo now carries its own TPM — Infineon SLB9672 (SPI TPM 2.0,
same part standardized fleet-wide), added via `avionics/kicad/Commo/scripts/inject_commo_tpm.py`
(schematic ref `TPM`). TPM + its 10 kΩ reset pull-up (`R_TPM_RST_EMMA`) + 100 nF
decoupling cap (`C_TPM_EMMA1`) are placed on the PCB (B.Cu — Commo's F.Cu is fully
saturated, confirmed by an exhaustive obstacle-aware search finding zero clear ≥6×6 mm
front-side sites anywhere on the board), nets assigned, DRC-clean. Routing from TPM/R/C
to the rest of the board is open (first-pass footprint population only, per this
project's established convention).

**Architecture, corrected 2026-07-26:** the TPM provides the last/first cryptographic
signature for radio messages Commo transmits and for messages it forwards to/from XO or
elsewhere. It binds to the PB2-I host it's plugged into — no local CAN-FD/RS-485
transceiver and, per the same reasoning, **no dedicated SPI hardware or header either**.
Commo is designed to run as a self-sufficient cape for other (non-Serenity) deployments
too, and the TPM binds to whichever PB2 host it's on, providing that host's full TPM
services. It therefore taps the **SPI1** slot already reserved on Commo's own P1/P2 trunk
— `SPI1_CS_TPM` / `SPI1_CLK` / `SPI1_MOSI` / `SPI1_MISO` (a shared bus also carrying
`SPI1_CS_NOR` and `SPI1_CS_LORA` to other on-board devices) plus the pre-existing
`TPM_IRQN` / `TPM_RSTN` global labels, all already wired to specific PB2-P1/P2 pins
elsewhere in `Commo.kicad_sch`. An earlier draft of `inject_commo_tpm.py` instead added a
dedicated 6-pin `J_TPM` header (reasoning that cross-*file* net-name reuse, e.g. Pilot's
`SPI0_CLK` name, doesn't connect anything — true, but irrelevant here since Commo's own
P1/P2 block already reserves an SPI1 slot for exactly this purpose within Commo's own
file). That header has been removed from both the schematic and the generator script;
see `inject_commo_tpm.py`'s docstring for the full correction. Prior to the TPM's
addition, cryptographic operations for AX.25 payload signing were entirely on the
TACCO host CPU; that remains true for any signing not routed through the local TPM.

---

## 8. Shielded Host Interface Connector (J1) and Wiring Requirements

### J1 SHIELD Pin (MP) — PGND Bond

The JST-GH SM06B-GHS-TB-1MP connector symbol for J1 now includes a SHIELD pin
(number "MP") connected to the PGND chassis ground net via the PCB mounting tab.

| Pin | Signal | Description |
|---|---|---|
| 1 | GND | Signal/power return |
| 2 | +5V | Host power input (5 V, 250 mA max) |
| 3 | UART_TX (SDA) | Host UART TX / I²C SDA |
| 4 | UART_RX (SCL) | Host UART RX / I²C SCL |
| 5 | PTT_N | Push-to-talk (active low) |
| 6 | RX_OUT | Received audio / RSSI analog |
| MP | PGND | Cable braid/foil drain — chassis ground |

### J1 Cable Assembly Specification

- **Cable type:** Belden 9533 6-conductor overall foil + braid shielded (or equivalent
  multi-conductor shielded, ≥ 28 AWG per conductor, overall shield coverage ≥ 85 %).
- **Drain wire:** 28 AWG stranded, terminate to the J1 PGND mounting-tab pad.  Bond the
  other end to XO's corresponding J_XCVR PGND pad.
- **Ferrite clamp:** Würth 74271222 snap-on ferrite (or Laird 28B0562-100) ≤ 25 mm from
  the connector body at BOTH the Commo end and the XO end.
- **Maximum cable length:** 150 mm (limited by signal integrity at 1200-baud AFSK and
  UART signal rise time ≤ 10 ns at 3.3 V LVCMOS).

### Wiring to Host (XO J_XCVR)

The J1-to-J_XCVR harness is the primary EMI ingress path.  In addition to the
cable shield, the following on-board measures are active (see §1):

- **CM5** Bourns SRF2012-100Y common-mode choke on UART_TX/RX pair
- **TVS6** PRTR5V0U2X on UART_TX/RX (pins 3–4) immediately at J1
- **FB-TX** series 0402 ferrite beads (Würth 742792510) on each of UART_TX, UART_RX,
  and PTT_N after CM5

### RP-SMA Antenna Cable (J2)

- **Connector:** Amphenol 132289RP RP-SMA edge-launch jack (reverse-polarity
  counterpart of 132289; §15.203 unique-coupling antenna restriction, see
  "Regulatory Constraints" above).
- **Cable type:** RG-316 or RG-178 50 Ω coaxial, maximum 500 mm, terminated in an
  RP-SMA plug to mate with J2.
- **Ferrite clamp:** One Würth 74271222 on the coaxial near the RP-SMA connector body
  at the antenna end (if cable length > 100 mm), to suppress common-mode current.
- **TVS-SMA:** SMAJ5.0A bidirectional TVS on the RP-SMA center conductor is already
  fitted (§6); no additional external protection required.

---

## Related Files

- `XCVR-49MHZ-1.kicad_sch` — original (Phase 1 stub) schematic
- `XCVR-49MHZ-1.md` — original Phase 1 design notes and committed BOM
- `TACCO.kicad_sch` — host board with J1 counter-connector
- `TACCO.md` — TACCO design notes

---

## References

1. Microchip MCP1703 Data Sheet DS22049E — PSRR curves (Figures 2-5)

- Step 2: Würth Elektronik EMC Design Guide — ferrite bead and LDO bypass layout

- Step 3: NXP PRTR5V0U2X Product Data Sheet Rev. 3

- Step 4: Laird MSA Series Shield Can Selection Guide

- Step 5: `archive/XCVR-49MHZ-1.md` — Phase 1 design decisions (IC selection rationale)

- Step 6: [REF-FCC-003 §15.235(b)] / [REF-FCC-003 §15.209] — FCC out-of-band emission requirements (not Part 95 §95.655, which does not apply to this band)

- Step 7: QUCS-S / SPICE Chebyshev filter synthesis reference:

   Williams & Taylor, "Electronic Filter Design Handbook" 4th ed., Table 11-60

---

## PCB File Inline Notes

KiCad S-expression files do not support inline comments. The following content was
previously carried as semicolon-prefixed comment lines in `XCVR-49MHZ-2.kicad_pcb`
and is preserved here per project standards (AGENTS.md §Coding Standards).

### File Header (removed from kicad_pcb)

- **Board:** Commo EMI-Hardened 49 MHz AX.25 KISS Transceiver
- **Date:**2026-06-03**Rev:** 2
- **4-layer stackup:** F.Cu (signal) / In1.Cu (GND) / In2.Cu (+5V power) / B.Cu (signal)
- **Board size:** 55 × 35 mm, origin at (100, 100) mm
- **FAB target:** JLCPCB 4-layer, 1.6 mm FR4, ENIG
- **Changes from Rev 1:** Added CMC_CAN (SRF2012), D_TVS (PRTR5V0U2X), FB1 (742792512),

  C_X2Y (4.7 nF X2Y cap); all UUIDs regenerated with prefix `49020000-0000-0000-0000-`

### Reference Designator Convention — CMC_CAN

The suffix "CAN" in `CMC_CAN` follows the project naming convention for the antenna
common-mode choke per the task specification "CMC_CAN: SRF2012 near antenna path".
This component suppresses common-mode currents on the antenna feed line to reduce
conducted EMI per IEEE 1613 / CISPR 32.
Pad 1 = ANT input (from RF section); Pad 2 = ANT output (clean side, toward J2 RP-SMA).
Both KiCad pads are assigned to net ANT because a separate ANT_CMC_OUT net was not
declared; the functional distinction is physical placement only.

### Footprint Pad Net Assignments

| Ref | Pad | Net | Notes |
| ----- | ----- | ----- | ------- |
| J1 | 1 | GND | Left-most pin, 1.25 mm pitch SMD |
| J1 | 2 | UART_TX |
| J1 | 3 | UART_RX |
| J1 | 4 | PTT_N |
| J1 | 5 | RSSI_ANA |
| J1 | 6 | +3V3 | Right-most pin |
| J2 | 1 | ANT | RP-SMA center pin, 0.9 mm drill, thru-hole circle |
| J2 | 2 | GND | Upper GND tab, 1.0 mm drill |
| J2 | 3 | GND | Lower GND tab, 1.0 mm drill |
| CMC_CAN | 1 | ANT | Input from RF section; left pad, silkscreen notch marks pin 1 |
| CMC_CAN | 2 | ANT | Output to J2; right pad |
| D_TVS | 1 | GND | Left column bottom — SOT-363 pin 1 per NXP PRTR5V0U2X pinout |
| D_TVS | 2 | ANT | Left column center — TVS anode A1 |
| D_TVS | 3 | GND | Left column top |
| D_TVS | 4 | GND | Right column top |
| D_TVS | 5 | RF_TX | Right column center — TVS anode A2 |
| D_TVS | 6 | GND | Right column bottom |
| FB1 | 1 | +5V | Input — raw +5V from J1 before filtering |
| FB1 | 2 | +5V_FILT | Output — clean supply to on-board ICs; 0805 pad reused for bead |
| C_X2Y | 1 | GND | Both pads GND for X2Y differential-mode bridge function |
| C_X2Y | 2 | GND | Both pads GND for X2Y differential-mode bridge function |

### Copper Pour Notes

- **In1.Cu — GND plane:** Full-board pour, polygon (100,100)→(155,135).

  Per IPC-2141A controlled-impedance inner plane requirement.
  Min thickness 0.25 mm; thermal gap 0.5 mm; thermal bridge width 0.5 mm.

- **In2.Cu — +5V power plane:** Digital section only, polygon (100,100)→(130,135).

  Excludes RF section (x = 130–155 mm) per PCB layout constraint: no power plane
  under RF section.

### Footprint Courtyard and Body Dimensions

| Ref | Courtyard (mm) | Fab body (mm) | Notes |
| ----- | ---------------- | --------------- | ------- |
| CMC_CAN | 2.4 × 1.4, centered | 2.0 × 1.25 | Silkscreen notch on left edge for pin 1 |
| D_TVS | 2.1 × 2.4 | 1.3 × 2.0 (SOT-363) | Filled triangle poly marks pin 1 |
| FB1 | 3.4 × 2.0 | 2.0 × 1.2 | Silkscreen tick on left edge for pin 1 |
| C_X2Y | 1.4 × 0.9 | 1.0 × 0.5 | 0402 metric |

---

## Schematic Inline Notes

The following content was previously carried as `;;`-prefixed comment lines in
`XCVR-49MHZ-2.kicad_sch` and is preserved here per project standards.

### Component Placement Coordinates

All coordinates are in KiCad schematic mm units. Pin offsets are from the component
anchor; they are needed for hand-editing this file because KiCad pin exits are at
fixed offsets from the symbol anchor per the lib_symbols definition above.

| Ref | Anchor (x, y) | Rotation | Pin exit notes |
| ----- | --------------- | ---------- | ---------------- |
| J1 | 50.00, 100.00 | 0° | Pins exit at x = 52.54; y pitch = 2.54 mm; pin 1 at y = 106.35 |
| FB1 | 90.00, 96.19 | 90° | Pin A exits at (86.19, 100.00); Pin B exits at (90.00, 92.38) |
| CMC_CAN | 200.00, 100.00 | 0° | L1A at (194.92, 101.27); L2A at (194.92, 98.73); L1B at (205.08, 101.27); L2B at (205.08, 98.73) |
| D_TVS | 240.00, 100.00 | 0° | A1 at (234.92, 101.27); A2 at (234.92, 98.73); K at (245.08, 100.00); GND at (240.00, 105.08) |
| J2 | 280.00, 100.00 | 0° | RF pin at (274.92, 100.00); GND pin at (285.08, 100.00) |
| C_X2Y | 270.00, 120.00 | 0° | Pin 1 top at (270.00, 116.19); Pin 2 bottom at (270.00, 123.81) |

### Power Symbol Placements

| Symbol | UUID suffix | At (x, y) | Connects to |
| -------- | ------------- | ----------- | ------------- |
| GND #PWR01 | …000201 | 57.62, 106.35 | J1 pin 1 (GND) |
| +5V #PWR02 | …000203 | 57.62, 103.81 | J1 pin 2 (+5V, before FB1) |
| +5V #PWR03 | …000205 | 90.00, 92.38 | FB1 pin B (filtered +5V output) |
| GND #PWR04 | …000207 | 240.00, 105.08 | D_TVS pin 6 (GND) |
| GND #PWR05 | …000209 | 285.08, 100.00 | J2 pin 2 (GND/shield) |
| GND #PWR06 | …000211 | 270.00, 123.81 | C_X2Y pin 2 (bottom) |
| GND #PWR07 | …000213 | 209.16, 98.73 | CMC_CAN L2B (pin 4, return path) |
| GND #PWR08 | …000215 | 190.84, 98.73 | CMC_CAN L2A (pin 2, input) |

### Signal Routing

- J1 pin 1 → GND power symbol at (57.62, 106.35)
- J1 pin 2 → +5V, then wire through (80.00, 103.81)→(80.00, 100.00)→(86.19, 100.00)

  to FB1 pin A

- J1 pin 3 → global label `SDA` (I²C data to transceiver MCU)
- J1 pin 4 → global label `SCL` (I²C clock to transceiver MCU)
- J1 pin 5 → global label `PTT_N` (push-to-talk, active LOW)
- J1 pin 6 → global label `RX_OUT` (received audio / AFSK out)
- `RF_ANT` label at (190.84, 101.27) → short wire → CMC_CAN L1A (194.92, 101.27)
- CMC_CAN L2A (194.92, 98.73) → GND at (190.84, 98.73)
- CMC_CAN L1B (205.08, 101.27) → `RF_ANT_F` label at (209.16, 101.27)
- CMC_CAN L2B (205.08, 98.73) → GND at (209.16, 98.73)
- `RF_ANT_F` label at (234.92, 101.27) → D_TVS A1 and A2 (junction at 234.92, 101.27)
- D_TVS K (245.08, 100.00) → `RF_ANT_F` label at (250.16, 100.00)
- `RF_ANT_F` label at (274.92, 100.00) → J2 RF pin
- J2 GND pin (285.08, 100.00) → GND power symbol
- `RF_ANT_F` label at (270.00, 116.19) → C_X2Y pin 1 (top)
- C_X2Y pin 2 (270.00, 123.81) → GND power symbol
