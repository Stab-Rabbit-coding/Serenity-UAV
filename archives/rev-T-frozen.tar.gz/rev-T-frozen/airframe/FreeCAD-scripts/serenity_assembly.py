"""
serenity_assembly.py — Serenity UAV full-airframe FreeCAD assembly.
Revision: R1.3 (2026-08-25)

Imports all printed airframe STL components and saves a single assembly
file for review in FreeCAD.

R1.3 Changes (2026-08-25):
    - OUTPUT now targets airframe/freecad/assembly/SerenityAssembly.FCStd
      directly (was airframe/Serenity-Assembled.FCStd). That file was
      previously a hand-built, manually-placed reference (17 objects, several
      stale/duplicated across revisions — e.g. both the current
      nacelle_port_revs and the superseded nacelle_port_revq were present)
      that this script's own docstring cited as the historical SOURCE for
      the baked hull-frame placements. This script is now the maintained,
      single source of truth for that file instead: it already imports every
      current canonical STL (shells, wings, nacelles, splice collars, cargo
      interior accessories, EDF sleeves, nozzle iris, landing gear, dorsal
      fin, bow sensor faceplate) with validated or explicitly-marked-VERIFY
      hull-frame placements. The old hand-built file's content is preserved
      in git history and in the pre-existing `.FCStd.bak2`/`.FCBak` files
      alongside it; nothing is lost by this switch.
    - Added a NACELLE TILT CONFIGURATION block (see NACELLE_TILT_PORT_DEG /
      NACELLE_TILT_STBD_DEG below): each side's nacelle body, EDF stator
      sleeve, EDF aft spider sleeve, and nozzle iris now rotate together as
      one rigid group about that side's tilt pivot (hull +X axis, through
      the nacelle's own CG/pivot station), driven by that one per-side
      degree value. 0 deg = forward/cruise (the stored/baked attitude);
      90 deg = vertical/hover (duct axis vertical, nozzle exit facing -Z/
      down, for lift). The rotation SIGN was reverse-engineered from the old
      hand-built file's own Nacelle_Stbd placement (axis (-1,0,0), angle
      90 deg = -90 deg about hull +X) rather than assumed, and reproduces
      that file's stbd-vertical/port-forward configuration by default.

R1.2 Changes (2026-07-18):
    Initial hull-frame VERIFY-tier placements added for all unpositioned parts:
    - Cargo bay interior mounts (11 parts: doors, hinge retention, cradle, FPV bezel,
      GPS ring, winch motor/spool, DRV8833 tray, servo brackets).
    - Nacelle tilt pylons (2).
    - Nacelle servo brackets (2, fuselage-mounted tilt actuators).
    - Dorsal antenna fin.
    All placements use estimated transforms based on design intent; user will
    visually verify in FreeCAD and correct gross errors before AI precision alignment.
    See airframe/VERIFY_PLACEMENT_CHECKLIST.md for full details and verification tasks.

Run headlessly (no GUI required) with the FreeCAD CONSOLE binary:
    freecadcmd airframe/FreeCAD-scripts/serenity_assembly.py

Or from the Makefile (from airframe/FreeCAD-scripts/):
    make assembly

Or in the FreeCAD GUI: open this file and run it as a macro.

Do NOT run it with plain `python3` (the FreeCAD / Mesh modules are only
importable inside FreeCAD's own interpreter — you'll get a clear error if
you try), and prefer `freecadcmd` over `freecad --background --python`:
the latter starts the GUI event loop, which on some platforms does not exit
cleanly after the script finishes, so the command appears to hang.

Output: <repo>/airframe/freecad/assembly/SerenityAssembly.FCStd
        (overwrites any existing file)

Author:  Steve Griffing, PE(CSE), CISSP-ISSEP, CPP
License: CC BY 4.0 — creativecommons.org/licenses/by/4.0

Coordinate system — hull frame (canonical, CLAUDE.md):
    X  positive port (left)
    Y  positive aft (back)
    Z  positive dorsal (up)
    Origin: SerenityAssembly.FCStd world origin.

R1 COORDINATE STANDARDISATION (2026-06-11):
    The validated placements for the eight primary airframe components
    (four fuselage sections, port/stbd wings, port/stbd nacelles) —
    manually positioned in FreeCAD and extracted from
    airframe/freecad/assembly/SerenityAssembly.FCStd on 2026-06-10 —
    are now BAKED INTO THE STL VERTEX DATA by tools/bake_hull_frame.py.
    Every primary STL in airframe/stls/ is therefore stored directly in
    hull-frame coordinates and is imported here with an IDENTITY
    placement.  The historical placement constants (the former PL_*
    tuples) live on as the single source of truth in
    tools/bake_hull_frame.py COMPONENTS; after regenerating any primary
    STL from its SCAD/Blender source, re-run that tool before use.
    Baked files carry the marker "SerenityUAV HULL-FRAME R1" in their
    binary STL header and are never double-transformed.

    Nacelle STLs are stored in cruise / forward-flight attitude (the
    validated assembly attitude).  Hover tilt is a rotation about the
    nacelle pivot applied downstream, not a stored orientation.

All other component placements (cargo accessories, battery tray,
EDF sleeves, nozzles, pylons, tip caps) are approximations and carry
a VERIFY marker indicating they require confirmation in FreeCAD.

References:
    [1] airframe/freecad/assembly/SerenityAssembly.FCStd — this script's own
        output (R1.3+); pre-bake it was the hand-placed source the R1 bake
        extracted from (see git history for that revision).
    [2] tools/bake_hull_frame.py — canonical bake transforms.
    [3] airframe/openscad/nacelles/nacelle_pod_50mm_tandem.scad
    [4] CLAUDE.md — project standards.
"""

import math
import os

try:
    import FreeCAD as App  # type: ignore[import-not-found]
    import Mesh  # type: ignore[import-not-found]
except ModuleNotFoundError as exc:  # not inside FreeCAD's interpreter
    raise SystemExit(
        "serenity_assembly.py must run inside FreeCAD's Python "
        f"(failed to import {exc.name!r}).\n"
        "  headless CLI:  freecadcmd airframe/FreeCAD-scripts/serenity_assembly.py\n"
        "  or:            make assembly   (from airframe/FreeCAD-scripts/)\n"
        "  GUI:           open this file in FreeCAD and run it as a macro\n"
        "Plain `python3` has no FreeCAD/Mesh module; `freecad --background "
        "--python` may not exit cleanly headless — use freecadcmd."
    )

# FreeCADGui (2026-09-05 fix): plain `freecadcmd` never attaches GUI
# ViewObjects to the objects it creates, so every Mesh::Feature this script
# adds silently defaults to ViewObject is None / Visibility False once a GUI
# does open the file — the tree lists everything but the 3D view is empty.
# Starting a headless GUI session (needs an X/Xvfb display: run this script
# under `xvfb-run -a freecadcmd ...` if $DISPLAY isn't already set) lets us
# force every object's Visibility = True before saving. If FreeCADGui truly
# can't be started (no display at all), fall back to saving without it —
# geometry and placements are unaffected, only the stored visibility flag.
try:
    import FreeCADGui  # type: ignore[import-not-found]

    FreeCADGui.showMainWindow()
    HAVE_GUI = True
except Exception:  # pragma: no cover - depends on display availability
    FreeCADGui = None  # type: ignore[assignment]
    HAVE_GUI = False

# ---------------------------------------------------------------------------
# Path setup — resolved relative to this script file so the script works
# regardless of the current working directory.
# ---------------------------------------------------------------------------
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
AIRFRAME = os.path.abspath(os.path.join(SCRIPT_DIR, ".."))
STL_DIR = os.path.join(AIRFRAME, "stls")
OUTPUT = os.path.join(AIRFRAME, "freecad", "assembly", "SerenityAssembly.FCStd")

# Aircraft datum R2 (plan 2026-10-19-001): the datums and every bake
# translation are READ from tools/hull_datums.py and tools/bake_hull_frame.py
# (numpy-only, importable in FreeCAD's interpreter), never restated here.
import re  # noqa: E402
import sys  # noqa: E402

sys.path.insert(0, os.path.join(os.path.dirname(AIRFRAME), "tools"))
import hull_datums as hd  # noqa: E402

_T5_PARAMS = os.path.join(AIRFRAME, "openscad", "fuselage", "cargo", "cargo_layout_t5_params.scad")


def _scad_param(path, name):
    """Read one numeric assignment `NAME = value;` from a generated SCAD include."""
    with open(path, encoding="utf-8") as fh:
        m = re.search(rf"^{name}\s*=\s*([-+0-9.eE]+)\s*;", fh.read(), re.M)
    if m is None:
        raise SystemExit(f"{name} not found in {path}")
    return float(m.group(1))


# ---------------------------------------------------------------------------
# R1: The eight primary components import with IDENTITY placements.
#
# The validated placement tuples that previously lived here (PL_HEAD_SHELL,
# PL_CARGO_SHELL, PL_MIDDLE_SHELL, PL_REAR_SHELL, PL_WING_PORT, PL_WING_STBD,
# PL_NACELLE_PORT, PL_NACELLE_STBD) were baked into the STL vertex data on
# 2026-06-11 and now reside solely in tools/bake_hull_frame.py COMPONENTS.
# Do not reintroduce per-part transforms here; if a primary STL is
# regenerated from source, re-run tools/bake_hull_frame.py instead.
# ---------------------------------------------------------------------------

# Identity placement shared by all baked hull-frame components.
PL_IDENTITY = (0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _stl(rel_path):
    """Return absolute path under STL_DIR."""
    return os.path.join(STL_DIR, rel_path)


def add_mesh(doc, stl_path, label):
    """
    Import an STL as a Mesh::Feature in doc.

    Returns the new document object, or None if the file is missing.
    The mesh is imported at the origin with identity orientation; call
    place_mesh() afterwards to position it in the hull frame.
    """
    if not os.path.exists(stl_path):
        print(f"[WARN] STL missing, skipping: {stl_path}", flush=True)
        return None
    mesh_data = Mesh.Mesh(stl_path)
    obj = doc.addObject("Mesh::Feature", label)
    obj.Mesh = mesh_data
    obj.Label = label
    return obj


def place_mesh(obj, placement):
    """
    Apply a validated placement tuple to a Mesh::Feature object.

    placement: (Px, Py, Pz, Qx, Qy, Qz, Qw) — position in mm plus unit
    quaternion (Qx, Qy, Qz, Qw) where Qw is the scalar component.
    Does nothing if obj is None (graceful missing-file handling).
    """
    if obj is None:
        return
    px, py, pz, qx, qy, qz, qw = placement
    obj.Placement = App.Placement(App.Vector(px, py, pz), App.Rotation(qx, qy, qz, qw))


def transform_mesh(obj, rows):
    """
    Apply a 4×4 transform matrix directly to the mesh geometry of obj.

    rows: 3-tuple or 4-tuple of 4-element rows:
        [r0c0, r0c1, r0c2, r0c3]
        [r1c0, r1c1, r1c2, r1c3]
        [r2c0, r2c1, r2c2, r2c3]
    The fourth row [0,0,0,1] is appended automatically.

    Uses Mesh.Mesh.transform() which supports det = ±1 matrices (improper
    rotations / reflections).  Retained for VERIFY items that require
    matrix-based fine-positioning; prefer place_mesh() for validated parts.
    """
    if obj is None:
        return
    r = [list(row) for row in rows]
    if len(r) == 3:
        r.append([0.0, 0.0, 0.0, 1.0])
    flat = [v for row in r for v in row]
    m = App.Matrix(*flat)
    # FreeCAD 1.0: obj.Mesh returns an immutable reference — transforming it
    # in place raises "This object is immutable".  Copy, transform the copy,
    # then reassign.  (Previously blocked the assembly save at the first
    # transform_mesh call; FCStd had been stale since the FreeCAD 1.0 upgrade.)
    mesh = obj.Mesh.copy()
    mesh.transform(m)
    obj.Mesh = mesh


# ---------------------------------------------------------------------------
# Nacelle-internal sub-component placement (Rev R1.1, 2026-06-21)
#
# The nacelle pods (nacelle_port_revs.stl / nacelle_stbd_revs.stl) are
# generated from airframe/openscad/nacelles/nacelle_pod_50mm_tandem.scad in
# a part-local frame: local +Z is the duct/bore axis (intake at Z = 0,
# nozzle exit at Z = NACELLE_L = 185.2 mm), local X is the spanwise/pylon
# axis, and local Y is the third (mesh-offset) axis.  This is exactly the
# STL vertex frame that tools/bake_hull_frame.py bakes via
# COMPONENTS['Nacelle_Port'] / ['Nacelle_Stbd'].  Every internal mechanism
# part below (gears, sleeves, nozzle, etc.) is modelled in SCAD using this
# SAME nacelle-local frame, so each part's hull-frame placement is the
# nacelle's own bake transform applied to the part's local offset:
#
#     T_hull = T_nacelle_bake  o  T_subcomponent_local
#
# Both nacelles share one bake rotation quaternion — only the translation
# differs (tools/bake_hull_frame.py COMPONENTS).  Expanding that
# quaternion (Qx, Qy, Qz, Qw) = (+SQ2, 0, 0, -SQ2) with the same
# quat_to_matrix() expansion bake_hull_frame.py uses gives the fixed
# rotation R_BAKE below:
#     hull_x =  x_local
#     hull_y =  z_local
#     hull_z = -y_local
# None of the placements built from this composition have been visually
# validated in FreeCAD — every entry uses transform_mesh() (the VERIFY-
# tier helper), never place_mesh().
# ---------------------------------------------------------------------------

# Fixed nacelle bake rotation — identical for port and stbd (see derivation
# above).  hull = R_BAKE @ local + T_BAKE[side].
R_BAKE = (
    (1.0, 0.0, 0.0),
    (0.0, 0.0, 1.0),
    (0.0, -1.0, 0.0),
)

# Per-side bake translation, READ from tools/bake_hull_frame.py
# COMPONENTS['Nacelle_Port'] / ['Nacelle_Stbd'] (the single source of truth
# for the primary nacelle placement).  Until 2026-10-20 these were copied here
# as R1 numbers.
T_BAKE_50 = {
    "port": hd.bake_translation("Nacelle_Port"),
    "stbd": hd.bake_translation("Nacelle_Stbd"),
}

# NACELLE GENERATION (Rev T6, 2026-10-03).  64 = the QX 64 mm EDF nacelle
# (nacelle_pod_64mm_tandem.scad), the build baseline; 50 keeps the legacy
# 50 mm pod and its internals for reference.  The 64 mm bake translation is
# DERIVED in tools/bake_hull_frame.py ('Nacelle64_*': tilt axis = level spar
# line, pod pad seats on each wing's measured pad face, starboard mirrored
# about X_CL) and READ here.  The R1 copy that used to live here mirrored
# starboard about the old measured plane X -169.241, 1.218 mm off the
# re-centred starboard pod (5149b8ce).
NACELLE_GEN = 64
T_BAKE_64 = {
    "port": hd.bake_translation("Nacelle64_Port"),
    "stbd": hd.bake_translation("Nacelle64_Stbd"),
}
T_BAKE = T_BAKE_64 if NACELLE_GEN == 64 else T_BAKE_50

# Nacelle pylon-side sign, matching nacelle_pod_50mm_tandem.scad's
# PYLON_SIDE override table (Rev R1/nacelle-swap, 2026-06-11):
#   Port nacelle (hull +X): PYLON_SIDE = -1 (inboard/pylon face at local X = -34)
#   Stbd nacelle (hull -X): PYLON_SIDE = +1 (inboard/pylon face at local X = +34)
PYLON_SIDE = {"port": -1.0, "stbd": +1.0}

_IDENTITY3 = ((1.0, 0.0, 0.0), (0.0, 1.0, 0.0), (0.0, 0.0, 1.0))


def _mat3_mul(a, b):
    """Return the 3x3 product a @ b (nested tuples)."""
    return tuple(
        tuple(sum(a[i][k] * b[k][j] for k in range(3)) for j in range(3))
        for i in range(3)
    )


def _mat3_vec(a, v):
    """Return the 3-vector product a @ v."""
    return tuple(sum(a[i][k] * v[k] for k in range(3)) for i in range(3))


def _rot_y(deg):
    """3x3 rotation about Y by deg, matching OpenSCAD's rotate([0, deg, 0])."""
    rad = math.radians(deg)
    c, s = math.cos(rad), math.sin(rad)
    return (
        (c, 0.0, s),
        (0.0, 1.0, 0.0),
        (-s, 0.0, c),
    )


def nacelle_rows(side, r_local, t_local):
    """
    Compose a nacelle sub-component's local placement into transform_mesh()
    rows in hull frame.

    side: "port" or "stbd".
    r_local: 3x3 rotation (nested tuples) of the part within the nacelle's
        own local frame; use _IDENTITY3 if the part's modelled axes
        already align with the nacelle frame.
    t_local: (x, y, z) translation in mm of the part's origin within the
        nacelle's own local frame.
    """
    r_total = _mat3_mul(R_BAKE, r_local)
    t_rot = _mat3_vec(R_BAKE, t_local)
    t_bake = T_BAKE[side]
    t_total = tuple(t_rot[i] + t_bake[i] for i in range(3))
    return [
        [r_total[0][0], r_total[0][1], r_total[0][2], t_total[0]],
        [r_total[1][0], r_total[1][1], r_total[1][2], t_total[1]],
        [r_total[2][0], r_total[2][1], r_total[2][2], t_total[2]],
    ]


# Nacelle local-frame Z stations, mm (nacelle_pod_50mm_tandem.scad):
#   intake Z=0 .. STATOR_SLV_Z_START=90.0 .. AFT_SLV_Z_START=122.5 ..
#   NOZZLE_RING_Z(=CROWN_Z)=166.25 .. NACELLE_L=185.2 (nozzle exit).
#   PIVOT_Z is the spar-crank / CG station, inside the sleeve span.
# Hoisted to module level (was local to assemble()) so nacelle_pivot_hull()
# can use PIVOT_Z; kept together since they share one source (the SCAD).
STATOR_SLV_Z_START = 90.0
AFT_SLV_Z_START = 122.5
# PIVOT_Z — the tilt pivot sits at the rotating assembly's CG, so this is an
# OUTPUT of a mass roll-up and not a chosen number.  `tools/nacelle_mass_cg.py`
# is the authority for it; this constant must track that tool's result and the
# SCAD's own PIVOT_Z, or the assembly tilts the nacelle about the wrong station.
#
# UPDATED 2026-09-06 (Rev T4c/T4d): 111.5 -> 107.5.  Raised as LG-33 by the
# landing-gear session, which found this file still carrying the 2026-07-19
# figure while the measured CG had moved twice underneath it.
#
# The history is worth keeping, because every move was a correction rather than
# a redesign, and the direction was not always the same:
#   111.5  2026-07-19, from an ESTIMATED header table that put the pod shell and
#          both sleeves at 130 g combined
#   105.8  the pod MEASURED, solid, at 285 g — the CG moved FORWARD
#   113.8  the pod hollowed with a forward-biased wall (Rev T4b), plus the
#          in-nacelle harness, which no earlier roll-up had counted at all
#   107.5  the ESCs sited where they actually FIT (measured bay centroid Z 104)
#          instead of at plan 003 KTD8's assumed Z 150.6 — a station no board
#          can occupy, so that lever never existed
PIVOT_Z = 107.5  # pivot station = full-assembly nacelle CG; see the note above
NOZZLE_RING_Z = 166.25  # nozzle ring station (nozzle placement)
# 64 mm (Rev T6): PIVOT_Z converged at 109.7 (tools/nacelle_mass_cg_64.py,
# measured CG 109.67); nozzle ring at 187.86 (nacelle_pod_64mm_tandem.scad).
if NACELLE_GEN == 64:
    PIVOT_Z = 109.7
    NOZZLE_RING_Z = 187.86


# ---------------------------------------------------------------------------
# NACELLE TILT CONFIGURATION (R1.3, 2026-08-25)
#
# Set each side's tilt angle here. 0 deg = forward/cruise (the stored/baked
# attitude every nacelle STL and every nacelle_rows() placement below is
# modelled in). 90 deg = vertical/hover: duct axis vertical, nozzle exit
# (the local +Z end, NACELLE_L = 185.2 mm) facing hull -Z (down), pushing
# air down for lift.
#
# The rotation SIGN below (TILT_SIGN = -1, i.e. rotate -tilt_deg about hull
# +X) was reverse-engineered from the pre-R1.3 hand-built
# airframe/freecad/assembly/SerenityAssembly.FCStd, whose Nacelle_Stbd
# object carried Placement.Rotation = (axis (-1,0,0), angle 90 deg) — the
# same rotation as (axis (1,0,0), angle -90 deg). Reproduced here as the
# STBD default so this script's default output matches that file's own
# configuration (stbd vertical, port forward) rather than an assumed
# convention. Confirmed to point the nozzle exit down (not up) via
# R_BAKE's own local->hull mapping (hull_y = local_z at cruise; a -90 deg
# rotation about hull +X sends hull_z' = -hull_y = -local_z, so the +Z/exit
# end ends up at negative hull Z).
NACELLE_TILT_PORT_DEG = 0.0     # port: forward / cruise
NACELLE_TILT_STBD_DEG = 90.0    # stbd: vertical / hover
NACELLE_TILT_DEG = {"port": NACELLE_TILT_PORT_DEG, "stbd": NACELLE_TILT_STBD_DEG}
TILT_SIGN = -1.0


def nacelle_pivot_hull(side):
    """Hull-frame tilt pivot for `side`: local (0, 0, PIVOT_Z) through the
    same R_BAKE/T_BAKE composition nacelle_rows() uses for every other
    nacelle-local point. PIVOT_Z (the spar-crank / nacelle CG station) is
    defined in the Main assembly section below and read here as a module
    global set before assemble() runs."""
    off = _mat3_vec(R_BAKE, (0.0, 0.0, PIVOT_Z))
    t_bake = T_BAKE[side]
    return tuple(t_bake[i] + off[i] for i in range(3))


def tilt_rotation(side):
    """FreeCAD Rotation for this side's configured tilt, about hull +X."""
    return App.Rotation(App.Vector(1.0, 0.0, 0.0), TILT_SIGN * NACELLE_TILT_DEG[side])


def tilt_placement(side):
    """Placement rotating a hull-frame-native (cruise/identity) mesh by this
    side's configured tilt about its own pivot -- identity when the
    configured tilt is 0 deg, so untilted sides are visually unchanged."""
    piv = App.Vector(*nacelle_pivot_hull(side))
    rot = tilt_rotation(side)
    base = piv - rot.multVec(piv)
    return App.Placement(base, rot)


def nozzle_iris_stl(side):
    """Nozzle iris STL matching this side's configured tilt.

    Rev T3 (2026-08-09, airframe/wings-nacelles/WBS.md SS1.1.3.1) exposed
    `FLAP_PHI` in nacelle_nozzle_iris.scad specifically so each published
    assembly STL is reproducible from source at a given flap angle, and the
    two committed renders are the two endpoints: nacelle_nozzle_iris-
    closed.stl (FLAP_PHI = PHI_CLOSED, petals shut, 0 deg tilt) and
    nacelle_nozzle_iris-open.stl (FLAP_PHI = PHI_OPEN, petals full open,
    90 deg tilt). This picks the nearer endpoint by a 45 deg threshold --
    it is NOT a continuous interpolation. A tilt strictly between 0 and 90
    deg would need a fresh `openscad -D 'FLAP_PHI=<computed>'` render (the
    SCAD supports it; this script does not invoke openscad) rather than a
    third discrete asset, since the flap angle is a continuous function of
    tilt, not a third fixed pose.

    The single-file nacelle_nozzle_iris.stl this script imported before
    R1.3 predates Rev T3 (2026-07-19 vs the 2026-08-09 shingle fix) and is
    stale -- superseded by the closed/open pair, not reintroduced here.
    """
    return _stl(
        "nacelles/nozzles/nacelle_nozzle_iris-open.stl"
        if NACELLE_TILT_DEG[side] >= 45.0
        else "nacelles/nozzles/nacelle_nozzle_iris-closed.stl"
    )


def apply_tilt_to_rows(rows, side):
    """Compose this side's configured tilt (about its own pivot) onto
    nacelle_rows()'s local->hull-cruise transform, for transform_mesh()
    callers (the EDF sleeves and nozzle iris -- rigidly attached to the
    nacelle body, so they must tilt with it as one group)."""
    flat = [v for row in rows for v in row]
    base_m = App.Matrix(*flat, 0.0, 0.0, 0.0, 1.0)
    total = tilt_placement(side).multiply(App.Placement(base_m))
    tm = total.Matrix
    return [
        [tm.A11, tm.A12, tm.A13, tm.A14],
        [tm.A21, tm.A22, tm.A23, tm.A24],
        [tm.A31, tm.A32, tm.A33, tm.A34],
    ]


# ---------------------------------------------------------------------------
# Main assembly
# ---------------------------------------------------------------------------


def assemble():
    """Build the Serenity UAV full-airframe assembly document."""

    print("[assembly] Creating FreeCAD document ...", flush=True)
    doc = App.newDocument("SerenityAssembly")

    # -------------------------------------------------------------------
    # FUSELAGE SECTIONS -- two-section SLS hull (2026-11-01)
    # Forward = head+cargo in one piece (tools/merge_head_cargo_shell.py,
    # commit d92c4f14); aft = middle+rear in one piece
    # (tools/merge_middle_rear_shell.py).  Both seams are blended lofts
    # checked against the QMx blueprints / Henning renders
    # (docs/SLS_PRINT_ORIENTATION.md section 6).  The only hull joint left is
    # the cargo/middle splice collar.  The separate head/cargo/middle/rear
    # shells and the head/cargo + middle/rear collars are RETIRED print
    # articles (tools/sls_retired_parts.py).  All parts are aircraft frame
    # R2 and import at identity.
    # -------------------------------------------------------------------
    print("[assembly] Fuselage sections (2-section hull) ...", flush=True)

    fwd = add_mesh(doc, _stl("fuselage/head_cargo_shell24_2mm_merged.stl"),
                   "Hull_Forward_HeadCargo")
    place_mesh(fwd, PL_IDENTITY)

    aft = add_mesh(doc, _stl("fuselage/middle_rear_shell24_2mm_merged.stl"),
                   "Hull_Aft_MiddleRear")
    place_mesh(aft, PL_IDENTITY)

    # Internal cargo/middle splice collar -- the one remaining hull joint
    # (2-wall bonded double-lap + anti-ovalisation ring; docs/structural_analysis.md
    # section 7.4).  The step at this joint is canonical (raised ring aft of
    # the cargo hold), so the joint stays.
    splice2 = add_mesh(
        doc,
        _stl("fuselage/cargo_middle_splice_collar.stl"),
        "Cargo_Middle_Splice_Collar",
    )
    place_mesh(splice2, PL_IDENTITY)

    # -------------------------------------------------------------------
    # MAIN BATTERY -- twin flat Tattu 6S 2200 packs in the head
    # (tools/twin_head_pack_fit.py, docs/BATTERY_TRIM_ENDURANCE_OPTIONS.md).
    # Replaces the retired cargo Battery_Cradle.  The tray STL is aircraft
    # frame; the sled and gate STLs are part-local, placed exactly as
    # twin_pack_tray.scad placed_sleds() / placed_gate() do, from the
    # generated twin_pack_tray_params.scad (single source).
    # -------------------------------------------------------------------
    print("[assembly] Twin battery tray, sleds, gate ...", flush=True)
    tp = os.path.join(AIRFRAME, "openscad", "fuselage", "twin_pack_tray_params.scad")
    tz0 = _scad_param(tp, "TRAY_ZC") - _scad_param(tp, "TRAY_H") / 2.0   # band floor
    ty0 = _scad_param(tp, "TRAY_Y0")
    lane_x = _scad_param(tp, "LANE_X")
    sled_len = _scad_param(tp, "CELL_L") + 2.0 * _scad_param(tp, "SLED_LIP")
    add_mesh(doc, _stl("fuselage/head/twin_pack_tray.stl"), "Twin_Pack_Tray")
    for side, sx in (("Port", 1.0), ("Stbd", -1.0)):   # +X = port (datum R2)
        sled = add_mesh(doc, _stl("fuselage/head/twin_pack_sled.stl"), f"Twin_Pack_Sled_{side}")
        if sled is not None:
            place_mesh(sled, (sx * lane_x, ty0, tz0, 0.0, 0.0, 0.0, 1.0))
    gate = add_mesh(doc, _stl("fuselage/head/twin_pack_gate.stl"), "Twin_Pack_Gate")
    if gate is not None:
        # TAB_L - (TAB_L - 0.5) = 0.5 mm, as in twin_pack_tray.scad placed_gate()
        place_mesh(gate, (0.0, ty0 + sled_len + 0.5, tz0, 0.0, 0.0, 0.0, 1.0))

    # Landing gear — Rev R6 canonical articulated legs (2026-07-21; split
    # into 1.5in/3.0in belly-clearance variants 2026-07-23).
    #
    # ** THE ACTIVE VARIANT IS NOW THE 3.0 in LEG (LG-31, 2026-09-06). **
    # It was the 1.5 in compound, and that configuration struck the ground with
    # the nozzle on every vertical takeoff and landing.  See
    # docs/plans/2026-09-06-001-fix-minimum-safe-landing-gear-leg-length-plan.md
    # and docs/LANDING_GEAR_ANALYSIS.md §4.8: the governing case is TOUCHDOWN
    # ROLL, not static clearance, because each nozzle sits ~73 mm outboard of its
    # own foot line, so roll costs 1.30 mm/deg (pitch and a four-feet-planted
    # slope cost nothing — the feet define the plane).  Minimum safe belly
    # clearance is 74.41 mm at the 5 deg attitude case with the built 40 mm
    # flaps; the 3.0 in leg gives 80.0 mm.
    #
    # Leg length is very nearly free, which was not previously understood: since
    # the 2026-08-09 hip-recess fix BOTH variants run R_h = 80 mm, so they carry
    # identical wire loads (39.7/79.4 g) and `M = 2.P.r` has no R_h term.  The
    # older "1.5 in runs hotter" note in LANDING_GEAR_ANALYSIS.md was four weeks
    # stale when it was quoted; it has been corrected there.
    #
    # The 1.5 in compound (canonical_leg_r6_1_5in.scad) is RETIRED to a non-flight
    # variant — kept for bench/handling use, not wired in here.  Both are already
    # in hull frame at the canonical QMx Sheet 5 bay stations (identity
    # placement).  The prior Thingiverse-derived feet_x_4/legs parts are archived
    # (ARCHIVE_INDEX.md).
    gear = add_mesh(
        doc,
        _stl("fuselage/landing-gear/lg_r6_3_0in_hull_legs.stl"),
        "Landing_Gear_R6",
    )
    place_mesh(gear, PL_IDENTITY)

    # 2026-10-31 refresh: the four CONFORMING 3.0 in gear bays (BHD-02,
    # tools/generate_lg_bays.py) are separate printed parts written in hull
    # frame (identity) and were never imported.  Port and starboard are
    # distinct MIRROR prints.  The *_print.stl siblings are the same parts
    # re-oriented for the bed, and lg_a1b_housing_*.stl is a CUTTING envelope
    # for merge_cargo_interior.py, not a part -- neither is placed here.
    for corner in ("fore-port", "fore-stbd", "aft-port", "aft-stbd"):
        add_mesh(doc, _stl(f"fuselage/landing-gear/lg_r6_3_0in_bay_{corner}.stl"),
                 "LG_Bay_" + corner.replace("-", "_").title())

    # -------------------------------------------------------------------
    # CARGO BAY SUB-ASSEMBLY
    # R1 coordinate audit (2026-06-11):
    #   - cargo_door_port/stbd.stl were generated 2026-06-01 from the
    #     pre-repair Rev-O shell pose and do NOT align with the
    #     validated (now baked) Cargo_Shell orientation.  Regenerate
    #     them from the baked shell via generate_cargo_doors.py, then
    #     verify belly (−Z) orientation — tracked in TODO.md §1.1.1.2.1.
    #   - The eight cargo mounts are part-local prints centred on their
    #     own origins; they have never been positioned in hull frame.
    # VERIFY: all eleven accessories below require hull-frame placement
    # validation against the baked Cargo_Shell.
    # -------------------------------------------------------------------
    print("[assembly] Cargo bay ...", flush=True)

    # -------------------------------------------------------------------
    # CARGO BAY INTERIOR MOUNTS
    # VERIFY: all parts imported at origin (identity placement).
    # User will manually position these in FreeCAD, then AI extracts
    # final placements from the corrected file for precision alignment.
    # See VERIFY_PLACEMENT_CHECKLIST.md §1 for positioning guidance.
    # -------------------------------------------------------------------
    print("[assembly] Cargo bay interior mounts ...", flush=True)

    # Cargo doors — baked into hull frame (already at identity).
    add_mesh(doc, _stl("fuselage/cargo/cargo_door_port.stl"), "Cargo_Door_Port")
    add_mesh(doc, _stl("fuselage/cargo/cargo_door_stbd.stl"), "Cargo_Door_Stbd")

    # Hinge retention blocks — baked into hull frame (already at identity).
    add_mesh(doc, _stl("fuselage/cargo/cargo_hinge_retention.stl"), "Cargo_Hinge_Retention")

    # Cargo accessories — VERIFY placements (2026-09-05 fix).
    # These previously imported at origin/identity with no place_mesh() call
    # at all — since world origin (0,0,0) sits inside Nacelle_Port's own
    # bounding box (+4..+86, -58..+108, +21..+105) and Wing_Port's (-93..+5,
    # -7..+122, +48..+77), every one of these "unplaced" parts rendered
    # stacked on top of the port wing/nacelle instead of inside the cargo
    # bay — this is what the owner spotted after the visibility fix above.
    # None of these parts has a .scad source (VERIFY_PLACEMENT_CHECKLIST.md
    # §1 confirms), so there is no documented local-axis convention to
    # derive a correct orientation from; the estimates below are position-
    # only (identity rotation), taken from that checklist's own Y/Z
    # estimates but re-centred on the CARGO SECTION'S ACTUAL hull-frame
    # centreline (X ~ -170, the mean of Cargo_Shell's measured bbox
    # -266.97..-72.68 — the checklist's original "X ~ -170" text was already
    # centreline-correct; only the never-applied code was missing). Rough
    # placement only — orientation and fine position still need the
    # checklist's own visual-fit pass in FreeCAD.
    CARGO_X_CL = hd.X_CL  # aircraft centreline (R1 -170.0)

    # cargo_cradle_autolatch retired 2026-10-19 (weight pass, BOM qty 0): the
    # stowed payload is held by the winch ratchet over the latched doors
    # (docs/CARGO_WINCH_SPECIFICATION.md state table).

    fpv = add_mesh(doc, _stl("fuselage/cargo/cargo_fpv_bezel.stl"), "Cargo_FPV_Bezel")
    place_mesh(fpv, (CARGO_X_CL, 365.7, 240.0, 0.0, 0.0, 0.0, 1.0))  # R2; R1 Y 60, Z 160

    gps = add_mesh(doc, _stl("fuselage/cargo/cargo_gps_retention_ring.stl"), "Cargo_GPS_Ring")
    place_mesh(gps, (CARGO_X_CL, 325.7, 241.5, 0.0, 0.0, 0.0, 1.0))  # R2; R1 Y 20, Z 161.5

    # 2026-10-19 placement audit (tools/placement_audit.py): the N20 winch
    # mount + spool (scrubbed 2026-07-27, airframe/fuselage-mid/WBS.md) and the
    # DRV8833 tray (retired 2026-09-21, docs/CARGO_DOOR_GATEWAY_SPEC.md) are no
    # longer placed -- a retired part in the assembly pollutes the joint census
    # and the mass ledger.  The current winch (SPT5425LV + pedestals + spool R2)
    # has no hull-frame STLs yet (WBS LEDGER-GAPS).

    # Door latch brackets and the cargo-door gateway tray: generated in hull
    # frame from cargo_layout_t5_params.scad (door_latch_mechanism.scad,
    # gateway_door_tray.scad) -- identity placement.  They were never added.
    add_mesh(doc, _stl("fuselage/cargo/door_latch_bracket_port.stl"), "Door_Latch_Bracket_Port")
    add_mesh(doc, _stl("fuselage/cargo/door_latch_bracket_stbd.stl"), "Door_Latch_Bracket_Stbd")
    # DOOR-REWORK (2026-10-26): the bell-crank is its own part (it turns on the pivot pin).
    add_mesh(doc, _stl("fuselage/cargo/door_latch_crank_port.stl"), "Door_Latch_Crank_Port")
    add_mesh(doc, _stl("fuselage/cargo/door_latch_crank_stbd.stl"), "Door_Latch_Crank_Stbd")
    add_mesh(doc, _stl("fuselage/cargo/gateway_door_tray.stl"), "Gateway_Door_Tray")

    door_servo = add_mesh(
        doc, _stl("fuselage/cargo/cargo_door_servo_bracket.stl"), "Cargo_Door_Servo_Bracket"
    )
    place_mesh(door_servo, (44.85, 390.7, 190.0, 0.0, 0.0, 0.0, 1.0))  # R2; R1 (-125, 85, 110)

    release_servo = add_mesh(
        doc, _stl("fuselage/cargo/cargo_release_servo_bracket.stl"), "Cargo_Release_Servo_Bracket"
    )
    place_mesh(release_servo, (-40.15, 390.7, 190.0, 0.0, 0.0, 0.0, 1.0))  # R2; R1 (-210, 85, 110)

    # -------------------------------------------------------------------
    # FUSELAGE ACCESSORIES (battery tray and belly panel) — VERIFY (2026-09-05
    # fix). Same never-applied-placement bug as the cargo accessories above:
    # both parts imported at world origin, landing inside Nacelle_Port/
    # Wing_Port's bounding boxes instead of the cargo bay's keel.
    #
    # Unlike the cargo accessories, both of these DO have a documented
    # part-local axis convention in their own .scad header (battery_tray.scad
    # line 97, belly_panel.scad — same convention, part-local origin):
    #   local X — longitudinal, +X = forward (toward nose)  => hull -Y
    #   local Y — vertical,     +Y = up                     => hull +Z
    #   local Z — lateral,      +Z = toward port             => hull +X
    # That mapping (hull_x=local_z, hull_y=-local_x, hull_z=local_y) is an
    # IMPROPER rotation (det = -1, a mirror) — transform_mesh() supports this
    # per its own docstring, but a mirror flips any left/right-asymmetric
    # feature. belly_panel is stated port/stbd-symmetric (safe to mirror);
    # battery_tray.scad's own detent screw bores are cut through only "the
    # stbd outer wall" (line 236) despite the header's generic +Z=port
    # convention, an inconsistency already flagged in that file's own Rev R1
    # note (conflicting cargo-vs-middle-section placement, never reconciled).
    # Applying the documented convention as-is may put those bores on the
    # wrong (port) wall — flag for visual confirmation in FreeCAD, per this
    # checklist's own established VERIFY workflow.
    #
    # Position: centred on the cargo/middle centreline (X ~ -170, see
    # CARGO_X_CL above) and placed within the cargo section per
    # battery_tray.scad's own current operative note ("place this tray in
    # the CARGO section, on the cargo keel segment") rather than the older,
    # explicitly-superseded middle-section note in the same header — Y
    # centred on Cargo_Shell's own Y span (-69.5..+129, mean +29.75) so the
    # 154 mm-long tray fits inside it; Z near the belly floor (Cargo_Shell
    # Z min ~ 0).
    # Rev T5 (2026-09-15): the keel-rail tray and its belly panel are
    # SUPERSEDED by Battery_Cradle (roof-hung, cargo roof band, imported in
    # the Rev T5 block below; docs/BATTERY_MOUNT.md Rev T5).  Kept, gated off.
    LEGACY_BATTERY_TRAY = False
    if LEGACY_BATTERY_TRAY:
        battery_tray = add_mesh(doc, _stl("fuselage/battery_tray.stl"), "Battery_Tray")
        transform_mesh(
            battery_tray,
            (
                (0.0, 0.0, 1.0, CARGO_X_CL - 31.0),  # hull_x = local_z + tx (tray Z half-width 31)
                (-1.0, 0.0, 0.0, 412.45),  # hull_y = -local_x + ty (R2; R1 106.75)
                (0.0, 1.0, 0.0, 82.0),  # hull_z = local_y + tz, ~2 mm off the floor (R1 2.0)
            ),
        )

        belly_panel = add_mesh(doc, _stl("fuselage/belly_panel.stl"), "Belly_Panel")
        transform_mesh(
            belly_panel,
            (
                (0.0, 0.0, 1.0, CARGO_X_CL - 32.5),  # panel is 65 mm wide, half-width 32.5
                (-1.0, 0.0, 0.0, 412.45),  # same X/Y centre as Battery_Tray (R2; R1 106.75)
                (0.0, 1.0, 0.0, hd.BELLY_Z),  # flush with the belly below the tray (R1 Z 0)
            ),
        )

    # -------------------------------------------------------------------
    # WINGS
    # R1: baked hull-frame STLs — identity placement.
    # -------------------------------------------------------------------
    print("[assembly] Wings ...", flush=True)

    port_wing = add_mesh(doc, _stl("wings/wing_port_s1223_revo.stl"), "Wing_Port")
    place_mesh(port_wing, PL_IDENTITY)

    stbd_wing = add_mesh(doc, _stl("wings/wing_stbd_s1223_revo.stl"), "Wing_Stbd")
    place_mesh(stbd_wing, PL_IDENTITY)

    # 2026-10-31 refresh: Rev T1c bonded wing-root moment flanges (WA-R1b,
    # generate_wing_root_flange.py; BOM PRINT-WING-ROOT-FLANGE).  Baked to the
    # aircraft frame (R2 header marker), identity placement; never imported.
    for side in ("port", "stbd"):
        add_mesh(doc, _stl(f"fuselage/wing_root_flange_{side}.stl"),
                 f"Wing_Root_Flange_{side.title()}")

    # -------------------------------------------------------------------
    # NACELLE TILT BRACKETS (INTEGRATED INTO WINGS)
    # INTEGRATION (2026-07-18): The separate pylon component
    # (wing_nacelle_pylon_revo.scad) is now superseded. Tilt bracket
    # functionality is integrated into the wing tip geometry
    # (wings_s1223_revo.scad Rev R1a). See VERIFY_PLACEMENT_CHECKLIST.md.
    # Standalone pylon STLs archived to airframe/archive/stls/nacelles/.
    # No separate pylon import needed.
    # -------------------------------------------------------------------
    print("[assembly] Nacelle tilt brackets (integrated into wings) ...", flush=True)

    # -------------------------------------------------------------------
    # NACELLE PODS (forward-flight / cruise configuration)
    # R1: baked hull-frame STLs — identity placement; stored attitude is
    # cruise.  Hover is a downstream rotation about the tilt pivot.
    #
    # nacelle_port_revs.stl: hull +X (port side), SWIRL_DIR=-1 (CCW),
    #   harness conduit exits -X (inboard) face.
    # nacelle_stbd_revs.stl: hull -X (starboard side), SWIRL_DIR=+1 (CW),
    #   harness conduit exits +X (inboard) face.
    # Labels corrected Rev R1/nacelle-swap (2026-06-11) after FreeCAD
    # layout inspection confirmed the original naming was inverted.
    # -------------------------------------------------------------------
    print("[assembly] Nacelle pods ...", flush=True)

    # PL_IDENTITY at 0 deg tilt (tilt_placement() reduces to identity there),
    # rotated about the per-side pivot by NACELLE_TILT_PORT_DEG/STBD_DEG
    # otherwise -- see the NACELLE TILT CONFIGURATION block above.
    pod_tag = "64mm" if NACELLE_GEN == 64 else "revs"
    port_nac = add_mesh(doc, _stl(f"nacelles/nacelle_port_{pod_tag}.stl"), "Nacelle_Port")
    if port_nac is not None:
        port_nac.Placement = tilt_placement("port")

    stbd_nac = add_mesh(doc, _stl(f"nacelles/nacelle_stbd_{pod_tag}.stl"), "Nacelle_Stbd")
    if stbd_nac is not None:
        stbd_nac.Placement = tilt_placement("stbd")

    # -------------------------------------------------------------------
    # NACELLE INTERNAL COMPONENTS (gear train, nozzle iris, EDF sleeves)
    # VERIFY: none of these sub-component placements have been validated
    # in FreeCAD; every entry below uses transform_mesh() via the
    # nacelle_rows() helper (see derivation comment above add_mesh()).
    # Station constants are taken from
    # airframe/openscad/nacelles/nacelle_pod_50mm_tandem.scad — the
    # canonical gear-train + iris-nozzle nacelle variant (TODO.md §1.1.3
    # build-task list references only this variant; the parallel
    # no-gear-train "_simple"/"_straight" variant is not on the tracked
    # build path and is NOT placed here).
    # -------------------------------------------------------------------
    print(
        "[assembly] Nacelle internal components (gear train, nozzle, sleeves) ...",
        flush=True,
    )

    # Nacelle local-frame Z stations -- module-level (STATOR_SLV_Z_START,
    # AFT_SLV_Z_START, PIVOT_Z, NOZZLE_RING_Z; see their definitions above,
    # near the NACELLE TILT CONFIGURATION block -- PIVOT_Z is hoisted there
    # because nacelle_pivot_hull() needs it before assemble() runs).

    if NACELLE_GEN == 64:
        # 64 mm tilt joint (baked in hull frame, tools/prep_nacelle_64_bake.py
        # + bake_hull_frame.py): the trunnion is bolted to the pod and tilts
        # with it; the tilt pinion rides the WING shaft and does not tilt.
        for side in ("port", "stbd"):
            label = "Port" if side == "port" else "Stbd"
            tr = add_mesh(doc, _stl(f"nacelles/nacelle_trunnion_64mm_{side}.stl"),
                          f"Nacelle_{label}_Trunnion")
            if tr is not None:
                tr.Placement = tilt_placement(side)
            add_mesh(doc, _stl(f"wings/wing_tilt_pinion_{side}.stl"),
                     f"Wing_{label}_Tilt_Pinion")
        # COVERAGE GAPS (joint census, plan 2026-10-03-002 R1): the 50 mm
        # stator / aft-spider sleeves and the 50 mm nozzle iris do not fit the
        # 64 mm bore and have no 64 mm counterparts yet (WBS NAC-64-GEOM-01,
        # nozzle per plan 2026-09-28-001).  Reported, never placed at 50 mm
        # stations.
        for gap in ("64 mm stator sleeve", "64 mm aft spider sleeve",
                    "64 mm nozzle iris", "64 mm EDF rotors/motors", "70 A ESCs"):
            print(f"[assembly] COVERAGE GAP: {gap} — no placed solid", flush=True)

    for side in (("port", "stbd") if NACELLE_GEN == 50 else ()):
        label = "Port" if side == "port" else "Stbd"

        # ── EDF1/EDF2 inter-stage stator sleeve ──────────────────────────
        # edf_stator_sleeve.scad: part-local frame is coaxial with the
        # nacelle duct (own local +Z = nacelle local +Z; sleeve forward
        # face at its own Z = 0) — identity rotation, translate to the
        # sleeve's forward-face station.
        sleeve = add_mesh(
            doc,
            _stl("nacelles/edf_stator_sleeve.stl"),
            f"Nacelle_{label}_Stator_Sleeve",
        )
        transform_mesh(
            sleeve,
            apply_tilt_to_rows(
                nacelle_rows(side, _IDENTITY3, (0.0, 0.0, STATOR_SLV_Z_START)), side
            ),
        )

        # ── EDF2 aft spider sleeve ────────────────────────────────────────
        # edf_aft_spider_sleeve.scad: same coaxial convention, forward
        # face at nacelle Z = AFT_SLV_Z_START.
        aft_sleeve = add_mesh(
            doc,
            _stl("nacelles/edf_aft_spider_sleeve.stl"),
            f"Nacelle_{label}_Aft_Spider_Sleeve",
        )
        transform_mesh(
            aft_sleeve,
            apply_tilt_to_rows(
                nacelle_rows(side, _IDENTITY3, (0.0, 0.0, AFT_SLV_Z_START)), side
            ),
        )

        # ── Nozzle pushrod drive — Rev T (Option B) ───────────────────────
        # Rev T (2026-07-18, docs/NOZZLE_DRIVE_TRADE.md Option B; user
        # decision 2026-07-18): the ENTIRE tilt-to-nozzle GEAR train is
        # DELETED — Drive Pinion A, the Nozzle Drive Pinion, the bevel
        # housing, the bevel pair, and the fixed sector gear (and, earlier,
        # the compound idler).  Those five STL placements are removed; the
        # parts are archived under airframe/archive/.  The nozzle is now
        # driven by a PUSHROD/BELLCRANK: a spar crank clamps the rotating
        # tilt spar and a ball-link pushrod strokes the unison-ring lever
        # ear (nacelle_nozzle_pushrod.scad + the ring lever in
        # nacelle_nozzle_iris.scad).
        #
        # FIRST-PASS PLACEMENT — VERIFY (spatial RSSR linkage, WBS §1.1.3):
        # the spar crank sits on the pivot axis (Y=0, Z=PIVOT_Z), clamp bore
        # along local X (the spar/tilt axis) — hence the 90 deg Y-rotation,
        # as the old Pinion A used.  The exact crank clock angle, pushrod
        # length, and ring-lever pose that give a monotonic 0..90 deg tilt ->
        # 0..23.75 deg ring map are NOT yet solved; the pushrod link itself
        # (COTS ball-link rod) is intentionally not placed here until that
        # synthesis is closed.
        # SUPERSEDED 2026-07-20 + ARCHIVED (ARCHIVE_INDEX.md): the spar-CLAMP
        # crank cannot actuate the nozzle — the spar is keyed to the nacelle, so
        # a crank on it shares the ring's rotating frame (zero relative motion).
        # Replaced by a WING-REFERENCED sync gear + geared bellcrank (hybrid A+B,
        # docs/NOZZLE_DRIVE_TRADE.md "DECISION AMENDMENT"; overlay
        # port_tilt_spar_assembly.scad §6).
        # RETIRED 2026-09-28 (servo drive, docs/NOZZLE_DRIVE_TRADE.md
        # "DECISION AMENDMENT — servo drive (2026-09-28)"): that sync-gear
        # drive could not be packaged either (0.0 mm axial room for the sun; pinion vs tilt-drive-shaft
        # collision; ring over-travel past 90 deg tilt).  Both
        # nacelle_nozzle_sync_gears.scad and nacelle_nozzle_pushrod.scad are
        # archived.  The nozzle is now servo-driven from inside the pod; the
        # servo mount is placed here once
        # docs/plans/2026-09-28-001-feat-nacelle-nozzle-servo-drive-plan.md U4
        # produces it.  Nothing is placed for the nozzle drive until then.

        # ── Nozzle iris assembly ──────────────────────────────────────────
        # nacelle_nozzle_iris-{closed,open}.stl are the combined renders
        # (cam-only unison ring + outer housing + 8 shingled master/seal
        # flaps, Rev T3) from nacelle_nozzle_iris.scad, one per petal-state
        # endpoint -- see nozzle_iris_stl() above for the tilt->file
        # selection and its "not continuous" caveat. Rev T: the ring is a
        # plain CAM disc (no gear teeth), servo-driven via a pull-only link
        # since 2026-09-28; the housing has no drive-pinion relief and is rotationally
        # symmetric, so identity rotation is fine. Translate to
        # NOZZLE_RING_Z.
        # History: Rev R1 compound idler (2026-06-22) -> Rev S1 internal ring
        # gear (2026-07-07) -> Rev T pushrod/cam-only drive (2026-07-18,
        # Option B) -> Rev T3 shingled flaps (2026-08-09); the entire gear
        # train is deleted and archived — see ARCHIVE_INDEX.md and
        # docs/NOZZLE_DRIVE_TRADE.md.
        nozzle = add_mesh(
            doc,
            nozzle_iris_stl(side),
            f"Nacelle_{label}_Nozzle_Iris",
        )
        transform_mesh(
            nozzle,
            apply_tilt_to_rows(
                nacelle_rows(side, _IDENTITY3, (0.0, 0.0, NOZZLE_RING_Z)), side
            ),
        )

        # Tip cap (outboard X-face end cap) — ARCHIVED 2026-06-22, legacy
        # part, no longer needed.  STLs moved to airframe/archive/stls/
        # nacelles/; see ARCHIVE_INDEX.md.  (Previously a best-guess VERIFY
        # placeholder with no active SCAD source — see TODO.md §1.1.3
        # history.)

    # -------------------------------------------------------------------
    # NACELLE SERVO BRACKETS — Fuselage-mounted tilt-control actuators
    # VERIFY: all parts imported at origin (identity placement).
    # User will manually position these in FreeCAD, then AI extracts
    # final placements from the corrected file.
    # See VERIFY_PLACEMENT_CHECKLIST.md §4 for positioning guidance.
    # -------------------------------------------------------------------
    print("[assembly] Nacelle servo brackets (fuselage-mounted tilt actuators) ...", flush=True)

    # Rev T5b (2026-09-15, docs/TILT_ACTUATOR_SELECTION.md): the DS3225 saddle
    # brackets are SUPERSEDED by the worm-drive actuator brackets below.  The
    # legacy import is kept, gated off, so the retired part stays traceable.
    LEGACY_SERVO_BRACKETS = False
    if LEGACY_SERVO_BRACKETS:
        add_mesh(
            doc, _stl("nacelles/nacelle_servo_bracket.stl"), "Nacelle_Servo_Bracket_Port"
        )
        add_mesh(
            doc, _stl("nacelles/nacelle_servo_bracket.stl"), "Nacelle_Servo_Bracket_Stbd"
        )

    # -------------------------------------------------------------------
    # REV T5 CARGO SECTION EQUIPMENT — all modelled DIRECTLY in hull frame
    # (identity placement; single-sourced from tools/cargo_layout_fit.py via
    # cargo_layout_t5_params.scad).  Worm and wheel are one part each: the
    # starboard copies are TRANSLATED by 2*(X_CL - WORM_X) = -89.2 mm (Rev
    # T5e, WORM_X -125.25), never mirrored (the worm has a hand; see
    # tilt_actuator_bracket.scad header).  The brake guide is the exception
    # (BHD-05): it is mirrored, from its own stbd STL.  Rev T5e adds the chin node shelf
    # (chin_node_shelf.scad); the cargo Observer tray is an ENVELOPE only until
    # cargo_vera_faraday.scad is re-authored in hull frame (OBS-CARGO).
    # -------------------------------------------------------------------
    print("[assembly] Rev T5e cargo equipment (tilt actuators, brake, chin shelf) ...", flush=True)
    # -89.2 mm port -> starboard translate, from the generated layout include
    T5_STBD_DX = 2.0 * (hd.X_CL - _scad_param(_T5_PARAMS, "WORM_X"))
    add_mesh(doc, _stl("fuselage/cargo/tilt_actuator_bracket_port.stl"), "Tilt_Bracket_Port")
    add_mesh(doc, _stl("fuselage/cargo/tilt_actuator_bracket_stbd.stl"), "Tilt_Bracket_Stbd")
    for side, dx in (("Port", 0.0), ("Stbd", T5_STBD_DX)):
        for part, label in (("tilt_actuator_worm", "Tilt_Worm"),
                            ("tilt_actuator_wheel", "Tilt_Wheel")):
            obj = add_mesh(doc, _stl(f"fuselage/cargo/{part}.stl"), f"{label}_{side}")
            if obj is not None and dx:
                place_mesh(obj, (dx, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0))
        # BHD-05 (2026-10-07): the brake guide is NOT symmetric about the worm
        # axis, so starboard is a MIRRORED print (tilt_brake.scad SIDE=-1),
        # already in hull frame -- never the translated port part, which put
        # the guide through the bracket web into the controller board.
        add_mesh(doc, _stl("fuselage/cargo/tilt_brake_guide"
                           + ("_stbd" if dx else "") + ".stl"),
                 f"Tilt_Brake_Guide_{side}")
    # Battery_Cradle RETIRED 2026-10-31 (twin head pack tray, block above).
    add_mesh(doc, _stl("fuselage/cargo/chin_node_shelf.stl"), "Chin_Node_Shelf")

    # -------------------------------------------------------------------
    # DORSAL ANTENNA FIN
    # VERIFY: all parts imported at origin (identity placement).
    # User will manually position these in FreeCAD, then AI extracts
    # final placements from the corrected file.
    # See VERIFY_PLACEMENT_CHECKLIST.md §5 for positioning guidance.
    # -------------------------------------------------------------------
    print("[assembly] Dorsal antenna fin ...", flush=True)

    add_mesh(doc, _stl("fuselage/dorsal_antenna_fin.stl"), "Dorsal_Antenna_Fin")

    # -------------------------------------------------------------------
    # Visibility (2026-09-05 fix)
    # This script builds the document headless (freecadcmd), which never
    # attaches GUI ViewObjects unless FreeCADGui is explicitly loaded first
    # (see main() below). Every object defaulted to ViewObject.Visibility =
    # False, so opening either output FCStd in the FreeCAD GUI showed an
    # empty 3D viewport — the tree was fully populated, but nothing was
    # switched on to draw. Force every object visible before saving.
    # -------------------------------------------------------------------
    for _obj in doc.Objects:
        if _obj.ViewObject is not None:
            _obj.ViewObject.Visibility = True

    # -------------------------------------------------------------------
    # Recompute and save
    # -------------------------------------------------------------------
    print(f"[assembly] Document has {len(doc.Objects)} objects", flush=True)
    print("[assembly] Recomputing ...", flush=True)
    doc.recompute()
    print("[assembly] Recompute complete", flush=True)

    print(f"[assembly] Saving → {OUTPUT}", flush=True)
    # FreeCAD 1.0: Document.save() takes no path — saveAs() sets the
    # file name and writes the document in one call.
    doc.saveAs(OUTPUT)
    print("[assembly] Document saved", flush=True)
    print(f"[assembly] File size check: use 'ls -lh {OUTPUT}'", flush=True)
    print("[assembly] Complete.", flush=True)


# ---------------------------------------------------------------------------
# Entry point
#
# Under "freecadcmd serenity_assembly.py" the executed module's __name__
# is the file stem ("serenity_assembly"), not "__main__" — accept both
# so the script runs in either invocation (verified FreeCAD 1.0.0,
# 2026-06-11).
# ---------------------------------------------------------------------------
if __name__ in ("__main__", "serenity_assembly"):
    assemble()
