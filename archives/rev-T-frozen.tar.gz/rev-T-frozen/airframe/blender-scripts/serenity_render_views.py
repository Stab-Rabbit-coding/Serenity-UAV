#!/usr/bin/env python3
"""
serenity_render_views.py — Rev T+ (2026-10-31; was Rev R1 2026-06-15)

Multi-view render suite for the Serenity UAV 24" assembly.

Renders every placed mesh of the FreeCAD master assembly
(airframe/FreeCAD-scripts/serenity_assembly.py, exported by
tools/export_assembly_meshes.py) as 17 PNG images:
  6  principal-aspect overviews  (port, stbd, top, bottom, bow, stern)
  8  diagonal iso overviews      (all 8 corners of the bounding box)
  3  close-up shots              (nose/bow, landing gear, port nacelle)

Output: graphical-build-guide/pngs/  (1280x720 PNG, CYCLES renderer)

Aircraft datum R2 (tools/hull_datums.py; plan 2026-10-19-001):
  X  positive port  (left)   — matches Blender world X
  Y  positive aft   (back)   — matches Blender world Y  (nose tip at Y 0)
  Z  positive dorsal (up)    — matches Blender world Z  (3.0 in gear ground at Z 0)
The assembly's default attitude is port nacelle at cruise (0 deg), starboard
at hover (90 deg) -- serenity_assembly.py NACELLE_TILT_* -- so one image set
shows both attitudes.

Run with (MESH_DIR from tools/export_assembly_meshes.py):
  blender --background --python serenity_render_views.py -- MESH_DIR

Rev T+ refresh by Claude (Claude Opus 5.5, Anthropic) under the direction of
Stab-Rabbit-coding, 2026-10-31, per AGENTS.md AI attribution.
Author: Steve Griffing, PE(CSE), CISSP-ISSEP, CPP
License: CERN-OHL-W-2.0 — see LICENSES/CERN-OHL-W 2.0 (SPDX-License-Identifier: CERN-OHL-W-2.0)
"""

import json
import logging
import math
import os
import sys

import bpy
from mathutils import Euler, Vector

log = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO)

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------
REPO = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
OUT = os.path.join(REPO, "graphical-build-guide", "pngs")
os.makedirs(OUT, exist_ok=True)

print(f"[render] repo  = {REPO}")
print(f"[render] out   = {OUT}")

# ---------------------------------------------------------------------------
# Assembly centre, aircraft datum R2 -- measured 2026-10-31 from the exported
# Rev T+ assembly (tools/export_assembly_meshes.py, 45 placed meshes):
#   X: -276 (stbd nacelle) to +276 (port nacelle)   -> Cx 0
#   Y:    0 (nose tip)     to +690 (stern tip)      -> Cy 345
#   Z:    0 (3.0 in gear ground plane) to +282 (head crown) -> Cz 141
# All values in mm (= Blender scene units here).
# ---------------------------------------------------------------------------
CX, CY, CZ = 0.0, 345.0, 141.0
SHIP_HALF_W = 276.0  # half-width  (mm) -- nacelle outer face to outer face
SHIP_HALF_L = 345.0  # half-length (mm) -- nose to stern from Cy
SHIP_HALF_H = 141.0  # half-height (mm) -- ground plane to crown from Cz
TARGET = (CX, CY, CZ)  # look-at point for all cameras

# ---------------------------------------------------------------------------
# Part source — the FreeCAD master assembly, never a list kept here.
#
# 2026-10-31 (Rev T+ refresh): the Rev R1 COMPONENTS / PHCOMPONENTS lists that
# lived here had drifted from the airframe (50 mm Rev S pods, 40 A ESCs and
# 50 mm EDF placeholders at R1 offsets, no gear, no tilt drive).  Following the
# "airframe rules, local informs" rule (owner 2026-10-03), this script now
# renders exactly what airframe/FreeCAD-scripts/serenity_assembly.py places.
# Export the placed meshes first, then pass that directory:
#
#   xvfb-run -a freecadcmd -c "import sys; sys.argv=['x','--','OUT']; \
#       exec(open('tools/export_assembly_meshes.py').read())"
#   blender --background --python serenity_render_views.py -- OUT
#
# Each manifest entry is already in the aircraft frame (identity import).
# ---------------------------------------------------------------------------
FUSELAGE_COLOR = (0.72, 0.60, 0.44, 1.0)  # warm sandy tan
NACELLE_COLOR = (0.55, 0.46, 0.34, 1.0)  # slightly darker tan
WING_COLOR = (0.70, 0.58, 0.42, 1.0)  # near fuselage
DETAIL_COLOR = (0.40, 0.36, 0.28, 1.0)  # medium brown for accessories
PROP_COLOR = (0.18, 0.16, 0.14, 1.0)  # near-black for propulsion units
SERVO_COLOR = (0.35, 0.30, 0.20, 1.0)  # dark tan for servos
BATT_COLOR = (0.20, 0.30, 0.18, 1.0)  # dark green for battery pack


# Label prefix -> colour (first match wins).
COLOR_RULES = [
    (("Nacelle_Port", "Nacelle_Stbd"), NACELLE_COLOR),
    (("Wing_Port", "Wing_Stbd"), WING_COLOR),
    (("Head_Shell", "Cargo_Shell", "Middle_Shell", "Rear_Shell", "Cargo_Door"), FUSELAGE_COLOR),
    (("Landing_Gear", "Tilt_Worm", "Tilt_Wheel", "Wing_Port_Tilt", "Wing_Stbd_Tilt"), PROP_COLOR),
    (("Battery",), BATT_COLOR),
    (("Tilt_", "Cargo_Door_Servo", "Cargo_Release_Servo"), SERVO_COLOR),
]

# Placed with a VERIFY-tier identity placement at the datum origin, i.e. NOT
# yet in its flight position -- rendering it would show it under the nose.
UNPLACED = {"Dorsal_Antenna_Fin"}


def color_for(label: str) -> tuple:
    """Return the render colour for an assembly label."""
    for prefixes, color in COLOR_RULES:
        if label.startswith(prefixes):
            return color
    return DETAIL_COLOR


def setup_renderer(res: tuple = (1280, 720)) -> None:
    """
    Configure EEVEE-NEXT for fast headless rendering.

    EEVEE-NEXT (rasteriser) is used instead of Cycles because the fuselage
    STLs total ~5 M triangles, which makes Cycles path-tracing prohibitively
    slow on the project's 4-core i7-7600U build machine.  EEVEE-NEXT handles
    the same mesh data in seconds per frame at equivalent visual quality for
    build-guide illustrations.
    """
    scene = bpy.context.scene
    scene.render.engine = "BLENDER_EEVEE_NEXT"
    scene.render.resolution_x, scene.render.resolution_y = res
    scene.render.resolution_percentage = 100
    scene.render.image_settings.file_format = "PNG"
    scene.render.image_settings.color_mode = "RGBA"
    scene.render.image_settings.compression = 15
    print(f"[render] EEVEE-NEXT renderer, {res[0]}×{res[1]}")


# ---------------------------------------------------------------------------
# Scene utility
# ---------------------------------------------------------------------------
def clear_scene() -> None:
    bpy.ops.object.select_all(action="SELECT")
    bpy.ops.object.delete()
    for block in list(bpy.data.meshes) + list(bpy.data.cameras) + list(bpy.data.lights):
        try:
            bpy.data.batch_remove((block,))
        except Exception:
            # Block may already be orphan-purged by a prior batch_remove call
            # in this loop; log rather than silently swallow per CLAUDE.md
            # "Everything is logged."
            log.debug("batch_remove failed for %r", block, exc_info=True)


# ---------------------------------------------------------------------------
# Materials
# ---------------------------------------------------------------------------
_MAT_CACHE: dict = {}


def get_material(color_rgba: tuple) -> bpy.types.Material:
    key = color_rgba
    if key in _MAT_CACHE:
        return _MAT_CACHE[key]
    r, g, b, a = color_rgba
    name = f"Mat_{r:.2f}_{g:.2f}_{b:.2f}"
    mat = bpy.data.materials.new(name)
    mat.use_nodes = True
    nodes = mat.node_tree.nodes
    links = mat.node_tree.links
    nodes.clear()

    out = nodes.new("ShaderNodeOutputMaterial")
    bsdf = nodes.new("ShaderNodeBsdfPrincipled")
    bsdf.inputs["Base Color"].default_value = (r, g, b, a)
    bsdf.inputs["Roughness"].default_value = 0.78
    bsdf.inputs["Metallic"].default_value = 0.05
    # Blender 4.x uses 'Specular IOR Level'; 3.x used 'Specular'.
    try:
        bsdf.inputs["Specular IOR Level"].default_value = 0.25
    except KeyError:
        try:
            bsdf.inputs["Specular"].default_value = 0.25
        except KeyError:
            pass

    links.new(bsdf.outputs["BSDF"], out.inputs["Surface"])
    _MAT_CACHE[key] = mat
    return mat


# ---------------------------------------------------------------------------
# STL import
# ---------------------------------------------------------------------------
def import_stl(
    filepath: str,
    obj_name: str,
    material: bpy.types.Material,
    offset: tuple | None = None,
    rotation: tuple | None = None,
) -> bpy.types.Object | None:
    if not os.path.isfile(filepath):
        print(f"[render] SKIP (not found): {filepath}")
        return None
    print(f"[render] importing {os.path.basename(filepath)} …")
    # Blender 4.0+ uses wm.stl_import; older builds use import_mesh.stl.
    try:
        bpy.ops.wm.stl_import(filepath=filepath)
    except AttributeError:
        bpy.ops.import_mesh.stl(filepath=filepath)
    objs = bpy.context.selected_objects
    if not objs:
        print(f"[render] WARN: import produced no objects for {filepath}")
        return None
    obj = objs[0]
    obj.name = obj_name

    # Apply smooth shading (Blender 4.x shade_smooth_by_angle preferred)
    bpy.ops.object.select_all(action="DESELECT")
    obj.select_set(True)
    bpy.context.view_layer.objects.active = obj
    try:
        bpy.ops.object.shade_smooth_by_angle(angle=math.radians(60))
    except AttributeError:
        bpy.ops.object.shade_smooth()

    # Optional part-local rotation (Euler XYZ, radians) for placeholder alignment
    if rotation is not None:
        obj.rotation_euler = Euler(rotation)
    # Optional part-local → hull-frame translation for non-baked parts
    if offset is not None:
        obj.location.x += offset[0]
        obj.location.y += offset[1]
        obj.location.z += offset[2]

    # Assign material
    obj.data.materials.clear()
    obj.data.materials.append(material)
    return obj


# ---------------------------------------------------------------------------
# Lighting
# ---------------------------------------------------------------------------
def setup_lighting() -> None:
    """
    Three-point sun-lamp rig for EEVEE-NEXT.

    SUN lamps are used instead of area lights because the scene is in mm units:
    area lights at 2000 mm standoff would need ~1e7 W to illuminate the hull,
    while SUN lamps have no distance falloff and are trivial to tune.
    A weak area lamp below the hull provides the belly bounce fill.
    """
    # World: dark near-space blue-grey with mild ambient
    world = bpy.data.worlds.get("World") or bpy.data.worlds.new("World")
    bpy.context.scene.world = world
    world.use_nodes = True
    bg = world.node_tree.nodes.get("Background") or world.node_tree.nodes.new(
        "ShaderNodeBackground"
    )
    bg.inputs["Color"].default_value = (0.05, 0.06, 0.10, 1.0)
    bg.inputs["Strength"].default_value = 0.30

    def add_sun(
        name: str, direction: tuple, strength: float, color=(1.0, 0.98, 0.92)
    ) -> None:
        """Add a directional SUN lamp pointing in *direction* (world XYZ vector)."""
        light = bpy.data.lights.new(name, "SUN")
        light.energy = strength
        light.color = color
        light.angle = math.radians(5)  # slight angular size for soft shadows
        obj = bpy.data.objects.new(name, light)
        bpy.context.scene.collection.objects.link(obj)
        # Sun direction is set via the object's -Z axis tracking the target.
        dir_v = Vector(direction).normalized()
        obj.rotation_euler = dir_v.to_track_quat("-Z", "Y").to_euler()

    def add_area(
        name: str,
        loc: tuple,
        energy: float,
        size: float,
        rot_euler=(0, 0, 0),
        color=(1.0, 1.0, 1.0),
    ) -> None:
        light = bpy.data.lights.new(name, "AREA")
        light.energy = energy
        light.size = size
        light.color = color
        obj = bpy.data.objects.new(name, light)
        bpy.context.scene.collection.objects.link(obj)
        obj.location = loc
        obj.rotation_euler = Euler([math.radians(a) for a in rot_euler])

    # Key — port-fore-dorsal (main illumination, warm white)
    add_sun("Key", (0.6, -0.7, 0.8), 5.0)
    # Fill — starboard-fore (softer, cool blue)
    add_sun("Fill", (-0.7, -0.5, 0.3), 1.8, color=(0.80, 0.88, 1.00))
    # Rim — aft-dorsal (warm accent on the stern)
    add_sun("Rim", (0.0, 0.8, 0.6), 2.0, color=(1.00, 0.95, 0.80))
    # Bounce — belly fill (large area lamp below, no falloff concern at hull scale)
    add_area(
        "Bounce",
        (CX, CY, CZ - 1000),
        8e6,
        1200,
        rot_euler=(70, 0, 0),
        color=(0.90, 0.85, 0.75),
    )


# ---------------------------------------------------------------------------
# Camera helpers
# ---------------------------------------------------------------------------
def look_at_euler(cam: tuple, tgt: tuple, up: tuple = (0, 0, 1)) -> Euler:
    """Return Euler rotation for a camera at *cam* looking at *tgt*."""
    direction = Vector(tgt) - Vector(cam)
    rot = direction.to_track_quat("-Z", "Y")
    return rot.to_euler()


def add_camera(
    name: str, location: tuple, target: tuple, lens: float = 85.0
) -> bpy.types.Object:
    cam_data = bpy.data.cameras.new(name)
    cam_data.lens = lens
    cam_data.clip_start = 1.0
    cam_data.clip_end = 10000.0
    obj = bpy.data.objects.new(name, cam_data)
    bpy.context.scene.collection.objects.link(obj)
    obj.location = Vector(location)
    obj.rotation_euler = look_at_euler(location, target)
    return obj


def render_camera(cam_obj: bpy.types.Object, filename: str) -> None:
    bpy.context.scene.camera = cam_obj
    outpath = os.path.join(OUT, filename)
    bpy.context.scene.render.filepath = outpath
    print(f"[render] rendering → {filename}")
    bpy.ops.render.render(write_still=True)
    print(f"[render] saved     → {outpath}.png")


# ---------------------------------------------------------------------------
# Camera position catalogue
#
# Hull frame orientation in Blender world space:
#   +X = port (left wing outboard)
#   +Y = aft  (stern / engine)
#   -Y = forward (nose)
#   +Z = dorsal (up)
# ---------------------------------------------------------------------------

# Overview stand-off distance
OVR = 1600  # mm from scene centre for principal views
ISO = 1500  # mm from scene centre for iso views (scaled per axis)

OVERVIEW_CAMERAS = [
    # (filename,        camera_pos,                     target,  lens, label)
    ("01_port", (CX + OVR, CY, CZ + 20), TARGET, 85, "Port side"),
    ("02_stbd", (CX - OVR, CY, CZ + 20), TARGET, 85, "Starboard side"),
    ("03_top", (CX, CY, CZ + OVR), TARGET, 85, "Dorsal (top)"),
    ("04_bottom", (CX, CY, CZ - OVR), TARGET, 85, "Ventral (bottom)"),
    ("05_bow", (CX, CY - OVR, CZ + 30), TARGET, 85, "Bow (forward)"),
    ("06_stern", (CX, CY + OVR, CZ + 30), TARGET, 85, "Stern (aft)"),
]

# Eight diagonal iso views — one per octant
_s = ISO * 0.707  # unit-sphere projection for 45° diagonals
_z_up = ISO * 0.55
_z_dn = ISO * 0.45
ISO_CAMERAS = [
    ("07_iso_port_bow_dorsal", (CX + _s, CY - _s, CZ + _z_up), TARGET, 70),
    ("08_iso_stbd_bow_dorsal", (CX - _s, CY - _s, CZ + _z_up), TARGET, 70),
    ("09_iso_port_stern_dorsal", (CX + _s, CY + _s, CZ + _z_up), TARGET, 70),
    ("10_iso_stbd_stern_dorsal", (CX - _s, CY + _s, CZ + _z_up), TARGET, 70),
    ("11_iso_port_bow_ventral", (CX + _s, CY - _s, CZ - _z_dn), TARGET, 70),
    ("12_iso_stbd_bow_ventral", (CX - _s, CY - _s, CZ - _z_dn), TARGET, 70),
    ("13_iso_port_stern_ventral", (CX + _s, CY + _s, CZ - _z_dn), TARGET, 70),
    ("14_iso_stbd_stern_ventral", (CX - _s, CY + _s, CZ - _z_dn), TARGET, 70),
]

# Close-up targets (aircraft datum R2, mm; from the exported assembly bounds)
# Nose: head shell Y 0..233, Z 141..282.
NOSE_TGT = (CX, 40, 210)
# Port nacelle (cruise attitude): X 181..276, Y 217..411, Z 97..196.
NACELLE_TGT = (228, 314, 146)
# 3.0 in landing gear + conforming bays: Y 239..466, Z 0..162.
GEAR_TGT = (CX, 352, 70)

CLOSEUP_CAMERAS = [
    # (filename,       camera_pos,                           target,       lens)
    ("15_closeup_nose", (CX - 150, -420, 260), NOSE_TGT, 50),
    ("16_closeup_gear", (CX + 520, 250, -60), GEAR_TGT, 50),
    ("17_closeup_nacelle", (CX + 650, 120, 330), NACELLE_TGT, 60),
]


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
def main() -> None:
    print("[render] === Serenity UAV render suite starting ===")

    clear_scene()
    setup_renderer(res=(1280, 720))  # 720p preview; increase for finals

    # Import every placed mesh of the master assembly (already in R2 frame).
    args = sys.argv[sys.argv.index("--") + 1:] if "--" in sys.argv else []
    if not args:
        raise SystemExit("usage: blender --background --python serenity_render_views.py -- MESH_DIR")
    with open(os.path.join(args[0], "manifest.json"), encoding="utf-8") as fh:
        manifest = json.load(fh)
    for label, entry in sorted(manifest.items()):
        if label in UNPLACED:
            print(f"[render] SKIP (unplaced, VERIFY): {label}")
            continue
        import_stl(entry["file"], label, get_material(color_for(label)))

    print("[render] All STLs imported — setting up lighting")
    setup_lighting()

    # -- Overview cameras --
    print("[render] === Overview renders ===")
    for fname, cam_loc, tgt, lens, label in OVERVIEW_CAMERAS:
        cam = add_camera(f"Cam_{fname}", cam_loc, tgt, lens)
        render_camera(cam, fname)

    # -- Iso cameras --
    print("[render] === Iso renders ===")
    for entry in ISO_CAMERAS:
        fname, cam_loc, tgt, lens = entry
        cam = add_camera(f"Cam_{fname}", cam_loc, tgt, lens)
        render_camera(cam, fname)

    # -- Close-up cameras --
    print("[render] === Close-up renders ===")
    for fname, cam_loc, tgt, lens in CLOSEUP_CAMERAS:
        cam = add_camera(f"Cam_{fname}", cam_loc, tgt, lens)
        render_camera(cam, fname)

    print(
        f"[render] === Complete. {len(OVERVIEW_CAMERAS) + len(ISO_CAMERAS) + len(CLOSEUP_CAMERAS)} images → {OUT} ==="
    )


if __name__ == "__main__":
    main()
