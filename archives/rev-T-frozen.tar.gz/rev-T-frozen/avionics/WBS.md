# Serenity UAV — Avionics (Pilot / XO / Commo Cape Hardware) Work Breakdown Structure (Detail)

**Author:** Steve Griffing, PE(CSE), CISSP-ISSEP, CPP
**License:** CC BY-SA 4.0 — creativecommons.org/licenses/by-sa/4.0 (SPDX-License-Identifier: CC-BY-SA-4.0)
**Current design revision:** Rev U (2026-11-03, see `docs/WBS.md` §6.5 for changelog)

> **Detail-holder for the root WBS.** The repository-root [`TODO.md`](../TODO.md)
> is a compact index — headings, subheadings, and short (<=70-char) checkbox items
> only, per root `AGENTS.md`. This file carries the full task detail for the WBS
> branches the root indexes below. Close an item here first, then check it off in
> the root index as a commit prerequisite (root `AGENTS.md` "Revisions and Version
> Control").

*"I'm a leaf on the wind — watch how I soar. — Pilot"*

---

## §1.2 — PCB Design: Pilot and Cape-B-1 (archived)

*(root `WBS.md` §1.2)*

- [x] **Regenerate Pilot gerbers** — `.kicad_pcb` modified 2026-05-23 (tamper-mesh commit); gerbers in `serenity/kicad/gerbers/Pilot/` are from 2026-05-22.
    - Open in KiCad → Plot → Gerbers; overwrite files in `serenity/kicad/gerbers/Pilot/`; re-export drill files.
    - Run DRC to zero errors before plotting.
    - **BLOCKS Phase 6 fab order**

- [x] **Regenerate TACCO gerbers** — same timestamp issue. `serenity/kicad/gerbers/CAPE-B-1/` files are from 2026-05-22.
    - **BLOCKS Phase 6 fab order**

---

## §1.2a — PCB Design: Pilot, XO, Commo (EMI-Hardened Variants)

*(root `WBS.md` §1.2a)*

### ***EM hardening Objective is to ensure safe and controlled operations in hostile em/rf environments such as the vicinity of radiating commercial broadcast, amateur radio and cellular towers.***

Design files on branch `claude/cape-em-harsh-variants-9Yfr1`. Schematics (`*.kicad_sch`) and PCB
layout files (`*.kicad_pcb`) are complete. Gerber files have not yet been generated or DRC-verified.

**Key changes from -1 variants:**

- **CAN FD**: ATA6561 (non-isolated) → ISOW1044BDFMR (TI, SOIC-16W, 5 kV reinforced isolation +
    integrated DC/DC converter, IEC 62368-1 / VDE 0884-11)
- **RS-485**: MAX3485E (non-isolated) → ADM2795EBRWZ (ADI, SOIC-20W, 5 kV reinforced isolation +
    integrated DC/DC converter)
- **Ethernet PHY (Rev S baseline; introduced Rev Q)**: DP83825I (TI, LQFP-32, 10/100BASE-TX RMII) with EMI hardening:
    HX1188NL LAN magnetics (1500 V isolation), SRF2012-100Y CMC, PRTR5V0U2X TVS, TPS62933 1.8V
    supply. JST SM06B-GHS-TB-1MP connector (no RJ45). Pilot: 2× PHY (RMII0+RMII1);
    XO: 1× PHY (RMII0).
- **Commo**: SRF2012-100Y CMC on antenna coax shield, PRTR5V0U2X TVS on PTT/RX lines,
    X2Y bridging capacitor on RF ground plane, Würth 742792512 ferrite bead on +5V rail

**Transform scripts** (generate -2 files from -1 originals):

- `avionics/kicad/gen_cape_a2.py` → `Pilot.kicad_sch`
- `avionics/kicad/gen_cape_b2.py` → `TACCO.kicad_sch`
- `avionics/kicad/add_eth_phy.py` — ETH PHY isolation sub-circuit generator (called by above)
- `avionics/kicad/gen_cape_a2_pcb.py` → `Pilot.kicad_pcb`
- `avionics/kicad/gen_cape_b2_pcb.py` → `TACCO.kicad_pcb`

**Open tasks:**

- [x] **USB-to-Ethernet bridge (LAN9500A class) evaluated as an alternative Ethernet
    front end and REJECTED (not deferred), 2026-07-11.** Rationale captured in
    `docs/ETHERNET_PHY_TRADE.md`: a single-port USB bridge cannot offload HSR/PRP
    (IEC 62439-3), so the redundant ring collapses; USB adds non-deterministic
    latency/jitter unfit for the flight-control bus, a fragile 480 Mbps EMI ingress
    path in the 200 V/m environment, and hard/costly galvanic isolation — while
    wasting the AM6254/AM62A7 native MAC. Native DP83825I / ADIN1300 / KSZ9477 path
    retained. If "reduce per-PHY glue on Pilot" resurfaces, the on-architecture answer
    is a managed KSZ9477/KSZ9567 switch, tracked as a separate trade — NOT USB.

##### 1.2a.2 *Commo Rev T — standalone MCU bus node (approved 2026-09-29)*

Owner decisions (2026-09-29, S. Griffing):

- One unit per airframe, co-located with its antennas.
- Isolated CAN-FD + RS-485 + MIL-STD-1553C RT.
- No Ethernet.
- SE instead of TPM.
- Mass from the PCB roll-up.

Sources: requirements in `docs/brainstorms/2026-09-29-commo-standalone-node-requirements.md`;
plan in `docs/plans/2026-09-29-001-feat-commo-standalone-bus-node-plan.md`.

Rev S cape items in `TODO.md` §1.2a.1 (Commo gerbers, SIK/ETH-PHY overlap DRC) are
**superseded** by Rev T and should not be worked. The §15.235 pre-compliance item still applies
to Rev T.

- **Phase 0 — architecture paperwork**
    - [x] Amend `avionics/AGENTS.md`: bus-topology 1553 exception, Commo re-classed as a
        standalone node with an SE (2026-09-29).
    - [x] Update root `AGENTS.md` §1 and §9 for single-Commo / bus-reachable radios
        (2026-09-29).
    - [x] Archive the Rev S cape snapshot to
        `archives/avionics-archives/kicad-archives/Commo-cape-RevS-superseded-2026-09-29/`
        and add it to `ARCHIVE_INDEX.md` (2026-09-29).
- **Phase 1 — part selection** (datasheet-verified)
    - [x] Confirm the MCU peripheral budget (2026-09-28). Result: MSPM0G351x-Q1 in VQFN-48 RGZ
        fits (1 CAN-FD, 6 UART, 3 I²C, 2 SPI, 44 GPIO against about 30 needed). RHB-32 is too
        small (28 GPIO). G3519 (512 KB) is recommended for dual-bank OTA headroom. Source: TI
        SLASFA6B Table 5-1. Detail is in the plan's Phase 1 findings.
    - [x] Owner sign-off: MCU = M0G3519QRGZRQ1 over G3518 (256 KB). Approved by
        S. Griffing 2026-09-28.
    - [ ] Choose 1553 coupling (direct 1:2.5 + 55 Ω, or transformer 1:1.79) once the antenna-site
        stub length is known (Holt DS1573 p. 2).
    - [x] Owner decision (S. Griffing, 2026-09-28): use a dedicated 1553 protocol engine
        (option 2), not MCU-peripheral Manchester. **Candidate: Holt HI-6138** (BC/RT/MT,
        40 MHz SPI host, on-chip dual-bus transceiver, 3.3 V, 48-pin 6×6 mm QFN or LQFP).
        Holt's product page states "MIL-STD-1553B/C, MIL-STD-1760, SAE AS15531A and STANAG
        3838 compliant" (holtic.com/products/3102-hi-6138.aspx, retrieved 2026-09-28).
    - [x] HI-6138 datasheet on file (S. Griffing, 2026-09-28):
        `avionics/datasheets/hi-6138_v-rev-s.pdf`, Holt DS6138 Rev S, dated October 2024.
    - [x] Verify the HI-6138 against DS6138 Rev S (2026-09-28):
        - **Magnetics:** Figure 28 (p. 255) uses a 1:2.5 isolation transformer for both
          direct coupling (2 × 55 Ω) and transformer coupling (1:1.4 stub coupler +
          2 × 52.5 Ω). The fleet's 1:2.5 PM-DB2791S therefore carries over; only the
          coupler choice depends on stub length.
        - **Host interface:** 40 MHz 4-wire SPI, modes 0 and 3.
        - **Control pins:** IRQ is active low, with an ACKIRQ pulse of at least 250 ns in
          level mode. MR is an active-low reset, minimum 50 ns.
        - **Transceiver and supply:** dual-bus transceiver on-chip, so the HI-1573 is
          dropped. Supply is 3.3 V (VCCP).
    - [x] **1553C conformance resolved (2026-09-28).** DS6138 Rev S says only "1553B", but
        MIL-STD-1553C (28 Feb 2018) is a document revision with no electrical or protocol
        change from 1553B [REF-MIL-001]. A 1553B-compliant terminal therefore meets 1553C.
        Holt's product-page "1553B/C" claim is consistent with this. The one C-specific
        paragraph, §4.4.3.2 "Superseding valid commands", is a protocol behavior that the
        HI-6138 RT logic handles. Confirm it during firmware bring-up.
    - [x] Confirm the fleet isolated CAN-FD part (ISOW1044) and RS-485 part for reuse. Done
        2026-09-29: ISOW1044BDFMR + **ISOW1412DFMR**, the fleet standard (the plan's ADM2795E is
        corrected). See `avionics/kicad/Commo/COMMO_REVT_PHASE1_PARTS.md` §1.
    - [x] Select the SE and check for an I²C address conflict with Si5351A. Done 2026-09-29:
        OPTIGA Trust M at 0x30 vs. Si5351A at 0x60, so there is no conflict.
    - [x] Define the power input rail and budget. Done 2026-09-29:
        - Input is +5 V from the avionics bus.
        - Logic 3.3 V comes from a TPS62933 buck, sized for the HI-6138's 695 mA max
            transmit current (DS6138 §24.3). (Pilot only: replaced 2026-10-17 by the 2 A
            TPSM828224SILR module [REF-PWR-008], see the §13.1 re-floorplan item.)
        - RF-analog 3.3 V comes from a TPS7A2033 LDO.
        - Worst case is about 1.9 A at 5 V, a net reduction against two Rev S capes.
    - [x] Select the Holt 1553C protocol engine. Done 2026-09-28: HI-6138, fleet part
        (§1.2a.3).
    - [x] RF-chain datasheet audit. Done 2026-09-29: the Rev S 49 MHz chain is miswired on the
        Si5351A (9/10 pins), TCXO, PE4259, and MGA-82563, has no receive demodulator, and uses
        three unbuildable packages (2N3866 SOT-89, MCP4921 SOT-23-8, LM393 SOT-23-5). See
        `avionics/kicad/Commo/COMMO_REVT_PHASE1_PARTS.md` §3.
    - [x] **49 MHz architecture decided (owner, 2026-09-29):** discrete receiver. The AX5043
        single chip is discontinued (onsemi Rev 4, 2026-06-11), and so are the SA605, SA614A,
        and SA636 FM-IF chips. Build an I/Q direct-conversion receiver with 2 × SA612A and an
        Si5351B VCXO-FM transmitter with no PA. Plan:
        `docs/plans/2026-09-29-002-feat-commo-revt-49mhz-iq-radio-plan.md`.
    - [x] **Background single-chip search (Claude agent, 2026-09-29):**
        `docs/brainstorms/2026-09-29-commo-49mhz-single-chip-search.md`. No in-production
        single chip with a modular grant exists. The best lead is the CML CMX994G receiver,
        whose datasheet states operation "down to 50 MHz", so 49.86 MHz is unconfirmed.
    - [ ] Ask CML in writing to confirm CMX994G performance at 49.86 MHz and its production
        status (owner action).
    - [ ] Budget full §15.235 certification for Commo. No modular-grant path exists.
- **Phase 2 — schematic (Rev T)**
    - [x] **49 MHz radio sheet designed (plan 2026-09-29-002 U2/U3, Claude Opus 5.5,
        2026-09-29):**
        - `avionics/kicad/Commo/kicads/Commo_radio.kicad_sch` has 79 parts. It is generated by
            `scripts/gen_commo_radio_sch.py`, with values from
            `scripts/commo_radio_design.py` (all checks pass).
        - ERC: 0 errors, plus 3 expected sheet-boundary labels to the MCU.
        - Design note: `avionics/kicad/Commo/COMMO_REVT_RF_DESIGN.md`.
        - The Rev S chain is replaced, not ported (Phase 1 audit). The design also corrects
            three more Rev S errors: nonexistent 0805HQ-101/-181 inductors, an SMAJ5.0A on the
            RF port, and a 742792510 bead mis-specified as 600 Ω.
    - [ ] Rev T top-level schematic (U1): MCU, HI-6138 1553C, ISOW1044, ISOW1412, OPTIGA,
        power, SiK, SWD. Include the radio sheet. ERC clean.
    - [ ] **Owner:** accept re-baselined RF current. The requirement was ≤ 15 mA; the design
        draws 34 mA typical at 5 V while receiving, because of the Si5351B core, and the
        rail is switched off by `RF_EN` when idle. Design note §4.
    - [ ] **Owner:** set the 49 MHz channel list inside 49.82–49.90 MHz. 49.860 MHz is
        provisional.
    - [ ] **Owner:** confirm the antenna shell bonds to RF GND, not the PGND ring. Design
        note §7.
    - [ ] Bench-verify the design-note §7 items (inductor Q, SA612A OSC_E open, I/Q balance,
        VCXO Kv and deviation, VC input). Set the TX pad at EMC test against §15.235
        [REF-FCC-003].
- **Phase 3 — layout**
    - [ ] Outline to the antenna site; owner does manual placement; RF rules retained.
    - [ ] Check the 1553 stub length; DRC clean; generate Gerbers.
- **Phase 4 — integration**
    - [ ] PCB mass roll-up, then update `airframe/README.md`, `docs/BATTERY_MOUNT.md`, and
        W&B/CG.
    - [ ] Fix the antenna-site station against the hull model and the emi-hardening separation
        checks.
    - [ ] Log firmware items in `avionics/firmware/WBS.md`: AFSK/AX.25, SiK bridge, PTT lease,
        1553 RT map / BC schedule, SE signing / secure boot.

##### 1.2a.3 *Fleet MIL-STD-1553C upgrade (approved 2026-09-28)*

Owner decision (S. Griffing, 2026-09-28): upgrade the whole fleet from MIL-STD-1553B to
MIL-STD-1553C. Today Pilot and TACCO use a Holt HI-1573 transceiver, which claims 1553A/B only
(DS1573 Rev U p. 1), with Manchester II handled in the AM6254 PRU. The candidate
replacement is the same protocol engine selected for Commo Rev T (§1.2a.2, HI-6138), so the
fleet shares one 1553 part.

**Finding 2026-09-28 [REF-MIL-001]:** 1553C is electrically identical to 1553B, so the capes'
HI-1573 and PM-DB2791S already meet 1553C electrically. The swap to the HI-6138 is therefore
**not required** for 1553C; it is justified by part commonality and by moving the protocol
off the PRU. The only C-specific work is §4.4.3.2 (superseding valid commands) in the RT
logic.

**Owner decision (S. Griffing, 2026-09-28): make the fleet swap.** Pilot and TACCO move from
HI-1573 + PRU Manchester to the HI-6138 on SPI, for one 1553 part fleet-wide and to take the
protocol off the PRU. The PM-DB2791S (1:2.5) and 55 Ω isolation resistors carry over (DS6138
Rev S Fig. 28 p. 255; [REF-MIL-001 §4.5.1.5.2.1]).

Plan: `docs/plans/2026-09-28-002-feat-fleet-1553c-hi6138-swap-plan.md` (Claude Opus 5.5,
2026-09-28). Phases 1–4 are listed below; each lands as its own commit.

- [x] **Phase 1 (U1):** HI-6138 footprint (custom, DS6138 §29), pin table, 50 MHz MCLK
    oscillator, and courtyard area budget. Done 2026-09-28; see
    `avionics/kicad/HI6138_FOOTPRINT_VERIFICATION.md`. Net courtyard change is −1.16 mm² per cape.
- [x] **Phase 2 (U2):** Pilot schematic regenerate, PCB in-place patch, ERC/DRC gates.
    Done 2026-09-28:
    - ERC: 0.
    - DRC: 0 violations, 0 schematic-parity issues. Unconnected pads went 388 → 390;
      routing is still open.
    - `1553-XCVR` kept its position and side; only the 4 new parts were added
      (`avionics/kicad/tools/swap_1553_hi6138.py`).
- [x] **Phase 3 (U3):** TACCO schematic regenerate, PCB in-place patch, ERC/DRC gates.
    Done 2026-09-28:
    - **Generator drift fixed first.** `gen_tacco_sch.py` still wrote the pre-rename
        `XO` library, and one datasheet string was stale. After the fix its output matches
        the committed netlist exactly (0 component and 0 pin-to-net differences).
    - **Gates:** ERC 0. DRC 169, equal to the pre-change baseline of 169 (no new
        violations), with 0 schematic-parity issues. Unconnected pads went 480 → 482.
    - **Placement:** `1553-XCVR` swapped in place.
- [x] **TACCO manual placement (owner):** **CLOSED 2026-10-05** — the regenerated 163-part TACCO
    board places `X-50M`, `C-50M`, `C-1553D`, and `R-1553IRQ` beside the HI-6138 (all within 10 mm;
    see the TACCO area-recovery entry in §1.2a). Original problem: `X-50M`, `C-50M`, `C-1553D`, and
    `R-1553IRQ` were
    parked off-board at the right edge. No collision-free site exists within 20 mm of
    the HI-6138 on either side of the board (TACCO area crisis; see memory
    project_xo_board_area_crisis). Options:
    - Free area as the 2026-09-20 area analysis proposes.
    - Drop `R-1553IRQ` in favor of the AM62x internal pull-up on P1-7, a firmware
        pinmux change.
    - Accept a 6-layer or denser-passive respin.
- [x] **Phase 4 (U4):** DTS (both capes), firmware WBS, Pilot.md, TACCO.md, HDD, and 1553C
    documentation. Done 2026-09-28:
    - **DTS:** PRU0 1553 disabled. The HI-6138 is an SPI child using a GPIO chip-select,
        IRQ, reset, and TXINH. Both DTS files pass a stub-header `cpp`/`dtc` syntax check;
        no kernel headers are available here for a real build.
    - **Firmware WBS:** retargeted to an HI-6138 driver, with a §4.4.3.2 conformance test
        and a response-time test.
    - **Docs:** REF-MIL-001 "Used in" list updated. `HDD.md` is marked for regeneration.
- [ ] **Pinmux verification:** the P1-7/8/9/20 GPIO numbers and pad offsets in both DTS
    files are carried over as `[ESTIMATE]`. Check them against the PB2 pin map / SPRUJ40.
- [ ] **TACCO DTS drift (pre-existing, found 2026-09-28):** the DTS names the SPI
    controller `main_spi1` and still lists the retired RFM95W, RFD900x, and WL1837, while
    the schematic uses SPI0_B with the TPM, flash, ZigBee, and HI-6138. Reconcile the DTS
    with `gen_tacco_sch.py`.
- [x] Add MIL-STD-1553C to `REFERENCES.md` (REF-MIL-001 rebuilt against the ASSIST text,
    2026-09-28).
- [x] **Footprint and space budget first. Both capes are space-critical (owner, 2026-09-28).**
    *Closed 2026-09-28 by Phase 1 (U1).*
    Findings from 2026-09-28:
    - **Current part:** `1553-XCVR` is HI-1573 in `QFN-44-1EP_7x7mm_P0.5mm_EP5.2x5.2mm` on
        B.Cu. Pilot has it at (142.5, 98.5), rotated −90°; TACCO at (142.86, 111.49).
    - **Replacement:** HI-6138PC* is a 48-pin QFN, 6.000 × 6.000 mm BSC, 0.40 mm pitch.
        Exposed pad 4.700 ± 0.050 mm, electrically isolated. Leads are 0.200 mm wide and
        0.400 ± 0.050 mm long (DS6138 Rev S §29, p. 263).
    - **Body area:** drops from 49 mm² to 36 mm², so the part fits inside the existing
        courtyard. The PQFP option (9 × 9 mm body) is rejected as larger.
    - **No stock KiCad match.** The closest stock footprint is
        `QFN-48-1EP_6x6mm_P0.4mm_EP4.66x4.66mm`. Author and verify a custom footprint in the
        SecureControllers library against DS6138 §29, following
        `docs/solutions/conventions/pb2-cape-datasheet-verified-footprints-and-courtyard-budget-before-layout.md`.
    - **Routing:** 0.40 mm pitch is finer than today's 0.5 mm, so check the fab's minimum
        clearance and solder-mask web.
    - **Extra parts cost area.** The part needs SPI (4 lines), IRQ, and MR to the host.
        Mode and configuration pins need tie-offs; count those strap resistors against the
        freed area before layout. The HI-1573's separate VDDA/VDDB decoupling (C-1553A/B/C)
        gets re-derived from the HI-6138 supply pins.
- [x] *(Closed 2026-09-28 by Phase 2.)* Pilot: replace HI-1573 with the protocol engine on a PB2 SPI port. Confirm a free SPI
    chip-select and IRQ on P1/P2. Update `Pilot.md` (1553B → 1553C) and the magnetics if
    the ratio changes.
- [x] TACCO: same change as Pilot. *(Closed 2026-09-28 by Phase 3; placement is a separate open item above.)* Update `TACCO.md` and `reports/HDD.md`.
- [x] *(Closed 2026-09-28 by Phase 4; driver work itself is open in `avionics/firmware/WBS.md`.)* Firmware: replace the PRU-ICSS Manchester RT task (`avionics/firmware/WBS.md`
    "MIL-STD-1553B RT implementation") with an SPI protocol-engine driver. Retire the
    PRU0 1553 pinmux in the DT overlays.
- [ ] Docs sweep: change remaining "1553B" statements to 1553C once the hardware matches.
    Status on 2026-09-28: the board docs, DTS, firmware WBS, and REFERENCES are done. About
    470 mentions remain in other active files. Many are legitimate and must not be changed:
    history, archived DTS, and TACCO's `M1553B_*` cape-B net names. Sweep file by file.
    `avionics/AGENTS.md` already states 1553C.

##### 1.2a.4 *TACCO DRC backlog — 140 hard violations (opened 2026-09-29)*

**Status 2026-10-07:** the 140-violation count was measured on the pre-regeneration layout and no
longer describes the board. The 2026-10-05/06 regeneration (163 parts, 60 × 35 mm) reports **0 DRC
errors and 0 schematic-parity issues before routing**, so the placement-driven items below are
closed as superseded. The isolation-shorts and clearance items stay open because routing
(`TACCO area recovery` U5, §1.2a) can reintroduce them. Re-run `tools/validate_kicad.py` after
routing.

This is a standalone backlog, separate from the 1553C swap (§1.2a.3) and Commo Rev T (§1.2a.2).
`tools/validate_kicad.py` (KiCad 9.0.9, CI "KiCad Validation") reports
**140 hard / 29 soft** DRC findings on `avionics/kicad/TACCO/kicads/TACCO.kicad_pcb`. PR #220
(merged 2026-09-29) surfaced them when it first touched TACCO. Most of the nets involved are
outside the 1553 area, so this looks like pre-existing layout debt. That is not proven: no
before/after run on the pre-swap board has been done.

**Findings by class** (CI log, run 36569510415, 2026-09-29):

| DRC rule | Approx. count | Notable nets / areas |
| --- | --- | --- |
| `solder_mask_bridge` | ~55 | Front and rear mask apertures bridging different nets |
| `shorting_items` | ~45 | RMII0_* ↔ +3V3_RF; PHY1_RSTN / MDIO0 / MDC0 / ETHB_TX± / +3V3 ↔ +5V_IN; PGND ↔ GND2_RS485B / VCC2_RS485B / SD_CD / GND / +3V3_RF; RF_SW1 ↔ TPM_B_* / SPI0_B_* / +3V3 / GND; RADIO_ANT_F ↔ RS485B iso rails; SDIO_CMD ↔ UART_WIOE5_TX_F; WIOE5_BOOT_BTN ↔ WIOE5_SWCLK; GND2_CANB ↔ GND; +3V3 ↔ +5V; FAN_PWM_B ↔ GND / +3V3 |
| `clearance` | ~25 | POWER / ISOLATION / Default netclasses, down to 0.000 mm |
| `courtyards_overlap` | 11 | — |
| `items_not_allowed` | 1 | Keepout "isolation keepout inner" |

The shorts across isolation domains (PGND and RADIO_ANT_F to the RS485B isolated rails, and
GND2_CANB to GND) break the 5 kV galvanic isolation requirement. They must be fixed, not waived.

- [x] Run the before/after DRC comparison (pre-§1.2a.3 TACCO vs. current) to separate existing
      debt from anything the HI-6138 swap introduced. *(Superseded 2026-10-05: board regenerated
      from scratch; the comparison is moot.)*
- [x] **Owner:** footprint repositioning for the courtyard overlaps and placement-driven shorts
      (`avionics/AGENTS.md`: repositioning is referred to the owner). *(Superseded 2026-10-05:
      generator placement is DRC-clean; owner approved the placement rules.)*
- [x] Clear the isolation-domain shorts (PGND, GND2_*, VCC2_* and RADIO_ANT_F crossings) and
      the keepout intrusion. *(Closed 2026-10-26: `tools/validate_kicad.py` on
      `avionics/kicad/TACCO/kicads/TACCO.kicad_pcb` at branch `pilot-refloorplan` @ 13a5a119
      reports 0 hard, 5 soft. No `shorting_items` or `items_not_allowed` finding remains on the
      canonical board. The hand-edited `TACCO-2.kicad_pcb` is not this item; see §1.2a.6.)*
- [x] Clear the remaining shorts, clearance and solder-mask-bridge findings. *(Closed 2026-10-26
      with the same measurement: 0 hard on the canonical TACCO board.)*
- [x] Re-run `tools/validate_kicad.py` until it reports 0 hard violations on TACCO, and document
      any accepted residuals with rule and reason. *(Met 2026-10-26 on `TACCO.kicad_pcb`; the
      5 soft findings remain accepted-class under the validator's severity policy.)*

##### 1.2a.5 *Pilot DRC backlog — 250 hard violations (measured 2026-10-26)*

**Measurement.** `tools/validate_kicad.py --changed-since origin/main --verbose` (KiCad 9.0.9
`kicad-cli pcb drc --severity-error`) on `avionics/kicad/Pilot/kicads/Pilot.kicad_pcb` at branch
`pilot-refloorplan` @ 13a5a119 (PR #258) reports **250 hard / 55 soft**. The same board
measured 79 hard on 2026-10-18, so the count grew during the Pilot re-route. The ERC on
`Pilot.kicad_sch` is 0 hard. The gate in CI "KiCad Validation" fails on this board.

| DRC rule | Count | Notes |
| --- | --- | --- |
| `clearance` | 109 | Requires track, pad, or via relocation; not a netclass edit |
| `hole_clearance` | 96 | Via-to-pad and via-to-hole spacing |
| `track_width` | 44 | Track width below the active netclass minimum |
| `items_not_allowed` | 1 | Keepout intrusion |

`kicad-cli` also reports 212 unconnected items. The validator gate does not count them, but the
Pilot routing is open (§1.2a "Finish Pilot PCB"), so the unconnected nets remain part of this
backlog.

- [ ] Clear the 109 `clearance` findings. Re-route or move the offending tracks, pads, or vias.
      Do not widen the netclass to pass the check.
- [ ] Clear the 96 `hole_clearance` findings. Move the vias or pads, or resize the drill where the
      design permits.
- [ ] Clear the 44 `track_width` findings by widening the affected tracks to the netclass minimum.
- [ ] Clear the `items_not_allowed` keepout intrusion.
- [ ] Route the 212 unconnected items and record any that stay open as accepted, with reason.
- [ ] Re-run `tools/validate_kicad.py` until `Pilot.kicad_pcb` reports 0 hard. Document any
      accepted residuals with rule and reason.

##### 1.2a.6 *TACCO-2 hand-edited board — 93 hard violations (measured 2026-10-26); owner decision required*

**Finding.** `avionics/kicad/TACCO/kicads/TACCO-2.kicad_pcb` has no matching schematic. It is a
hand-edited layout copy, not a generator output. The validator scans it because it is a
`.kicad_pcb` in the repository. Measured at the same ref as §1.2a.5: **93 hard / 36 soft**, of
which 48 are `solder_mask_bridge`, 34 are `shorting_items`, 7 are `clearance`, 3 are
`hole_clearance`, and 1 is `courtyards_overlap`. The shorting items match the PB2 socket-rail
pattern in `docs/solutions/design-patterns/pb2-socket-rails-bind-connector-overhang-not-connector-family.md`,
which records these findings as caused by hand-edited what-if copies.

The canonical TACCO board (§1.2a.4) is `TACCO.kicad_pcb` and reports 0 hard. This item does not
reopen §1.2a.4.

- [x] **Owner decision:** delete `TACCO-2.kicad_pcb`, `.kicad_pro`, and `.kicad_dru`, not
      regenerate them. *(Decided 2026-10-26 by the owner. The files are removed from the tree and
      remain in git history before the deletion commit.)*
- [x] Delete the three TACCO-2 files and confirm `tools/validate_kicad.py` no longer scans
      `TACCO-2`. *(Closed 2026-10-26 with the deletion commit on `track/drc-backlog`.)*

##### 1.2a.1 *Cape DRC / routing / ETH2 status (2026-06-12)* — see `avionics/kicad/README.md`

- [x] **Wire second Ethernet (ETH2) on Pilot.** `ETH2` / `ETH2-PHY` (ADIN1300) /
    `T-ETH2` (749010012A) were placed but unconnected; nets now mirror ETH1
    (`ETH2_LINE_*` → `T-ETH2` → `ETH2_*` → PHY), reusing the host-side `RMII1_*`,
    `MDIO`/`MDC`, `PHY2_INTRN`/`PHY2_RSTN`, `VCC2_ETH`/`GND`/`GND2_ETH` nets on
    PB2-P2. 44 pads assigned; diff pairs verified. *(PR #59, 2026-06-12)*
- [x] **Separate the two Pilot PHYs onto independent MDIO buses** (instead of an
    address strap). PHY1/ETH1-PHY → `MDIO0`/`MDC0` (CPSW MDIO, PB2-P2 pins 17/18);
    PHY2/ETH2-PHY → `MDIO1`/`MDC1` (2nd bus, PB2-P2 pins 1/2 = the two spare servo
    channels SERVO6/7). Each PB2-I NIC manages its own PHY; no shared-address
    conflict. PCB + schematic global labels updated. *(2026-06-12)*
    - **Firmware/DT:** PHY2's bus must be brought up as `mdio-gpio` (bit-banged) on
        the two repurposed balls; verify they are GPIO-capable in the PB2-I pinmux.
- [x] **Wire the field-connector pins to their signals on Pilot** (connectors were
    all floating). Done per each footprint's Description pinout: SERVO-PWM pads 1–6
    → SERVO0–5 (PWM); ESC-TLM → UART_ESC_TX/RX; GPIO-A…F → GND/+3V3 (+ `GPIO_EXP_*`
    signal pin labeled); CAN-FD → CAN_H/CAN_L; RS-485 → RS485_A/B; PWR-IN → +5V/GND.
    *(2026-06-12)*
- [x] **Source the 6 `GPIO_EXP_A…F` signals via an I2C GPIO expander.** Added
    `U-GPIO` (PCA9555DB, SSOP-24, addr 0x20) on the existing I2C1 bus with a
    `C-GPIO` 100 nF decoupling cap; P0_0–P0_5 → GPIO_EXP_A–F. *(2026-06-12)*
    - [ ] Verify/add I2C1 pull-ups (≈4.7 kΩ to +3V3 on SDA/SCL) — none on cape;
        confirm whether the PB2-I provides them.
    - [ ] Finalise placement of U-GPIO/C-GPIO (added at a tentative location).
- [x] **Add an ESC-PWM output connector for DSHOT0–3.** Added `ESC-PWM`
    (JST-GH 5-pin SM05B): pins 1–4 → DSHOT0–3, pin 5 → GND. *(2026-06-12)*
    - [ ] Finalise ESC-PWM placement (added at a tentative location).
- [ ] **Reconcile Pilot.md §14 field-connector table with the actual PCB
    connectors** (PCB has SERVO-PWM 1×8 + GPIO-A…F + ESC-TLM; §14 lists J_SERVO/
    J_ESC/J_GPS/J_ENC/J_SBUS/J_VBAT/J_FAN). Bring the doc and board into agreement.
- [ ] **Wire the MIL-1553 connector + transformer.** `MIL-1553` connector and the
    `1553-XFM` transformer coupling to the bus are unwired at the IC level; the
    driver/receiver (DS26LV31/32) are only partially netted.
- [ ] **Redesign the tamper mesh as a per-domain anti-tamper mesh (all 4 capes).**
    The current `TMESH_P`/`TMESH_N` cross-hatch grid on F.Cu/B.Cu shorts across SMD
    pads and across the isolated `GND2_*` domains (≈335 of Pilot's 465 DRC errors;
    similar on XO). Rework as one monitored mesh net per isolation region
    (secure/`GND` + per-`GND2_CAN`/`GND2_ETH`/`GND2_RS485` field side), keeping the
    0.5 mm `ISOLATION` creepage moat clear between domains. **BLOCKS DRC-clean.**
    Quantified against the IEC 62368-1 reinforced-insulation requirement in §0.6
    (2026-06-22): 13 genuine cross-domain `TMESH`-vs-`GND2_*` violations on Pilot
    (min 0.125 mm), 9 on XO (min 0.0 mm/direct contact) — both far short of the
    0.5 mm netclass minimum and the ≥ 8 mm physical creepage target in `Pilot.md`.
- [ ] **Carry the tamper signal over the link for the TPM-less boards.** Flight Engineer
    and Commo have no local TPM: route Flight Engineer's mesh signal to Pilot and
    Commo's to XO over the inter-board link.
- [ ] **Route the rearranged capes.** The manual component reseat left ~60 signal
    nets per cape unrouted (7 power/ground nets are planes). Headless freerouting
    was **not** usable (see toolchain findings in `avionics/kicad/README.md`):
    KiCad 9.0.2 `ExportSpecctraDSN` is broken in standalone Python, and freerouting
    2.1 headless never self-exits and emits incomplete SES. **Finish routing in the
    KiCad GUI**; route the impedance-controlled Ethernet pairs interactively
    (length-matched, 100 Ω ±10% MDI). **BLOCKS gerbers / fab.**
- [ ] **Clear residual DRC after mesh + routing** (counts measured 2026-06-12,
    error+warning): Pilot 465 / 121 unconnected, XO 554 / 146, Commo 421 /
    160, Flight Engineer 221 / 181. Remaining types after the mesh fix are mostly
    silk-over-copper, text-height, courtyard-overlap, and lib-footprint mismatch.

- [ ] **Finish Pilot PCB (CAPE-A-2) close-out pass:**
    - [ ] Verify every external-facing connector (SERVO-PWM, ESC-PWM, MIL-1553, CAN-FD,
        RS-485, ETH) is a shielded-shell part with shell tied to PGND — audit against
        the footprint Description pinout already documented at §1.2 line ~1340.
    - [ ] Run ERC/DRC net-validity pass — confirm zero unconnected nets outside the
        13-net Commo-style residual list; cross-check against the 465/121 DRC count
        already logged for Pilot at §1.2.
    - [ ] Verify all ferrite beads are placed at each digital/RF section boundary and
        on +5V/+3V3 entering from off-board connectors (pattern already used on
        Commo's +5V boundary, §1.2/§1.3 Phase 3).
    - [ ] Verify isolation caps/creepage moat (0.5 mm `ISOLATION`) are intact after the
        per-domain tamper-mesh rework (§1.2, "Redesign the tamper mesh").
- [ ] **Pilot ISOW §13.1 compliance re-floorplan (owner 2026-10-12: §13.1 is binding).**
    TI SLLSFF7A §13.1 p. 36 [REF-SENSOR-009] / SLLSF86C §13.1 p. 41 [REF-SENSOR-010]: 10 nF
    0402 < 1 mm from VISOOUT (12) / GND2 (11), bulk >= 10 uF 2-4 mm away, BLM15EX331SN1 beads
    VISOOUT->VISOIN and GND2->GISOIN [REF-SENSOR-043], and **no metal traces or ground pour
    within 4 mm of pins 11/12 on any layer**. Analysis 2026-10-12 (Claude Opus 5.5): the B.Cu
    PB2 rail pads (inner rows end y 96.6 / 113.4 mm) leave one strip where the bubbles can sit,
    and PWR-IN's THT pads + T-ETH2 leave ~0 mm spare across it, so the two 4 mm bubbles displace
    the 3V3 buck, IMU/BARO, GPS and the 1553 transceiver. Owner chose to move GNSS off the cape
    (next item). Measured from pad edge to metal edge (conservative).
    - [x] Schematic: four beads, split `*_DCDC` nets, 0402 HF caps, MODE -> GND2 (d1196555).
    - [x] Schematic: MAX-M10S, bias-T, J-ANT, C-GPS1/2 removed; P1-31/32, P2-9/10 NC.
    - [x] Schematic + land: 3V3 buck TPS62933 + WE-MAPI 3015 -> **TI TPSM828224SILR** fixed-3.3 V,
        2 A MicroSiP module [REF-PWR-008] (owner 2026-10-17; Claude Opus 5.5). FB to VOUT, EN to
        VIN, PG open; R-EN3, C-BST, C-SS, L-3V3, R-FB3H/L removed; CIN/COUT to 0603 TI Table 9-1
        parts (CIN later moved to the 22 uF part, below); land `TI_SIL0010D_uSiP-10_2.0x2.5mm_P0.5mm` (solder-mask-defined, STEP linked);
        111 parts, ERC 0. PCB swapped in place by `scripts/inject_tpsm828224.py`.
    - [x] PCB: `U-3V3` at B (138.0, 100.6) with CIN south, COUT east/north, hand-placed per
        SLVSEP0F sec 11.1 (2026-10-17).
    - [x] C-3V3-O1/O2 DC bias (2026-10-17): Taiyo Yuden MSASJ168BC6226MTNA01 curve [REF-PWR-011]
        -51 % at 3.333 V -> worst case 7.2 uF per cap (tol, bias, X6S 105 C) >= 5 uF.
    - [x] C-3V3-IN DC bias (2026-10-17): Murata GRM188Z71A106MA73 [REF-PWR-012] fails worst case
        (2.65 uF at 5.5 V < 3 uF); owner approved the swap to MSASJ168BC6226MTNA01 22 uF 6.3 V X6S
        [REF-PWR-011] -> 4.2 uF worst. Same 0603 land; schematic ERC 0, PCB value updated.
    - [x] TPSM828224 3D body pin-1 orientation: done 2026-10-17 (kicad-cli top render of the
        footprint alone); the body's pin-1 dot sits over pad 1, on the silk pin-1 marker side.
    - [x] PCB: both isolators rot 180 at (135.1, 107.1) / (150.5, 107.1); GNSS removal synced
        to the PCB (2026-10-17, `scripts/refloorplan_keep_copper.sh`, owner chose keep-copper).
    - [x] PCB: 21 displaced parts re-placed (supply caps follow their moved parent; X-50M first;
        C-1553C hand-placed at VCCP; 2.75 mm M2.5 hole keep-out); ISO_BAND / GND2 islands /
        notched planes / BUBBLE_CAN + BUBBLE_485 redrawn by `scripts/iso_zones_pilot.py`, DRC
        rules `bubble_*` + named §13.1 courtyard exemption in Pilot.kicad_dru.
    - [ ] OWNER DECISION — logic parts on B.Cu under the isolated F/inner domains: X-50M
        (50 MHz), C-50M, BARO + caps, HI-6138 west pads, X2Y-RS485 GND pad sit below GND2_*
        island copper with no logic plane and no legal via (band). EMC: their returns couple to
        the isolated grounds. Options: accept; shrink the F domains; or move them (board full).
    - [ ] PCB: B.Cu ground under the IMU's new west-edge site (F, 126.45 / 95.86) and the
        C-P1-CTD1/2 pads 2.48 / 2.57 mm from H2 (M2.5 standoff keep-out 2.75 mm, owner placement).
    - [ ] PCB: PGND fence PARTIAL (`scripts/fence_pgnd_pilot.py`): 20 vias + F/B ring in 8 runs tied to
        H1-H4, ~40 of 180 mm perimeter; the rest is PB2 rail pads, edge connectors, the band.
        Re-run after the remaining routing to fill any edge it frees.
    - [ ] PCB: re-route. 2026-10-17: DRC 0 errors, parity 0, 107 unconnected (66 signal, 41
        plane) after grid router + rip-up rounds; the signal core (RMII0/1, MDC/MDIO, PHY
        reset/INT, SPI fan-in, RS485 logic) was already open on the owner's board (73) and is
        walled in at ETH1/ETH2-PHY and the P2 rail under the band. Needs KiCad interactive
        routing or a regional strip-and-reroute of the PHY corridor (owner decision).
    - [ ] Pilot.md, PROJECT_INDEX, memory updated; device tree drops the GPS UART.
- [ ] **Isolated CAN-FD GPS pucks for the two dorsal GPS cups (owner 2026-10-12).** Replaces the
    on-cape MAX-M10S (previous item). Each puck: patch antenna in the existing O36 x 6 mm flush
    recess; electronics board under the cup floor through the O6.5 mm SMA bore. Envelope check
    2026-10-12 (scratch run of `tools/cargo_layout_fit.py` geometry, Claude Opus 5.5): **O28 mm x
    8 mm** fits under each cup centred 4 mm aft of the station (X -135 / -205, Y 96), 1 mm to the
    skin, 2 mm to the battery-cradle aft hanger and the aft-node cable zone; O30 does not fit.
    - [ ] Owner chose an **isolated** puck (ISOW1044 in the puck). Prove it fits: ISOW1044
        SOIC-20W + its own §13.1 4 mm bubble + MAX-M10S + MSPM0G3518 + OPTIGA Trust M + LDO +
        GH connector on a O28 mm board, and keep the isolated DC-DC away from the GNSS front end.
    - [ ] Power: the Pilot's ISOW1044 offers only 20 mA extra on VISOOUT (SLLSFF7A §8.9), so each
        puck needs its own 5 V feed from the cargo rail (harness + connector pinout).
    - [ ] Add the puck as a fleet trust-module node (§1.9.2): own MCU + secure element.
    - [ ] Schematic, PCB, enclosure/cup adapter, `tools/cargo_layout_fit.py` envelope + gate.
- [ ] **Add SBUS/UART DIP switch to Pilot** — add a 2-position DIP (or solder-jumper
    pair) to select SBUS vs. plain UART framing on the existing J_SBUS-equivalent
    pad, matching the J_SBUS line item already in Pilot.md §14's field-connector
    table (§1.2, "Reconcile Pilot.md §14...").
- [ ] **Generate Pilot gerbers** — the 2026-09-19 schematic-first Rev T
    rebuild (`avionics/kicad/Pilot/Pilot.md`) superseded the pre-Rev-T design. **Correction
    2026-09-27: `Pilot.kicad_pcb` was re-checked and does exist** (538 KB, current) — the
    "no longer exists" claim below was stale/wrong, not a description of a real gap; the file
    was simply regenerated under the same name, not deleted.
    Rev T is fully generated (`gen_pilot_sch.py`/`gen_pilot_footprints.py`/
    `gen_pilot_pcb.py`), datasheet-verified, 6-layer, ERC 0 / DRC 0 at 0%
    routed (388 connections). Two freerouting attempts via the Specctra bridge
    did not produce a safe result — the second completed but introduced 9 real
    shorts + 118 hole-clearance violations around the dense PocketBeagle 2
    headers and was rejected; see `Pilot.md` "Routing status" for the full
    account. Remaining: route (recommend KiCad's interactive push-and-shove
    router, which applies this project's live DRC rules including the
    isolation-domain `ISO_BAND` rule, unlike the batch Specctra round-trip),
    then `bash scripts/export_pilot_gerbers.sh`.
    - **BLOCKS Pilot fab order**
- [ ] **Generate XO/TACCO gerbers** — a `gerbers/TACCO/` set exists but its embedded
    `G04 ... date` line reads 2026-06-04, predating the 2026-09-20 schematic-first rebuild,
    the WIOE5/mLRS radio swap, and the Type2EL Wi-Fi/BT/Zigbee consolidation — confirmed
    stale (2026-09-27, checked embedded date, not filesystem mtime which just reflects
    checkout time). Regenerate against the current `TACCO.kicad_pcb` once routing/DRC
    closeout (§1.10 U7) is done.
    - **BLOCKS TACCO fab order**

- [x] remove Wi-Fi, sik, and loRa antennas from XO. Use filtered chokes on rf lines to route all
    RF signals from antennas to Wi-Fi, lora, zigbee,and sik xcvr circuits on XO, and/or use uart
    or i2c with filtering to connect isolated xcvrs to the cape. **Done (2026-06-05):** Added §13
    antenna filter chains to TACCO.kicad_sch — each radio ANT pin now routes through a Johanson
    BPF (FL_LORA/FL_SIK: 0915LP15B0100E; FL_WIFI: 2450BP15B050E) and RCLAMP0502B ESD shunt to a
    dedicated SMA connector (J_SMA_LORA, J_SMA_WIFI, J_SMA_SIK). SiK uses Hirose U.FL J_SIK_ANT for
    module pigtail. All connector shells PGND. See TACCO.md §13.
- [x] **Re-evaluate space / restore Ethernet to XO** — One DP83825I EMI-hardened PHY
    added to XO at Rev R (introduced Rev Q); J_ETH_B connector populated. Board has adequate
    space; RF SMA connectors remain. *(done 2026-06-07)*
- [x] **Zigbee RF chain gap (flagged 2026-06-22, cross-ref §1.4.2) — CLOSED, not via the
    CC2652R7+diplexer route this item originally specified.** Reconciled 2026-09-27: the
    2026-09-21 Murata Type2EL swap (see below, "XO WiFi/BT + Zigbee consolidated onto one
    module") closed this same gap by a different, owner-directed path — replacing WL1837MOD
    with an NXP IW612-based module (Murata Type2EL / LBES5PL2EL-923) that natively adds IEEE
    802.15.4 (Zigbee) on the existing shared antenna, instead of adding a discrete CC2652R7 +
    diplexer as originally planned here. Verified against `TACCO.kicad_sch`/`.kicad_pcb`: no
    CC2652R7, but 15 schematic + 5 PCB references to the Type2EL module including its
    `Murata_Type2EL_LGA107` footprint. This checkbox and the "XO WiFi/BT + Zigbee consolidated"
    entry were tracking the same fact from two different checklist entries; closing this one
    as a duplicate rather than re-doing the CC2652R7 design.
- [x] **REJECTED (2026-09-20): mLRS as XO's SiK radio-link protocol.** Considered during the
    XO board-area rebuild (via `ce-ideate`) as a possible replacement for the RFD900ux-SMT SiK
    channel. XO's and Commo's radio links provide **redundant multiband connectivity between
    the UAV and its human-piloted ground station** — the whole point is path diversity across
    independent hardware/modulation families. mLRS is a real, mature open-source project
    (github.com/olliw42/mLRS) with genuinely competitive range/performance, but it runs on
    Semtech LoRa silicon (SX1280/1276/1262/etc.) — the **same radio family Commo's LoRa link
    already uses**. Adopting it on XO would collapse two supposedly-independent links onto one
    LoRa failure domain (interference, jamming, a LoRa-specific hardware defect), defeating the
    redundancy the two-link architecture exists to provide. Also a poor fit operationally: mLRS
    is architected as an MCU+radio-chip *subsystem* (not a self-contained module like SiK), which
    would have made XO's board-area crisis worse, not better. Kept for the record per the
    project's "explicit rejection with reasons" ideation discipline — do not re-propose mLRS for
    XO or any other node carrying a LoRa link elsewhere in the fleet.
- [x] **DONE (approved 2026-09-21, implemented and verified 2026-09-27): relocate SiK (RFD900ux-SMT) from XO to Commo, remove
    Commo's LoRa (RFM95W).**

    **Radio swap at a glance (unambiguous summary — both boards changed radios,
    not just Commo):**

    | Board | Radio before | Radio after |
    |---|---|---|
    | XO (renamed **TACCO** 2026-09-22) | SiK modem, RFD900ux-SMT | **mLRS on a Seeed Wio-E5 (STM32WLE5) module** |
    | Commo | LoRa modem, RFM95W | **SiK modem, RFD900ux-SMT** (the same physical-design unit XO gave up) |

    Net effect on the fleet: still exactly one SiK-class link and one
    LoRa-family link (mLRS runs on LoRa-class silicon), just swapped between
    the two radio-comms capes rather than added or removed. See
    `avionics/kicad/TACCO/TACCO.md` and `avionics/kicad/Commo/Commo.md` for
    each board's own status note on this swap, and
    `avionics/kicad/TACCO/reports/HDD.md` / `avionics/kicad/Commo/reports/HDD.md`
    for the generated hardware design descriptions.

    Considered via `ce-ideate` (targeted
    primary-source analysis, not the full multi-agent dispatch — disclosed).
    Initial pass flagged three findings and rejected the idea; the owner
    overruled two of the three as acceptable tradeoffs and asked for the
    third to be checked against real numbers:
    - **Firmware rewrite (SiK↔LoRa/AX.25 protocol stacks on both hosts):
      owner-accepted.** Rationale: "firmware can be rewritten more easily
      than parts can be manufactured" — a real cost, but not a blocker.
    - **Commo's power budget (250 mA documented vs SiK's 1A Tx peak):
      owner-accepted.** Commo is already the fleet's high-power radio-comms
      cape by design; per the owner, absorbing SiK's draw there is "mostly
      just moving the power requirement from XO, not building a whole new
      power distribution rail from the batteries."
    - **Footprint headroom: CHECKED, confirmed sufficient.** Commo's actual
      `Commo.kicad_pcb` (not estimated) carries 81 footprints at **1342.7
      mm^2 (34.9%)** of the 3850 mm^2 two-sided ceiling — LoRa's own real
      placed courtyard is 307.4 mm^2 (not the 289 mm^2 footprint-generator
      estimate used in the first pass). Remove LoRa -> 1035.3 mm^2 (26.9%);
      add RFD900ux-SMT (666.0 mm^2, same courtyard as XO's own instance) ->
      **1701.3 mm^2 (44.2%)** — comfortably under the ~70% guideline ceiling
      for Commo's 4-layer stackup (`Commo.md` "Layer stackup: 4-layer"),
      leaving ~994 mm^2 of headroom even against that conservative bar.
      Commo was never remotely area-constrained the way XO is.
    **Resolved 2026-09-21 — XO's replacement link decided: mLRS on a Seeed
    Wio-E5 module.** Removing SiK from XO clears ~666 mm^2 there; what fills
    the slot was a separate decision from the earlier mLRS-for-SiK rejection
    (that rejection assumed XO would still carry a SiK-class self-contained
    modem in parallel with a new LoRa-family link, collapsing path diversity
    — here XO no longer carries SiK at all, so a LoRa-family link on XO does
    not collapse anything; the fleet still ends up with one SiK-class link
    (now on Commo) and one LoRa-class link (now on XO), same split as today).
    - **mLRS vs. bare LoRa+custom firmware:** mLRS chosen — closest
      like-for-like replacement for what SiK actually did (MAVLink-transparent
      telemetry + bidirectional RC + frequency hopping, out of the box,
      github.com/olliw42/mLRS), vs. writing a new protocol stack from scratch.
    - **Target MCU: STM32WLE5 (mLRS's own primary-supported target), NOT a
      tiny non-ARM MCU.** A CH32V006-class RISC-V MCU was considered and
      rejected: mLRS's firmware is confirmed ARM-only (STM32F103/G4/L4/F3/
      WLE5, or ESP32/ESP8285) with **no RISC-V support in the codebase at
      all** — this is a firmware-architecture hard-stop, not a size
      tradeoff, and CH32V006 also has no integrated radio (would still need
      a separate discrete Semtech LoRa chip) and only 8KB RAM vs. the
      32-64KB SRAM mLRS's codebase assumes. STM32WLE5 has the LoRa radio
      **integrated in the die** (verified against ST's own datasheet,
      `avionics/datasheets/st/stm32wle5jc.pdf`): UFQFPN48 (7x7mm) or UFBGA73
      (5x5mm) package, up to 256KB flash / 64KB SRAM — single-chip courtyard
      ~36-64mm^2, smaller than the bare RFM95W module (289 mm^2) it's
      replacing, and a rounding error against the ~666 mm^2 SiK frees up.
    - **Hardware form factor: pre-certified module (Seeed Wio-E5), not a
      bare-chip layout.** Considered Seeed Wio-E5 vs. EByte E77-MBL (mLRS's
      two suggested "easy" pre-certified options) on supply-chain grounds:
      EByte is Chengdu Ebyte Electronic Technology Co., Ltd. (Chengdu,
      China) with no public schematics/design files. Seeed Wio-E5 is
      designed by Seeed Technology Co., Ltd. (Shenzhen, China HQ; US offices
      in Austin/San Francisco are sales/support only, not manufacturing —
      no US fab exists for this product) but **publishes full open-source
      schematics/KiCad source/documentation** for the module itself, and the
      underlying silicon (STM32WLE5) is from STMicroelectronics N.V., a
      company incorporated in the Netherlands — satisfies the project's
      source-control requirement on the chip even though final module
      assembly is in China. **Owner's call**, made explicitly on these
      tradeoffs (open documentation + EU-domiciled silicon outweighing
      Chinese module assembly, vs. EByte's closed documentation with no
      offsetting benefit).
    **Implemented 2026-09-21 — both boards' schematics rebuilt, ERC 0 on
    both.** XO: `gen_xo_sch.py` regenerated with WIOE5 (mLRS/Wio-E5) IC
    entry replacing the SIK entry, plus a second TPS62933 regulator
    (`U-1V8RF`) sharing the RF 1.8V rail instead of a separate TLV75718
    LDO (owner's "one bigger regulator, not two" call) — `kicad-cli sch
    erc` = **0 violations**. Commo: since `gen_commo_sch.py` is PCB-first
    and confirmed drifted (do not re-run), the LoRa->SiK swap was done via
    a new one-off script, `avionics/kicad/Commo/scripts/swap_lora_for_sik.py`
    (direct S-expression lib_symbol + instance + wiring surgery, matching
    Commo's existing per-part symbol convention). Also fixed, in the same
    pass, 2 pre-existing dangling-net bugs unmasked once the swap's
    incidental ERC improvements exposed them clearly: `RF_ANT_SW` (a T/R
    switch antenna pin) was on a differently-named net one row away from
    the already-working ANT filter chain — renamed to merge; and
    `PA_EMIT`/`U3B` emitter-degeneration resistor was in-circuit but the
    "PA 100mW" (2N3866) transistor's own emitter pin was wired straight to
    GND, bypassing the resistor — rewired onto `PA_EMIT`. 37 PB2-header
    passthrough signals genuinely unused by Commo (RMII0/1_*, SDIO_*,
    PWM_CH*, WINCH_*, LOAD_CELL_*, TPM_*, PHY1_*, I2C0_*, MCAN1_*, RS485_*,
    CAN_STB, PRU_1553_*) were converted from `global_label` to `no_connect`,
    matching the same-meaning convention already proven ERC-clean on Pilot
    and XO. `DDS_FSYNC` (the MCP4921 TX DAC's SPI chip-select, previously
    never routed to a controller pin) was wired to PB2-P1 pin 26 — the
    exact pin freed by the LoRa->SiK swap (was `SPI1_CS_LORA`, now unused
    since SiK talks UART not SPI) — **owner's explicit call** (asked
    directly rather than guessing a GPIO assignment). `kicad-cli sch erc`
    = **0 violations** on Commo too (down from 45: 43 pre-existing +
    3 incidentally introduced then fixed by the swap itself).
    **PCB sync (schematic-driving-PCB, not the reverse):** XO's PCB
    regenerated via `gen_xo_pcb.py` (143 footprints, 135 nets; 86.1% of
    the 2-sided area ceiling; DRC 169 violations/0 schematic-parity
    issues — residual violations are the pre-existing 41-footprint
    unplaced backlog, not new). Commo's PCB (no reliable generator exists
    for it either) was synced via direct `pcbnew` Python scripting: removed
    the old RFM95W footprint, added the 8 new SIK-chain footprints (SIK +
    6 passives + MMCX jack), matched nets 1:1 to the schematic (verified
    against the real `Commo:S_SIK` lib_symbol pin table, not guessed).
    While placing the SIK footprint, DRC caught a real, previously-latent
    footprint-geometry bug in `gen_xo_footprints.py`'s `rfd900ux_smt()`:
    the estimated 1.9mm pad pitch (flagged "NOT pixel-verified" in that
    function's own docstring) was replaced with the real Table 6-1 value
    (A=2mm, confirmed against "RFD900ux DataSheet v1.2.pdf" p.11 — 13
    gaps x 2mm + 1.5mm margins each side = 29mm body height, exact match),
    and the pad's width/height (B=2.4mm depth-into-board, C=1mm along-edge)
    had been assigned to the wrong axis, causing every adjacent castellated
    pad to short into its neighbor — fixed and confirmed via DRC (the
    SIK-internal `shorting_items` count dropped to 0 after the fix).
    **Known residual, disclosed, not silently papered over:** Commo's
    existing hand-placed layout is extremely dense (88 footprints in
    55.1x35.1mm) and has no contiguous free region large enough for the
    21x29mm SIK module without touching an existing neighbor in any
    orientation — the aggregate-area headroom computed above (46.1% used
    of the 2-sided ceiling post-swap) does not by itself guarantee a 2D
    placement fits. Placed SIK rotated to minimize the conflict (fits
    cleanly between the PB2-P1/PB2-P2 connector rows; the SIK-internal
    pad-pitch bug is fixed) but its GND thermal pad and edge pads still
    partially overlap ETH-PHY's and T-ETH's back-layer footprints —
    `kicad-cli pcb drc --schematic-parity` on Commo: 0 net conflicts,
    0 missing/extra footprints (down from 8 missing + 1 extra), 262
    ordinary DRC violations (up from a 160 pre-existing baseline — the
    increase is the disclosed placement-density cost of fitting 8 new
    parts into an already-packed board, not a hidden regression), 93
    schematic-parity issues remaining (down from 136; all residual ones
    are either the pre-existing `footprint_symbol_mismatch` noise from
    Commo's own established convention of leaving symbols' Footprint
    property blank, or 4 pre-existing duplicate mounting-hole footprints
    unrelated to this work). **Real physical floorplan rework — moving
    ETH-PHY/T-ETH or re-siting SIK's neighbors — is still needed before
    Commo's PCB is fab-ready; flagging for the owner's hand-placement
    pass, per the same convention already accepted for XO's own PCB.**
    - **Re-verified 2026-09-27 against the actual PCB coordinates** (no kicad-cli in this
      environment, so by footprint position + courtyard size rather than a live DRC run):
      SIK (anchor 120, 117.5) sits 27–28.5 mm away from ETH-PHY (148.5, 123.5) and T-ETH
      (147, 108.5), well clear of any plausible bounding-box overlap even at SIK's full
      21×29 mm courtyard. The specific "SIK's GND thermal pad and edge pads still partially
      overlap ETH-PHY's/T-ETH's back-layer footprints" claim above looks stale/overstated —
      geometry does not currently support it. The 93/262 DRC-violation counts themselves
      could not be reproduced from static text either way. **Recommend the owner re-run
      `kicad-cli pcb drc --schematic-parity` on Commo before relying on this paragraph's
      numbers**; leaving this item open pending that confirmation rather than closing it
      on unverified figures.
- [x] **REJECTED (2026-09-21, initial pass, superseded above): swap XO's SiK
    (RFD900ux-SMT) with Commo's LoRa (RFM95W) between boards** on three
    findings — footprint asymmetry (RFD900ux-SMT's 666 mm^2 courtyard vs
    RFM95W's then-estimated 289 mm^2, a 2.3x ratio), Commo's documented 250 mA
    power budget vs SiK's 1A Tx peak, and the SiK-modem-vs-bare-LoRa-chip
    firmware rewrite on both hosts. **Superseded same day**: the owner
    accepted the power and firmware costs as tradeoffs worth taking, and
    asked for the footprint finding specifically to be re-checked against
    Commo's real PCB rather than estimated — see the approved-direction entry
    above for the confirmed numbers. Kept for the record (not deleted) per
    the project's "explicit rejection with reasons" discipline — the
    reasoning here was sound given what was checked at the time; it just
    turned out the one load-bearing finding (footprint) didn't hold once
    verified against Commo's actual PCB instead of a generic estimate.

- [x] **SUPERSEDED 2026-09-29 by Rev T (§1.2a.2) — Generate Commo gerbers** — a gerbers/`XCVR-49MHZ-2` set exists but its embedded
    `CreationDate` (2026-06-04) and the PCB's own title-block date (2026-06-03) both predate
    the 2026-09-21 LoRa→SiK radio swap — confirmed stale (2026-09-27). Regenerate against
    the current `Commo.kicad_pcb` once the floorplan rework above and DRC closeout (§1.10 U7)
    are done.
    - **BLOCKS Commo fab order**
- [ ] **FCC Part 15 §15.235 pre-compliance checklist for Commo** — document field strength
    (≤10,000 µV/m at 3 m per §15.235(a), ≈30 µW / −15.2 dBm EIRP-equivalent — requires firmware
    PA limit, not the ≤100 mW previously assumed), harmonic suppression ≥40 dBc at 2nd/3rd
    harmonics (§15.235(b)/§15.209), FCC ID silkscreen labeling block (§2.803/§15.19).  Not
    Part 95 — see §0.1.
- [ ] **EMI isolation validation checklist** — verify isolation barrier clearance: ISOW1044BDFMR
    5 kV working voltage; ADM2795EBRWZ 5 kV working voltage; measure CMRR at 1 MHz on CAN and
    RS-485 channels; verify differential impedance 100 Ω ±10% on ETH MDI traces.

- [ ] **Merge `claude/cape-em-harsh-variants-9Yfr1` → master** after gerbers pass DRC and
    pre-compliance checklist is signed off.

- [ ] **Design Faraday cages / boxes to protect all PCBs** — minimize weight/space while meeting
    the 500 W/m² design objective. Placeholder geometry (FAR-CAGE-AV 76×56×88 mm, FAR-GASKET-AV,
    FAR-FAN-40, FAR-EMI-VENT-40, FAR-BOND-STRAP, FAR-FT-PANEL, FAR-FERRITE-4MM) already exists at
    §1.1.5 (364 g / 0.80 lbm system total) — these sub-tasks convert the placeholders into
    real, build-ready enclosures:
    - [ ] **Shepherd's Room cage** (Cape-A-2 + TACCO stack, no Commo) — final wall thickness,
        seam/gasket detail, FAR-FAN-40 mount, FAR-EMI-VENT-40 vent location.
    - [ ] **Inara's Shuttle cage** (Cape-A-2 + TACCO stack, no Commo) — same scope as Shepherd's.
    - [ ] **River's Room cage** (Cape-A-2 + TACCO + Commo stack) — add Commo board clearance and
        LoRa/49 MHz feedthrough ports to the FAR-FT-PANEL design.
    - [ ] **Simon's Medbay cage** (Cape-A-2 + TACCO + Commo stack) — same scope as River's Room.
    - [ ] **Flight Engineer (PDB) enclosure** — verify whether the PDB needs a full Faraday cage or only a
        bond strap to the keel ground plane (no TPM/RF on Flight Engineer; see §1.2 "Carry the tamper
        signal over the link for the TPM-less boards").
    - [ ] Bond each cage to the airframe ground reference via FAR-BOND-STRAP with no second
        return path (avoid ground loops per §1.4.1 prose constraint).
    - [ ] Re-run the §1.1.5 mass budget after all 5 enclosures are finalized — confirm cumulative
        T/W stays ≥1.2 (currently estimated ~1.19–1.25, §1.1.5).

- [ ] **Specify / implement tightly twisted pair bonded shielded wiring throughout the aircraft** —
    per-bus-type wiring spec (duplicates the per-bus breakdown tracked at §1.4.3/§1.4.4; this
    item is the airframe-wide harness/cable-selection pass, those are the connector/pinout pass):
    - [ ] CAN FD trunk (inter-node ring) — shielded twisted pair, 120 Ω characteristic impedance,
        drain wire bonded at each node chassis, not floating mid-run.
    - [ ] RS-485 trunk — shielded twisted pair, 120 Ω, daisy-chain topology, end termination at
        the two physical bus ends only.
    - [ ] MIL-STD-1553B bus — twinax/twisted-shielded-pair per the existing 1553-XFM transformer
        coupling spec (§1.2), stub length ≤1 ft from coupler to RT.
    - [ ] Ethernet (CPSW3G ring) — shielded Cat5e/Cat6, 100 Ω ±10% MDI pairs matching the
        impedance-controlled PCB traces already specified at §1.2.
    - [ ] Servo/PWM and ESC telemetry leads — twisted pair, routed ≥5 mm from RF/antenna runs.
    - [ ] Power harness (14 AWG nacelle feeds, battery-to-Flight Engineer) — twisted where co-routed with
        signal wiring; ferrite bead at each digital/RF section boundary crossing.

---

### Pilot footprint verification and schematic-first rebuild (2026-07-13/14) — SUPERSEDED

**Closed out 2026-09-27.** Everything below this heading described the pre-Rev-T Pilot design
(schematic = stale DP83825I baseline, PCB = ADIN1300/ISO6442 with broken net↔pin mapping). The
"Pilot SCHEMATIC-FIRST REBUILD" it called for actually landed as **Rev T (2026-09-19)** —
verified 2026-09-27 directly against the current `Pilot.kicad_sch`/`.kicad_pcb`: the file is
already named `Pilot.kicad_sch` (the promote-from-`Wash_rebuild.kicad_sch` step is done), and
every part this section asked for is present with a real footprint:

- [x] TPM SLB9672: now `QFN-32-1EP_5x5mm_P0.5mm_EP3.6x3.6mm` (matches spec exactly).
- [x] BARO BMP388: now `Bosch_BMP388_LGA-10_2x2mm` (matches spec exactly).
- [x] GPS: part changed to **MAX-M10S** (Rev T, external-antenna requirement) with a real
    `ublox_MAX` land pattern — moot rather than fixed in place, but the "2-pad blob" problem
    no longer exists.
- [x] ETH PHY: part changed to **DP83825I** (`Texas_RMQ0024A_WQFN-24-1EP_3x3mm`) — ADIN1300
    was dropped, so the ADIN1300 LFCSP-40 footprint fix is moot.
- [x] RS485: part changed to **ISOW1412DFMR** (fleet standardization) — ADM2795E was dropped,
    so its SOIC-16W footprint fix is moot.
- [x] 1553 transformer: part changed to **Premier Magnetics PM-DB2791S** (SMD), footprint
    `Xfmr_1553_SMD_0.40in_8pin` — SM-1553-11/THT is no longer the part; **not independently
    re-verified against the PM-DB2791S datasheet that SMD is the correct package for that
    specific part** (flagged, not re-checked here).
- [x] U-ISO-RX/TX ISO6442 net-mapping bug: **moot** — ISO6442 and the whole non-isolated ETH
    subcircuit it wired were dropped along with ADIN1300; Rev T's ETH isolation is a different
    design.
- [x] "Rewrite Pilot.md §§1-3 to as-built": done as part of Rev T's own doc rewrite.
- [ ] **CAN-TR/RS485 land pattern still genuinely unconfirmed.** Both ISOW1044 (CAN) and
    ISOW1412 (RS485) now use `Package_SO:SOIC-20W_7.5x12.8mm_P1.27mm` — the pin count (20) is
    now right (fixes the old 16-pad error), but this is a generic wide-SOIC land, not confirmed
    against either datasheet's specific "DFM" package outline/pitch. **Needs a datasheet
    land-pattern check before fab** — genuinely open, not closed by the rebuild.
- [x] X2Y caps / Molex Nano-Fit / JST GH part-number gaps: superseded — Rev T's BOM is a
    different part list; re-verify against Rev T's own BOM if/when it's assembled, not against
    this now-obsolete gap list.

### §1.9.3 — Trust-Module MCU/TPM Retarget (MSPM0G351x-Q1 + SLB 9672), 2026-08-03

*(Moved here 2026-09-15 from root `TODO.md` §1.2d, where this detail had lived with no `WBS.md` home — the only copy of these findings was in the open-items view. Root `WBS.md` §1.2d now indexes this section. See also `docs/WBS.md` §0.10.2 item 4.)*

Applied 2026-08-03 by `avionics/kicad/retarget_mspm0g351x_slb9672.py` (schematics) and
`avionics/kicad/retarget_pcb_footprints.py` (PCBs).  Parts per REF-SENSOR-017 and REF-SEC-002.

| Board | MCU | Package | TPM |
|---|---|---|---|
| Observer (observer) | `M0G3519QRGZRQ1` | 48-pin RGZ VQFN 7×7 | `SLB 9672AU2.0` |
| `CAN-PERIPH-GW-1` (gateway) | `M0G3518QRHBRQ1` | 32-pin RHB VQFN 5×5 | `SLB 9672AU2.0` |
| FlightEngineer (flight engineer) | `M0G3518QRHBRQ1` | 32-pin RHB VQFN 5×5 | `SLB 9672AU2.0` |

- [x] Verify the MSPM0G351x-Q1 RGZ-48 pin map against the MSPM0G350x it replaces —
      identical for all 48 pads plus the exposed pad (SLASFA6B Fig 6-5 vs SLASEX6C Fig 6-4).
- [x] Re-pinmux the gateway and FlightEngineer onto RHB-32, which bonds out PA0–PA27 only and has
      no PBx ports: RS485_TX→PA8 (UART1_TX PF2), RS485_RX→PA9 (UART1_RX PF2),
      RS485_DE→PA21, RS485_FLT_N→PA22, CANFD_FLT_N→PA23 (FlightEngineer),
      FLEX_PWM_IO→PA25 (TIMA0_C3 PF5), FLEX_BSHOT_IO→PA26 (TIMG8_C0 PF4).
- [x] Swap and re-anchor the PCB footprints on the gateway (U1_1/U1_2) and Observer (U3).
- [x] Tie the TPM exposed pad to GND on all three boards — the SLB9670 symbol omitted pad 33
      entirely, so it was floating (Infineon SLB9672 datasheet rev 1.3 §2.1.2 requires it).
- [x] Correct the MCU land pattern: the design used
      `QFN-48-1EP_7x7mm_P0.5mm_EP5.15x5.15mm`, which KiCad's own `descr` identifies as an
      **Analog Devices LTC legacy** outline. TI's RGZ0048F exposed pad is 4.1 mm square, so
      the old land overhung the package thermal pad by 0.525 mm per side.
- [x] Separate FlightEngineer's overlapping `U_MCU` / `U_TPM` symbols (17 pads shared a coordinate,
      shorting the SPI bus and tying MCU VCORE to TPM GND); `U_TPM` moved +34.29 mm.

**Open — blocks fabrication:**

- [ ] **Re-route the gateway MCU area.** U1_1/U1_2 went from 48 pads at 7×7 mm to 32 pads at
      5×5 mm, so every trace into them is dangling. Needs a manual placement/routing pass and
      a DRC sign-off before gerbers.
- [ ] **Confirm MSPM0G351x-Q1 errata and TRM applicability.** SLAZ742G covers MSPM0G3x0x /
      G1x0x / G3x0x-Q1 and does not enumerate MSPM0G3518/3519; SLAU846E contains no
      occurrence of either part number. Obtain the correct errata/TRM for MSPM0G351x-Q1
      before firmware sign-off (REF-SENSOR-018 "requires verification").
- [ ] **Update firmware pinmux constants for the new family.** CAN moves from
      `CAN_TX`/`CAN_RX` PF5/PF6 to `CAN0_TX`/`CAN0_RX` **PF12**; PA15 offers `SPI1_CS2`
      (PF3) rather than `SPI1_CS0`; PB15/PB16 offered UART2 on the old part and UART7 on the
      new one (moot on the 32-pin boards, which now use UART1 on PA8/PA9). See §4.6.2.
- [ ] **Add the missing MCU support parts per SLAAE76E Table 1-1.** No board has the
      10 µF bulk C(VDD) local to the MCU (the gateway shares one 22 µF at the regulator and
      FlightEngineer's MCU has no local 100 nF at all), and none has the recommended NRST network —
      all three use a 10 kΩ pull-up with no 10 nF pull-down capacitor against the
      recommended 47 kΩ + 10 nF.
- [ ] **Add a pull-up on the gateway's PA0/PA1 FLEX UART.** PA0/PA1 are 5 V-tolerant
      open-drain on this family with no internal pull-up available, so `FLEX_UART_TX` cannot
      drive high without an external pull-up (SLASFA6B §9.1.1; SLAAE76E §8.5).
- [ ] **Pull PA18 down on the gateway and Observer.** PA18 is the default BSL invoke pin and is
      used as SPI MOSI on both boards; it floats during reset, so the part can enter BSL
      (SLAAE76E Table 1-1).
- [ ] **Add thermal vias under the MCU exposed pad.** Only gateway U1_1 has any (3);
      U1_2 and Observer U3 have none. TI requires the pad be soldered to a board thermal pad
      and recommends the 3×3 via pattern in the land-pattern drawing. *(Re-confirmed 2026-09-27
      by coordinate-matching all 165 vias in `CAN-PERIPH-GW-1.kicad_pcb`: 3 within 3mm of
      U1_1, 0 within 3mm of U1_2 — still exactly as stated.)*
- [x] **FlightEngineer's ground-net naming — CLOSED, no longer reproduces (verified 2026-09-27).**
      Re-checked directly against `FlightEngineer.kicad_sch`/`.kicad_pcb`/`.net`: zero occurrences
      of `CM2_OUT_N` anywhere in any of the three files. The board ground net is cleanly named
      `PGND` (~20 occurrences). A separate `S_CM2` current-monitor symbol exists but is not
      merged into the ground net. Either this was fixed in a later pass without closing the
      item, or the original finding didn't hold against the current files — either way, closing
      rather than re-doing a fix that's already reflected on disk.
- [ ] **Clean up FlightEngineer's dangling no-connect flags.** The retarget left ~30 `no_connect`
      markers that no longer sit on a pin (ERC warnings only; error count is unchanged at 0).
- [ ] **Close the Observer sch↔pcb parity gap.** `RS485_DE`, `RS485_TX` and `RS485_RX` exist on
      U3 in the schematic but not in the PCB net table; those pads were left unconnected
      rather than inventing net entries.
- [ ] **Place gateway lanes 3 and 4.** `U1_3`/`U1_4` and `U2_3`/`U2_4` exist in the
      schematic but are not on the PCB, so only two of the four tiled lanes were retargeted
      on the board.
- [x] **Commo, Pilot and TACCO (formerly Emma, Wash, XO) follow to the SLB 9672 — DONE,
      verified 2026-09-27.** All three now instantiate `SLB9672XU20`/`SLB 9672AU2.0` in both
      schematic and PCB with zero remaining `SLB9670` references anywhere in any of the six
      files checked (Pilot, TACCO, Commo × sch + pcb). This happened as part of each board's
      own later rebuild/rework (Pilot's Rev T schematic-first rebuild 2026-09-19, TACCO's
      2026-09-20 rebuild, Commo's 2026-09-21 radio swap), not as a dedicated follow-up to this
      item — closing it as accomplished rather than re-tasking work already done.

## §1.10 — Avionics close-out plan (2026-08-25-001), unit index

Owning plan: `docs/plans/2026-08-25-001-finish-avionics-plan.md`. These nine units
were listed in `avionics/TODO.md` from 2026-08-25 without a `WBS.md` home; added here
2026-09-15 so the generated `TODO.md` can carry them. Each unit's acceptance
criteria, skills gate and file list live in the plan; the per-board ERC/DRC backlog
they close over is §1.9.2 "Board status" above. **U1, U7 and U8 are on the
first-flight critical path** (`docs/FIRST_FLIGHT_READINESS.md` §3).

- [ ] **U1** — Retire Pilot `J_ESC`/`J_SERVO` PWM headers → CAN-FD/RS-485 actuator
    trunk (gates U2/U3/U6). ★
- [ ] **U2** — Open-Secure-ESC tilt controller (REF-ESC-001, build
    `6s/10A/BRUSHED_CAN_485_isolation`, 2026-09-17) as a self-signing node on the
    CAN-FD/RS-485 trunk: verify the gateway-signed AK7455 angle frame, publish
    telemetry and brake state; the `CAN-PERIPH-GW-1` `J_FLEX` bare-UART gap is
    now winch-only (REF-SENSOR-014).
- [ ] **U3** — Open-Secure-ESC 50A/6S `CAN_485_faraday` integration + PID governor
    rewrite off PRU/BDSHOT onto CAN-FD frames.
- [ ] **U4** — OpenServoCore SG90 TTL+CMAC bus finalize; re-check the REF-SENSOR-015
    upstream-maturity gate literally, not from memory.
- [ ] **U5** — Observer pitot-tube airspeed sensor (`J_PITOT`); remove Pilot's
    unbacked "airspeed sensor" claim. Datasheet pull precedes any REFERENCES.md edit.
- [ ] **U6** — Fleet host+message authentication wiring for ESC / brushed tilt
    controller / SG90 endpoints; one `secure-controller-assurance` mapping per
    endpoint class (the tilt endpoint is a brushed-ESC class since 2026-09-17,
    with the brake-release command class of `TILT_DRIVE_CONTROL_SPEC.md` §5.5).
- [ ] **U7** — Per-board ERC/DRC/gerber closeout (Pilot, XO, Commo, Flight Engineer,
    Observer, CAN-PERIPH-GW-1); runs after U1/U2/U3/U5 land on the boards. ★
    *Baseline 2026-09-26 (kicad-cli 9.0.2, errors+warnings): Pilot 0/0; TACCO
    ERC 0 / DRC 169; Commo 0 / 257 + 93 parity; Flight Engineer 0 / 31 + 2 parity;
    Observer 157 / 115 + 21 parity; CAN-PERIPH-GW-1 168 / 829 + 54 parity;
    ENC-NACELLE-1 52 / 4. Unrouted connections tracked separately (routing ≠ clean).*
    - [ ] **U7.1** — Shared, datasheet-verified symbol / footprint / 3D library in
        the SecureControllers repo (`kicad/libraries/`), consumed by every board via
        the `${SECURE_CONTROLLERS_LIB}` path variable (owner decision 2026-09-26).
        MPN-named symbols with real pin electrical types; stock `Device:*` passives.
        Replaces ~500 per-refdes `S_<ref>` symbols and board-prefixed names
        (`Observer_ISOW1044BDFMR`, `GW_ISOW1412`) that block reuse and have
        already drifted (ISOW1412, SLB 9672 pin 10/33, PRTR5V0U2X).
        *2026-09-26: SecureControllers `c61cf51` (branch `feat/shared-kicad-library`)
        — generator `tools/sclib.py`, 13 of ~75 parts verified with footprint
        pad checks + package-options ledger (`kicad/libraries/VERIFICATION.md`).*
        - [ ] U7.1a — Verify + add the remaining ~60 parts (Commo analog/RF,
            Flight Engineer power, TACCO radios/storage, Pilot sensors/GNSS,
            Observer KSZ9477/SoM, AK7455, connectors).
        - [ ] U7.1b — Datasheets not obtainable by download (mark "requires
            verification" until sourced): SN74LVC1G157, MBRD1045CT, RCLAMP0502B,
            MGA-82563, TG2520SMN, MMBT2222A, SMBJ33CA, 2N3866.
        - [ ] U7.1c — STEP models for every `SecureControllers.pretty` footprint;
            install `kicad-packages3d` on the build workstation (stock
            `${KICAD9_3DMODEL_DIR}` models are absent — owner action, needs root).
        - [x] U7.1d — Wurth 749010012A usage notice (excludes aviation use
            unless Wurth is informed). Owner decision 2026-09-26: keep the Wurth
            parts; notice quoted verbatim + "uncrewed aircraft only" on Pilot,
            TACCO, Commo, Flight Engineer, Observer (.md, schematic, PCB
            Cmts.User, title-block comments 8/9) via `tools/add_board_notices.py`
            [REF-SENSOR-028]. Generator-owned schematics (gen_*_sch.py) will drop
            the stamp on regeneration -- re-run the tool after any regen.
        - [ ] U7.1g — Catalogue the remaining uncited-but-used IDs
            REF-SENSOR-024/031/032/034/035/036 (020/021 catalogued on main 2026-09-29; 022-040 subset done
            2026-09-26); ICM-42688-P, PM-DB2791S, HI-1573, SLB 9672 public
            URLs require verification.
        - [x] U7.1e — TLV62569 FB/PG swap (gateway, Observer) and 3-pad SOT-23
            (Flight Engineer). Owner-approved 2026-09-26: all four TLV62569 ->
            TLV62569PDRLR (SOT-563) and Observer TLV75725 -> TLV75725PDRVR
            (WSON-6, EP to GND) via `tools/kicad_relink.py` (pin-name remap).
            Datasheet-driven fixes found on the way (TLV62569 Sec. 8.2.2.2, Eq. 2,
            VFB 0.6 V): gateway divider 10k/20k set 0.9 V -> 453k/100k (3.318 V);
            Observer dividers were placeholders -> 453k/100k (3V3), 100k/100k
            (1V2); Flight Engineer had EN on its own output and FB tied straight
            to +3V3 -> EN = +5V, divider R_H_FBT 453k / R_H_FBB 100k added.
            Flight Engineer parity 2 -> 0.
        - [x] U7.1j — Deprecated parts (owner 2026-09-26): RCLAMP0502B antenna
            clamps (TACCO D-ANT-WIOE5/D-ANT-RADIO, Commo D-ANT-SIK) ->
            Infineon ESD101-B1-02ELS 0201 (0.1 pF); RClamp0504FA rejected for
            RF (3 pF). MMBT2222A -> Nexperia PMBT2222A (drop-in). Commo MUX1
            (miswired SN74LVC1G157) -> SN74LVC1G3157DRYR, rewired per datasheet.
        - [x] U7.1m — Library extraction batch 2 (2026-09-27, Claude Sonnet 5):
            LMV331, MCP1703A, MCP4921, AO3400A, MBRD1045CT, SMAJ/SMBJ-TVS added
            (24 symbols total). Datasheets extracted for BMP388/ICM-42688-P/
            INA226/ATF16V8BQL/PM-DB2791S/W25Q128/749010012A already covered by
            REFERENCES.md entries; TOML library entries for those still pending.
        - [ ] U7.1n — ★ Commo ref "RX Demod" (Value "LM393 Comparator RX-AFSK
            Demodulator") is mislabeled: real TI LM393 has no 5-pin package
            (dual comparator, 8-pin minimum). The drawn symbol has 5 pins with
            NO output pin -- pin 5 is wired to GND instead of an output net.
            Likely meant to be a single comparator (LMV331-class, same part as
            the correctly-wired RSSI_CMP). Do not fabricate the intended output
            net -- trace AFSK demodulator design intent before relinking.
        - [ ] U7.1o — Remaining ~35 parts needing library entries (datasheets
            already in avionics/datasheets/, not yet extracted to TOML):
            ADIN1300BCPZ (40-pin PHY), BQ76930PWRQ1 (30-pin AFE), Wio-E5
            (STM32WLE5 module), LBES5PL2EL-923 (Type2EL Wi-Fi/BT module),
            Si5351A-B-GT, TG2520SMN, PE4259-63, MGA-82563, SN74LVC1G04,
            TFmini-S, MAX-M10S-00B, RFD900ux-SMT, TPS54540DDAR, TPS54620RGYT,
            TPS63031DSKR, W25Q128JVSIQ, ATF16V8BQL-15XI, PM-DB2791S,
            749010012A, BMP388, ICM-42688-P, INA226AIDGSR (REFERENCES.md
            entries exist for the last 7; TOML library entries still pending).
            Connectors/mechanical (lower priority, not yet started):
            PB2I-P1/P2 (PocketBeagle socket), TSM-108-01-L-DV, SM0xB-GHS-TB
            family, MMCX, U.FL, RPSMA, XH-7P, XT30/XT60, Nano-Fit, microSD,
            switches, mounting hardware.
        - [ ] U7.1k — STEP model for SecureControllers
            Infineon_TSSLP-2-4_0.62x0.32mm (0.62 x 0.32 x 0.31 mm, Fig. 10).
        - [ ] U7.1l — Commo reference designators contain spaces ("PA Drvr",
            "PA 100mW", ...); rename to standard refdes in the Commo pass.
        - [ ] U7.1h — Placement follow-ups from the swaps: gateway U_REG_3V3
            overlaps U1_1 (pre-existing); Observer R_FB3B/R_FB1T sit on
            C_VISO/C_VCORE (pre-existing).
        - [x] U7.1i — Stale-component cleanup: `tools/kicad_prune_stale.py`
            (kicad-cli parity driven; removes electrical extras/duplicates and
            only the copper they orphan; mechanical parts get board_only + MHn).
            Commo parity 93 -> 86, Observer 21 -> 17. Gateway: 423 pad-less
            copper items on stack 3/4 nets reported, not removed (U7.1h).
        - [ ] U7.1f — Observer 749010012A symbol/footprint is an invented 8-pin
            part; replace with the verified 16-lead part.
    - [x] **U7.2** — PRTR5V0U2X pinout/package blocker: **resolved 2026-09-27.**
        All 12 instances across Pilot/TACCO/FlightEngineer/Commo/Observer relinked
        to the shared SecureControllers PRTR5V0U2X (SOT143B, Table 2 pinout) via
        `tools/kicad_relink.py --rewire`, position/rotation preserved. ERC 0 on
        all 5 boards; parity flat/improved. Judgment call recorded, not fabricated:
        Observer's 5 Ethernet/CAN instances and Commo's 2 RF/UART instances had no
        VCC net in the original wrong-package design — VCC tied to local GND/PGND
        as a conservative fallback (line/ground clamping preserved, rail-clamp
        direction inert); flagged for design review, see commit `24f2c315`.
        One new mechanical-only DRC warning (Pilot TVS-CAN/C-IN1 courtyard overlap)
        left unresolved rather than guess a placement nudge blind — see U7.1h.
    - [ ] **U7.3** — Migrate the seven boards' `lib_id`s to the shared library
        (Pilot, TACCO, Commo, Flight Engineer, Observer, CAN-PERIPH-GW-1,
        ENC-NACELLE-1); schematic-to-PCB parity 0.
    - [ ] **U7.4** — ERC 0 and DRC 0 (errors + warnings) on all seven boards.
    - [ ] **U7.5** — Route remaining unrouted connections per board; gerbers.
    - [ ] **U7.6** — Per-board README / HDD (kidoc) + WBS/TODO status refresh.
- [ ] **U8** — Faraday cage / shielded-harness spec (still open). **Tamper-mesh creepage fix
    reframed 2026-09-27:** Rev T's own "Known gaps" note says the anti-tamper mesh was **not
    carried forward at all** in the rebuild — the "13 DRC violations, 0.125 mm vs 8 mm" figure
    described the old per-domain mesh on the now-superseded schematic/PCB and no longer applies
    to a mesh that doesn't exist on the current board. This is now an open **owner decision**
    (re-add the mesh to Rev T and re-fix the creepage violation, or accept Rev T without it) —
    not a numeric DRC fix to chase. ★
- [ ] **U9** — REFERENCES.md, WBS/TODO and `avionics/AGENTS.md` closeout for U1–U8.

### §1.10a — Bay A forward avionics items (2026-11-01)

Spec `docs/BAY_A_FWD_LAYOUT.md`; thermal `docs/BAY_A_FWD_THERMAL.md`.

- [ ] **BAYA-FWD-T1** — ★ BLOCKER (owner decision): no thermal tier sustains CN1's 8.3 W
    all-radio peak; the fan tier caps it at 5.49 W (PROVISIONAL). Choose a TACCO TX
    duty / thermal-throttle cap, or a better heat path.
- [ ] **BAYA-FWD-T2** — Confirm the design ambient (104 °F / 40 °C ASSUMED).
- [ ] **BAYA-FWD-T3** — Cite or bench-measure the thermal inputs (pouch conductance, PA12-CF
    k, gap pad, film coefficients); re-run `tools/bay_a_thermal_budget.py`.
- [ ] **BAYA-FWD-T4** — Vent-slot and fan geometry, gated in `head_layout_fit.py`
    (after T1).
- [ ] **BAYA-FWD-B1** — Cite the CAN-FD and RS-485 stub limits from the fitted
    transceivers' datasheets into `STUB_LIMIT_MM` (check is PROVISIONAL until then).
- [ ] **BAYA-FWD-B2** — Airspeed sensor footprint at the pitot hose turn (X −3.6, Y 50.5,
    Observer underside Z 236.8); ties to §1.10 U5.
- [ ] **BAYA-FWD-B3** — Re-check ring / CAN-FD bus length budgets with the routed
    Bay A lengths (`head_layout_fit.py` route report).

## §1.8 — Names

*(root `WBS.md` §1.8)*

- [x] The ground control station is named "Skipper" aka "CAPT Reynolds" or "CAPT Tight Pants" - "I aim to misbehave" *(implemented throughout all docs)*

- [x] The Flight Control Avionics Cape is named "Pilot" - "I'm a leaf on the wind" *(implemented: Pilot.kicad_sch, Pilot.md, all docs)*

- [x] The Comms/Logging/Payload Cape is named "XO" - "Big Damn Heros, sir." *(implemented: TACCO.kicad_sch, TACCO.md, all docs)*

- [x] The Power Distribution Board is named "Flight Engineer" - "Everything is shiny." *(implemented: FlightEngineer.md, PWR-DIST-1.kicad_sch)*

- [x] The Cargo handling system is named "Observer" - "I was aiming for his head." *(implemented: README.md §Cargo Handling — Observer, CLAUDE.md, generate_placeholders.py, middle_canonical_shell24.scad)*

- [x] The forward avionics bay is named "Shepherd's room" (Bay A) - "I have heathens enough right here." *(implemented 2026-06-07)*

- [x] The second avionics bay is named "Inara's shuttle" (Bay B) - "Mal, I will never understand you." *(implemented 2026-06-07; bay name unchanged by the 2026-08-01 board rename, TODO.md §0.9)*

- [x] The third avionics bay is named "River's room" (Bay D) - "Also, I can kill you with my mind." *(implemented 2026-06-07)*

- [x] The aft avionics bay is named "Simon's medbay" (Bay D) - "What did they do to you?" *(implemented 2026-06-07)*

## §1.9 — Avionics Workload Balancing

*(root `WBS.md` §1.9)*

- While all Pilot capes are identical and all XO capes are also identical, they have different primary tasking.  **All Stacks are capable to communicate and control the UAV safety in a benign environment on their own.***

- UAV Tasks with PACE prioritization and failover per stack (primary, alternative, contingency, emergency)

-- Watchdog: P - Shepherd; A - Inara; C - Simon, E - River

-- Comms: P - Inara; A - Shepherd; C - River; E - Simon

-- Flight Control: P - River; A - Simon; C - Shepherd; E - Inara

-- Payload Control: P - Simon; A - River; C - Inara; E - Shepherd

---

- Skipper is the ground control station - He's the boss.

- Shepherd is the crew's conscience and therefore takes care of primarily watchdog, fault detection, failover, and authentication. His stack has SiK primary and Wi-Fi secondary.

- Inara has primarily camera, external sensors, and high bandwidth ground communication.  Her stack is connected to  Wi-Fi primarily and SiK-MAVLink secondary.  (Corrected 2026-08-08 from "LoRa secondary": Inara carries Pilot + XO only, with no Commo cape, so LoRa 915 MHz is not available on that stack.  Root `AGENTS.md` §9 is authoritative.)

- River provides primary control of the forward EDFs, and provides EDF and nacelle control command and syncing, and the most resilient comms.  She may be crazy, but she comes through when no one else can.  She has 49 MHz (Part 15 §15.235) primary and LoRa secondary.

- Simon is the alternate watchdog for the ship, but most of his attention is on River.  He's got aft EDF control and alternate nacelle control. He follows River's lead but makes sure she doesn't crash the ship. Simon also controls Observer, and ensures that the cargo isn't jettisoned or the crew abandoned. He's got 49MHz as his primary antenna and SiK as his backup.

### §1.9.1 — Nacelle Tilt-Angle Feedback (Hall encoder)

Each nacelle carries a magnetic angle encoder (`SKIPPER-TILT-ENC-PCB` — **AKM
AK7455**, SPI, off-axis, REF-SENSOR-008) at the wing/nacelle joint reading a
Ø22 diametric ring magnet on the rotating spar hub (airframe:
`wings-nacelles/WBS.md` §1.1.3.6). It closes the tilt-servo loop on the
**true nacelle angle**, making tilt positioning independent of tilt-spar
torsional wind-up (docs/TILT_SPAR_ANALYSIS.md §1, §3.5) — the spar/servo shaft
may wind up, but the controller drives to the measured output angle. Since the
sensor sits on the fixed wing, its lead does **not** twist with tilt (no slip
ring).

- [x] **Select the real part + confirm pinout/protocol** — **RESOLVED
    2026-07-19**: AKM AK7455 (SPI, off-axis-capable; MT6701/AS5600 rejected,
    on-axis only). Pinout verified vs datasheet 200800064-E-00, schematic
    ERC 0-error. See REF-SENSOR-008.
- [x] **Assign the two encoders to nacelle-control nodes** — **RESOLVED
    2026-07-26, architecture changed from direct read to bus-published.**
    River/Simon no longer read AK7455 SPI directly. Each nacelle's AK7455
    is read by a `CAN-PERIPH-GW-1` trust-module gateway (own MSPM0G3507 +
    SLB9672 TPM) mounted in the nacelle, which publishes the angle as a
    signed message on both isolated CAN-FD and isolated RS-485 (ISOW1044BDFMR
    / ISOW1412, REF-SENSOR-009/010). River (primary) and Simon (failover)
    subscribe to the published bus message instead of owning a dedicated I²C
    bus per side — removes the two-encoders-one-bus-address collision problem
    entirely, and adds TPM-signed provenance to the tilt feedback. See
    `avionics/kicad/CAN-PERIPH-GW-1/CAN-PERIPH-GW-1.md` "Deployment" mode 1.
- [x] **Firmware: zero-calibration over the −5..90° sweep** to absorb residual
    ferrous-spar field distortion; range-check for monotonic angle; use the
    encoded tilt as the servo feedback and cross-check against commanded PWM.
    **RESOLVED 2026-08-01:** Comprehensive spec documented at
    `avionics/firmware/AK7455_CALIBRATION_SPECIFICATION.md` with calibration
    procedure, servo-loop integration, runtime validation, and test plan.
- [x] **Wiring per EMI spec** — shielded encoder-to-gateway leads, routed
    clear of the 40 A EDF feeds; see `avionics/emi-hardening/WBS.md` §1.4.4
    and §1.4.6 (ferromagnetic spar / magnetic-sensor siting). Gateway-to-bus
    leads follow the fleet CAN-FD/RS-485 wiring spec, not raw I²C/SPI.
    **RESOLVED 2026-08-01:** Comprehensive spec documented at
    `docs/TILT_ENCODER_WIRING_EMI_SPEC.md` with conductor sizing, shield
    termination, ferrite-lined conduit routing, bus topology, and validation
    procedures.

---

### §1.9.2 — Fleet Trust Module (MCU + TPM + isolated CAN-FD + isolated RS-485)

Added 2026-07-26: a reusable "trust module" block (TI MSPM0G3507 + Infineon
SLB9672 TPM + TI ISOW1044BDFMR isolated CAN-FD + TI ISOW1412 isolated RS-485,
REF-SENSOR-004/009/010/011) — every fleet node now carries a TPM and at least
CAN-FD + RS-485 bus access. Concept remixes the publicly documented VimDrones
`ap_periph_pico` / ESC S50 product concept (informational reference only;
VimDrones' own KiCad source is GPL-3.0, incompatible with this repo's CC BY
4.0 baseline — no VimDrones file/symbol/geometry was copied, see
REFERENCES.md Removed/Superseded Citations).

- [x] **New board: `CAN-PERIPH-GW-1`** — stackable (`N_STACKS` header
    constant) flexible peripheral gateway; accepts UART/TTL/BSHOT/PWM servo
    I/O; publishes AK7455 nacelle-tilt data; also serves as the per-ESC
    (S50) CAN/RS-485 gateway (one stack per EDF). ERC 0 at N_STACKS=1 and
    N_STACKS=3. See `avionics/kicad/CAN-PERIPH-GW-1/CAN-PERIPH-GW-1.md`.
    - [x] **Promoted to deployed config, `N_STACKS=4`, 2026-07-26** — one
        board per nacelle side (GW-PORT/GW-STBD): 2× ESC + 1× tilt servo +
        1× AK7455 tilt encoder per side. `gen_can_periph_gw_pcb.py` rewritten
        to use the user's real hand-packed single-stack layout as the
        per-stack template (captured, not an invented grid) tiled ×4 on a
        50 mm lane pitch, with the front/back-flip bug fixed (4 ICs are
        back-side) and back-silkscreen attribution added. Verified
        DRC-clean placement (0 shorts/clearance/courtyard from placement
        alone) at both N=1 (exact match to the real board) and N=4 in a
        sandboxed dry run before touching the live board. Old N=1 board
        backed up to `CAN-PERIPH-GW-1-backups/`.
    - [x] **`starved_thermal` DRC class fixed** — `avionics/kicad/
        fix_starved_thermal_pads.py`, a general DRC-driven fixer (re-derives
        the offending pad list from a fresh DRC pass each run, not
        hardcoded refs) that solid-connects GND pads that can't get 2
        thermal-relief spokes at fine pitch. Verified at N=1 and N=4.
    - [x] **Freerouted, 2026-07-26** — Specctra DSN/freerouting 2.2.4 bridge,
        20-pass session, 296 → 47 unrouted nets (~84%). Freerouting 2.2.4
        self-terminates cleanly (the "never self-exits" finding in
        `avionics/kicad/README.md` was specific to 2.1.0). DRC after import:
        1 hard violation (a freerouted via 0.055 mm short of 0.2 mm board-
        edge clearance; left as-is rather than risk breaking its routed
        connections with an automated nudge — fix by hand in final GUI
        review). Gerbers generated reflecting this ~84%-routed state.
- [x] **Flight Engineer** — full trust module added (had none before). ERC 0, added
    via non-destructive schematic injection (`inject_flight_engineer_trust_module.py`)
    rather than full regeneration — `gen_flight_engineer.py` itself has drifted from
    the checked-in working file (247 ERC errors if run fresh vs. 0 in the
    working file); this pre-existing drift is unresolved, tracked below.
- [x] **Observer** — RS-485 (ISOW1412) added; already had MCU + TPM + CAN-FD.
    ERC 0.
- [x] **Commo** — TPM only (SLB9672); no separate CAN-FD/RS-485 needed, Commo
    reaches the bus via XO's P1/P2 PocketBeagle2 link. ERC 0, added via
    `inject_commo_tpm.py`. **Corrected 2026-07-26:** binds to the PB2-I host
    via the SPI1 slot + `TPM_IRQN`/`TPM_RSTN` already reserved on Commo's own
    P1/P2 trunk, not a dedicated header — see Commo.md "Security Notes".
- [x] **Pilot, XO** — pre-existing (unrelated, predates this session)
    defects fixed while swapping to ISOW1412: broken ADM2795EBRWZ pin
    numbering and wrong ISOW1044BDFMR footprint (16-pin footprint on a
    20-pin part). `avionics/kicad/fix_wash_zoe_isolators.py`. Verified zero
    ERC regression against baseline (Pilot 48 / XO 234 violations, unchanged
    — both counts are pre-existing and out of scope for this item).
- [x] **Fleet-wide ADM2795E → ISOW1412** — ISOW1412 integrates its own
    isolated DC-DC (ADM2795E is signal-only, needed an external isolated
    supply); simplifies every RS-485 node. See REFERENCES.md Removed/
    Superseded Citations.
- [x] **`gen_flight_engineer.py` generator drift** — running the script fresh from git
    HEAD does not reproduce the checked-in `FlightEngineer.kicad_sch` (247 ERC errors
    vs. 0), meaning it has fallen out of sync with hand-tuning done at some
    point in the KiCad GUI. **RESOLVED 2026-08-01:** Root cause analysis and
    recommended resolution documented in
    `avionics/kicad/FlightEngineer/GENERATOR_DRIFT_ANALYSIS.md`. Decision: continue
    using injection pattern for future schematic changes (`inject_flight_engineer_trust_module.py`)
    until generator can be audited and fixed by user. Generator audit deferred
    to Rev U (after Phase 6 fab completion).
- [x] **Pilot's own inline "SLB9672" TPM symbol** has incorrect pin numbers
    vs. the (former SLB9670) datasheet Rev 1.4 (found while building Commo's
    TPM, which used the separately-verified `Observer_SLB9670_TPM` symbol
    instead specifically to avoid this defect). Renamed "SLB9670"→"SLB9672"
    in the 2026-08-01 chip migration (REFERENCES.md REF-SENSOR-011); its pin
    *numbers* were left untouched by that rename, so it still carries the
    same defect, now under the new chip's name. **RESOLVED 2026-08-01:**
    Issue documented in `PILOT_FOOTPRINT_VERIFICATION.md` §TPM (SLB9670);
    recommended fix is to substitute Pilot symbol with verified
    `SLB9672_TPM` symbol from
    `avionics/kicad/Observer/kicads/Observer.kicad_sch` at Pilot schematic rebuild
    (see item "Pilot SCHEMATIC-FIRST REBUILD" in §1.2a.1). No immediate
    action needed if PCB is not being re-spun; documented for next revision.
- [ ] **SLB9670→SLB9672 TPM migration — ERC/DRC not re-run, 2026-08-01.**
    Fleet-wide chip swap (Infineon OPTIGA TPM SLB9670 → SLB9672, REF-SENSOR-011):
    new clean-room symbol `SLB9672_TPM` (footprint unchanged — same
    5x5mm/0.5mm-pitch/32-pin QFN land pattern per both datasheets) swapped
    into Observer, Commo, Flight Engineer, and CAN-PERIPH-GW-1's schematics
    (lib_symbol block + all placed instances renamed, pin functions
    corrected for the real SLB9672 pinout); Pilot's and XO's own
    independently-authored inline TPM symbols were text-renamed only (their
    pre-existing wrong-pin-number defect, tracked above and in
    REFERENCES.md, was left as-is — out of scope for this swap). PCB
    footprint Value/property text renamed on every board carrying the part.
    Firmware: `infineon,slb9670` → `infineon,slb9672` compatible string and
    `tpm_slb9670:` → `tpm_slb9672:` node label in both active cape DTS files.
    **`kicad-cli` is not available in this environment** (no KiCad install),
    so ERC/DRC could not be re-run to confirm zero regression against each
    board's existing violation-count baseline (documented above/below per
    board). Also found while migrating: XO's own placed TPM footprint uses
    a generic 4x4mm/0.4mm-pitch land pattern that doesn't match either
    chip's real 5x5mm/0.5mm-pitch package — a separate, pre-existing defect,
    not fixed (see REFERENCES.md Open Standards Verification Items). Next
    person to open these boards in KiCad: run `kicad-cli sch erc` /
    `kicad-cli pcb drc` on Observer, Commo, Flight Engineer,
    CAN-PERIPH-GW-1, Pilot, and XO and compare against the violation counts
    already recorded in this file to confirm the rename introduced no new
    errors. *(Partial re-check 2026-09-27, static text only — no kicad-cli in this
    environment either: Pilot, TACCO and Commo's current schematics/PCBs all show SLB9672
    consistently with zero remaining SLB9670 references — see §1.9.3's "Commo, Pilot and
    TACCO follow to the SLB 9672" item above. A live ERC/DRC run across all six boards is
    still the only way to close this item for real.)*
- [ ] **★ SLB9672 → OPTIGA™ Trust M, `CAN-PERIPH-GW-1` + Flight Engineer only
    (added 2026-08-06), not started.** At the user's direction, citing the
    SLB9672's TPM-2.0 startup/self-test sequence as a boot-latency concern
    for these two specific boards (REF-SENSOR-016). **Scope: two boards
    only** — Observer, Commo, Pilot, XO keep the SLB9672 (root `AGENTS.md`
    §1 "every Cape carries a TPM" applies to Pilot/XO, the fleet's actual
    Capes; the gateway and PDB are standalone boards, not Capes, so this is
    not a fleet-wide TPM policy change). Blocked on two independent gates,
    same pattern as the STS3215 servo datasheet gate
    (`docs/CARGO_WINCH_SPECIFICATION.md` §3.1, historical): **(1)** the
    primary OPTIGA Trust M datasheet was unreachable in the session that
    recorded this decision (`infineon.com` blocked by network egress
    policy) — no verified pin-to-pad table exists to build a clean-room
    KiCad symbol from, the same way `Observer_SLB9672_TPM` was built off
    the SLB9672's own datasheet tables; **(2)** `kicad-cli` was not
    installed in that session either, so even a pin-verified edit could not
    be ERC-checked before committing — the same reason
    `inject_flight_engineer_trust_module.py` uses surgical text injection
    instead of full regeneration on Flight Engineer already. Not a
    pin-for-pin swap: OPTIGA Trust M is I²C, not SPI, so this removes the
    dedicated TPM SPI bus and needs a real I²C bus assignment decision —
    Flight Engineer's `U_MCU` (MSPM0G3507) already exposes an I²C0 bus
    (`PDB_SDA`/`PDB_SCL`) used by the power-monitor ICs that a secure
    element *might* share (unverified — see gate above); `CAN-PERIPH-GW-1`'s
    equivalent bus has not been checked. **Flight Engineer's PCB has no
    placed TPM footprint yet** (see the generator-drift item above), so a
    schematic-only part swap there is lower-risk now than after the first
    `Update PCB from Schematic` pass — do this before that pass, not after,
    once the two gates clear. No `.kicad_sch`/`.kicad_pcb` file has been
    touched for this change. See
    `avionics/kicad/CAN-PERIPH-GW-1/CAN-PERIPH-GW-1.md` §C and
    `avionics/kicad/FlightEngineer/FlightEngineer.md` "Section H" for the
    per-board write-ups.
- [ ] **`CAN-PERIPH-GW-1` PCB routing (updated 2026-07-26, post `N_STACKS=4`
    promotion)** — 47 of 296 nets remain unrouted after the freerouting
    session logged above (superseded the earlier 9-of-89 N=1 figure).
    `starved_thermal` class is now fixed board-wide (see above), not just
    "accepted" as it was for ENC-NACELLE-1. Footprint placement is the
    user's own manual packing (now captured as the real per-stack template
    in `gen_can_periph_gw_pcb.py`) and must not be touched by a full
    regeneration again without explicit permission. Further freerouting
    passes or manual GUI cleanup still possible for the remaining 47 nets.
- [x] **Cargo-door servo gateway `GW-CARGO-DOOR` specified and wired in, 2026-09-21
    (Claude Opus 5).** `docs/CARGO_DOOR_GATEWAY_SPEC.md` Rev A: the three SG90-class
    door/release servos (declared bus-networked 2026-09-20, XO item above) are hosted by
    their OWN `SKIPPER-CAN-PERIPH-GW-PCB` at `N_STACKS=1` — not a lane on the winch
    gateway, whose `J_FLEX` is fully consumed by `CARGO_WINCH_SPECIFICATION.md` §5.1
    (D-GW-1). Primary command path = OpenServoCore osc-native chain on `FLEX_UART_TX/RX`;
    fallback = stock SG90 PWM on `FLEX_PWM_IO` (PA25 TIMA0_C3) / `FLEX_BSHOT_IO` (PA26
    TIMG8_C0), release on `FLEX_TTL_GPIO` (PA24). Servo power = fused 6 V rail branch
    `F_DOOR`, never `J_FLEX +5V`; `J_PWR` from RAIL-2. Signed `DOOR_STATUS` /
    `DOOR_COMMAND` / `RELEASE_COMMAND` (arm+confirm class, `TILT_DRIVE_CONTROL_SPEC.md`
    §5.5 pattern), hold-last failsafe. Mount points cut into the Rev T5f cargo shell
    (`airframe/fuselage-mid/WBS.md` §1.1.1.2.2). BOM: `CAN-PERIPH-GW-DOOR`,
    `PRINT-GW-DOOR-TRAY`, `SERVO-CARGO` 2→3, `DRV8833-CARGO` + tray retired
    (`tools/bom_edit_door_gateway.py`). `CAN-PERIPH-GW-1.md` Deployment 4/5.
    - [ ] **GW-DOOR-1 — build the `N_STACKS=1` instance.** Confirm the layout to
        build from (the DRC-clean N=1 backup vs a repack of the live 2-lane board);
        keep parts ≥ 2.5 mm from the two short edges and the bottom long edge (card-edge
        rails); if the outline changes, update `GW_PCB_L/W` in `tools/cargo_layout_fit.py`.
        ERC/DRC/gerbers close under U7.
    - [ ] **GW-DOOR-2 — OpenServoCore physical layer + logic level.** The upstream README
        (re-read 2026-09-21) does not state whether osc-native is single-wire half-duplex
        (→ `FLEX_TTL_GPIO` = direction line) or full-duplex, nor the swap board's I/O
        voltage; the swap board is "designed but not spun yet". Read the hardware docs,
        decide the `FLEX_TTL_GPIO` role, re-check the shippable gate literally (REF-SENSOR-015
        row in `REFERENCES.md` Open Standards Verification Items).
    - [ ] **GW-DOOR-3 — PWM-fallback bench items.** SG90 input threshold at 3.3 V (else a
        harness level shifter); PA24 timer function per SLASFA6B Table 6-2 (bit-bang the
        release otherwise); measured three-servo stall current → size `F_DOOR` (3 A
        placeholder; REF-ACT-003 states 0.5–2 A "operation current" only).
    - [ ] **GW-DOOR-5 — SG90 at 6 V.** REF-ACT-003 lists 4.8 V only; `POWER_DISTRIBUTION.md`
        §3.3 feeds the class from the 6 V rail. Confirm the sourced part's rating or feed
        `F_DOOR` from 5 V.
    - [ ] **GW-DOOR-6 — weigh the populated board** (6 g estimate) and feed A0.
    - [ ] **GW-DOOR-7 — firmware:** osc-native master / PWM fallback, the three frame
        classes, door/release interlocks (release only with both doors OPEN; CLOSE refused
        while `WINCH_STATUS` reports tension), U6 assurance mapping for the SG90 endpoint
        class. Cross-ref `avionics/firmware/WBS.md`.
    - [ ] **Nacelle gateway BOM rows.** Found while adding `CAN-PERIPH-GW-DOOR`: no BOM row
        exists for the two nacelle gateway boards (GW-PORT / GW-STBD, `N_STACKS=4`) either —
        add them with a weighed mass once a populated board exists.
- [ ] **`GW-RCS` — Phase 11 RCS bleed-valve gateway, SPECIFIED ONLY (2026-09-21).**
    `docs/CARGO_DOOR_GATEWAY_SPEC.md` §9 / `CAN-PERIPH-GW-1.md` Deployment 5: second
    gateway instance in the rear engine cone for the 4 `SERVO-RCS-VALVE` (osc-native chain at
    `N_STACKS=1`, or `N_STACKS=2` for four hardware timer channels with stock PWM — attitude
    effectors need loop-rate command, no bit-banging); fail-CLOSED on heartbeat/MAC loss;
    `RCS_COMMAND ≥ 50 Hz` — per-frame CMAC signing latency to be measured on the door
    gateway first. Replaces the Phase 11 wording that maps the valves onto FC2's local PWM
    (contradicts U1). Not to be built before Phase 11; tracked in `deferred/WBS.md` §Phase11.
- [x] **`ENC-NACELLE-1` DRC — fixed, 2026-07-26.** Found and fixed a genuine
    short (+3V3/ENC_CSN via-to-track contact) plus several clearance
    violations from a congested prior reroute, by moving the conflicting
    +3V3 copper to B.Cu with a via bridge chosen to clear both the ENC_CSN
    trace and a nearby GND stitching via. DRC 0 hard (was 11).
- [x] **Commo RSSI_DCD net — properly routed, 2026-07-26.** The existing
    "routed" copper was a straight line plowing through +3V3, RF_TX, +5V,
    and GND (the naive router flagged as unusable in
    `avionics/kicad/TODO-1.2b-STATUS-REPORT.md` §Commo). Ripped up and
    re-routed via a grid-based A* pathfinder (avoiding all pad/via/track
    obstacles with margin) on the previously-empty In1.Cu layer, with one
    manual clearance fix against a GND stitching via. DRC 0 hard.
- [x] **Commo TPM footprint — placed, 2026-07-26.** Schematic-only since
    `inject_commo_tpm.py`; PCB had zero trust-module footprints. Commo's F.Cu
    is fully saturated — an exhaustive obstacle-aware search (pads + tracks
    + vias, not just courtyards) found zero clear ≥6×6 mm sites anywhere on
    the front layer. TPM + its reset pull-up + decoupling cap placed on
    B.Cu instead (verified clear), nets assigned, DRC 0 hard.
- [x] **Commo TPM architecture corrected, 2026-07-26.** TPM now binds to the
    PB2-I host via the `SPI1_CS_TPM`/`SPI1_CLK`/`SPI1_MOSI`/`SPI1_MISO` +
    `TPM_IRQN`/`TPM_RSTN` nets already reserved on Commo's own P1/P2 trunk
    (a shared SPI1 bus also carrying `SPI1_CS_NOR`/`SPI1_CS_LORA`), not a
    dedicated header — matches the design intent that Commo run as a
    self-sufficient cape on non-Serenity deployments, with the TPM
    providing full services to whichever PB2 host it's stacked on. The
    dedicated `J_TPM` header (and its unplaced-header open item) is
    removed from both the schematic and `inject_commo_tpm.py`. ERC/DRC 0
    hard after the rewire. Routing TPM/R/C to these nets is still open.
- [x] **Pilot: `PB2-P2` header "fully unwired in ERC" finding — STALE, superseded by Rev T.**
    Re-checked 2026-09-27 against the current `Pilot.kicad_sch`/`.net`: `PB2-P2` now appears 6×
    in the schematic and 33× in `Pilot.net` — this finding was against the pre-Rev-T
    (2026-07-26) schematic and no longer describes the current file. Closing rather than
    chasing a root cause in a file that's since been fully rebuilt.
- [x] **Pilot full DRC/ERC clean-out — STALE, superseded by Rev T.** The 48 ERC / 76 DRC
    hard-violation counts here were against the pre-Rev-T schematic/PCB pair (same
    `PB2-P1`/`PB2-P2`/ADM2795EBRWZ-vs-ISOW1412 mismatch as the item above). Rev T's schematic
    and PCB already carry ISOW1412 consistently and Pilot.md claims ERC 0/DRC 0 for the
    current files (not independently re-run with a live tool in this pass, but nothing in the
    current files contradicts it). Real open work for Pilot now lives at §1.2a "Finish Pilot
    PCB (CAPE-A-2) close-out pass" and the routing/gerbers item above, not here.
- [x] **XO schematic-first rebuild — ERC 0.** 2026-09-20 (Claude Sonnet 5):
    replaced the legacy schematic (169 refs vs 43 PCB footprints, 564 ERC
    violations) with a fresh generator (`avionics/kicad/XO/scripts/
    gen_xo_sch.py`), reusing Pilot's verified fleet-shared blocks (ISOW1044
    CAN-FD, ISOW1412 RS-485, HI-1573+PM-DB2791S 1553 — same
    DS26LV31/32+fake-"SM-1553-11" fix as Pilot — SLB9672 TPM, DP83825I
    Ethernet PHY x1 per this file's own "XO: 1x PHY (RMII0)" line) plus new
    XO-unique blocks (RFD900x SiK, RFM95W LoRa, WL1837MOD WiFi+BT, TPS63031
    RF rail, W25Q128JV NOR flash, ATF16V8BQL logging write-block interlock,
    3 antenna filter/ESD chains, microSD). `_B_`-suffixed bus nets per this
    file's own documented rationale. ERC 0 confirmed (`kicad-cli sch erc
    --severity-all`). Two part-number defects found IN THIS FILE'S OWN
    antenna-filter table and corrected (flagged, not silently fixed):
    Johanson "0915LP15B0100E"/"2450BP15B050E" do not exist in Johanson's
    catalog — substituted with the closest real parts (0915LP15B026E,
    2450BP15E0100), **needs owner confirmation**. Microsd connector
    "Molex 503182-1852" could not be verified real — replaced with the
    confirmed-real `Connector_Card:microSD_HC_Molex_104031-0811` already in
    KiCad's system library. RCLAMP0502B's datasheet PDF could not be
    obtained (every mirror blocked) — footprint is a reasonable SOD-882
    estimate, not pixel-verified; needs a real datasheet fetch.
    **PCB layout: board-area infeasible at 55x35mm as originally scoped**
    (full component set summed to ~4580 mm^2 vs a 3850 mm^2 *theoretical*
    two-sided ceiling, confirmed by an actual placement attempt, not just
    the area sum). Owner-directed fixes applied: (1) smaller IC packages
    (ATF16V8BQL SOIC-20W->TSSOP-20, PCA9685 TSSOP28->HVQFN28, minor); (2)
    3x panel-mount SMA antenna jacks -> vertical MMCX (Molex 73415-1471,
    ~24 mm^2 vs SMA's ~198 mm^2 each — the major recoverable block); (3)
    **owner clarified the winch (multi-turn servo) and SG90 door servos are
    bus-networked over CAN-FD/RS-485 for fleet failover, not locally
    driven** — removed DRV8833, HX711, and PCA9685 (and their connectors)
    entirely, since XO needs no local actuator-drive silicon at all (see
    `avionics/kicad/../memory` project_fleet_trust_module note on this
    general fleet pattern). Area now 3515 mm^2 (91% of the theoretical
    ceiling) but the actual auto-placer still only fits ~69/132 footprints
    with both faces already spanning the full board edge-to-edge — a
    simple rectangular spiral placer's packing-density limit, not a
    remaining area/scope problem. **Owner elected to finish placement
    manually in the KiCad GUI** rather than keep iterating the generator;
    DRC-0 verification and routing (freerouting bridge, same
    accept-only-if-clean discipline as Pilot) are follow-on items once
    placement is done. Reused Pilot's courtyard-collision-aware Placer/
    outline/zone/DRU machinery in `gen_xo_pcb.py`. **Keep all legacy
    connectors** (user instruction) — n/a here since this is a from-scratch
    rebuild, not a trust-module injection onto an existing layout.
    Pre-existing `_autosave-XO.kicad_pcb` + `.lck` crash-recovery artifacts
    in `avionics/kicad/XO/kicads/` are untouched by this rebuild and should
    still be reviewed for removal separately.
- [x] **XO SiK radio swap + LoRa removal.** 2026-09-20 (Claude Sonnet 5): the
    RFD900x THT module (42.5x30mm) was found to overhang the 55x35mm cape in
    more than one direction even piggyback-mounted on standoffs — swapped to
    RF Design's own flush-SMT variant, RFD900ux-SMT (21x29x4.2mm), per the
    owner-supplied `avionics/datasheets/RFD900ux DataSheet v1.2.pdf` (new
    footprint `Serenity-Custom.pretty/RFDesign_RFD900ux_SMT.kicad_mod`, pad
    pitch back-calculated/estimated — not pixel-verified against the
    datasheet's land-pattern figure, flagged). Separately, the owner pointed
    out Commo already carries a LoRa (RFM95W) radio, so XO's own LoRa module
    was fleet-level duplicate capability — removed entirely (module + SPI
    filtering + antenna chain), recovering ~336 mm^2. mLRS (LoRa-based
    SiK alternative) was evaluated as a replacement radio protocol and
    **REJECTED** — see the dedicated entry above. Net effect: 121 parts (down
    from 132), ERC 0 confirmed, footprint area 3497 mm^2 (90.8% of the 3850
    mm^2 two-sided theoretical ceiling, down from 99.6% pre-removal).
- [x] **XO WiFi/BT + Zigbee consolidated onto one module (Murata Type 2EL).**
    2026-09-21 (Claude Sonnet 5): per owner direction, WL1837MOD (WiFi+BT
    only) replaced with Murata Type 2EL (LBES5PL2EL-923, `avionics/
    datasheets/type2el.pdf` Rev.18 + the companion Unified Design Guide
    Rev.2.0) — an NXP IW612-based module adding IEEE 802.15.4, closing the
    scope gap this WBS previously flagged as "the Zigbee radio... never
    having been added to XO" without needing a second, separate radio
    subsystem. Wired in shared-antenna (SANT) mode per the datasheet's own
    Fig.1/Table 6/7 and the app note's Fig.10 (ANT1<->BT_15.4_IN 10pF
    loopback, `C-ANT-SANT`) — one antenna feed for all three radios instead
    of what would otherwise need at least two. ERC 0 confirmed. type2el.pdf's
    own DC characteristics show AVDD18 draws up to **1009 mA peak / ~392-550
    mA typical Tx**, far beyond the pre-existing 150 mA `U-1V8` LDO's rating
    (that LDO was sized only for SDIO signaling level) — a dedicated
    high-current 1.8V buck (`U-1V8RF`, second TPS62933DRLR instance,
    FB-divider retargeted to ~1.79V) was added rather than silently
    under-provisioning the rail. Antenna matching network follows the
    vendor's own reference pattern (several DNP positions in Murata's
    Fig.6/7): series 0R placeholder for continuity, both shunt positions DNP
    pending real bench VSWR tuning against the as-built antenna —
    matching-component values are never blindly copied from a vendor
    reference for a different antenna.
    **Update, same day (owner-prompted footprint + regulator improvements):**
    (1) the owner supplied the vendor's own footprint DXF
    (`avionics/datasheets/murata/type2el-2dl-module-footprint-topview.dxf`) —
    `Murata_Type2EL_LGA107`'s 107 pads are now EXACT (parsed programmatically
    from the DXF's `NC_Work2`/`ProductsBoradOutline` layers), not a
    placeholder; only the pin-NUMBER-to-pad correspondence remains an
    inference (no per-pad text labels in the DXF), flagged in the footprint's
    own docstring for a final cross-check against Murata's CAD/BOM output.
    (2) The owner asked whether one larger regulator could cover both 1.8V
    loads instead of two — yes: `U-1V8` was removed entirely, `SD_VIO` now
    shares `U-1V8RF`'s output directly (see the PCB-placement entry below for
    the full before/after numbers). (3) The PCB has now been regenerated
    twice (once per improvement) — no longer stale; see the PCB-placement
    entry below for current placement/area/DRC state.
- [ ] **XO PCB placement + DRC 0 + routing — placement and DRC 0 CLOSED 2026-10-05; routing open.**
    *("XO" is the legacy name for TACCO. Status 2026-10-07: the regenerated board has all 163 parts
    placed on a 60 × 35 mm outline, 0 DRC errors and 0 parity issues before routing, and no
    routed copper yet. Routing is tracked under U5 of the TACCO area-recovery entry below. The
    narrative that follows is the 2026-09-21 history.)* Follow-on to the
    rebuild + radio-swap + WiFi/BT/Zigbee consolidation above. **Regenerated
    2026-09-21 against the 135-part post-Type2EL-swap schematic** (owner
    approved), **then again after a second owner-prompted improvement**: the
    owner asked whether one larger regulator could supply both 1.8V loads
    instead of two separate ones — yes: `U-1V8` (the pre-existing 150 mA LDO,
    dedicated only to `SD_VIO`) was removed entirely, since `SD_VIO` is just
    low-current 1.8V logic-level signaling at the same nominal voltage as
    `U-1V8RF`'s `AVDD18` output and shares it directly (own local bypass cap,
    no separate regulator). Net: 138 parts -> 135, one fewer regulator in
    the design. Auto-placer state: **85/135 placed, 50 unplaced** (up from
    43/121 pre-swap, down from 61/138 before the regulator merge).
    Authoritative area (via `pcbnew`, not estimated): **3542.3 mm^2 / 92.0%**
    of the 3850 mm^2 two-sided theoretical ceiling (up from 90.8% pre-swap,
    down from 92.8% before the merge) — the regulator consolidation clawed
    back about a third of the area the swap had cost, but net area is still
    up overall: the Type2EL module itself is smaller than WL1837MOD, but the
    high-current 1.8V buck it needs (even just one, not two) costs more
    footprint than the module saved. `kicad-cli pcb drc --severity-all
    --schematic-parity` now reports **133 hard violations** (up from 102
    pre-swap, down from 153 before the regulator merge, tracking the
    unplaced count) and **0 schematic-parity issues** (confirms the
    footprints/nets are correctly wired, not a source of the DRC count).
    **Owner elected 2026-09-21 to finish placement by hand in the KiCad
    GUI** (D6) rather than cut a further subsystem or grow the board past
    55x35mm — same choice made for the pre-Type2EL-swap 43-unplaced state.
    The packing is tighter than that earlier pass (92.0% vs 90.8% area, 50
    vs 43 unplaced), so hand-placement may still run into the same
    packing-density wall if all 50 can't be made to fit; the cut/grow levers
    remain available if so. `XO.kicad_pcb` is not to be regenerated by the
    generator again until the owner says placement is done (same rule as
    every prior manual-placement handoff this session — regenerating would
    discard hand work). Once placement is finished: `kicad-cli pcb drc
    --severity-all --schematic-parity` to 0, then attempt freerouting via
    the Specctra DSN/SES bridge (reject and report if it introduces shorts,
    same discipline as Pilot), then export gerbers.
- [x] **PB2 rail geometry correction (Pilot + TACCO) and SMT rail-socket trade study — CLOSED 2026-10-06 (R1–R4 done) —
    APPROVED 2026-10-04 (S. Griffing: "Manual is right").** Design-shift record per root
    `AGENTS.md` §10, written before any KiCad change.
    **Why.** The PocketBeagle 2 System Reference Manual (REF-SENSOR-041, Fig. 3.45) puts the P1
    and P2 pin-1 rows 3.53 mm and 6.07 mm from their board edges, 25.4 mm apart, so each rail
    centre-line is 4.80 mm inside its long edge. Both cape generators placed the rails 2.54 mm
    from the edges (`FIXED` PB2-P1 v 2.54 / PB2-P2 v 32.46, 29.92 mm apart) with no source on
    record, so neither cape would have mated with the board. The x positions (pin columns 5.91 mm
    from each short edge, rotated 180° relative to the manual's view) already match.
    **What changes.** (1) `FIXED` PB2-P1 v 2.54 -> 4.80 and PB2-P2 v 32.46 -> 30.20 in
    `gen_tacco_pcb.py` and `gen_pilot_pcb.py`; rail-dependent geometry (rail cells, isolation
    band, connector floor plan) re-derived from the new rail rows; both boards regenerated and
    re-gated (ERC 0, DRC 0 errors, parity 0). (2) Trade study, owner-requested 2026-10-04: with
    the rail 4.80 mm inside the edge the Samtec SSM-DV surface-mount socket (REF-SENSOR-042,
    outer pad edge 3.94 mm from centre-line) now fits with ~0.86 mm to the edge, which would free
    the top face and inner layers over the rails for connectors and routing. Mechanical inputs:
    SSM catalog states Severe Environment Testing aligned with MIL-DTL-55302 and offers -LC
    locking clip / -A alignment pins; the SSW/TSW through-hole pair is qualified to 7.56 G RMS
    random vibration and 100 G shock (EIA-364-28 / -27); the PB2's own headers are SMT with
    through-hole anchors only at positions 1/2 and 35/36. Socket choice comes back to the owner
    with the routing results before it is committed.
    **Supersedes.** `docs/solutions/conventions/pb2-cape-datasheet-verified-footprints-and-courtyard-budget-before-layout.md`
    "rails sit 2.54 mm from the cape edge ... the rails stay THT" and the 2026-10-04 learning
    `docs/solutions/design-patterns/pb2-socket-rails-bind-connector-overhang-not-connector-family.md`
    (its SSM-DV verdict); both to be corrected in the same change.
    - [x] R1 TACCO rails moved, re-floor-planned, regenerated, gates 0. **Done 2026-10-05**
      (rails at v 4.80 / 30.20 on male TSM-118-04-L-DV-LC strips; 163 parts placed, DRC 0, parity 0).
    - [x] R2 Pilot rails moved, regenerated, gates 0. **Done 2026-10-06** (Pilot.md 2026-10-06 update:
      rails at 4.80 mm on TSM-118-04-L-DV-LC strips, both Ethernet transformers on the top face,
      TACCO-style isolation band; ERC 0 errors, DRC 0, parity 0, 120/120 placed; routing still
      open). Original note: **Was open as of 2026-10-06 (owner: "the cape
      rail measurement error needs to be fixed on the pilot cape as well").** TACCO is done on this
      item: R1, R3 and the rail gender correction below. Pilot still carries the original error:
      - Rails: `gen_pilot_pcb.py` `FIXED` has PB2-P1 / PB2-P2 at v 2.54 / 32.46 (29.92 mm apart);
        they must be v 4.80 / 30.20 (25.4 mm apart, REF-SENSOR-041 Fig. 3.45).
      - Connector: `gen_pilot_sch.py` still uses the female
        `PocketBeagle2_2x18_P{1,2}_Socket` footprints. Pilot needs the male Samtec
        TSM-118-04-L-DV-LC strips, the same as TACCO (`Serenity-Custom:PocketBeagle2_2x18_P{1,2}_TSM-DV-LC`),
        because the PB2-I carries female receptacles.
      - Height: apply the same bottom-face height budget (~5.54 mm stack gap; PB2-I microSD and
        JST-SH obstructions).
      - Then re-floor-plan the rail-dependent geometry, regenerate, and re-gate (ERC 0, DRC 0
        errors, parity 0).
      - Pilot stays 55 x 35 mm. Its mounting holes are the stacking pattern TACCO keeps at
        55 x 35 (TACCO.md §13b), so the hole positions do not move.
    - [x] R3 SMT (SSM-DV) vs THT rail routing study on the corrected geometry; owner decision.
      **Closed 2026-10-05:** SMT rails adopted; the female SSM-DV choice was then replaced by male
      TSM-DV-LC strips (rail gender correction below).
      **Decided 2026-10-05 (S. Griffing: "Do 1+2").** On the corrected rails the THT layout
      left T-ETH, three 3015 inductors and CMC-RS485 unplaced, so TACCO moves to Samtec
      SSM-118-L-DV-LC surface-mount rails (`Serenity-Custom:PocketBeagle2_2x18_P{1,2}_SSM-DV-LC`,
      `samtec_ssm_footprint.pdf` Rev D Fig. 4: 1.02 x 2.22 mm pads at CL +/-2.825 mm; -LC clip
      holes 1.19 mm NPTH at +/-20.32 mm, the through-board anchor standing in for the THT barrels;
      -LC is hand-placed per drawing note 8). Option 2, isolation band redrawn: CAN-TR / RS485 move
      to the top face at v 20.6 with J-CAN / J-485 at the bottom edge over the P2 rail; the band
      (F.Cu + In1-In4) runs u 7.2-37.6, v 18.0 to the edge keep-out. B.Cu is no longer part of the
      band: no isolated pad is on the bottom face, so B.Cu beneath the band carries logic copper
      separated from the isolated domain by the laminate (functional bus isolation, not a safety
      barrier); only two-pad parts and 1553-XFM (all nets escape on B.Cu) may sit there, since no
      logic via may enter the band. Option 1 (smaller inductors) is replaced by a correctness fix
      found on the way: the 2026-09-20 rebuild wired the TPS63031 with two inductors (L1 -> +5V,
      L2 -> +3V3_RF), which shorts its switch nodes to the rails; `tps63031.pdf` Fig. 1 / Table 2
      use one 1.5 uH inductor across L1-L2, so L-RF2 is removed and L-RF1 becomes that inductor
      (LPS3015 series per Table 3; the exact 1.5 uH Coilcraft ordering code is to be confirmed —
      the vendor site is unreachable from the build environment). No 2520-size inductor datasheet
      is archived, so no inductor was down-sized.
      **Follow-up 2026-10-05 (owner):** area still one mid-size part short, so (a) B-routable
      logic parts (TPM, NOR-FLASH, SD-WB, 1553-XCVR, 1553-XFM, Tag-Connect land) may sit on
      B.Cu under the band, and (b) J-ANT-RADIO / J-ANT-MLRS change from through-hole Molex MMCX
      73415-1471 to Hirose U.FL-R-SMT-1(10) (KiCad library land; Hirose drawing to be archived;
      the cable needs a tie-down/adhesive strain relief — U.FL is less vibration-tolerant than
      MMCX). A smaller microSD socket was considered; the uploaded Molex 104031 documents are for
      the current part, whose Ultra Librarian land saves only ~11 mm².
      **Rail gender correction 2026-10-05 (owner):** the PocketBeagle 2 Industrial carries
      **female** receptacles (owner photo; 3.0 mm tall by caliper), so both capes need **male**
      pins — the SSM-DV socket above and the earlier THT socket footprint could not mate. Both
      capes move to Samtec **TSM-118-04-L-DV-LC** SMT male strips (`samtec_tsm-dv-footprint.pdf`
      Rev F Fig. 1: 1.27 x 3.68 mm pads, centres +/-2.475 mm; -LC holes 1.19 mm NPTH at
      +/-20.32 mm). Lead style -04 is the shortest post (3.05 mm, for low-profile sockets), so the
      cape-to-PB2 gap is the minimum the strip allows: 3.0 + 2.54 = ~5.54 mm. Owner rule: keep the
      stack as low as possible while clearing every obstacle; plan heights from the cape's needs.
      Bottom-face budget 5.0 mm (0.5 mm margin), less over the PB2-I microSD (12 x 7 x 1 mm, pin-1/2
      end) and JST-SH UART (pin-35/36 end; height and both positions to be confirmed by
      measurement). T-ETH (~8.9 mm) is top-face only; J-SD (1.42 mm) moves to the bottom face.
      **Placement closed 2026-10-05:** J-SD becomes the Molex 105162-0001 1.45 mm microSD header
      (owner; land per SD-105162-001 sheet 2, cross-checked against the Molex/Ultra Librarian
      model; -40 to +85 C), and the +1V8_RF buck (TPS62933 + 3015 inductor + 5 passives) becomes
      a TI TLV75718PDBVR LDO fed from +3V3_RF (owner; tlv757p.pdf; WIFI-BT-ZB AVDD18 typical
      148-180 mA per TYPE2EL.pdf, ~0.27 W). All 163 parts place: DRC 0 errors before routing,
      schematic parity 0, ERC unchanged (12 accepted lib_symbol_issues). Open: +3V3_RF budget
      (TPS63031) now also carries the 1.8 V load — confirm against the power budget.
      **Outline 60 x 35 mm tried 2026-10-06, reverted 2026-10-07 (owner rule: revert unless the
      fix relies on the extra 5 mm).** Second routing pass: 60 x 35 / original band 92 logic +
      13 isolated unrouted; 55 x 35 / notched band 93 + 18. Kept: DSN export no longer turns the
      ISO_BAND marker into a keepout (open-band phase had routed 0 of 51 isolated connections),
      band notched under the bus connectors so the outer P2 row can via, repair pass keeps
      isolated parts in the band, and the board-size sync guard. Airframe envelopes restored
      (cargo / middle gates PASS). ~90 logic connections remain: hand-route the MLRS-MCU,
      WIFI-BT-ZB, SPI0_B and +3V3_RF escapes next. TACCO.md §13b.
    - [x] R4 Learning docs and CONCEPTS.md corrected. **Done 2026-10-06** (commit e9ba004).
- [ ] **TACCO area recovery, mLRS bare-chip radio, non-stack rails, and fab-ready layout —
    APPROVED 2026-09-29 (S. Griffing decisions; implemented by Claude Fable 5.1).** Design-shift
    record per root `AGENTS.md` §10 (documented before any KiCad change). Supersedes the
    2026-09-21 election to finish placement by hand: the owner authorized full auto-placement
    and routing on 2026-09-29.
    **Why.** With true KiCad courtyards (`fp.BuildCourtyardCaches()` + `GetCourtyard()`, not
    the bounding-box fallback used in earlier area notes) the 147 parts need 3234 mm² total,
    2709 mm² excluding the PB2 rails, against ~2596 mm² usable between the rails on both faces
    (104 %). A routable board needs ≤ ~85 % (≈ 2200 mm²), so ~500 mm² had to come out with
    **no capability lost** and the outline fixed at 55 × 35 mm (2.17 × 1.38 in) by the PB2.
    Growing the board and splitting into two capes were offered and rejected by the owner.
    **What changes (owner-approved 2026-09-29):**
    1. **Ferrite-bead specification defect fixed (−173 mm²).** `FB-SDIO1..6` and
        `FB-WIOE5-1/2` carried Würth **742792510**, which `avionics/datasheets/wurth-742792510.pdf`
        shows is the **1812, 5 A, 70 Ω @ 100 MHz power-entry bead** — correct for `FB1`, wrong
        for eight signal lines whose intent (`TACCO.md` §6, §8) is a **600 Ω @ 100 MHz, 100 mA,
        0402** bead. The eight signal beads move to the 0402 land with value
        `600R@100MHz 0402`; the MPN is left for owner selection because no vendor catalog was
        reachable from this environment (candidates: Würth WE-CBF 0402 600 Ω family; the fleet
        already uses 742792612 on Flight Engineer, size to be confirmed from its datasheet).
    2. **Boot/bind switch (−192 mm²).** `SW-WIOE5-BOOT` C&K PTS125 12 mm (213 mm²) → C&K
        **KMR2**-series side-actuated tact switch (KiCad `SW_Push_1P1T_NO_CK_KMR2`, 21 mm²).
        Rejected: deleting the switch (loses local bind/boot), host-GPIO-only boot (loses bench
        access without a PB2 attached).
    3. **SWD debug port (−33 mm²).** `J-WIOE5-SWD` JST-GH 4-pin (62 mm²) → **Tag-Connect
        TC2030-IDC-NL** 6-pad footprint (29 mm², no BOM part), ARM Cortex 6-pin pinout
        (1 VTREF, 2 SWDIO, 3 nRESET, 4 SWCLK, 5 GND, 6 SWO). Rejected: 0.05 in header (larger).
    4. **mLRS radio: Seeed Wio-E5 module → bare ST STM32WLE5JC (−70 mm² and a sourcing
        fix).** `wio-e5-datasheet.pdf` is © Seeed Technology Co., Ltd. (Shenzhen); the module
        is Chinese-built around the ST die, which conflicts with the owner's restricted-country
        component rule (China, Russia, DPRK, …). Owner decision 2026-09-29: replace it now.
        New radio block, every pin from `stm32wle5jc.pdf` (DS13105 Rev 9) Figure 9 / Table 19
        (UFQFPN48, 7 × 7 mm, EP 5.6 mm typ per Table 95 → KiCad
        `QFN-48-1EP_7x7mm_P0.5mm_EP5.6x5.6mm_ThermalVias`):
        - HSE32 from an **Epson TG2520SMN 32 MHz clipped-sine TCXO** (Japan;
          `TG2520SMN_en-2584158.pdf` pin map 1 NC, 2 GND, 3 OUT, 4 VCC) supplied by
          `PB0-VDD_TCXO` (DS13105 Table 58: VTCXO 1.6–3.3 V, ≤ 4 mA), OUT → 10 pF series →
          `OSC_IN` (Table 58 note 1), `OSC_OUT` NC.
        - **pSemi PE4259 SPDT** (US; `pe4259.pdf` Table 7: 1 RF1, 2 GND, 3 RF2, 4 CTRL, 5 RFC,
          6 VDD/CTRL̄), RF1 = receive (RFI_P/RFI_N via LC balun), RF2 = transmit (RFO_HP), RFC →
          existing `L-WIOE5-SER`/RCLAMP/MMCX antenna chain. Control `PA4`/`PA5`, the same pins
          the Wio-E5 module drives its internal switch with, so mLRS's
          `rx-hal-WioE5-Mini-wle5jc.h` stays valid — **verify polarity against that header**.
        - SMPS mode: `VLXSMPS`→`VFBSMPS` 15 µH, `VFBSMPS` 470 nF (DS13105 SMPS
          characteristics, Lout/Cout); `VDDRF1V55` tied to `VFBSMPS` (§3.9.1); `VDD`,
          `VDDRF`, `VDDSMPS`, `VDDA`, `VBAT` on `+3V3_RF` (§3.9.1 note: VDD/VDDRF/VDDSMPS wired
          together); 100 nF per supply pin plus 4.7 µF bulk; `VR_PA` decoupled.
        - Host map unchanged: `PA2/PA3` USART2 ↔ `UART_WIOE5_TX/RX` (net names kept so the DTS
          does not drift), `PB13` bind/boot button, `PA15` green LED, `PB5` red LED,
          `PA13/PA14` SWD, `NRST` 22 k pull-up + 100 nF, `PH3-BOOT0` 10 k pull-down.
        - **RF matching and harmonic-filter VALUES REQUIRE VERIFICATION.** The topology
          (RFO_HP DC-feed inductor from `VR_PA`, DC block, 2-section LC low-pass; RFI_P/RFI_N
          series-C / shunt-L balun) follows DS13105 Figures 2–4, but the 915 MHz element values
          come from ST AN5457, which could not be fetched here. Positions are populated with
          the topology and flagged `[VERIFY AN5457]` in the schematic; **bench-tune before
          flight** (same discipline as the Type 2EL antenna match). `TODO.md` §0.x item.
        - Alternative considered, not rejected: **Murata Type 1SJ** (STM32WLE5-based module,
          Japan) would remove the RF design burden; its datasheet was unobtainable here, so it
          is logged for the owner as a fallback if bench tuning of the bare chip fails.
        - Reference-designator prefix `WIOE5-*` → `MLRS-*` (`MLRS-MCU`, `X-MLRS`, `SW-MLRS`,
          `R-MLRS-*`, `LED-MLRS-*`, `FB-MLRS-*`, `J-MLRS-SWD`, `J-ANT-MLRS`, `D-ANT-MLRS`).
    5. **PB2 rails are no longer stack-through, and the P2 rail gets an 8-position gap
        (owner request 2026-09-29).** Commo Rev T is a standalone node (§1.2a.2), so nothing
        stacks on top of TACCO. The existing socket lands already carry their courtyard only on
        the component (bottom) side, so the top-face band between rail pins is DRC-free; the
        placer may put 0402/0201 parts there at 45° (a 1.56 × 0.86 mm 0402 courtyard fits in
        every 2.54 mm cell with ≥ 0.47 mm hole clearance). **Header-net clustering:** only
        GPIO-class nets can move (SPI0, MCAN0, SDIO, RMII0, MDIO, both UARTs are fixed to
        their PB2 balls). The six GPIO nets on P2-5..10 (`FAN_PWM_B`, `PLD_CLK`, `PLD_I1`,
        `PLD_I2`, `WIFI_EN`, `WIFI_IRQ`) move to the six spare P1 positions
        (P1-10/18/19/28/29/30), so **P2-3..10 becomes one contiguous 8-position gap**: the new
        `PocketBeagle2_2x18_P2_Socket_Gap3-10` land has no pads or holes there, the P2 socket
        is fitted as a 2×1 (pins 1–2) plus a 2×13 (pins 11–36) strip, and the matching PB2
        header pins 3–10 are left unpopulated. Both faces of that ~10 × 5.6 mm patch are free
        for parts. **Verification owed:** the repo has no PB2 ball-capability map; P1-10, P2-3,
        P2-4, P2-27 are GPIO by prior use, but **P1-18/19/28/29/30 must be checked against the
        PocketBeagle 2 pin map / SPRUJ40 before fab** (on the original PocketBeagle those were
        analog-reference/ADC positions). Tracked with the existing DTS pinmux `[ESTIMATE]`
        item in §1.2a.3.
    6. **Layout:** placement is regenerated by `gen_tacco_pcb.py` with a floor-planned FIXED
        table (connectors on edges, isolated CAN/RS-485 bus sides in the bottom band so the
        `ISO_BAND` rule area and GND2 islands match the real transceiver positions, RF at the
        antenna edge), then freerouting via the Specctra bridge, `kicad-cli pcb drc
        --severity-all --schematic-parity` to 0, Gerber/drill/position export.
    **Affected files:** `avionics/kicad/TACCO/scripts/gen_tacco_sch.py`,
    `gen_tacco_footprints.py`, `gen_tacco_pcb.py`, `avionics/kicad/Serenity-Custom.pretty/`,
    `avionics/kicad/TACCO/kicads/*`, `avionics/kicad/TACCO/gerbers/`, `TACCO.md`,
    `reports/HDD.md`, `avionics/firmware/` DTS (net names unchanged; UART_WIOE5_* kept).
    **Plan (units):** U1 this record + `TACCO.md` note → U2 footprints → U3 schematic
    generator, ERC 0, netlist → U4 PCB generator + placement DRC-clean → U5 route + DRC 0 →
    U6 Gerbers/drill/pos + gerber analyzer → U7 docs, HDD regen, TODO regen.
    - [x] U1 decision record (this entry) and `TACCO.md` status note — 2026-09-29.
    - [x] U2 footprints — KMR2 / Tag-Connect TC2030-NL / QFN-48 EP 5.6 / TG2520SMN / SC-70-6 from
        the KiCad 9.0.3 system library; RCLAMP0502B courtyard widened to cover its pads; the
        rail lands are unchanged (their courtyard is already component-side only). 2026-09-29.
    - [x] U3 schematic — beads, switch, SWD, STM32WLE5JC block, PB2 map (item 7), DP83825I
        table (item 8), SDIO removed, Wi-Fi/TPM 100 nF bypasses moved to 0201 (the only free
        sites left are the rail cells). `kicad-cli sch erc --severity-all`: 0 design violations
        (12 `lib_symbol_issues` are this container's missing global `power` library, not the
        schematic). 170 parts, 287 nets. 2026-09-29.
    - [x] U4 placement — all 170 parts on the 55 × 35 mm outline, `kicad-cli pcb drc
        --severity-all --schematic-parity` before routing: **0 errors, 4 silkscreen warnings,
        0 parity issues, 499 unconnected** (unrouted by definition). Floor plan: microSD and
        Wi-Fi module bottom-right, 1553 block left, isolated CAN/RS-485 band across the bottom
        with the GND2 islands and `ISO_BAND` derived from the SOIC-20W positions, mLRS radio at
        the right edge under its MMCX, Tag-Connect at (39.4, 26.0). 2026-09-29.
    - [ ] U5 routing: freerouting, outer GND pours, DRC 0 incl. `.kicad_dru` isolation rules.
      *Status 2026-10-07: board has 0 routed segments; the placed outline is 60 × 35 mm with 163
      parts (U4 below recorded 170 parts on 55 × 35 mm at 2026-09-29).*
    - [ ] U6 Gerbers (6 Cu + mask/paste/silk/edge), Excellon drill, pick-and-place, BOM.
    - [ ] U7 `TACCO.md`, `reports/HDD.md`, `TODO.md` regen, `REFERENCES.md` "Used in".
    - [ ] Owner: select the 0402 600 Ω bead MPN and the KMR2 variant; verify RF values (AN5457).
    - [x] ~~Confirm P1-18/19/28/29/30 are GPIO-capable~~ — **resolved by the owner-supplied PB2
        schematic (2026-09-29, item 7 below)**; the P2-3..10 gap is withdrawn.
    - [ ] mLRS HAL: BUTTON moves PB13 → PA0 (PB13 is not bonded on UFQFPN48), RF switch
        PA4 = RX_EN (PE4259 CTRL), PA5 = TX_EN (CTRL̄).
    7. **PB2 header map was wrong — rebuilt from the real schematic (2026-09-29, owner-supplied
        `avionics/datasheets/beagleboard/pocketbeagle2_sch.pdf` + `pocketbeagle-2.syscfg`).** The Rev S2
        `PB2_P1`/`PB2_P2` tables put GND on P1-1 (the PB2's 5 V **VIN**), +3V3/+5V on
        P1-33..36 (PRU/UART balls), MCAN0 on the GND pins P1-15/16, SPI0 on ADC/GPIO balls and
        SDIO on MDC/PRU balls; mating that cape would have shorted VIN to ground. The verified
        ball-by-ball map and the new TACCO allocation are in
        `avionics/kicad/PB2_HEADER_PINMAP.md` (MCAN0 P2-5/7, UART2 = RS-485 with hardware DE on
        UART2_RTSn, UART0 = mLRS link, UART1 + flow control = BT, SPI0 P2-25/27/29 + CS1,
        RMII2 + MDIO0 for the DP83825I, EHRPWM2_A = fan, GPIOs for the rest; net names
        `RMII0_*` → `RMII2_*`). The header is fully subscribed (24 GPIO-class nets on 25 free
        positions), so the "gap" clustering asked for on 2026-09-29 is not achievable; the
        `PocketBeagle2_2x18_P2_Socket_Gap3-10` land was removed again. **Pilot uses the same
        table family and must be re-derived the same way** (separate item, not done here).
        **Wi-Fi host interface:** MMC2/SDIO is not on the headers, so the Murata Type 2EL WLAN
        core (SDIO-only) cannot be hosted; the six SDIO beads are deleted and the module's SDIO
        pins are NC. **Owner decision 2026-09-29: Wi-Fi moves to a USB module on USB1
        (P1-9/11, `USB1_DP/DM/VBUS/DRVVBUS`), BT stays on UART1, 802.15.4 on SPI0.** Module
        selection is open: no vendor catalog or datasheet is reachable from this environment,
        so the USB Wi-Fi/BT module (non-restricted vendor) and, if Type 2EL is dropped, a
        separate 802.15.4 SPI radio need owner-selected parts with datasheets before the
        symbol/land can be authored. **FAB BLOCKER until resolved.**
    - [ ] Owner: choose the USB Wi-Fi/BT module (and 802.15.4 radio if Type 2EL goes) and
        supply datasheets; then author symbol/land, re-run the area budget (adds ≈ 100–200 mm²).
    8. **DP83825I pin table was wrong (found 2026-09-29 while wiring `RMII2_REF_CLK`).** The
        generator's `dp83825i()` (shared verbatim with Pilot's `gen_pilot_sch.py`) listed X1 on
        pin 8, X2 on 9, DGND 10, DVDD10 11, RESET 12, MDIO 13, MDC 14, INT 15, TXOP/TXON 17/18,
        RXIP/RXIN 21/22, RBIAS 24 — a DP83848-family table, not the DP83825I. TI SNLS638C
        Table 4-1 (WQFN-24 RMQ): 1 TX_EN, 2 50MHzOut/LED2, 3 INTR/PWRDN, 4 LED0, 5 RST_N,
        6 VDDA3V3, 7 RD_M, 8 RD_P, 9 GND, 10 TD_M, 11 TD_P, 12 XO, 13 XI/50MHzIn, 14 RBIAS,
        15 MDIO, 16 MDC, 17 RX_D1, 18 RX_D0/PHYAD0, 19 VDDIO, 20 CRS_DV, 21 GND, 22 RX_ER,
        23 TX_D0, 24 TX_D1, DAP GND. TACCO's table is rebuilt from the datasheet; in RMII
        Leader mode pin 2 sources the 50 MHz reference clock to `RMII2_REF_CLK` (P1-34).
        **Pilot's ETH1-PHY/ETH2-PHY carry the same defect (not fixed here).**
    - [ ] Pilot: PB2 header re-map against the OFFICIAL BeagleBoard references (owner
        2026-10-17: verify against BeagleBoard sources, not project files). Sources: openbeagle
        pocketbeagle/pocketbeagle-2 @ be5f0a4 (`pocketbeagle2_sch.pdf` V10 sheet 16,
        `design/pocketbeagle2 revA_dimension.pdf`, `images/pocketbeagle2-back.jpg`) and the
        PocketBeagle 2 SRM (docs.beagleboard.org/pocketbeagle-2.pdf) §4.2. Work items:
        - [ ] FLEET: `PocketBeagle2_2x18_P1/P2_TSM-DV-LC` footprints put pin 1 on the wrong row
            once placed on B.Cu (KiCad flip mirrors y): official drawing + silkscreen = P1 pin 1
            OUTER row, P2 pin 1 INNER row. Fix the library footprints; Pilot updated here.
        - [ ] FLEET: TACCO.kicad_pcb carries the same row swap (P1 pin 1 inner) — update its
            rails from the fixed footprints and re-check its routing.
        - [ ] Pilot `PB2_P1` / `PB2_P2`: power/GND/VIN/VOUT/3V3/USB/BAT/PWR_BTN/RESET# pins per
            SRM; hardware-fixed functions (RMII2 + MDIO0, SPI0, MCAN0, UART for RS-485, SPI2 /
            I2C / UART for the GH headers) on their mux pins; GPIO roles placed to shorten
            routes (firmware pin mux follows; no wiring decision rests on firmware alone).
        - [x] Ethernet ring, 2026-10-17: KSZ8863RLLI switch evaluated and REJECTED (10.5 mm
            courtyard; largest free square ~6 mm). Owner chose two NICs: CPSW3G port 2 / RMII2 leg =
            DP83825I on RMII2 + MDIO0 (TI SNLS638C re-verified); USB1 leg = USB 10/100 controller on USB1
            (P1-5/9/11), bridged in Linux (ring forwarding depends on this node's CPU — owner
            accepted). Candidates in Pilot.md "Rejected candidates".
        - [ ] ETH2 USB NIC = ASIX AX88772E (owner 2026-10-17; public datasheet v1.03, 0-70 C):
            owner to download the reference schematic, application design note v1.10 and demo BOM
            (free MyASIX login) into avionics/datasheets/, then replace the CH397A block (WCH =
            PRC, fails the AGENTS.md sourcing rule) and verify the 20 MHz crystal, buck inductor
            and decoupling against them.
            - [x] Datasheet v1.03 received 2026-10-17 (owner) and catalogued as REF-SENSOR-056: no
                confidentiality marking. The 0-70 C rating is accepted: the -40..85 C figure in
                docs/AVIONICS_PB2_REDESIGN.md is the PB2-I module's rating, not a board
                requirement (owner 2026-10-17).
            - [x] Reference schematic, application design note and demo BOM received 2026-10-18
                (owner) and catalogued as REF-SENSOR-057 / 058 / 060 (no confidentiality
                marking). CH397A block replaced in `gen_pilot_sch.py` (`ax88772e()` + support
                block, Claude Opus 5.5): ERC 0, 134 parts. Own ECS 20 MHz crystal
                [REF-SENSOR-059]; BLM15EX331 beads; VBUS = 4.7 k pull-up + P1-31 GPIO0_59 (owner
                2026-10-18). Pilot.md update 2026-10-18.
            - [x] `L-USB1` 2.2 uH: Murata DFE201610P-2R2M=P2 chosen 2026-10-20 (data sheet on file, land matches the
                Murata recommended pattern); all 55 BOM lines now carry an MPN and maker (REF-SENSOR-062).
            - [ ] Confirm ECS-200-20-33-AGM-TR option-code availability with a distributor.
            - [ ] DTS: hold P1-31 GPIO0_59 as an input (high-Z) by default; drive it low only to
                force an AX88772E USB detach.
        - [x] ~~Two JST-GH expansion headers replacing the GNSS~~ — superseded 2026-10-17 by the
            single-port item below (only one board-edge site).
        - [x] Sourcing rule (AGENTS.md §5, 2026-10-17), Pilot — done 2026-10-18 (Claude Opus 5.5):
            TVS-CAN -> TI ESD2CAN24DCKRQ1 [REF-SENSOR-053]; TVS-RS485 -> Bourns CDSOT23-SM712
            [REF-SENSOR-054] (the PRTR5V0U2X also clamped both buses to 0..5 V, far narrower than
            their common-mode ranges); TVS-1553P/N -> Bourns SMAJ33CA [REF-SENSOR-055], with a new
            `Manufacturer` schematic property. Pilot.md update 2026-10-18.
        - [x] Only one GH header fits at a board edge — done 2026-10-18 (Claude Opus 5.5): J-SPI is
            a 6-pin SM06B-GHS-TB (5V, SCK/UART1_TX, MISO/UART6_RX, MOSI/UART6_TX, SS1/UART1_RX,
            GND on the SPI2 pins); J-GPS, F-GPS, C-GPS5, R-I2C-SCL/SDA, ESD-GPS, ESD-SS2 removed;
            P1-31/33/36 and P2-2/4 spare.
        - [ ] Regenerate schematic (ERC 0), then PCB: sync, re-place, re-route, DRC 0 + parity 0.
            - [x] Placement (2026-10-19, Claude Sonnet 5.5 / Opus 5.5): parity 0, 0 copper DRC errors, 13
                warnings (reference designators moved to Fab). Committed; 130 unconnected items remain.
            - [ ] **Finish routing by hand** (owner decision 2026-10-20; R-1 in `avionics/kicad/Pilot/docs/Pilot-Design-Review.md`):
                130 open connections on 68 nets, listed in `docs/Pilot-Routing-Worklist.md`. Two automatic
                routers stalled (grid router 254 to 130; freerouting 2.2.4 about 190 unrouted). After
                routing: DRC with parity (0 / 0 / 0), refill zones, regenerate gerbers.
            - [ ] **Resolve R-15:** five through vias on non-exempt nets have centers inside the TI 13.1
                bubble outlines but DRC does not flag them. Relocate or find the cause.
        - [ ] Pilot manufacturing release (Sunstone fab, Cyber City Circuits assembly; owner 2026-10-19).
            Package: `avionics/kicad/Pilot/docs/Pilot-Manufacturing-Transfer.md`. Open items:
            - [ ] Stackup and controlled impedance (90 ohm USB1, 100 ohm Ethernet) from Sunstone's proposal.
            - [ ] Owner fab choices: thickness 0.062 / 0.063 in, finish, IPC class, Tg, ITAR / FAI.
            - [ ] Verify Sunstone outer-layer limits (min drill, annular ring, copper-to-edge): the
                capabilities tabs are script-loaded; call 800.228.8198 or send the RFQ.
            - [ ] Fiducials, part number and revision on silkscreen, panel strategy.
            - [x] Part numbers for the 26 BOM lines: done 2026-10-20 via the DigiKey API (key in ~/.config/secrets.env); owner to approve the makers; derate the X5R parts.
            - [ ] Catalogue IPC-6012 and the surface-finish standard in `REFERENCES.md`.
            - [ ] Verify the JST GH URL (REF-CONN-003 returned HTTP 403).
        - [x] Pilot ICDs, HDD, design review and manufacturing package written (kidoc scaffold, generated
            tables): `avionics/kicad/Pilot/docs/`. Open inside them: power budget, mass and CG, test-point
            plan, ICD OPEN items.
            - [x] Schematic regenerated 2026-10-18: ERC 0, 111 parts after the GH and TVS items,
                134 after the AX88772E swap.
            - [ ] PCB sync, re-place, re-route (DRC 0 + parity 0). The board gains 23 parts for
                the AX88772E (own crystal, buck inductor, two beads, per-pin decoupling) on a
                cape whose largest free square was ~6 mm. TVS footprints change (SOT-363 ->
                SC-70-3 / SOT-23); seven expansion parts leave. `refloorplan_pilot.py`
                PARENT anchors updated for the new `*-USB1` parts. Best done after the
                `L-USB1` MPN fixes its land.
        - [x] Pin and net name alignment, Pilot + TACCO (owner 2026-10-17): PB2 header pins
            P1.01..P2.36 (BeagleBoard SRM), Ethernet ring parts/nets to TI interface names
            (`PHY-RMII2`, `NIC-USB1`, `T-RMII2`, `T-USB1`, `RMII2_PHY_*`, `ETH_RMII2_*`,
            `ETH_USB1_*`, ...) in generators, schematics, symbol libraries, PCBs, netlists,
            project netclasses and scripts via `avionics/kicad/align_pb2_ti_names.py`. ERC /
            DRC / parity counts unchanged (Pilot 0 / 43 / 112 pre-existing; TACCO 0 / 5 / 0).
            Map in Pilot.md and TACCO.md.
        - [ ] Firmware: Pilot DTS overlay for the new pin mux.
        - [x] AM625 capability check against the SoC data sheet, 2026-10-17 (owner: "page 2 of its
            datasheet says that it supports 2 ethernet ports"): recorded in
            `avionics/kicad/PB2I_AM625_HEADER_CAPABILITIES.md` [REF-SENSOR-049] [REF-SENSOR-050].
            CPSW3G has 2 external ports but port 1 has no header balls; RGMII2 (gigabit) is fully
            on the header; 3 CAN-FD (MCAN0, MCU_MCAN0 P1-26/28, MCU_MCAN1 P2-9/11) reachable;
            P1-2/4/6 second balls added to `PB2_HEADER_PINMAP.md` §1.
        - [x] REJECTED 2026-10-17 (owner): second/third CAN-FD bus on MCU_MCAN0 (P1-26/P1-28) or
            MCU_MCAN1 (P2-9/P2-11). The fleet already has four buses per node (CAN-FD, RS-485,
            MIL-STD-1553B, Ethernet ring); another CAN-FD bus adds no needed capability.
        - [x] MSPM0L1105 on the PB2-I AIN pins — pin move REJECTED 2026-10-17 (owner); pins stay,
            RMII2 timing with the extra load is checked at bring-up. (capability doc §6): Pilot RMII2
            (P1-2/19/25/27) and DSHOT0/3 (P1-21/23) each also load an MSPM0 pin (5 pF + stub)
            whose post-boot state depends on BeagleBoard's MSPM0 firmware. Owner decision: accept
            (verify RMII2 timing with the extra load at bring-up), or move those nets off AIN
            pins in the next re-map. P2-35 carries the MSPM0 SWCLK pull-down — keep it spare.
            Analysis 2026-10-17: RMII2 cannot move (each RMII2 signal has one AM625 ball, SPRSP58C
            Table 5-5, wired only to its current header pin). DSHOT0/3 could move to another PRU0
            GPO pin, but the free ones (P2-30, P2-34) are on the P2 rail under ISO_BAND while
            J-PWM sits over the P1 rail, so a move lengthens routes and crosses the band; DShot
            is not sensitive to 5 pF. Recommendation: keep the pins and verify RMII2 at bring-up.
            - [ ] Bring-up: verify RMII2 timing/eye on P1-2/19/25/27 with the PB2-I MSPM0 load.
        - [ ] Pilot + TACCO DTS: hold the unused second ball of every dual-ball header pin
            (P1-2/4/6/10/12/26/28/33/36, P2-1/3/5/7/9/11/29/31) as a GPIO input with no pull
            (PB2I_AM625_HEADER_CAPABILITIES.md §2 CAUTION).
    - [ ] FLEET sourcing audit (AGENTS.md §5 "Component sourcing and openness", owner
        2026-10-17): check every board's ICs / semiconductors / modules for manufacturer
        domicile/control in a restricted country and for NDA-only datasheets — TACCO, XO, Commo,
        Observer, Flight Engineer, CAN-PERIPH-GW-1, ESC / servo boards. Nexperia parts
        (PRTR5V0U2X, PMBT2222A in the shared library) are the first known hits.
    - [ ] Firmware: TACCO DTS overlay per `PB2_HEADER_PINMAP.md` §4 (console moves off UART0).
- [x] **Flight Engineer schematic-first rebuild — ERC 0.** 2026-09-20 (Claude
    Sonnet 5): the legacy schematic (586 ERC violations, PCB pad nets not
    matching at all, `gen_flight_engineer.py` itself confirmed drifted per its own
    injector script's warning) was replaced by a fresh generator
    (`avionics/kicad/FlightEngineer/scripts/gen_fe_sch.py`), transcribing every
    pin table from OEM datasheets: TPS54620/TPS54540 (dual+single BEC),
    INA226 x5, BQ76930 (6S cell monitor, Table 9-3 6-cell tap config), plus
    the CURRENT (not superseded) trust module target — MSPM0G3518-Q1 RHB-32
    (pinmux reused verbatim from `retarget_mspm0g351x_slb9672.py`'s own
    verified `FLIGHT_ENGINEER_REMAP`/`FLIGHT_ENGINEER_TPM_NETS` tables, not
    re-derived), SLB9672, ISOW1044BDFMR, ISOW1412DFMR (same parts/pin tables
    as Pilot/XO). ISOW1412's EN/FLT pin now wired to a real MCU GPIO
    (RS485_FLT_N) instead of Pilot's hard-tied convention, since the RHB-32
    pinmux happened to free one. ERC 0 confirmed (151 parts, 539 pins).
    **One part-number defect found in FlightEngineer.md's own BOM and
    corrected** (flagged, not silently fixed): "AON6556" (Q_BATT_DSG,
    cited 60V/30A) does not exist in AOSMD's catalog (their 30V AlphaMOS
    family tops out at AON6554/6558; no 60V "6556" found) — substituted with
    AON6260, a real AOSMD 60V/85A DFN5x6 MOSFET, NEEDS owner confirmation.
    MBRD1045CT and SMBJ33CA are confirmed real via manufacturer/distributor
    catalog search but their datasheet PDFs could not be fetched this pass
    (every mirror blocked) — standard package pinouts used, flagged for a
    follow-up fetch. **PCB: courtyard-budgeted before layout** per
    `docs/solutions/conventions/pb2-cape-datasheet-verified-footprints-and-
    courtyard-budget-before-layout.md` — 7377 mm^2 total footprint area vs
    FlightEngineer.md's own 90x65mm/4-layer spec (11700 mm^2 two-sided
    theoretical ceiling) = 63%, comfortably under the ~70% (4-layer)
    guideline, so no capability was cut to make this board fit (unlike XO).
    All 151 footprints placed (0 unplaced). DRC reduced from a 213-hard
    baseline (on the old, unrelated PCB) to **31 remaining violations** on
    the new layout (9 solder-mask-bridge + 8 shorting-items + 8 cosmetic
    silk-over-copper + 4 hole-clearance + 2 clearance), all concentrated
    around D_OR1/D_OR2 (the 5V BEC OR-diodes) and U_RS485 landing close to a
    few ESC-branch passives — a placer packing-density limit on this
    generator's simple rectangular spiral placer (same class of limit XO
    hit), not an area or scope problem. Routing not yet attempted.
- [ ] **Flight Engineer PCB: close the last DRC items + route + gerbers —
    not started.** Follow-on to the rebuild above. The remaining violations
    are localized to D_OR1/D_OR2 vs CM_ESC3/F_ESC3/C_DEC4 and U_RS485 vs
    C1/C2 — nudging those ~5 footprints apart in the KiCad GUI (same
    approach used on XO) should clear it faster than further generator-side
    placement iteration. The project's own `tools/validate_kicad.py` CI gate
    (run 2026-09-21 via PR #207's "KiCad Validation" check) reports **29
    hard violations** on the current `FlightEngineer.kicad_pcb` — close to,
    but not identical to, the 31 raw `kicad-cli pcb drc` count recorded
    above (the CI validator applies its own accepted-class filter, which
    reclassifies a small number of findings — not a design change). Then
    `kicad-cli pcb drc --severity-all --schematic-parity` to 0, freerouting
    attempt via the Specctra bridge (reject/report on any shorts, same
    discipline as Pilot/XO), then gerbers.
- [x] **Observer PCB resync — done 2026-07-27 on `don't-let-all-the-air-out`; merged and
    retargeted 2026-10-18.** The branch's resynced PCB (ISOW1412 U6 + trunk connectors, nets
    from the schematic netlist, 124 pre-existing DRC violations fixed, scoped `Observer.kicad_dru`
    pad-pitch exceptions) replaced the 2026-07-14 PCB, and `retarget_pcb_footprints.py --apply`
    (Observer job) re-applied the MCU/TPM footprint retarget on top. KiCad 9.0.2, default rules:
    0 copper/clearance errors, 305 unrouted connections. Open: route, re-verify sch<->PCB parity
    (§1.9.3), regenerate gerbers (the branch's pre-retarget `Jayne/gerbers` were dropped as stale).
- [ ] **Observer PCB: route (305 unrouted), re-verify sch<->PCB parity, regenerate gerbers.**
    Open remainder of the resync item above, split out 2026-10-19 so the generated TODO keeps it.
- [ ] **Reconcile 2026-10-18 — branch work NOT carried into main (decision: main wins).**
    Recorded here so it is not rediscovered as "missing". All of it remains in git history on
    `don't-let-all-the-air-out`: (a) the Kaylee MAX42408/LM76005 buck architecture (4x MAX42408
    36 V/8 A, 1x LM76005, 6x INA226, per-ESC CMC) vs FlightEngineer's TPS54540/TPS54620 BEC
    design; (b) the Wash Jul-28 rebuild (DS26LV31/32 1553, SAM-M10Q) superseded by Pilot Rev T
    (HI-6138, MAX-M10S); (c) CAN-PERIPH-GW-1 2-stack alignment placement vs Bus-Gateway
    `N_STACKS=4`; (d) the Rev R3 fuselage splice-collar redesign vs main's Sep-5 collars.
- [x] **Commo schematic file-corruption fix — lib_id prefix, ERC 127 -> 48.**
    2026-09-20/21 (Claude Sonnet 5): `Commo.kicad_sch` had no
    `sym-lib-table`/`fp-lib-table` and used bare (unprefixed) `lib_id`s
    (e.g. `"S_+5V_Bead"` instead of `"Commo:S_+5V_Bead"`) — prefixing only
    the instance references without also prefixing the matching embedded
    `lib_symbols` cache-key definitions produced a state that segfaulted
    `kicad-cli sch erc` outright. Fixed both together (matching
    `gen_pilot_sch.py`/`gen_xo_sch.py`'s own convention), extracted the
    embedded `lib_symbols` block into a companion `Commo.kicad_sym`, added
    the missing `sym-lib-table`/`fp-lib-table`. Raw `kicad-cli sch erc`
    count: 127 -> 48 (all 79 `lib_symbol_issues` resolved; 43
    `global_label_dangling` + 5 cosmetic `endpoint_off_grid` remain,
    neither diagnosed yet). **Per the project's own `tools/validate_kicad.py`
    CI gate** (accepted-class-aware), `Commo.kicad_sch` is already **0 hard,
    51 soft (accepted-class)** — the dangling-label findings are in an
    accepted class, so this schematic already clears the real gate despite
    the raw ERC count looking non-zero. PCB side (DRC) not yet touched this
    pass; legacy baseline was 160 DRC / 113 unconnected.
- [x] **avionics PR #207 opened and babysat.** 2026-09-21 (Claude Sonnet 5):
    the `avionics` branch's accumulated work (XO/FlightEngineer rebuilds,
    RFD900ux-SMT swap, LoRa dedup, mLRS rejection, Commo lib_id fix) pushed
    to PR #207 (`Stab-Rabbit-coding/Serenity-UAV#207`). All 12 unresolved
    review threads resolved — every one was a GitHub Advanced Security
    (devskim) false positive: 9x `DS126858` "Weak/Broken Hash Algorithm"
    matched the substring `md4` inside the `SMD4` (Surface-Mount-Device
    4-pad) Johanson RF-filter footprint-family naming convention (no
    `hashlib`/md5/sha1 call exists in either flagged file); 3x `DS176209`
    "Suspicious comment" matched the literal word "TODO" inside BOM `Notes`
    fields referencing this project's own tracked `TODO.md` items. All 12
    alerts dismissed as false positive. CI lint/type-check failures fixed
    (`mypy`/`flake8`/`shfmt`) — one was a real bug (a module-level variable
    name reused across two unrelated loops in `gen_pilot_sch.py` with
    genuinely different types), the rest were formatting/annotation gaps.
    **The `KiCad Validation` CI job carries `needs: lint` in `ci.yml`, so it
    had never actually run on this PR until the lint fix unblocked it** —
    it then surfaced the 131 pre-existing hard DRC violations recorded
    above (102 XO + 29 FlightEngineer), which are the same open placement
    work, not a regression from this PR. **Owner decision 2026-09-21:**
    leave `KiCad Validation` red and accepted as documented follow-up work
    rather than a merge blocker — `main` carries no branch-protection rules,
    so nothing technically prevents merging PR #207 as-is. PR not yet
    merged as of this entry.

---

## Procurement — §2.4, §2.5 (Avionics BOM tables)

*(root `TODO.md` §2.4-§2.5)*

*Rev R: all nodes use v2 EMI-hardened capes. Pilot / Cape-B-1 / XCVR-49MHZ-1 are retired.*

| Item | Qty | Unit Cost | Total | Notes |
|------|-----|----------|-------|-------|
| PocketBeagle 2 Industrial (AM6254) | 4× | $51.03 | ~$204 | DK 2820-100003007-ND |
|Pilot PCB (JLCPCB assembled) | 2× | ~$55 | ~$110 | FC1/Shepherd's room (Bay A) + FC2/Inara's shuttle (Bay B) (v2, EMI-hardened) |
| XO (XO) PCB (JLCPCB assembled) | 2× | ~$95 | ~$190 | CN1/Shepherd's room (Bay A) + CN2/Inara's shuttle (Bay B) (v2, EMI-hardened) |
| Commo PCB (JLCPCB assembled) | 2× | ~$25 | ~$50 | 49 MHz (Part 15 §15.235) sub-module for CN1, CN2 (v2 EMI-hardened) |
| SiK 915MHz ground station radio | 1× | ~$15 | ~$15 | MAVLink GCS link |
| microSD 64GB (log, write-blocked) | 2× | ~$10 | ~$20 | CN1-LOG, CN2-LOG |
| JST-GH cables: CAN 3-pin, RS-485 3-pin, ETH 6-pin, 1553 4-pin, GPS 5-pin | assorted | — | ~$20 | Per §14 connector table |
| USB-UART adapter (CP2102) | 1× | ~$8 | ~$8 | Debug console (one-time tool) |
| 3M double-sided foam tape | 1× | ~$5 | ~$5 | ESC and node mounting |
| Zip ties 100mm + 200mm | 1 bag | ~$4 | ~$4 | Wire management |

*Rev Q: all Phase 7 nodes also use v2 EMI-hardened capes.*

| Item | Qty | Approx. Cost | Notes |
|------|-----|-------------|-------|
| PocketBeagle 2 Industrial (AM6254) | 4× | ~$204 | CN3, FC3, CN4, FC4 |
|Pilot PCB (JLCPCB assembled) | 2× | ~$110 | FC3/River's room (Bay C) + FC4/Simon's medbay (Bay D) (v2) |
| XO (XO) PCB (JLCPCB assembled) | 2× | ~$190 | CN3/River's room (Bay C) + CN4/Simon's medbay (Bay D) (v2) |
| Commo PCB (assembled) | 2× | ~$50 | CN3, CN4 (v2 EMI-hardened) |
| microSD 64GB (log) | 2× | ~$20 | CN3-LOG, CN4-LOG |
| VL53L5CX 8×8 ToF sensor | 12× | ~$84 | Dual OA arrays |
| TCA9548A 8-ch I²C multiplexer | 2× | ~$3 | One per array host |
| MCP23008 8-port I²C GPIO expander | 2× | ~$2.40 | XSHUT control |
| JST-SH1.0 4-wire sensor cable 300mm | 12× | ~$12 | ToF sensor leads |
| 5mm PMMA disc 0.5mm thick | 12× | ~$6 | ToF aperture covers |
| UV adhesive | 1× | ~$6 | ToF aperture seal |
| JST-GH cables (remaining bus segments) | assorted | ~$20 | Ring completion |
