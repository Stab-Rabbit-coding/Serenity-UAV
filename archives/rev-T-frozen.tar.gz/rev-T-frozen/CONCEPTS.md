# Concepts

Shared domain vocabulary for this project — entities, named processes, and status concepts with project-specific meaning. Seeded with core domain vocabulary, then accretes as ce-compound and ce-compound-refresh process learnings; direct edits are fine. Glossary only, not a spec or catch-all.

## Hull Frame

The single coordinate system every airframe design artifact (SCAD source, generated STL, FreeCAD assembly) is authored or baked into: X positive toward port, Y positive toward aft, Z positive dorsal (up), with the origin at the full-assembly world origin. A part's own local modelling frame is distinct from hull frame until it has been explicitly baked into it — a raw generator output is not assumed to already be in hull frame.

## Fuselage Section

One of the four hull-frame body segments — head, cargo, middle, rear — each published as its own independent, individually watertight STL. Sections are joined end to end along the hull Y axis at three fuselage joints, in order: head/cargo, cargo/middle, middle/rear.

## Mating Face

The flat cross-section at one end of a Fuselage Section where it meets the adjacent section at a fuselage joint. A mating face must be a genuinely open bore — not a solid disk — so a Splice Collar can pass through it and bond to the section's inner wall; a mesh check that only confirms the section is watertight cannot tell an open mating face from one sealed shut by a thin membrane, because both report as watertight.

## Splice Collar

The internal bonded sleeve that joins two adjoining Fuselage Sections across a fuselage joint, inserted through both sections' open Mating Faces and bonded to each section's inner wall. A collar secures and aligns the joint; it is not a substitute for either section's own load path.

## Tilt Spar

The transverse carbon-fibre member at the wing root that carries the nacelle's loads into the fuselage, running along the hull X axis at the spar station. Since Rev T1 it is a **fixed, bonded wing member**, not a rotating shaft: the nacelle pivots on its own trunnion bearings, and tilt torque travels a separate, smaller Tilt Drive Shaft. (Through Rev S it was keyed to the nacelle and rotated with it, which is why older documents treat "spar" and "tilt axis" as the same thing — they no longer are.)

## Tilt Drive Shaft

The Ø4 steel shaft, parallel to the Tilt Spar, that carries tilt torque from the fuselage-mounted actuator out to the nacelle. It turns more than one revolution over the nacelle's sweep because the tip stage is a reduction, so the nacelle angle is read by an absolute sensor on the nacelle itself rather than inferred from the shaft.

## Tilt Drive Train

The two-stage path from the tilt actuator to the nacelle: a fuselage stage on the Tilt Drive Shaft (a worm stage) and a tip stage at the nacelle. A train is either self-locking or it is not; when it is not, a Tilt Brake — never the motor's own drag — is what holds the nacelle unpowered. For a motor coaxial with its worm, the motor's clearance to the wheel tip is set by the worm's pitch diameter alone — not by the centre distance and not by where the worm sits on the wheel — so the worm's inboard reach caps the motor diameter.

## Layout Envelope

A simple solid — box or cylinder — standing in for a piece of equipment, a moving part, a cable zone or a keep-out inside a Fuselage Section, used to prove a layout by boolean intersection against the section's published shell and against every other envelope, rather than by eye. Each envelope carries its own clearance budget (larger for moving parts than for static ones) and a declared list of the envelopes it is allowed to touch; anything a bracket or cradle carries must be an envelope too, because a part drawn only in its own source file is invisible to the proof.

## Void Former

A removable printed shape, cut to the exact cavity of a published shell, that is placed before an optional foam pour and withdrawn after cure so that the volume it occupied — a collar seat, an equipment bay, a harness way — stays foam-free. Formers are derived from the shell mesh, not drawn by hand, because a hand-drawn shape is either too big to insert or leaves a foam fillet where the equipment must later go.

## Chin Node Shelf

The printed plate on the cargo-section chin floor, under the battery nose and forward of the hoisted payload, that carries two comms control nodes lying flat side by side with a shared cable channel on the centreline. It exists because the chin flanks beside the battery were measured too narrow three times; the chin floor was clear first try.

## Tilt Brake

The spring-applied, power-released mechanical lock that holds a nacelle at its last commanded angle when its actuator loses power. It is flight-critical because every propulsion path is fused independently so the aircraft can descend on the remaining units; the brake must survive the actuator's own path failing during that descent.

## Unison Ring

The single rotating ring inside a nacelle's nozzle that drives every nozzle flap together, so all flaps hold one common exit area rather than being actuated individually. It rotates about the duct axis, and its rotation angle is what sets the nozzle's exit area; a cam or lever profile on the ring converts that one rotation into each flap's swing.

## Passive Tilt Drive

The project's standing requirement that the nozzle's exit area be driven by nacelle tilt alone — no dedicated nozzle actuator, servo, or control channel. Nozzle position is a pure function of tilt angle, so tilt and nozzle schedule cannot disagree in flight.

Because the driven parts ride the tilting nacelle, a passive tilt drive must take its input datum from a body that does *not* tilt with the nacelle (the wing); a pickup fixed to any nacelle-mounted body, the Tilt Spar included, has zero relative motion against the Unison Ring and transmits nothing.

## Tilt Controller

The per-side bus device that closes the tilt actuator's inner loop: it drives the gearmotor, reads the actuator-shaft sensor, holds and releases the Tilt Brake, and receives the nacelle's absolute angle from the gateway over the fleet bus. It is an instance of the project's own Open-Secure-ESC platform (a brushed-DC build), not a servo controller, so its identity is a build folder in that repository rather than a board of its own.

## Control Node

One of the four PocketBeagle 2 Industrial single-board computers that fly the aircraft, each with exactly one cape stacked on its two 0.1 in rails and each carrying a point of presence on all four wired buses (MIL-STD-1553B, CAN-FD, RS-485, Ethernet) so any node can take over any role. Flight-control nodes carry the Pilot cape; comms nodes carry the TACCO cape (formerly called XO). Nodes are spread through the airframe — a Faraday tray in the nose, Faraday pouches in the cargo section, and a saddle in the middle ring — and sit in a different orientation at each station, so a cape's outline is bounded by the node envelope at every station it occupies, not just one. That is why a node is one cape, never a stack of two, and why a cape's board size is never changed without re-proving every station that carries it.

## Cape Usable Band

The strip of a cape between its two PocketBeagle 2 stacking rails that can actually hold parts and copper. Each rail centre-line sits 4.80 mm inside its long edge (PB2 System Reference Manual Fig. 3.45; the rails are 25.4 mm apart). With through-hole rail sockets the pads exist on every copper layer, so the rails consume both faces and no part on either face may put pads over them; with surface-mount rail connectors whose pads stay under their own body the rails consume only the face they mount on, and the opposite face over them is usable. Component area budgets are computed against the usable band, per face, using each footprint's courtyard and checking every through-hole or NPTH pad against the opposite face's copper, not against the board outline or package body sizes.

## Shared Header Pin

A PocketBeagle 2 stacking-rail pin that is wired on the PocketBeagle itself to more than one active pin: two SoC balls, an analog-input pin of the board's co-processor, or both. The board documentation names the second SoC ball with an "A" suffix (for example P1.02A). A cape owns only one function on a shared header pin. Every other pin tied to it must be held as a high-impedance input. Its load and stub stay on the cape's signal whatever the cape does, so fast signals on a shared header pin are budgeted with that load. Whether the other pins stay quiet is a firmware setting, so it is never the basis for a wiring decision.
*Avoid: dual-ball pin, A-pin*

## Isolation Band

The region of a cape that belongs to the isolated (bus-side) reference of the isolated CAN-FD and RS-485 transceivers: their isolated pin rows, the field connectors and the filters between them. Only isolated-domain nets and chassis ground may have copper inside it on the layers it covers, and the main ground and supply planes are cut away beneath it; the gap between the band and logic-side copper is the barrier the board actually delivers, whatever the transceiver's own isolation rating says. A band need not cover every layer: when every isolated pad sits on one face, the opposite outer layer may carry logic copper beneath it, separated by the laminate, provided no logic via enters the band — so whatever sits there must route on that face alone.

## Bay Station

One of the two fore-aft positions — fore and aft — at which a landing-gear bay
is mounted on each side of the cargo section. Each of the four corners
(station × side) is its own printed solid, generated from one SCAD design
source: the bay's back face conforms to the hull flank measured at that
corner, so the fore and aft bays differ, and each starboard bay is the
**mirror image** of its port twin about the ship centreline, not a rotated
copy. Any property claimed for "the bay" (one body, clearance, fit) has to be
shown at every corner, because the conforming back face alone can change it.

## Gear Box

The canonical (Henning) faceted block on each lower cargo flank, under the wing root, that houses the landing-gear hips. Each thigh leaves the box through a square leg-support pillar with an open trapezoidal swing slot. It is fused into the one-piece forward hull as skin, not as a separate part: its walls stand only outside the old hull, and its interior opens into the cargo hold. The bolted gear bays (see Bay Station) sit inside it as internal structure. It is styling plus enclosure, not the primary load path.

## Corner Cartridge

The field-replaceable unit for one landing-gear corner: leg, hip pin, CF backbone, tension fuses and mounting frame, removed and installed as one assembly through a removable canonical hatch in the Gear Box. A broken corner is swapped in the field and repaired at the bench. Port and starboard cartridges are exact mirrors; fore and aft cartridges differ.
