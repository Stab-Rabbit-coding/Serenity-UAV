#!/usr/bin/env python3
"""Serenity UAV -- the aircraft datum (frame R2), defined ONCE.

Every generator, gate and SCAD part reads its hull datums from here instead of
re-typing them.  Before 2026-10-19 the hull centreline alone existed as
-169.85, -169.9, -170.0 and -169.241 in different files, the head and cargo
bake translations were copied into three scripts, and the shells themselves
had drifted off the centreline (rear 5.9 mm to starboard, head 1.6 mm to
port) -- owner direction 2026-10-19: "standardize the generator scripts to
prevent future drift".

Rules (enforced by tools/check_datum_drift.py, run by .githooks/pre-commit and
CI):
  * Python imports these names; it never assigns a datum to a literal.
  * OpenSCAD includes the GENERATED airframe/openscad/hull_datums.scad
    (``python3 tools/hull_datums.py --write-scad``); it never re-types them.
  * Shell bake placements live in tools/bake_hull_frame.py COMPONENTS and are
    read through bake_translation(); starboard twins are DERIVED by mirroring
    about X_CL, never measured separately.

Dependency-free (standard library only) so FreeCAD's interpreter and the
OpenSCAD writer can both use it.

Aircraft frame R2: X = +port, Y = +aft, Z = +dorsal (mm); origin = centreline / nose
tip / 3.0 in ground plane (AGENTS.md datum rule; plan 2026-10-19-001).

Author  : Steve Griffing, PE(CSE), CISSP-ISSEP, CEH (GitHub Stab-Rabbit-coding)
AI note : Written by Claude (Claude Opus 5.5, Anthropic) under the author's
          direction, 2026-10-19, per AGENTS.md AI attribution.
License : MIT -- see LICENSES/MIT (SPDX-License-Identifier: MIT)
"""

from __future__ import annotations

import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.dirname(HERE)
SCAD_OUT = os.path.join(REPO, "airframe", "openscad", "hull_datums.scad")

# AIRCRAFT DATUM, frame R2 (owner directive 2026-10-19): the ONE origin for the
# whole aircraft -- X = 0 on the centreline (port/starboard symmetry plane),
# Y = 0 at the nose tip, Z = 0 on the static ground plane with the aircraft at
# rest and level on the 3.0 in flight gear.  +X port, +Y aft, +Z up.
#
# The former R1 "hull frame" origin was the SerenityAssembly.FCStd world
# origin; R2 = R1 + R1_TO_R2.  In R1 the centreline was X -169.85 (the value
# the cargo merge and layout tools were built on; head and rear re-centred onto
# it 2026-10-19), the nose tip Y -305.704 (foremost vertex of the re-centred
# head shell -- the datum is set at -305.70, leaving the tip at Y -0.004 mm so
# every converted Y stays on its original 0.01 mm grid), the 3.0 in foot-sole
# plane Z -80.00.  R1_TO_R2 is used ONLY by migration tools; nothing else may
# carry R1 numbers (tools/check_datum_drift.py).
R1_TO_R2 = (169.85, 305.70, 80.00)

# Header marker stamped into every published aircraft-frame STL (80-byte
# binary header).  One definition; every generator that writes or checks the
# marker imports it.
FRAME_MARKER = b"SerenityUAV AIRCRAFT-FRAME R2"

X_CL = 0.0            # centreline
Y_NOSE = 0.0          # nose tip
GROUND_Z_3IN = 0.0    # static ground plane, 3.0 in flight gear

# Cargo belly (lowest skin of the cargo section, R1 Z 0).
BELLY_Z = 80.0

# Wing root station -- THE ONE fore/aft number for the wing root and every
# part that has to fit around it (spar socket, root flange, mortise, harness
# ports, drive-shaft bushing, tilt worm stage, wing and nacelle bakes).
#
# 2026-10-31 (plan docs/plans/2026-10-31-001-feat-one-piece-aft-sls-hull-plan.md
# R5, owner-settled): the single tilt pivot moves 0.5 in (12.7 mm) AFT, so the
# root leading edge goes 298.70 -> 311.40.  Before this date the leading edge
# was typed as a literal in merge_cargo_interior.py, the spar line here, the
# shaft station in cargo_layout_fit.py and the wing bake in bake_hull_frame.py
# -- four copies of one fact.  They now all read these names.
#
# The chordwise stations are fixed by the WING (wings_s1223_revo.scad
# SPAR_BORE_STATION / SHAFT_BORE_STATION) and are NOT free here: the shaft is
# 25.6 mm aft of the spar because that is the 14T/50T m0.8 tip-stage centre
# distance at the nacelle ((14 + 50) x 0.8 / 2), so the two move together.
WING_LE_ROOT_Y = 311.400      # R1 -7.0 + 12.7 (was 298.700 until 2026-10-31)
WING_ROOT_CHORD = 129.0
WING_SPAR_STATION = 28.00     # mm aft of the root LE (wing SPAR_BORE_STATION)
WING_SHAFT_STATION = 53.60    # mm aft of the root LE (wing SHAFT_BORE_STATION)
WING_AFT_SHIFT_2026_10_31 = 12.7  # record of the move; used only by audit tools
# Shift still to be ADDED by CG studies that model "the 0.5 in pivot shift"
# on top of the live ledger (cg_relocation_study family, aft_skin_thinning,
# min_stretch_relocation, twin_head_pack_fit).  It was 12.7 while the shift
# was planned; it is 0.0 now that the geometry, the pivot and the ledger all
# carry it -- adding it again would count the shift twice.
PENDING_PIVOT_SHIFT = 0.0

# Wing spar line = nacelle tilt axis = hover thrust line (Rev T6): the spar and
# its fuselage socket are level here (merge_cargo_interior.py WING_SPAR_Z,
# wings_s1223_revo.scad dihedral).  R1 (Y 21.000, Z 66.851) before the
# 2026-10-31 shift; now Y 339.400.
SPAR_Y = WING_LE_ROOT_Y + WING_SPAR_STATION      # 339.400 (was 326.700)
SPAR_Z = 146.851
# Clamshell cargo-bay door aperture, fore/aft (the belly opening the payload
# box is hoisted through; doors, hinge knuckles, merge_cargo_interior.APERTURE,
# the hoist line and the AUW ledger all read it).
# 2026-10-31 (owner): moved 3.0 mm FORWARD, 307.70 -> 304.70, so that with the
# wing root 12.7 mm aft the hoist line (box hung 1.0 mm off this edge) lands at
# Y 356.5 -- 3.0 mm clear of the unswung tilt worm and 17.1 mm aft of the
# thrust line (the closest the fixed-size bay allows; it was 21.8 mm).
CARGO_BAY_Y_FWD = 304.700     # R1 2.0 - 3.0
CARGO_BAY_LEN = 106.0
CARGO_BAY_Y_AFT = CARGO_BAY_Y_FWD + CARGO_BAY_LEN  # 410.700 (was 413.700)

# Tilt drive-shaft axis (wing chord station 53.6, hull Z from the camber
# midline -- merge_cargo_interior.py WING_SHAFT_Z).
SHAFT_Y = WING_LE_ROOT_Y + WING_SHAFT_STATION    # 365.000 (was 352.300)


def mirror_x(x: float) -> float:
    """Starboard twin of a port X (or vice versa) about the hull centreline."""
    return 2.0 * X_CL - x


def bake_translation(component: str) -> tuple[float, float, float]:
    """(Px, Py, Pz) of a shell's bake placement, from bake_hull_frame.py."""
    if HERE not in sys.path:
        sys.path.insert(0, HERE)
    import bake_hull_frame as bhf  # local import: bake_hull_frame imports this module
    px, py, pz = bhf.COMPONENTS[component][1][:3]
    return (px, py, pz)


DATUMS = {"X_CL": X_CL, "Y_NOSE": Y_NOSE, "GROUND_Z_3IN": GROUND_Z_3IN, "BELLY_Z": BELLY_Z,
          "WING_LE_ROOT_Y": WING_LE_ROOT_Y, "SPAR_Y": SPAR_Y, "SPAR_Z": SPAR_Z,
          "SHAFT_Y": SHAFT_Y, "CARGO_BAY_Y_FWD": CARGO_BAY_Y_FWD,
          "CARGO_BAY_Y_AFT": CARGO_BAY_Y_AFT}


def scad_text() -> str:
    lines = ["// hull_datums.scad -- GENERATED by tools/hull_datums.py --write-scad.",
             "// Do not edit: change tools/hull_datums.py and regenerate.",
             "// Aircraft datum R2: origin centreline / nose tip / ground plane on the",
             "// 3.0 in gear; X = +port, Y = +aft, Z = +dorsal (mm)."]
    lines += [f"{k} = {v:.4f};" for k, v in DATUMS.items()]
    return "\n".join(lines) + "\n"


def main(argv: list[str]) -> int:
    if "--write-scad" in argv:
        with open(SCAD_OUT, "w", encoding="utf-8") as fh:
            fh.write(scad_text())
        print(f"wrote {os.path.relpath(SCAD_OUT, REPO)}")
    elif "--check" in argv:
        ok = os.path.exists(SCAD_OUT) and open(SCAD_OUT, encoding="utf-8").read() == scad_text()
        print("hull_datums.scad " + ("up to date" if ok else "STALE -- run --write-scad"))
        return 0 if ok else 2
    else:
        for k, v in DATUMS.items():
            print(f"{k:14s} {v:10.4f}")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
