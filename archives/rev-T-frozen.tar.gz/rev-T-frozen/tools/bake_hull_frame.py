#!/usr/bin/env python3
"""
bake_hull_frame.py — bake validated FreeCAD placements into STL files.

Revision: R1 (2026-06-11)

Purpose
-------
As of Rev R1 the project standardises every 3D artifact on the single
empirically validated hull-frame coordinate system (see CLAUDE.md,
"FreeCAD Assembly Coordinate System"):

    X  positive port (left)
    Y  positive aft (back)
    Z  positive dorsal (up)
    Origin: the SerenityAssembly.FCStd world origin.

This tool applies each component's validated FreeCAD placement
(rotation quaternion + translation, extracted from
airframe/freecad/assembly/SerenityAssembly.FCStd, 2026-06-10) directly
to the STL vertex data, so the published STL coordinates ARE hull-frame
coordinates.  After baking, the FreeCAD assembly loads every component
with an identity placement and no per-part recalculation is needed.

Pipeline rule (Rev R1 onward)
-----------------------------
Generator scripts (OpenSCAD / Blender) may model parts in a convenient
part-local frame, but any STL published to airframe/stls/ for one of
the components listed in COMPONENTS below MUST be passed through this
tool after regeneration:

    python3 tools/bake_hull_frame.py            # bake all components
    python3 tools/bake_hull_frame.py Head_Shell # bake one component
    python3 tools/bake_hull_frame.py --check    # report state, no write

Idempotence / safety
--------------------
Output is always binary STL.  The 80-byte binary header is stamped with
the marker "SerenityUAV HULL-FRAME R1"; a file whose header already
carries the marker is skipped, so the transform can never be applied
twice.  ASCII STL input (OpenSCAD export) is converted to binary on
bake.  Bounding boxes are printed before and after baking, and the
written file is re-read and verified against the in-memory result.

Quaternion convention matches FreeCAD App.Rotation: (Qx, Qy, Qz, Qw)
with Qw the scalar; vertices map as v' = R(q) @ v + P.  The
quaternion-to-matrix expansion follows Shoemake, "Animating rotation
with quaternion curves", SIGGRAPH 1985 (standard form).

Binary STL layout per the 3D Systems STL specification (1989):
80-byte header, uint32 triangle count, then 50 bytes per triangle
(normal 3f, vertices 9f, uint16 attribute byte count).

Author:  Steve Griffing, PE(CSE), CISSP-ISSEP, CPP
License: CERN-OHL-W-2.0 — see LICENSES/CERN-OHL-W 2.0 (SPDX-License-Identifier: CERN-OHL-W-2.0)
"""

import argparse
import os
import struct
import sys

import numpy as np

# ---------------------------------------------------------------------------
# Path setup — resolved relative to this script so it works from any CWD.
# ---------------------------------------------------------------------------
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
REPO_ROOT = os.path.abspath(os.path.join(SCRIPT_DIR, ".."))
STL_DIR = os.path.join(REPO_ROOT, "airframe", "stls")
sys.path.insert(0, SCRIPT_DIR)
import hull_datums as hd  # noqa: E402  single-source hull datums (X_CL)

# Marker stamped into the 80-byte binary STL header after baking.
# Its presence means "vertices are already hull-frame" — do not re-bake.
MARKER = b"SerenityUAV AIRCRAFT-FRAME R2"

# 1/sqrt(2), shared by all 90-degree-family quaternions below.
_SQ2 = 0.7071067811865476

# ---------------------------------------------------------------------------
# Validated placement constants — single source of truth.
#
# Extracted from airframe/freecad/assembly/SerenityAssembly.FCStd
# (manually positioned and validated 2026-06-10; previously duplicated
# in serenity_assembly.py as PL_* constants, retired at R1).
#
# Tuple format: (Px, Py, Pz, Qx, Qy, Qz, Qw)
#   Position in mm; rotation as unit quaternion with Qw the scalar.
# ---------------------------------------------------------------------------
# AIRCRAFT DATUM R2 (2026-10-19): every placement below is in the aircraft
# frame -- origin on the centreline, at the nose tip, on the static ground
# plane (tools/hull_datums.py).  P_R2 = P_R1 + hull_datums.R1_TO_R2.  The
# dated notes inside the table quote R1 numbers as they were recorded.
COMPONENTS = {
    # Head: identity rotation — STL axes already matched the hull frame.
    # Paths standardised to the no-"s_"-prefix published basenames (Rev R1,
    # 2026-06-11): the regenerated watertight 2 mm shells from
    # blender_shells_2mm_solidify.py + hollow_manifold.py are published under
    # these names.  The duplicate "Cargo_Shell_Repair2" entry was consolidated
    # into the single Cargo_Shell below (per the TODO.md mesh-repair log).
    "Head_Shell": (
        "fuselage/head_shell24_2mm_repaired.stl",
        # 2026-10-19 RE-CENTRED: Px -331.9993360 -> -333.6383 (-1.639 mm).  The
        # head's own symmetry plane measured X -168.211 (median of 147 section
        # samples, IQR 0.17 mm) -- 1.6 mm port of the hull centreline hd.X_CL.
        # QMx Sheet 5 [REF-CAD-003] shows a symmetric hull; owner direction:
        # correct to symmetric unless canonically justified.
        # R2: R1 (-333.6383360, -17.9999640, 60.9998780) + R1_TO_R2.
        (-163.7883360, 287.7000360, 140.9998780, 0.0, 0.0, 0.0, 1.0),
    ),
    # Cargo: 180 deg about +Z flips the section hull-forward.
    "Cargo_Shell": (
        "fuselage/cargo/cargo_sect_shell24_2mm_repaired.stl",
        (-104.5500100, 22.8999560, 80.0000000, 0.0, 0.0, 1.0, 0.0),  # R2
    ),
    # Middle / Rear: 90 deg about -X brings the SCAD section axis
    # (modelled along local Z) upright into hull +Z (dorsal).
    "Middle_Shell": (
        "fuselage/middle_shell24_2mm_repaired.stl",
        (-181.1492980, 436.1001963, 90.0174324, -_SQ2, 0.0, 0.0, _SQ2),  # R2
    ),
    "Rear_Shell": (
        "fuselage/rear_shell24_2mm_repaired.stl",
        # 2026-10-19 RE-CENTRED: Px 0.0 -> +5.914.  The rear measured symmetric
        # about X -175.764 (194 samples, IQR 0.06 mm) -- 5.9 mm starboard of the
        # centreline, a 5.7 mm lateral step at the middle/rear joint.
        # R2: R1 (5.9140000, 203.1999999, -31.9999360) + R1_TO_R2.
        (175.7640000, 508.8999999, 48.0000640, -_SQ2, 0.0, 0.0, _SQ2),
    ),
    # Wings: identity rotation, translation only.
    # Filenames use the no-"s_"-prefix convention (Rev R1, 2026-06-11).
    # Chord updated to 129/93 mm (root/tip) and LE sweep zeroed in Rev R1
    # 2026-06-14; PORT bake translation unchanged (LE root stays at hull Y=-7).
    #
    # REV S1c (2026-08-18) — Wing_Stbd MIRROR-CORRECTED.  It had been baked
    # 5.00 mm AFT-of-mirror in Y (-12.0 vs the port -7.0) and 4.52 mm outboard
    # in X, so the two wings were not mirror images of each other.  That is not
    # canonical asymmetry -- Serenity is symmetric here -- and it broke the spar
    # interface: airframe/blender-scripts/merge_cargo_interior.py derives ONE
    # WING_SPAR_Y (+38.15) from ONE WING_LE_ROOT_Y (-7.0) and cuts BOTH spar
    # bores, BOTH bearing bosses and BOTH nacelle-servo pads on it, so the
    # starboard spar was 5 mm out of line with its own wing.  Correcting the
    # bake is what lets that single constant stay correct for both sides.
    #
    #   Y: -11.9999760 -> -6.9999860, i.e. identical to port.  Y is the
    #      fore/aft axis and is NOT mirrored; both wings share one station.
    #   X: -261.9994760 -> -257.4822.  Derived, not guessed: mirrored about the
    #      hull's own symmetry plane MEASURED on the baked cargo shell at the
    #      spar station (trimesh Y-sections over hull Y 37..41 at Z 55/58/62.5
    #      give centreline X = -169.241, sd 0.03), as
    #        Px_stbd = 2 * (-169.241) - (-80.9998380).
    #      Check: this puts the starboard root face 2.28 mm outboard of the
    #      starboard skin, against 2.24 mm for port -- symmetric.  The cargo
    #      shell is the right reference because the wing root is a mortise/tenon
    #      plus spar-bore joint into it; the nacelle-pair midpoint (-171.05)
    #      disagrees by 1.8 mm, but that bake is itself known-stale pending the
    #      Rev T CG re-bake (wings-nacelles WBS SS1.1.3), so it is not used here.
    #   Z: unchanged -- both wings already shared 57.9998840.
    # 2026-10-31: Py is the wing-root datum (hull_datums.WING_LE_ROOT_Y,
    # 298.70 -> 311.40, the 0.5 in aft pivot shift, plan 2026-10-31-001 R5);
    # the 0.0000140 is the bake's original sub-micron residual, kept so the
    # re-bake differs from the published mesh by exactly +12.7 mm in Y.
    "Wing_Port": (
        "wings/wing_port_s1223_revo.stl",
        (88.8501620, hd.WING_LE_ROOT_Y + 0.0000140, 137.9998840, 0.0, 0.0, 0.0, 1.0),  # R2
    ),
    "Wing_Stbd": (
        "wings/wing_stbd_s1223_revo.stl",
        # 2026-10-19: DERIVED as the mirror of Wing_Port about hd.X_CL (was
        # -257.4822, mirrored about a measured -169.241 that disagreed with the
        # centreline every other generator used).
        # R2
        (hd.mirror_x(88.8501620), hd.WING_LE_ROOT_Y + 0.0000140, 137.9998840,
         0.0, 0.0, 0.0, 1.0),
    ),
    # Nacelles: 270 deg about +X = cruise / forward-flight attitude.
    # This is the canonical stored attitude; hover tilt is applied
    # about the pivot (Z = PIVOT_Z = 111.5 mm from intake, the full-assembly
    # CG station — see nacelle_pod_50mm_tandem.scad) downstream, not here.
    #
    # nacelle_port_revs.stl — port side (hull +X, Px ≈ +47 mm).
    #   SWIRL_DIR=−1 (CCW from intake); harness exit on −X (inboard) face.
    # nacelle_stbd_revs.stl — starboard side (hull −X, Px ≈ −385 mm).
    #   SWIRL_DIR=+1 (CW from intake); harness exit on +X (inboard) face.
    #
    # NOTE: filenames were corrected 2026-06-11 (Rev R1 nacelle-swap).
    # The original SCAD output used "port" for the NACELLE_SIDE=+1 (right
    # outer shell, harness on +X face) part, which physically fits starboard.
    # Files were renamed so each filename matches its physical mounting side.
    "Nacelle_Port": (
        "nacelles/nacelle_port_revs.stl",
        (216.8499060, 241.7001280, 142.9998740, _SQ2, 0.0, 0.0, -_SQ2),  # R2 (50 mm, legacy)
    ),
    "Nacelle_Stbd": (
        "nacelles/nacelle_stbd_revs.stl",
        (-215.2460040, 235.7001400, 144.9719300, _SQ2, 0.0, 0.0, -_SQ2),  # R2 (50 mm, legacy)
    ),
}

# ---------------------------------------------------------------------------
# 64 mm nacelles (Rev T6, 2026-10-03) — DERIVED FROM SHARED DATUMS, mirrored.
#
# Unlike the 50 mm entries above (hand-extracted from an FCStd, and known to be
# asymmetric: X +47 / -385, Y -64 / -70, Z 63.0 / 65.0), these are computed,
# one rule for both sides, so the pair cannot desync (owner rule 2026-10-03:
# local joint geometry informs, the airframe rules):
#
#   rotation   the same 270 deg about +X as above: hull = (x_l, z_l, -y_l).
#   Y, Z       the tilt axis IS the spar line.  The spar and its fuselage
#              socket are LEVEL at hull Y 21.000, Z 66.851
#              (merge_cargo_interior.py WING_SPAR_Z; wings_s1223_revo.scad
#              Rev T6 dihedral makes the wing bore level on it).  The pod's
#              axis point is local (0, 0, PIVOT_Z = 109.7), so
#              Py = 21.000 - 109.7 = -88.700,  Pz = 66.851.
#   X          each pod's wing-pad seat (local x = +/-53.84 =
#              WING_TIP_FACE_X - TIP_PAD_PROUD) on its own wing's pad face,
#              measured on the baked wings: stbd -345.182, port +6.700, so
#              Px = -399.022 / +60.540.  Midpoint -169.241 = the measured hull
#              centre plane (Wing_Stbd note above): symmetric by construction.
#
# The trunnion and the wing tilt pinion are staged in the SAME nacelle-local
# frame by tools/prep_nacelle_64_bake.py, so they take the same transform.
# The pinion is WING-fixed: serenity_assembly.py does not tilt it.
# ---------------------------------------------------------------------------
# 2026-10-05: pivot and wing-pad seat come from the single sources (the x1.06
# enlargement moves both).  Seat = WING_TIP_FACE_X - TIP_PAD_PROUD
#      = (41.7 + axis shift + 7.0 stub) - 2.0  (53.84 at x1.00 shift 7.14).
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import nacelle_64_scale  # noqa: E402
_N64_SEAT_SCALED = 41.7 + nacelle_64_scale.get("P64_AXIS_SHIFT_S") + 7.0 - 2.0
# 2026-10-19 (drift found by fitting the published pods' duct bore): the pods
# under airframe/stls/nacelles/ were baked at the x1.00 seat, axis X +60.540 /
# -399.022, NOT at the x1.06 seat the scale file now gives (+63.01) -- the
# x1.06 enlargement is in nacelle_64_scale.scad but the pods were never
# re-rendered (owner HOLD until the servo linkage is finished).  This table
# describes the meshes that are actually published; the re-render is WBS
# NAC-64-REBAKE, and tools/check_datum_drift.py compares the two.
_N64_SEAT = 53.84            # as baked (x1.00, axis shift 7.14)
_N64_Y, _N64_Z = hd.SPAR_Y - nacelle_64_scale.pivot_z(), hd.SPAR_Z
# 2026-10-19: starboard DERIVED as the mirror of port about hd.X_CL (was the
# separately measured stbd pad face -345.182, mirrored about -169.241).
# Port wing-pad face: R1 +6.700 -> R2 +176.550.
_N64_X = {"Port": 176.550 + _N64_SEAT, "Stbd": hd.mirror_x(176.550 + _N64_SEAT)}
for _side in ("Port", "Stbd"):
    _pl = (_N64_X[_side], _N64_Y, _N64_Z, _SQ2, 0.0, 0.0, -_SQ2)
    _s = _side.lower()
    COMPONENTS[f"Nacelle64_{_side}"] = (f"nacelles/nacelle_{_s}_64mm.stl", _pl)
    COMPONENTS[f"Trunnion64_{_side}"] = (f"nacelles/nacelle_trunnion_64mm_{_s}.stl", _pl)
    COMPONENTS[f"TiltPinion64_{_side}"] = (f"wings/wing_tilt_pinion_{_s}.stl", _pl)


def quat_to_matrix(qx, qy, qz, qw):
    """
    Return the 3x3 rotation matrix for unit quaternion (qx, qy, qz, qw).

    Standard expansion (Shoemake 1985); matches FreeCAD App.Rotation.
    The quaternion is normalised first to guard against drift in the
    recorded constants.
    """
    norm = np.sqrt(qx * qx + qy * qy + qz * qz + qw * qw)
    qx, qy, qz, qw = qx / norm, qy / norm, qz / norm, qw / norm
    return np.array(
        [
            [
                1.0 - 2.0 * (qy * qy + qz * qz),
                2.0 * (qx * qy - qz * qw),
                2.0 * (qx * qz + qy * qw),
            ],
            [
                2.0 * (qx * qy + qz * qw),
                1.0 - 2.0 * (qx * qx + qz * qz),
                2.0 * (qy * qz - qx * qw),
            ],
            [
                2.0 * (qx * qz - qy * qw),
                2.0 * (qy * qz + qx * qw),
                1.0 - 2.0 * (qx * qx + qy * qy),
            ],
        ],
        dtype=np.float64,
    )


def is_baked(path):
    """Return True if the file's binary header carries the bake marker."""
    with open(path, "rb") as fh:
        header = fh.read(80)
    if b"SerenityUAV HULL-FRAME R1" in header:
        # Baked in the retired R1 frame: never bake again (that would apply the
        # placement twice).  Translate it with tools/migrate_stl_r2.py instead.
        sys.exit(f"[bake] {path}: carries the R1 frame marker -- run "
                 "tools/migrate_stl_r2.py, do not re-bake")
    return MARKER in header


def read_stl(path):
    """
    Read an STL file (binary or ASCII) and return triangle vertices.

    Returns a float64 array of shape (N, 3, 3) — facet normals are
    discarded here and recomputed from vertex winding on write.
    """
    with open(path, "rb") as fh:
        data = fh.read()

    # Binary detection: an ASCII STL starts with "solid", but so can a
    # mis-labelled binary file.  Trust the declared triangle count: the
    # file is binary iff its size matches 84 + 50 * count exactly.
    if len(data) >= 84:
        count = struct.unpack_from("<I", data, 80)[0]
        if len(data) == 84 + 50 * count:
            rec = np.frombuffer(data, dtype=np.uint8, offset=84).reshape(count, 50)
            # First 48 bytes per record: 12 little-endian float32
            # (facet normal + 3 vertices); last 2: attribute count.
            floats = np.ascontiguousarray(rec[:, :48]).view("<f4")
            floats = floats.reshape(count, 4, 3)
            return floats[:, 1:4, :].astype(np.float64)

    # ASCII fallback: collect every "vertex x y z" line in file order.
    verts = []
    for line in data.decode("ascii", errors="replace").splitlines():
        line = line.strip()
        if line.startswith("vertex"):
            parts = line.split()
            verts.append([float(parts[1]), float(parts[2]), float(parts[3])])
    arr = np.asarray(verts, dtype=np.float64)
    if arr.size == 0 or arr.shape[0] % 3 != 0:
        raise ValueError(f"{path}: unable to parse as ASCII STL")
    return arr.reshape(-1, 3, 3)


def write_stl_binary(path, tris, header):
    """
    Write tris (N, 3, 3) as a binary STL with the given header bytes.

    Facet normals are recomputed from the (preserved) counter-clockwise
    vertex winding; degenerate facets get a zero normal, which slicers
    recompute themselves per common STL practice.
    """
    count = tris.shape[0]
    edge1 = tris[:, 1, :] - tris[:, 0, :]
    edge2 = tris[:, 2, :] - tris[:, 0, :]
    normals = np.cross(edge1, edge2)
    lengths = np.linalg.norm(normals, axis=1, keepdims=True)
    # Guard divide-by-zero on degenerate (zero-area) facets.
    safe = np.where(lengths > 0.0, lengths, 1.0)
    normals = np.where(lengths > 0.0, normals / safe, 0.0)

    # Structured dtype packs to exactly 50 bytes per record (numpy does
    # not pad structured dtypes unless align=True is requested).
    rec_dtype = np.dtype([("data", "<f4", (12,)), ("attr", "<u2")])
    assert rec_dtype.itemsize == 50, "unexpected STL record padding"
    rec = np.zeros(count, dtype=rec_dtype)
    rec["data"][:, 0:3] = normals.astype("<f4")
    rec["data"][:, 3:12] = tris.reshape(count, 9).astype("<f4")

    with open(path, "wb") as fh:
        fh.write(header[:80].ljust(80, b"\0"))
        fh.write(struct.pack("<I", count))
        fh.write(rec.tobytes())


def bbox_str(tris):
    """Return a compact 'min .. max' bounding-box string for tris."""
    lo = tris.reshape(-1, 3).min(axis=0)
    hi = tris.reshape(-1, 3).max(axis=0)
    return (
        f"X[{lo[0]:+9.3f} ..{hi[0]:+9.3f}] "
        f"Y[{lo[1]:+9.3f} ..{hi[1]:+9.3f}] "
        f"Z[{lo[2]:+9.3f} ..{hi[2]:+9.3f}]"
    )


def bake_component(name, check_only=False):
    """
    Bake one component's placement into its STL file.

    Returns one of: "baked", "already", "missing", "check".
    Raises on read/write/verify failure.
    """
    rel_path, placement = COMPONENTS[name]
    path = os.path.join(STL_DIR, rel_path)

    if not os.path.exists(path):
        print(f"[MISSING] {name}: {rel_path}")
        return "missing"

    if is_baked(path):
        print(f"[ALREADY] {name}: header carries '{MARKER.decode()}'")
        return "already"

    if check_only:
        print(f"[PENDING] {name}: {rel_path} not yet baked")
        return "check"

    px, py, pz, qx, qy, qz, qw = placement
    rot = quat_to_matrix(qx, qy, qz, qw)
    pos = np.array([px, py, pz], dtype=np.float64)

    tris = read_stl(path)
    print(f"[BAKE   ] {name}: {tris.shape[0]} facets")
    print(f"          before: {bbox_str(tris)}")

    # v' = R @ v + P applied to every vertex; einsum keeps the
    # (N, 3, 3) triangle structure intact.
    tris = np.einsum("ij,nkj->nki", rot, tris) + pos
    print(f"          after : {bbox_str(tris)}")

    header = MARKER + b" " + name.encode("ascii") + b" 2026-06-11"
    write_stl_binary(path, tris, header)

    # Verification: re-read the written file and confirm it matches the
    # in-memory result to float32 precision.
    verify = read_stl(path)
    if verify.shape != tris.shape:
        raise RuntimeError(f"{name}: facet count changed on write")
    err = np.abs(verify - tris).max()
    if err > 1.0e-3:
        raise RuntimeError(f"{name}: verify error {err:.6f} mm")
    print(f"          verify: re-read OK, max error {err:.2e} mm")
    return "baked"


def retranslate_y(name, dy):
    """Move an ALREADY-BAKED rigid part by dy in hull Y (marker required).

    For parts whose bake is a rigid placement and whose SOURCE may not be
    re-rendered right now: the 64 mm nacelle group (pods, trunnions, tilt
    pinions) is on owner HOLD NAC-64-REBAKE -- a re-render would pull in the
    unapplied x1.06 enlargement -- yet its placement follows hd.SPAR_Y, which
    the 2026-10-31 0.5 in wing-root shift moved +12.7 mm.  A pure Y
    translation of a rigidly placed mesh is exact; it is NOT a second bake (the
    placement transform is not re-applied), so the "never re-bake a baked
    mesh" rule is not broken.  Everything that CAN be rebuilt from source
    (wings, hull shells) is.
    """
    rel_path, _ = COMPONENTS[name]
    path = os.path.join(STL_DIR, rel_path)
    if not is_baked(path):
        raise RuntimeError(f"{name}: not baked; bake it instead of translating")
    tris = read_stl(path)
    tris[..., 1] += dy
    with open(path, "rb") as fh:
        header = fh.read(80).rstrip(b"\0")
    write_stl_binary(path, tris, header)
    print(f"[MOVE Y ] {name}: {dy:+.3f} mm -> {bbox_str(tris)}")


def main():
    """CLI entry point — bake all or selected components."""
    parser = argparse.ArgumentParser(
        description="Bake validated hull-frame placements into STLs."
    )
    parser.add_argument(
        "components",
        nargs="*",
        metavar="COMPONENT",
        help="component names to bake (default: all); one of: " + ", ".join(COMPONENTS),
    )
    parser.add_argument(
        "--check",
        action="store_true",
        help="report baked/pending state only; write nothing",
    )
    parser.add_argument(
        "--retranslate-y",
        type=float,
        metavar="DY",
        help="move already-baked rigid parts by DY mm in hull Y (see retranslate_y)",
    )
    args = parser.parse_args()
    if args.retranslate_y is not None:
        for name in args.components:
            retranslate_y(name, args.retranslate_y)
        return

    names = args.components or list(COMPONENTS)
    for name in names:
        if name not in COMPONENTS:
            parser.error(f"unknown component '{name}'")

    results = {}
    for name in names:
        results[name] = bake_component(name, check_only=args.check)

    missing = [n for n, r in results.items() if r == "missing"]
    if missing:
        print(f"\n{len(missing)} component STL(s) missing: " + ", ".join(missing))
        sys.exit(1)
    print("\nAll requested components processed.")


if __name__ == "__main__":
    main()
