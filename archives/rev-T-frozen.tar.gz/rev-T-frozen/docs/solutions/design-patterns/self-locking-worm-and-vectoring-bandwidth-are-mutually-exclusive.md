---
title: "A self-locking worm and a vectoring-class actuator are mutually exclusive — pick the fast worm and add a mechanical brake"
date: 2026-09-15
last_updated: 2026-09-16
category: design-patterns
module: "nacelle tilt drive — tools/tilt_actuator_options.py, airframe/openscad/fuselage/cargo/tilt_actuator_bracket.scad, tilt_brake.scad"
problem_type: design_pattern
component: tooling
severity: high
applies_when:
  - "sizing any actuator whose output is also a flight-control axis (tilt rotors, thrust vectoring, control surfaces)"
  - "a worm or lead-screw stage is proposed because it 'holds by itself'"
  - "a holding provision is about to be closed by an electrical short-brake"
  - "a rate requirement is missing and the sweep time is being sized instead"
related_components:
  - tools/tilt_actuator_options.py
  - airframe/openscad/fuselage/cargo/tilt_actuator_options.scad
  - airframe/openscad/fuselage/cargo/tilt_brake.scad
  - docs/TILT_ACTUATOR_SELECTION.md
  - docs/TILT_DRIVE_CONTROL_SPEC.md
tags: [worm-gear, self-locking, lead-angle, bandwidth, tilt-rotor, brake, holding-provision, actuator-selection, flight-critical]
---

# A self-locking worm and a vectoring-class actuator are mutually exclusive — pick the fast worm and add a mechanical brake

## Context

The Rev T5 nacelle-tilt drive was first cut as a single-start m1 worm (lead 3.2°)
on a Pololu 20D 25:1 gearmotor because it closed WA-R16 — "the train is not
self-locking" — by geometry, and packaged the motor along the sidewall. The
kinematics were sized to a *sweep* (140° in ~6 s). The owner then pointed out
that on a lateral tandem pair the nacelles "sweep back and forth for
manoeuvring": the tilt actuator is the hover pitch actuator and, differentially,
the yaw actuator. At 24 °/s the drive could not do that job at all
(0.8 Hz rate-limit at ±5°, `tools/tilt_actuator_options.py`).

The same session then closed the holding question the "obvious" way — a
shorted-winding motor brake — before checking that a shorted DC motor has
**zero static holding torque** (no speed ⇒ no back-EMF ⇒ no current). It is a
damper, not a hold.

*Update 2026-09-16 (Rev T5e):* the four-start/25D option chosen on 2026-09-15
could not be packaged — a motor coaxial with its worm clears the wheel by
`WORM_PD/2 − MOTOR_D/2 − m` whatever the centre distance, and the cradle caps
the worm at Ø26 (see the coaxial-worm-motor-clearance doc). The built drive is
a **six-start** Ø26 worm (6.67:1, lead 13.0°) on a Pololu 20D 25:1: 144 °/s
no-load, 4.6 Hz at ±5°. The rule below is unchanged — a larger lead angle
costs nothing the brake was not already carrying.

## Guidance

1. **Write the rate/bandwidth requirement before choosing the stage.** For an
   axis that is also a control axis, the requirement is small-signal: "±5° at
   ≥ 4 Hz, ≥ 120 °/s" class, not "full sweep in N seconds". The sweep time is
   a *consequence*, never the sizing case.
2. **A worm cannot be both.** Self-locking needs lead angle λ < friction angle
   φ = atan μ (≈ 3–6° for realistic pairs); at m1 that is a ≥ 30:1 stage, and
   the ratio is exactly what makes it slow. A multi-start worm — 4-start (λ ≈ 9.5°,
   10:1, 168 °/s on a 25D) or the built 6-start (λ ≈ 13.0°, 6.67:1, 144 °/s on a
   20D) — is fast but only *conditionally* self-locking (μ ≥ 0.17 / 0.23 — dry
   printed PETG, not a lubricated or bronze pair, not under vibration). Treat
   conditional self-locking as **zero** in the design basis.
3. **Hold by a positive mechanical brake, spring-applied, released by the
   actuator's own power.** Size it to the train's own torque limit so it is never
   the weakest link; a pin into a castellated collar holds in shear and needs a
   release force of only spring + μ × side-load. Place it where backlash between
   brake and output is smallest that packaging allows, and say plainly what it
   does *not* protect against (a broken worm frees the nacelle regardless).
4. **The brake's power path is the actuator's power path, per path.** If the
   airframe fuses each propulsion path independently so a single failure gives
   a controlled descent, the tilt hold must survive its *own* path failing during
   that descent — which makes the brake flight-critical, not a redundancy item,
   and rules out "just share the ESC rail".
5. **Model the drive's acceleration as motor-limited.** The nacelle's own
   inertia (7.2 × 10⁻⁴ kg·m²) is irrelevant next to the rotor inertia reflected
   through ratio² (≈ 1.4 kg·m² at the nacelle for a 143:1 train); move times are
   rate-limited plus the motor's mechanical time constant. A "torque/inertia"
   acceleration figure (thousands of rad/s²) is a tell that the model is wrong.

## Why This Matters

The first cut passed every geometric gate and would have shipped an aircraft
that could hover only if nothing disturbed it. The physics is unforgiving: the
two properties come from the same number (lead angle), so no amount of
motor selection recovers one without giving up the other. Recognising that early
turns a redesign into a brake part and a change request.

## When to Apply

Any actuator whose output is a flight-control axis; any worm/lead-screw
proposed for its holding property; any holding provision being closed by
"the motor brakes"; any requirement document that has a sweep time but no
rate/bandwidth figure (Serenity: TILT-CTL-05 was exactly that gap).

## Examples

Trade table for the four Serenity options (all from cited inputs; full table in
`docs/TILT_ACTUATOR_OPTIONS.md`, generated by `tools/tilt_actuator_options.py`;
Opt 4 is the built Rev T5e configuration):

| | 1-start worm 40:1 | 4-start worm 10:1 + brake (25D) | spur 1:1 + DS3225 + brake | **6-start worm 6.67:1 + brake (20D, built)** |
|---|---|---|---|---|
| nacelle rate (no-load) | 24 °/s | 168 °/s | 129 °/s | **144 °/s** |
| ±5° / 140° | 0.24 / 5.9 s | 0.06 / 0.86 s | 0.07 / 1.11 s | **0.06 / 1.00 s** |
| ±5° rate-limit bandwidth | 0.8 Hz | 5.3 Hz | 4.1 Hz | **4.6 Hz** |
| unpowered hold | geometry | brake (lock conditional, μ ≥ 0.17) | brake | **brake (lock conditional, μ ≥ 0.23)** |
| packaging | fits | motor 1.5 mm into the wheel (T5d-1) | fouls the battery cradle | **fits, 2.0 mm to the wheel** |

Self-locking test as coded (`worm_eta(lead, drive=False)` returns the back-drive
efficiency; ≤ 0 means locked):

```python
def worm_eta(lead_deg, mu=0.20, drive=True):
    phi = math.degrees(math.atan(mu))
    lam, ph = math.radians(lead_deg), math.radians(phi)
    if drive:
        return math.tan(lam) / math.tan(lam + ph)
    return math.tan(lam - ph) / math.tan(lam)   # < 0  ->  self-locking
```

Brake requirement as written (`docs/TILT_DRIVE_CONTROL_SPEC.md` §5.2):
BRK-1 hold the last commanded angle unpowered for a three-EDF controlled descent;
BRK-2 independent of the actuator's electrical path and of the bus;
BRK-3 automatic engage on power loss, commanded release after the loop unloads the pin.

## See also

* `docs/solutions/design-patterns/coaxial-worm-motor-clearance-is-set-by-worm-diameter-not-placement.md`
  — why the 25D option in the table above could not be built, and the
  packaging algebra that chose the 20D + six-start worm.
