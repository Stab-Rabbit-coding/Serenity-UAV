# ============================================================================
# HULL-FRAME COORDINATE STANDARD - Rev R1 (2026-06-11).  See CLAUDE.md.
#   Hull frame (canonical for ALL design artifacts): X = +port (left),
#   Y = +aft (back), Z = +dorsal (up); origin = SerenityAssembly.FCStd
#   world origin.  Primary-component STLs published to airframe/stls/
#   are stored directly in hull frame, baked by tools/bake_hull_frame.py
#   (marker 'SerenityUAV HULL-FRAME R1' in the binary STL header).
#   NEVER re-bake a mesh derived from an already-baked file.
#   This file:
#     DEPRECATED PROTOTYPE - retained for reference only.  The canonical
#     assembly script is airframe/FreeCAD-scripts/serenity_assembly.py.
#     Placement/transform values in this file predate the R1 bake and MUST
#     NOT be applied to the baked hull-frame STLs (double transform).
# ============================================================================
"""
Serenity-UAV Subsystem Assembly Script
FreeCAD Assembly4 subsystem builder - Rev R (June 2026)
Assembles individual airframe subsystems from OpenSCAD-generated STL/STEP files

Author: Generated for Serenity-UAV project
License: CC BY 4.0
"""

import FreeCAD as App
import FreeCADGui as Gui
from FreeCAD import Vector, Placement, Rotation
import Assembly4Lib
import os
import sys

# Configuration
AIRFRAME_PATH = "./airframe"  # Adjust to your repo path
STLS_SUBPATH = "stls"
SCADS_SUBPATH = "openscad"

class SerenitySubsystemAssembler:
    def __init__(self, airframe_root=AIRFRAME_PATH):
        self.airframe_root = airframe_root
        self.stl_path = os.path.join(airframe_root, STLS_SUBPATH)
        self.scad_path = os.path.join(airframe_root, SCADS_SUBPATH)
        self.assemblies = {}
        
    def import_stl_part(self, doc, filename, part_name):
        """
        Import an STL file and create a Part::FeaturePython object
        """
        filepath = os.path.join(self.stl_path, filename)
        if not os.path.exists(filepath):
            print(f"Warning: STL file not found: {filepath}")
            return None
        
        # Import using FreeCAD's built-in STL import
        imported = App.ActiveDocument.addObject("Mesh::Feature", part_name)
        imported.Mesh = App.Mesh.read(filepath)
        imported.Label = part_name
        return imported
    
    def assemble_fuselage_hull(self):
        """
        Assemble the main fuselage hull subsystem
        
        Components:
        - Hull shell (main_hull.stl, generated from blender_shells_v3.py)
        - Structural braces (port/starboard internal framing)
        - Foam fill boundary definition (2 lb/ft³ closed-cell foam)
        - Landing gear mounts
        
        Dimensions: 24.0" L × 19.1" W × 7.2" H (609 × 486 × 182 mm)
        Material: 2.5 mm PLA shell + foam fill
        """
        doc = App.newDocument("Fuselage_Assembly")
        doc.Label = "Fuselage Hull Assembly"
        
        # Create Assembly4 container
        assy = Assembly4Lib.newAssembly(doc, "FuselageAssembly")
        assy.Type = "Assembly"
        
        # Import main hull (should be a closed mesh from blender_shells_v3.py)
        hull = self.import_stl_part(doc, "hull_shell_main_24in.stl", "MainHull")
        if hull:
            hull.Placement = Placement(Vector(0, 0, 0), Rotation(0, 0, 0))
            hull.Label = "Hull Shell"
        
        # Port structural brace (CF reinforcement)
        brace_port = doc.addObject("Part::FeaturePython", "BracePort")
        brace_port.Label = "Structural Brace - Port"
        brace_port_placement = Placement(
            Vector(-100, 150, 0),  # Offset from centerline
            Rotation(0, 0, 0)
        )
        brace_port.Placement = brace_port_placement
        
        # Starboard structural brace (mirrored)
        brace_starboard = doc.addObject("Part::FeaturePython", "BraceStarboard")
        brace_starboard.Label = "Structural Brace - Starboard"
        brace_starboard_placement = Placement(
            Vector(100, 150, 0),
            Rotation(0, 0, 0)
        )
        brace_starboard.Placement = brace_starboard_placement
        
        # Landing gear mounts (8 mm steel rod passing through fuselage)
        # Two main gear pods + tail skid
        gear_mount_main = self.import_stl_part(
            doc, 
            "landing_gear_mount_main.stl",
            "GearMountMain"
        )
        if gear_mount_main:
            gear_mount_main.Placement = Placement(
                Vector(0, 200, -50),  # Aft position
                Rotation(0, 0, 0)
            )
            gear_mount_main.Label = "Landing Gear Main Mount"
        
        gear_mount_tail = self.import_stl_part(
            doc,
            "landing_gear_mount_tail.stl",
            "GearMountTail"
        )
        if gear_mount_tail:
            gear_mount_tail.Placement = Placement(
                Vector(0, -150, -50),  # Forward position
                Rotation(0, 0, 0)
            )
            gear_mount_tail.Label = "Landing Gear Tail Skid Mount"
        
        doc.recompute()
        self.assemblies["Fuselage"] = doc
        return doc
    
    def assemble_nacelle_pod(self, side="port"):
        """
        Assemble a single nacelle subsystem (port or starboard)
        
        Per-nacelle thrust: 1240 g × 2 EDFs × 0.90 efficiency = 2232 g
        Critical pivot point: Z = 83 mm (at nacelle CG for zero gravity torque)
        
        Components:
        - Nacelle pod structure (CF-PETG, generated by nacelle_pod_50mm_tandem.scad)
        - EDF 1 intake shroud (forward 50mm XFly Galaxy X5)
        - EDF 2 intake shroud (aft 50mm, tandem)
        - Inter-stage stator (11-fin twisted, 33° vane angle)
        - Variable-area iris nozzle (8-petal, M=1.0)
        - Tilt pivot bearing assembly (Z=83mm datum)
        - Nozzle linkage to tilt pivot (gear M=1.0)
        - LED ring (WS2812B, translucent-blue PETG backlit petals)
        
        Args:
            side: "port" or "starboard"
        """
        doc_name = f"Nacelle_{side.capitalize()}_Assembly"
        doc = App.newDocument(doc_name)
        doc.Label = f"Nacelle {side.upper()} Subsystem"
        
        assy = Assembly4Lib.newAssembly(doc, f"Nacelle_{side}")
        assy.Type = "Assembly"
        
        # Main nacelle pod (CF-PETG, from nacelle_pod_50mm_tandem.scad)
        nacelle_pod = self.import_stl_part(
            doc,
            f"nacelle_pod_50mm_tandem_{side}.stl",
            f"NacelleBody_{side}"
        )
        if nacelle_pod:
            nacelle_pod.Placement = Placement(Vector(0, 0, 0), Rotation(0, 0, 0))
            nacelle_pod.Label = f"Nacelle Pod {side.upper()}"
        
        # EDF 1 (forward 50mm EDF, XFly Galaxy X5 12-blade 6S 3200KV)
        # Placement: 0,0,0 relative to nacelle pod origin
        edf_1 = self.import_stl_part(
            doc,
            f"edf_50mm_intake_shroud_1_{side}.stl",
            f"EDF_1_{side}"
        )
        if edf_1:
            edf_1.Placement = Placement(
                Vector(0, 0, 0),
                Rotation(0, 0, 0)
            )
            edf_1.Label = f"EDF 1 (Forward) - {side.upper()}"
        
        # EDF 2 (aft 50mm, tandem offset)
        # Placement: -50 mm aft in Z (tandem series along exhaust axis)
        edf_2 = self.import_stl_part(
            doc,
            f"edf_50mm_intake_shroud_2_{side}.stl",
            f"EDF_2_{side}"
        )
        if edf_2:
            edf_2.Placement = Placement(
                Vector(0, 0, -50),  # Tandem offset
                Rotation(0, 0, 0)
            )
            edf_2.Label = f"EDF 2 (Aft/Tandem) - {side.upper()}"
        
        # Inter-stage stator (11-fin twisted, 33° vane angle, CF-PETG)
        # Critical for thrust efficiency in tandem EDF pair (90% additive vs 100%)
        stator = self.import_stl_part(
            doc,
            f"nacelle_inter_stage_stator_11fin_33deg_{side}.stl",
            f"InterStageStator_{side}"
        )
        if stator:
            stator.Placement = Placement(
                Vector(0, 0, -25),  # Centered between EDF 1 and 2
                Rotation(0, 0, 0)
            )
            stator.Label = f"Inter-stage Stator (11-fin) - {side.upper()}"
        
        # Variable-area iris nozzle (8-petal, M=1.0 design)
        # Nozzle gear-linked to tilt pivot passively
        # 0° tilt = fully closed, 90° tilt = fully open
        nozzle = self.import_stl_part(
            doc,
            f"nacelle_iris_nozzle_8petal_linkage_{side}.stl",
            f"IrisNozzle_{side}"
        )
        if nozzle:
            nozzle.Placement = Placement(
                Vector(0, 0, -60),  # Aft of both EDFs
                Rotation(0, 0, 0)
            )
            nozzle.Label = f"Iris Nozzle (8-petal, M=1.0) - {side.upper()}"
        
        # Tilt pivot bearing assembly
        # CRITICAL: Placement at Z = 83 mm (CG pivot for zero gravity torque)
        # This is where the nacelle rotates for tilt (0° hover, 90° cruise, 120° backing)
        pivot = self.import_stl_part(
            doc,
            f"nacelle_pivot_bearing_assembly_{side}.stl",
            f"TiltPivot_{side}"
        )
        if pivot:
            pivot.Placement = Placement(
                Vector(0, 0, 83),  # CG pivot datum - CRITICAL
                Rotation(0, 0, 0)
            )
            pivot.Label = f"Tilt Pivot Bearing (CG @ Z=83mm) - {side.upper()}"
        
        # LED ring (WS2812B addressable, translucent-blue PETG backlit)
        # 16-pixel ring for petal backlighting + status indication
        led_ring = self.import_stl_part(
            doc,
            f"ws2812b_led_ring_16pixel_{side}.stl",
            f"LEDRing_{side}"
        )
        if led_ring:
            led_ring.Placement = Placement(
                Vector(0, 0, -55),  # Inside nozzle, at exit plane
                Rotation(0, 0, 0)
            )
            led_ring.Label = f"LED Ring (WS2812B 16px) - {side.upper()}"
        
        # Nozzle linkage mechanism (8-petal iris gear train)
        # M=1.0 ratio: Sector R=22mm → Pinion 12T → Bevel 14T 45° → Crown 12T → Ring 28mm
        # ~70.7° ring travel for 90° nacelle tilt sweep
        linkage = self.import_stl_part(
            doc,
            f"nacelle_nozzle_linkage_gears_{side}.stl",
            f"NozzleLinkageGears_{side}"
        )
        if linkage:
            linkage.Placement = Placement(
                Vector(0, 0, -25),  # Co-located with stator
                Rotation(0, 0, 0)
            )
            linkage.Label = f"Nozzle Linkage Gears (M=1.0) - {side.upper()}"
        
        doc.recompute()
        self.assemblies[f"Nacelle_{side}"] = doc
        return doc
    
    def assemble_cargo_bay(self):
        """
        Assemble cargo bay subsystem (Rev P complete)
        
        Components:
        - Clamshell port door (CF-PETG)
        - Clamshell starboard door (CF-PETG)
        - 8-barrel piano hinge on 3 mm CF rod (hinged on aft edge)
        - SG90 servo for door actuation
        - SG90 servo for payload release
        - DRV8833 H-bridge motor controller PCB
        - N20 winch motor + 50:1 gearbox
        - Dyneema SK75 0.5 mm line (tether for winch)
        - Auto-latch payload cradle
        - HX711 24-bit load cell (payload mass sensing)
        - FPV camera bezel (forward viewing window)
        - GPS retention ring (GNSS antenna mount)
        - 3M foam gasket door seal (5mm perimeter gasket)
        
        Payload capacity: 400 g
        Door servo travel: 0-90° (full open/close)
        Winch pull: N20 @ 50:1 ≈ 5 kg force (payload release)
        """
        doc = App.newDocument("CargoBay_Assembly")
        doc.Label = "Cargo Bay Subsystem"
        
        assy = Assembly4Lib.newAssembly(doc, "CargoBay")
        assy.Type = "Assembly"
        
        # Port cargo door (CF-PETG clamshell)
        door_port = self.import_stl_part(
            doc,
            "cargo_door_cfpetg_port.stl",
            "DoorPort"
        )
        if door_port:
            door_port.Placement = Placement(
                Vector(-100, 0, 0),  # Port side offset
                Rotation(0, 0, 90)  # Hinge along Y-axis
            )
            door_port.Label = "Cargo Door - Port"
        
        # Starboard cargo door (mirrored CF-PETG)
        door_starboard = self.import_stl_part(
            doc,
            "cargo_door_cfpetg_starboard.stl",
            "DoorStarboard"
        )
        if door_starboard:
            door_starboard.Placement = Placement(
                Vector(100, 0, 0),  # Starboard side offset
                Rotation(0, 0, 90)
            )
            door_starboard.Label = "Cargo Door - Starboard"
        
        # Piano hinge assembly (8-barrel hinge on 3 mm CF rod)
        hinge = self.import_stl_part(
            doc,
            "piano_hinge_8barrel_3mm_CF.stl",
            "CargoDoorHinge"
        )
        if hinge:
            hinge.Placement = Placement(
                Vector(0, -50, 0),  # Along aft edge
                Rotation(0, 90, 0)  # Axis of rotation
            )
            hinge.Label = "Piano Hinge (8-barrel, 3mm CF rod)"
        
        # Door servo (SG90, opens/closes doors)
        door_servo = self.import_stl_part(
            doc,
            "servo_sg90_door.stl",
            "DoorServo"
        )
        if door_servo:
            door_servo.Placement = Placement(
                Vector(0, 20, 50),  # Internal mounting
                Rotation(0, 0, 0)
            )
            door_servo.Label = "Door Servo (SG90)"
