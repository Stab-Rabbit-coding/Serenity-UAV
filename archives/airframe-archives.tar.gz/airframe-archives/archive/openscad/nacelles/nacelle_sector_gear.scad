// ===========================================================================
// HULL-FRAME COORDINATE STANDARD - Rev R1 (2026-06-11).  See CLAUDE.md.
//   Hull frame (canonical for ALL design artifacts): X = +port (left),
//   Y = +aft (back), Z = +dorsal (up); origin = SerenityAssembly.FCStd
//   world origin.  Primary-component STLs published to airframe/stls/
//   are stored directly in hull frame, baked by tools/bake_hull_frame.py
//   (marker 'SerenityUAV HULL-FRAME R1' in the binary STL header).
//   NEVER re-bake a mesh derived from an already-baked file.
//   This file:
//     Part-local print frame, coaxial with the nacelle duct (duct axis =
//     local +Z, intake at Z = 0).  Hull placement derives from the nacelle
//     pose (cruise = 270 deg about +X + translation; hover rotates about the
//     tilt pivot at duct Z = 83 mm).  Assembly placement VERIFY pending
//     (serenity_assembly.py).
// ===========================================================================
// nacelle_sector_gear.scad
// Serenity UAV Rev R — Nacelle Tilt Linkage, Fixed Sector Gear
//
// Purpose:
//   Sector gear fixed to the fuselage-side tilt bracket.  The sector does NOT
//   rotate with the nacelle.  As the nacelle tilts, Drive Pinion A rolls along
//   this fixed sector, translating nacelle rotation angle into pinion shaft
//   rotation that ultimately drives the iris nozzle open/closed.
//
//   Gear ratio contribution (sector side):
//     This mesh is EPICYCLIC (sun-fixed/planet-on-carrier), not a simple
//     two-gear mesh: the sector (sun) is fixed and centred on the tilt
//     pivot axis, while Pinion A (planet) is carried by the nacelle and
//     orbits the pivot axis as the nacelle tilts.  Contact-point velocity
//     matching gives omega_pinionA = omega_nacelle × (1 + R_sector/R_pinionA):
//       Nacelle tilt 0–90° → Pinion A rotates 90° × (1 + 22/8.5) = 322.94°
//     (Pinion A is 17T M1 R=8.5 as of Rev S1; the orbital "+1" term is
//     required for this sun-fixed epicyclic topology — see
//     nacelle_pinion.scad for the full derivation.)
//   Mechanical range (Rev R1): -5° to 140° hard stops (145° span), widened
//     from the original 0-90° operating range — see SECTOR_TEETH below.
//   Full system ratio (Rev S1 internal-ring nozzle drive, 2026-07-07):
//     tilt 90° → Pinion A 322.94° (this mesh) → bevel pair ×10/14
//     (nacelle_bevel_pair.scad) → drive pinion 14T M0.5 meshing the
//     INTERNAL nozzle ring gear 136T M0.5 ×14/136 → ring 23.74°.
//     The Rev R1 compound idler stage (nacelle_nozzle_idler.scad) is
//     DELETED — its teeth protruded ~10 mm past the nacelle OD; see
//     docs/NOZZLE_DRIVE_TRADE.md for the trade study and decision.
//
// Mating interfaces:
//   • Drive Pinion A (nacelle_pinion.scad):
//       Pitch circles tangent at mesh point; 0.1 mm backlash on centre distance.
//   • Tilt bracket pivot bolt: M4, MOUNT_BORE_D = 4.2 mm clearance.
//   • Nacelle boss posts (×4 M2.5 adjustment slots): SLOT_BC_R = 18 mm,
//       SLOT_D = 2.7 mm clearance, SLOT_ARC_DEG = 10° per slot.
//
// Gear standard: AGMA/ISO involute, Module M = 1.0 mm, Pressure angle 20°.
// Tooth profile method: tooth-space subtraction — angular pitch wedges removed
//   from a solid sector annulus, leaving a functional trapezoidal approximation
//   of the involute tooth form.  Adequate for M = 1.0 in PETG or resin.
//
// Print specification:
//   Preferred:  SLA resin, ≤ 0.05 mm layer height (captures M=1 tooth detail).
//   Backup:     CF-PETG FDM, 0.10 mm layers, 4 perimeters, 40 % gyroid infill.
//   Nozzle:     Hardened steel (CF-PETG is abrasive).
//   Orientation: Print flat (teeth facing up) to maximise tooth-face quality.
//   Note:       M = 1.0 mm is printable in FDM at 0.10 mm layer height with a
//               0.25 mm nozzle; a 0.40 mm nozzle will round tooth crests —
//               acceptable for prototype but use resin for final flight article.
//
// Author:  Steve Griffing, PE(CSE), CISSP-ISSEP, CPP
// License: CC BY 4.0  <https://creativecommons.org/licenses/by/4.0/>
// Date:    2026-05-24
// Rev:     R (2026-06-11): Rev R baseline — no geometry changes (carried forward from Rev O initial release).
// Rev:     R1 (2026-06-22): Corrected epicyclic ratio comment (330° -> 420°,
//          omitted orbital "+1" term) and stale sector-arc figure (155° ->
//          99.1°, matching SECTOR_ARC_DEG).  Comment-only.
// Rev:     R1.1 (2026-06-22): Geometry change — grew SECTOR_TEETH 38 -> 58
//          (SECTOR_ARC_DEG 99.1° -> 151.3°) to cover the widened -5°/140°
//          mechanical tilt range (was 0-90°+/-5° overtravel).  Companion
//          change to the crown-pinion/nozzle-ring mismatch (TODO.md
//          §1.1.3) added a new idler gear stage — see
//          nacelle_nozzle_idler.scad.
// Rev:     S1 (2026-07-07): TOOTH-MATH BUG FIX + internal-ring drive rebuild.
//          (a) N_FULL was computed as round(2*PI*R/M) = 138 — that formula
//          yields circumference/module, NOT teeth.  Correct involute count
//          is N = 2R/M = 44 for R=22 M=1.  As published, the sector's teeth
//          were cut at 2.61°/tooth (1.0 mm circular pitch ≈ M0.32 spacing)
//          while Drive Pinion A (nacelle_pinion.scad) is a true M1 gear at
//          30°/tooth — THE TWO GEARS COULD NOT MESH.  Fixed: N_FULL = 44,
//          angular pitch 8.18°, circular pitch π mm.  (b) SECTOR_TEETH
//          58 -> 19 (19 × 8.18° = 155.5° arc — same physical coverage of
//          the -5°/140° tilt range + margin as the old 151.3° figure).
//          (c) Header ratios updated for the Rev S1 internal-ring nozzle
//          drive (Pinion A now 17T R8.5; idler stage deleted) — see
//          docs/NOZZLE_DRIVE_TRADE.md.

// ── Resolution ────────────────────────────────────────────────────────────────

$fn = 72;   // standard circle resolution for all rotational solids

// ── Gear Parameters ───────────────────────────────────────────────────────────

MODULE          =  1.0;   // [mm] AGMA Module — tooth size standard
PRESSURE_ANGLE  = 20.0;   // [deg] standard involute pressure angle
PITCH_R         = 22.0;   // [mm] pitch circle radius of sector gear
SECTOR_TEETH    = 19;     // [count] number of teeth spanning the active arc
                        //   19 T covers ≈155.5° (see SECTOR_ARC_DEG below) —
                        //   encompasses the nacelle's Rev R1 operating range
                        //   of -5° to 140° mechanical hard stops (145° span)
                        //   plus ≈5° entry/exit mesh margin each end.
                        //   Rev S1: recount 58 -> 19 as part of the N_FULL
                        //   tooth-math bug fix (see Rev S1 header note) —
                        //   the ARC covered is unchanged; only the number of
                        //   correctly-pitched M1 teeth filling it changed.
BODY_H          =  3.0;   // [mm] plate (web) thickness behind teeth
MOUNT_BORE_D    =  4.2;   // [mm] M4 clearance bore at pivot axis
SLOT_BC_R       = 18.0;   // [mm] bolt-circle radius for M2.5 adjustment slots
SLOT_D          =  2.7;   // [mm] M2.5 clearance slot width
SLOT_ARC_DEG    = 10.0;   // [deg] arc length of each slot (mesh preload range)
N_SLOTS         =  4;     // [count] number of adjustment slots (evenly spaced)

// ── Derived Gear Geometry ─────────────────────────────────────────────────────

// Full-circle equivalent tooth count for M = 1.0 at PITCH_R = 22 mm.
//   Correct involute relation: pitch diameter D = N × M  =>  N = 2R/M = 44.
//   (Rev S1 BUG FIX: this was round(2π×R/M) = 138 — that expression is
//   circumference/module, not a tooth count; it cut 2.61°/tooth "teeth"
//   with 1.0 mm circular pitch (≈M0.32 spacing) that could never mesh the
//   true-M1 Drive Pinion A.  Standard M1 circular pitch is π ≈ 3.14 mm.)
N_FULL = round(2 * PITCH_R / MODULE);   // = 44 teeth (full circle, M=1, R=22)

// Standard tooth proportions per AGMA 201:
ADDENDUM   = MODULE;              // [mm] tooth height above pitch circle = 1.0
DEDENDUM   = 1.25 * MODULE;      // [mm] tooth depth below pitch circle = 1.25
TIP_R      = PITCH_R + ADDENDUM; // [mm] addendum (tip) circle radius  = 23.0
ROOT_R     = PITCH_R - DEDENDUM; // [mm] dedendum (root) circle radius = 20.75
BASE_R     = PITCH_R * cos(PRESSURE_ANGLE); // [mm] base circle radius ≈ 20.67

// Angular pitch — angle subtended by one tooth + one space at pitch circle:
ANGULAR_PITCH = 360.0 / N_FULL;  // [deg] = 2.609° per tooth

// Tooth space width at pitch circle = π × MODULE / 2 = 1.5708 mm.
// In angular terms at pitch circle circumference:
//   tooth_space_angle = (PI * MODULE / 2) / (2 * PI * PITCH_R / 360) = 4.09°
//   (half angular pitch, because equal space and tooth width at pitch circle)
SPACE_HALF_ANG = ANGULAR_PITCH / 2;  // [deg] half-width of tooth space

// Sector arc angle based on actual tooth count:
SECTOR_ARC_DEG = SECTOR_TEETH * ANGULAR_PITCH;  // [deg] ≈ 151.3° for 58 T

// Starting angle of sector arc.  Zero the midpoint of the sector at 0° so the
// sector spans symmetrically about the tilt-bracket centreline.
SECTOR_START_DEG = -SECTOR_ARC_DEG / 2;  // [deg] first tooth left edge

// Backing plate inner radius — small ledge behind root circle for rigidity:
BACK_INNER_R = ROOT_R - 3.0;   // [mm] = 17.75 mm
// Backing plate outer radius matches addendum circle:
BACK_OUTER_R = TIP_R;          // [mm] = 23.0 mm

// ── Polygon Helpers ───────────────────────────────────────────────────────────
//
// arc_pts(r, a1, a2, n) — n+1 points along an arc at radius r from a1 to a2.
//   Returns a list of [x, y] vectors usable in polygon().
//   Using polygon() for tooth spaces avoids nested 2D CSG (circle−circle−square²)
//   which forces CGAL into exponential work for each of the 38+ tooth subtractions.
//
function arc_pts(r, a1, a2, n) =
    [for (i = [0 : n]) let(a = a1 + i * (a2 - a1) / n) [r * cos(a), r * sin(a)]];

// annular_wedge(r_in, r_out, a1, a2, n) — closed annular-sector polygon.
//   Inner arc runs a1→a2; outer arc runs a2→a1 (reversed for winding order).
//   n = arc-segment count per edge; total vertices = 2*(n+1).
//
function annular_wedge(r_in, r_out, a1, a2, n) =
    concat(arc_pts(r_in,  a1, a2, n),
            arc_pts(r_out, a2, a1, n));

// ── Module Definitions ────────────────────────────────────────────────────────

// sector_plate() — solid pie-wedge annulus covering the full sector arc.
//   The teeth will be formed by subtracting tooth-space wedges from this solid.
//   Built as a single polygon (annular_wedge) — no nested 2D boolean operations.
//   Arc resolution matches $fn=72 over the sector span: 72*(SECTOR_ARC_DEG/360)≈20;
//   using 24 segments for the outer/inner arcs gives smooth edges at this scale.
module sector_plate() {
    linear_extrude(height = BODY_H) {
        polygon(annular_wedge(
            BACK_INNER_R, BACK_OUTER_R,
            SECTOR_START_DEG, SECTOR_START_DEG + SECTOR_ARC_DEG,
            24   // arc segments per edge (≈ $fn=72 proportional to 99° span)
        ));
    }
}

// tooth_space(i) — subtract one tooth-space gap between teeth i and i+1.
//   The gap is a thin angular wedge at the root-to-tip radial band, centred
//   midway between adjacent tooth centrelines.
//   Built as a polygon — avoids the 4-level CSG (circle−circle−square−square)
//   that caused CGAL to time out with 38+ iterations.
//
//   Arguments:
//     i  — tooth index (0-based); space is placed between tooth i and tooth i+1
module tooth_space(i) {
    // Angular centre of this tooth space:
    //   teeth are at i × ANGULAR_PITCH; spaces fall between teeth.
    //   Space centre = SECTOR_START_DEG + (i + 0.5) × ANGULAR_PITCH
    space_centre_deg = SECTOR_START_DEG + (i + 0.5) * ANGULAR_PITCH;

    // Half-angle of the trapezoidal tooth-space wedge.
    // AGMA circular tooth thickness at pitch circle = π × MODULE / 2.
    // As an angle: (π × MODULE / 2) / PITCH_R × (180/π)
    //            = (1.5708 / 22) × 57.296 = 4.09°
    // Tooth space width = same (equal division), so half-angle ≈ 2.045°
    half_ang = SPACE_HALF_ANG / 2;   // [deg]

    // Each tooth space spans only ~4° — 2 arc segments per edge is sufficient;
    // the arc deviates < 0.001 mm from a straight line over this narrow angle.
    linear_extrude(height = BODY_H + 0.1) {
        polygon(annular_wedge(
            ROOT_R - 0.1, TIP_R + 0.2,
            space_centre_deg - half_ang, space_centre_deg + half_ang,
            2   // 2 segments per arc edge (tooth space is only ~4° wide)
        ));
    }
}

// adjustment_slot(i) — one M2.5 adjustment slot at SLOT_BC_R.
//   The slot is an arc of SLOT_ARC_DEG length and SLOT_D width, allowing
//   radial adjustment of the sector for mesh preload setting.
module adjustment_slot(i) {
    slot_centre_deg = i * (360.0 / N_SLOTS);   // evenly spaced around bolt circle

    // Render arc slot as hull of two small circles at slot endpoints
    hull() {
        rotate([0, 0, slot_centre_deg - SLOT_ARC_DEG / 2])
            translate([SLOT_BC_R, 0, -0.1])
                cylinder(h = BODY_H + 0.2, d = SLOT_D);
        rotate([0, 0, slot_centre_deg + SLOT_ARC_DEG / 2])
            translate([SLOT_BC_R, 0, -0.1])
                cylinder(h = BODY_H + 0.2, d = SLOT_D);
    }
}

// sector_gear() — top-level module: assembles the complete sector gear.
//
//   Geometry sequence:
//     1. Start with solid sector annulus plate.
//     2. Subtract SECTOR_TEETH + 1 tooth-space wedges (N spaces for N teeth).
//     3. Subtract pivot bore (M4 clearance).
//     4. Subtract N_SLOTS adjustment slots.
//
//   Coordinate origin: centre of pivot (tilt axis) bore.
//   +Z = forward face (Pinion A meshes from this side).
//   Sector arc centred at 0° in X-Y plane.
module sector_gear() {
    difference() {
        // ── Base solid ──────────────────────────────────────────────────────
        sector_plate();

        // ── Tooth-space subtractions ────────────────────────────────────────
        // Subtract SECTOR_TEETH + 1 spaces (one space on each outer flank):
        for (i = [0 : SECTOR_TEETH]) {
            tooth_space(i);
        }

        // ── Pivot bore ──────────────────────────────────────────────────────
        // M4 clearance through-hole at tilt-axis pivot.  Centre at origin.
        translate([0, 0, -0.1])
            cylinder(h = BODY_H + 0.2, d = MOUNT_BORE_D);

        // ── Adjustment slots ────────────────────────────────────────────────
        // Four M2.5 arc slots at SLOT_BC_R = 18 mm bolt circle.
        for (i = [0 : N_SLOTS - 1]) {
            adjustment_slot(i);
        }
    }
}

// ── Fit Confirmation ──────────────────────────────────────────────────────────
//
//   Interface          Mating part               Clearance / fit
//   ─────────────────  ────────────────────────  ─────────────────────────────
//   Tooth pitch circle Drive Pinion A            0.10 mm radial backlash
//                      (nacelle_pinion.scad)     (centre distance = 22+6+0.1)
//   MOUNT_BORE_D 4.2   M4 tilt-bracket pivot     0.2 mm diametral clearance
//   SLOT_D 2.7         M2.5 boss posts            0.2 mm diametral clearance
//   Plate face (Z=0)   Tilt bracket pocket        bonded / face contact

// ── Render ────────────────────────────────────────────────────────────────────

// Uncomment to render:
sector_gear();
