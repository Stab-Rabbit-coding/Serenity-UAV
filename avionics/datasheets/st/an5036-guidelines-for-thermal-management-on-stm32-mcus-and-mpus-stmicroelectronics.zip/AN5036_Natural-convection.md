# Natural convection {#AN5036_topic_9}

The term ‘natural convection’ is used when no fan is used in the casing. This cooling method is a combination of natural convection and radiation that always work in parallel.

**Parent topic:**[Main cooling methods](AN5036_Main-cooling-methods.md)

