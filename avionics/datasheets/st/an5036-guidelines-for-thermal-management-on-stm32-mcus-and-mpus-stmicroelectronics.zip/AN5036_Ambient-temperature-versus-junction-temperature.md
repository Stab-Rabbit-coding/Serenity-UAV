# Ambient temperature versus junction temperature {#topic_xmq_kqx_fcb}

Both the ambient and the junction temperatures specify the thermal performance of STM32 devices.

For many STM32 devices, only the maximum ambient temperature is specified as their thermal performance limit. The junction temperature is also sometimes added.

The use of the ambient temperature for thermal performance assessment is much easier than using the junction temperature, as the die of a packaged device is not accessible. This makes the conventional temperature measurement methods unusable for measuring the die temperature.

Measuring the junction temperature requires more advanced measurement techniques. Most STM32 devices embed a junction temperature sensor, which serves as a primitive building block for thermal watchdog implementations. But at the design stage, this embedded temperature sensor cannot help in determining the thermal performance of the whole application. Instead, the junction temperature is estimated at the design stage. It is based on many parameters including the application power profile, the device thermal resistances, the surrounding temperature \(board temperature and device case temperature\). For accurate estimation of the junction temperature, modeling software tools are used when the final application has a complex thermal model and a complex power profile.

**Parent topic:**[STM32 thermal parameters](AN5036_STM32-thermal-parameters.md)

