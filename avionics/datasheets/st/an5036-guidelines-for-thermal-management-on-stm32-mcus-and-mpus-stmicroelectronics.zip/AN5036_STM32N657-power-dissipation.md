# STM32N657 power dissipation {#id_69333}

As stated in [STM32 thermal parameters](AN5036_STM32-thermal-parameters.md), the dissipated power varies with TJ. The power consumption in this example is measured for different TJ values \(as [Figure 1](#fig_nmr_t2f_ldc) below demonstrates\).

![](DT75954.svg "Junction-temperature-dependent dissipated power for STM32N657")

**Parent topic:**[Discovery kit with STM32N657XOH3 MCU](AN5036_Discovery-board-with-STM32N657XOH3-MCU.md)

