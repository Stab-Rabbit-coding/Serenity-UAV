# Thermal systems definitions and basic concepts {#topic_xmq_kqx_fcb}

This section details basic definitions and concepts related to thermal systems, as applied to silicon-based integrated circuits \(ICs\).

-   **[Thermal systems definitions](AN5036_Thermal-systems-definitions.md)**  

-   **[Thermal system study](AN5036_Thermal-systems-study.md)**  

-   **[Thermal model of a chip carrier](AN5036_Thermal-model-chip-carrier.md)**  


