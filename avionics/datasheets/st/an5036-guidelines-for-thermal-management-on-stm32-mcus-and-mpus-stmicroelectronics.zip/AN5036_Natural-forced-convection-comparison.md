# Natural and forced convection comparison {#AN5036_topic_11}

The table below details the main comparison factors between the natural and forced convection.

**Table 1. Natural and forced convection comparison**

<table>
<thead>
<tr>
<th>Comparison factors</th>
<th>Natural convection</th>
<th>Forced convection</th>
</tr>
</thead>
<tbody>
<tr>
<td>Cooling efficiency</td>
<td>Low</td>
<td><p>Medium to high</p>
 <p>(depending on air speed)</p></td>
</tr>
<tr>
<td>Cost</td>
<td>Low (no fan)</td>
<td>Higher (cost of the fan)</td>
</tr>
<tr>
<td>Reliability</td>
<td><p>Higher</p>
 <p>(no moving parts)</p></td>
<td><p>Lower</p>
 <p>(mechanical part moving)</p></td>
</tr>
<tr>
<td>Acoustic noise</td>
<td>None</td>
<td><p>Small to medium</p>
 <p>(depending on air speed)</p></td>
</tr>
<tr>
<td>Possibility to control cooling efficiency based on needs</td>
<td>None</td>
<td>Yes, by varying fan voltage</td>
</tr>
</tbody>
</table>

**Parent topic:**[Main cooling methods](AN5036_Main-cooling-methods.md)

