# STM32MP135 power dissipation {#id_50173 .concept}

-   **[Use case about cpuburn](AN5036_cpuburn-use-case-STM32MP135.md)**  

-   **[Use case about dd](AN5036_dd-use-case-STM32MP135.md)**  


**Parent topic:**[Internal validation board with STM32MP135 MPU](AN5036_Internal-Validation-board-with-STM32MP135-MPU.md)

