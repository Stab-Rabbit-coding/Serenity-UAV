# Internal validation board with STM32MP215F MPU {#id_77576}

This thermal analysis was done on an internal validation board with an STM32MP215F device without casing.

The test case is the following:

-   Tests on hwrng
-   Tests on DDR \(memtester\)
-   Tests on DMA

-   **[STM32MP215F power dissipation](AN5036_STM32MP215F-power-dissipation.md)**  

-   **[STM32MP215F thermal measurements at TA = 25 °C](AN5036_STM32MP215F-thermal-measurements.md)**  


**Parent topic:**[Thermal analysis examples](AN5036_Thermal-analysis-example.md)

