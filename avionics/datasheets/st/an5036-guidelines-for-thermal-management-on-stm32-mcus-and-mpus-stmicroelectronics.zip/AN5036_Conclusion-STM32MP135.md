# Conclusion {#id_50224 .concept}

The measurement details given in the previous sections give:

-   An 11% and 13% increase of the power consumption between 900 MHz and 1 GHz. These are respectively for the cpuburn and dd use cases.
-   A 2 and 3 °C increase of TJ between 900 MHz and 1 GHz \(for cpuburn and dd use case respectively\)
-   No risk of thermal runaway

[Table 1](#table_qjj_w5w_n5b) summarizes the maximum ambient temperature for various configurations.

**Table 1. Maximum ambient temperature (STM32MP135 MPU)**

<table>
<thead>
<tr>
<th rowspan="3">Frequency</th>
<th colspan="4">Maximum ambient temperature (°C)</th>
</tr>
<tr>
<th colspan="2">TJ = 105 °C</th>
<th colspan="2">TJ = 125 °C</th>
</tr>
<tr>
<th>cpuburn</th>
<th>dd</th>
<th>cpuburn</th>
<th>dd</th>
</tr>
</thead>
<tbody>
<tr>
<td>900 MHz</td>
<td>77.5</td>
<td>81</td>
<td>93.5</td>
<td>97.5</td>
</tr>
<tr>
<td>1 GHz</td>
<td>74</td>
<td>78</td>
<td>91</td>
<td>94</td>
</tr>
</tbody>
</table>

**Parent topic:**[Internal validation board with STM32MP135 MPU](AN5036_Internal-Validation-board-with-STM32MP135-MPU.md)

