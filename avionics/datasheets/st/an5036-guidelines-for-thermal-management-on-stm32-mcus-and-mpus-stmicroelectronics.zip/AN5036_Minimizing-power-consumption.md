# Minimizing power consumption \(Pdiss\) {#AN5036_topic_3}

To reduce the power consumption, the first action is to reduce the supply voltage. Some STM32 devices offer a multipower domain architecture that allows the different power domains to be set in low-power mode. The goal is to optimize the power efficiency \(see the corresponding datasheets for more details\).

The power consumption profile also varies with the application. Some applications are most of the time in idle mode, working on full or limited capacity only when an event occurs. Some others demand a regular workload.

For these various power profiles, the user programmer enables the low-power modes by software.

The most common available modes are listed below:

-   Power gating: reduces power consumption by shutting off the current to a part of the circuit that is not in use.
-   Clock gatings: reduces dynamic power dissipation by shutting down clocks to a circuit or portion of the clock tree.
-   Dynamic voltage scaling: power management technique where the voltage is increased or decreased, depending upon circumstances.
-   Dynamic frequency scaling \(also known as throttling when applied to a CPU\): frequency automatically adjusted on-the-fly depending on the actual needs, to conserve power and reduce the amount of heat generated.

All these modes are available, for example, on STM32H7 and STM32MP1 series devices \(see the reference manuals for more details\).

**Parent topic:**[Power dissipation and cooling methods](AN5036_Power-dissipation-cooling.md)

