# STM32MP257 power dissipation {#id_65649}

As stated in [STM32 thermal parameters](AN5036_STM32-thermal-parameters.md), the dissipated power varies with TJ. In [Figure 1](#fig_hrt_jyj_5bc), the power consumption is measured for different TJ values.

![](DT75049.png "Junction temperature-dependent dissipated power for STM32MP257")

**Parent topic:**[Internal validation board with STM32MP257 MPU](AN5036_Internal-Validation-board-with-STM32MP257-MPU.md)

