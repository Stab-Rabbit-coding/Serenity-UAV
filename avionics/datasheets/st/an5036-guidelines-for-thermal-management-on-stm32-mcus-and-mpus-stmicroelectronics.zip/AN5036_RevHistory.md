# Revision history {#reference_mcz_lqx_fcb .reference}

**Table 1. Document revision history**

<table>
<thead>
<tr>
<th>Date</th>
<th>Version</th>
<th>Changes</th>
</tr>
</thead>
<tbody>
<tr>
<td>24-May-2018</td>
<td>1</td>
<td>Initial release.</td>
</tr>
<tr>
<td>4-Mar-2019</td>
<td>2</td>
<td>Updated: <ul>
<li>Title of the document</li>
<li>Section 2.3 Thermal model of a chip carrier</li>
<li>Section 3.3 Ambient temperature versus junction temperature</li>
<li>Section 3.5 Board temperature</li>
<li>Section 4 Power dissipation and cooling methods</li>
</ul>
 <p>Added:</p>
 <ul>
<li>Section 3.6 STM32 thermal parameters</li>
<li>Section 6 Thermal analysis example</li>
</ul></td>
</tr>
<tr>
<td>19-Apr-2019</td>
<td>3</td>
<td>Updated Section 3.6 STM32 thermal parameters. <p>Added Section 6.2 Discovery kit with STM32H747XI MCU.</p></td>
</tr>
<tr>
<td>28-Feb-2023</td>
<td>4</td>
<td>Updated:<ul>
<li>Section orders between Section 6.1 and Section 6.2</li>
<li>Section 6.2 Evaluation board with STM32MP157 MPU</li>
<li>Figure 3. HDC (heat dissipation capability)</li>
</ul>
<p>Added Section 6.3 Internal validation board with STM32MP135 MPU</p></td>
</tr>
<tr>
<td>11-Oct-2023</td>
<td>5</td>
<td>Updated:<ul>
<li>Document title</li>
<li><a href="AN5036_cpuburn-use-case-STM32MP135.md#fig_xnb_dnq_bzb">Figure 1</a></li>
</ul></td>
</tr>
<tr>
<td>28-Jun-2024</td>
<td>6</td>
<td>Added <a href="AN5036_Internal-Validation-board-with-STM32MP257-MPU.md">Internal validation board with STM32MP257 MPU</a></td>
</tr>
<tr>
<td>21-Nov-2024</td>
<td>7</td>
<td>Added <a href="AN5036_Discovery-board-with-STM32N657XOH3-MCU.md">Discovery kit with STM32N657XOH3 MCU</a></td>
</tr>
<tr>
<td>19-Jan-2026</td>
<td>8</td>
<td><p>Updated document title</p>
 <p>Added <a href="AN5036_Internal-Validation-Board-with-STM32P215FMPU.md">Internal validation board with STM32MP215F MPU</a></p></td>
</tr>
</tbody>
</table>

