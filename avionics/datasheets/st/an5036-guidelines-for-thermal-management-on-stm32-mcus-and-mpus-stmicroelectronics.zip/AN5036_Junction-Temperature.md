# Junction temperature {#topic_xmq_kqx_fcb}

The junction temperature is the widely used term to refer to the temperature of a die. Obviously, the die temperature is the most important temperature to consider for a device, as all its electrical parameters depend on this junction temperature. Indeed, the junction temperature is the one considered when qualifying the reliability of a device.

In theory, the die temperature is not uniformly distributed across the die. There is a temperature gradient across the die. In practice, the die temperature is generally considered to be uniformly distributed, and only a single temperature measurement is provided. This reduction of a temperature gradient into one temperature reading introduces a small uncertainty into subsequent assumptions and computations when the die dimensions are relatively small. This is the case for most STM32 devices.

**Parent topic:**[STM32 thermal parameters](AN5036_STM32-thermal-parameters.md)

