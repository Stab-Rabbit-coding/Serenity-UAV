# Main cooling methods {#AN5036_topic_8}

The heat sink and the PCB dissipate the power to the surrounding environment by the convection and radiation methods.

-   **[Natural convection](AN5036_Natural-convection.md)**  

-   **[Forced convection](AN5036_Forced-convection.md)**  

-   **[Natural and forced convection comparison](AN5036_Natural-forced-convection-comparison.md)**  


**Parent topic:**[Cooling](AN5036_Cooling.md)

