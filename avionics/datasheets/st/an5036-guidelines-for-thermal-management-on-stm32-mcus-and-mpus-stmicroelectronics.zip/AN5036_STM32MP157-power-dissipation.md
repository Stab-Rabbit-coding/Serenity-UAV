# STM32MP157 power dissipation {#id_7173}

As stated in [STM32 thermal parameters](AN5036_STM32-thermal-parameters.md#), the dissipated power varies with TJ. The power consumption in this example is measured for different TJ values \(see the table and the figure below\).

**Table 1. STM32MP157 power dissipation versus T J**

<table>
<thead>
<tr>
<th rowspan="2">TJ (°C)</th>
<th colspan="2">STM32MP157x-EV1 board (supplied with 5 V)</th>
<th rowspan="2">STM32MP157 power dissipation (mW)</th>
</tr>
<tr>
<th>Current consumption (A)</th>
<th>Power consumption (mW)</th>
</tr>
</thead>
<tbody>
<tr>
<td>39</td>
<td>0.4</td>
<td>2000</td>
<td>970.2</td>
</tr>
<tr>
<td>46</td>
<td>0.4</td>
<td>2000</td>
<td>973.8</td>
</tr>
<tr>
<td>65</td>
<td>0.405</td>
<td>2025</td>
<td>1006.4</td>
</tr>
<tr>
<td>81</td>
<td>0.41</td>
<td>2050</td>
<td>1053.1</td>
</tr>
<tr>
<td>95</td>
<td>0.42</td>
<td>2100</td>
<td>1104.7</td>
</tr>
<tr>
<td>106</td>
<td>0.432</td>
<td>2160</td>
<td>1195.5</td>
</tr>
<tr>
<td>116</td>
<td>0.445</td>
<td>2225</td>
<td>1280.6</td>
</tr>
<tr>
<td>125</td>
<td>0.456</td>
<td>2280</td>
<td>1366.6</td>
</tr>
</tbody>
</table>

![](DT61722.svg "Junction-temperature-dependent dissipated power for STM32MP157")

**Parent topic:**[Evaluation board with STM32MP157 MPU](AN5036_evaluation-board-STM32MP157-MPU.md)

