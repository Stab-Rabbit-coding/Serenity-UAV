# STM32H7 thermal measurements at TA = 25 °C {#id_7171}

The figures and table below detail the thermal measurements performed at TA = 25 °C.

![](DT61718.png "STM32H747XI thermal measurements at TA = 25 °C")

**Table 1. STM32H7 thermal measurements at T A = 25°C**

<table>
<thead>
<tr>
<th rowspan="2">TJ (°C)</th>
<th colspan="3">Thermal camera module measurement (°C)</th>
<th rowspan="2">STM32H7 power consumption (mW)</th>
<th rowspan="2">Total power consumption (mW)</th>
</tr>
<tr>
<th>Avg</th>
<th>Min</th>
<th>Max</th>
</tr>
</thead>
<tbody>
<tr>
<td>46.9</td>
<td>45.5</td>
<td>39.7</td>
<td>50.6</td>
<td>737</td>
<td>1975</td>
</tr>
</tbody>
</table>

![](DT62099.svg "HDC at 25 °C and junction-temperature-dependent dissipated power for STM32H7 ")

Once the design HDC is defined \(by measurement at 25 °C\), and assuming that this HDC is constant at 25 °C and 85 °C, the operating point of the design at 85 °C is given by translating the HDC at 85 °C. See the figure and table below.

![](DT62600.svg "HDC at 85 °C and junction-temperature-dependent dissipated power for STM32H7 ")

**Table 2. Measurement interpolation at T A = 85 °C for STM32H7**

|Parameter|Value|
|:-------:|:---:|
|TJ|119 °C|
|PTOT|3050 mW|

In conclusion, the STM32H7 device is safe, with no thermal runaway, and TJ remaining < 125 °C.

**Parent topic:**[Discovery kit with STM32H747XI MCU](AN5036_Discovery-board-with-STM32H7-MCU.md)

