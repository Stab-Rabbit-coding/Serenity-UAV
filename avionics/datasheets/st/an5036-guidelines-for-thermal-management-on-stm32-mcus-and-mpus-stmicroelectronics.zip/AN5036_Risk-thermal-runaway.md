# Risk of thermal runaway {#AN5036_topic_5}

The junction-to-room temperature thermal resistance, Theta\_j\_room, characterizes the cooling system of a design.

This thermal resistance gives the capability to dissipate power in the design while limiting the junction temperature.

The following equation gives the heat dissipation capability \(HDC\):

<math display="inline"><mrow><mi>H</mi><mi>D</mi><mi>C</mi><mo>=</mo><mtext> </mtext><mrow><mo>(</mo><msub><mrow><mi>T</mi></mrow><mrow><mi>j</mi></mrow></msub><mo>−</mo><msub><mrow><mi>T</mi></mrow><mrow><mi>r</mi><mi>o</mi><mi>o</mi><mi>m</mi></mrow></msub><mo>)</mo><mo>/</mo><mo>(</mo><mi>T</mi><mi>h</mi><mi>e</mi><mi>t</mi><mi>a</mi><mi>_</mi><mi>j</mi><mi>_</mi><mi>r</mi><mi>o</mi><mi>o</mi><mi>m</mi><mo>)</mo></mrow></mrow></math>

![](DT62062V1.svg "HDC (heat dissipation capability)")

**Note:**

-   Better: design has more ability to dissipate heat
-   Worse: design has less ability to dissipate heat

## Case 1 { .section}

The figure below shows the operating point at the intersection of the curve of the power that can be dissipated inside the design at a given TJ \(HDC\) and the curve of the power effectively dissipated inside the design \(Pdiss\).

![](DT62063V1.svg "HDC and junction-temperature-dependent dissipated power (case 1)")

The cooling design is safe \(no thermal runaway\) if an intersection point exists for Troom = Troom\_max, with a junction temperature < 125 °C.

## Case 2 { .section}

The figure below shows the effect of an increased room temperature \(without changing any other factors\).

![](DT62064V1.svg "HDC and junction-temperature-dependent dissipated power (case 2)")

## Case 3 { .section}

The figure below shows the effect of an increased junction-to-room thermal resistance \(without changing any other factors\).

![](DT62065V1.svg "HDC and junction-temperature-dependent dissipated power (case 3)")

The two curves in case 2 and case 3 do not intersect. For this reason, no stable operating point is defined. This is a condition of thermal runaway.

## Case 4 { .section}

The figure below shows the effect of a decrease in power dissipation \(without changing any other factors\).

![](DT62066V1.svg "HDC and junction-temperature-dependent dissipated power (case 4)")

**Parent topic:**[Power dissipation and cooling methods](AN5036_Power-dissipation-cooling.md)

