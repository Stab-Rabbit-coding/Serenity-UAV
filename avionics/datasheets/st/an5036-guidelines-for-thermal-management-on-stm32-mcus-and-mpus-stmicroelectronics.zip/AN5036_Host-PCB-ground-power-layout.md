# Host PCB ground and power layout {#AN5036_topic_13}

The ground \(GND\) plane must have a low resistance \(thermal and electrical\) for all PCB areas. This improves signal quality and power dissipation. It also reduces EMI. The use of a ground layer and flooding of other layers with multiple vias maintain the resistance at a low level.

Placing as many thermal vias as possible on the ground and power planes just below the package, ensures that there is enough continuous copper between the adjacent vias for power distribution and thermal dissipation. A compromise must be found.

The possible thermal vias are listed below:

-   ground vias: connecting GND to the unified GND plane \(these are the most efficient thermal vias\)
-   power vias: connecting power to the power plane

The thermal vias conduct heat from the device to the internal GND and power planes. These planes spread the heat inside the PCB that acts as a planar heat sink.

**Parent topic:**[Bottom cooling - host PCB design](AN5036_Bottom-cooling-host-PCB-design.md)

