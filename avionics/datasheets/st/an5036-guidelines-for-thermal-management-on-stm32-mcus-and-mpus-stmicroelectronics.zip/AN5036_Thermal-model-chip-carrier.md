# Thermal model of a chip carrier {#topic_xmq_kqx_fcb}

A simplified thermal model for an LQFP-packaged STM32 product is provided in the figure below. All surface temperatures and thermal resistance \(as defined by the JEDEC EIA/JESD 51-X standards\) are depicted.

![](DT50493.svg "Thermal model of a chip carrier")

The definitions of thermal parameters mentioned in this figure are listed in the table below.

**Table 1. Thermal parameters**

<table>
<thead>
<tr>
<th>Symbol</th>
<th>Description</th>
<th>Unit</th>
</tr>
</thead>
<tbody>
<tr>
<td>TJ</td>
<td>Temperature of the die</td>
<td rowspan="4">°C</td>
</tr>
<tr>
<td>TA</td>
<td>Temperature of surrounding air</td>
</tr>
<tr>
<td>TC</td>
<td>Temperature of the package top</td>
</tr>
<tr>
<td>TB</td>
<td>Temperature of the board near the device</td>
</tr>
<tr>
<td>θJC</td>
<td>Thermal resistance between the die and the package</td>
<td rowspan="3">°C/W</td>
</tr>
<tr>
<td>θJB</td>
<td>Thermal resistance between the die and the PCB on which the IC is mounted</td>
</tr>
<tr>
<td>θJA</td>
<td>Thermal resistance between the die and the air surrounding the die package</td>
</tr>
<tr>
<td>PB</td>
<td>Amount of power dissipated by the device through the board</td>
<td rowspan="3">W</td>
</tr>
<tr>
<td>PC</td>
<td>Amount of power dissipated by the device through the package top</td>
</tr>
<tr>
<td>PTOT</td>
<td>The total power dissipated by the device (PTOT = PB + PC)</td>
</tr>
</tbody>
</table>

**Parent topic:**[Thermal systems definitions and basic concepts](AN5036_Thermal-systems-definitions-basic-concepts.md)

