# STM32MP215F thermal measurements at TA = 25 °C {#id_77578}

This section explains the STM32 thermal parameters as specified by their respective datasheets.

Figure and table below detail the thermal measurements performed at TA = 25 °C.

![](DT80405.svg "STM32MP215F thermal measurements at TA = 25 °C")

**Table 1. STM32MP215F thermal measurements at T A  = 25°C.**

<table>
<thead>
<tr>
<th>TJ (°C)</th>
<th colspan="2">IO</th>
<th colspan="2">CPU</th>
<th colspan="2">CORE</th>
<th colspan="2">DDR</th>
<th colspan="2">1V8</th>
<th>Power (mV)</th>
</tr>
</thead>
<tbody>
<tr>
<td rowspan="2">43<sup><a href="#fn1">1</a></sup></td>
<td>V (V)</td>
<td>3.319</td>
<td>V (V)</td>
<td>0.935</td>
<td>V (V)</td>
<td>0.893</td>
<td>V (V)</td>
<td>1.239</td>
<td>V (V)</td>
<td>1.814</td>
<td rowspan="2">934.37</td>
</tr>
<tr>
<td>I (mA)</td>
<td>40</td>
<td>I (mA)</td>
<td>160</td>
<td>I (mA)</td>
<td>315</td>
<td>I (mA)</td>
<td>226</td>
<td>I (mA)</td>
<td>50</td>
</tr>
</tbody>
</table>

Figure and table hereafter detail the thermal measurements performed at maximum ambiant temperature TA = 100 °C.

![](DT80406.svg "HDC at 100 °C and junction temperature-dependent dissipated power for STM32MP215F")

**Table 2. Measurement interpolation at maximum ambient temperature for STM32MP215F**

|Parameter|Value|
|---------|-----|
|TJ|125 °C|
|PTOT|1327 mW|
|Maximum ambient temperature|100 °C|

In conclusion, the STM32MP215F device is safe, with no thermal runaway, and for TJ = 125 °C, the maximum ambient temperature TA = 100 °C.

**Parent topic:**[Internal validation board with STM32MP215F MPU](AN5036_Internal-Validation-Board-with-STM32P215FMPU.md)

<a id="fn1"></a>

[^1]: Thermocouple measurement

