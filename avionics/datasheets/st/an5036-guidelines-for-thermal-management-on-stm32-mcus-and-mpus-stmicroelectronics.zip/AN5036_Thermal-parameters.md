# STM32 thermal parameters {#id_7154}

Most of the STM32 datasheets give only Theta‑JA thermal resistance, but some specify also Theta‑JC and Theta‑JB, defined in the table below.

**Table 1. STM32 thermal resistances**

<table>
<thead>
<tr>
<th>Thermal metric</th>
<th>Symbol</th>
<th>Value</th>
<th>Main purpose</th>
</tr>
</thead>
<tbody>
<tr>
<td><strong>Theta‑JA</strong></td>
<td>θJA</td>
<td><p><math display="inline"><mfrac><mrow><msub><mi>T</mi><mi>J</mi></msub><mo>−</mo><msub><mi>T</mi><mi>A</mi></msub></mrow><msub><mi>P</mi><mrow><mi>T</mi><mi>O</mi><mi>T</mi></mrow></msub></mfrac></math></p></td>
<td>Used to rank package performance in the JEDEC environment</td>
</tr>
<tr>
<td><strong>Theta‑JC</strong></td>
<td>θJC</td>
<td><p><math display="inline"><mfrac><mrow><msub><mi>T</mi><mi>J</mi></msub><mo>−</mo><msub><mi>T</mi><mi>C</mi></msub></mrow><msub><mi>P</mi><mi>C</mi></msub></mfrac></math></p></td>
<td><p>Used to rank package performance</p>
<strong>Used in simulations with a 2R model</strong> (2R = two resistances)</td>
</tr>
<tr>
<td><strong>Theta‑JB</strong></td>
<td>θJB</td>
<td><p><math display="inline"><mfrac><mrow><msub><mi>T</mi><mi>J</mi></msub><mo>−</mo><msub><mi>T</mi><mi>B</mi></msub></mrow><msub><mi>P</mi><mi>B</mi></msub></mfrac></math></p></td>
<td><p>Used to rank package performance</p>
<strong>Used in simulations with 2R model</strong></td>
</tr>
</tbody>
</table>

These parameters are determined under the following specific conditions that differ from the final application conditions:

-   Theta‑JA: The JEDEC51-2 document *Integrated circuits thermal test method environmental conditions - natural convection \(still air\)* describes the thermal test method to define Theta‑JA.
-   Theta‑JB: The JEDEC51 document *Integrated circuit thermal test method environmental conditions – junction-to-board* describes the thermal test method to define Theta‑JB.
-   Theta‑JC: The MIL‑STD-883E document *Test method standard microcircuits* describes the thermal test method to define Theta‑JC.

These thermal resistances must be carefully defined in semiconductor packages and devices context.

The most important point about these values is that the total power dissipated by the device flows between the two following “points”:

-   The junction
-   Ambient or board temperature

There are no extraneous parallel thermal paths in the system allowing some of the heat to “leak” away. All the heat leaving the junction eventually arrives at or passes through the other point.

It is usually possible to know the total power dissipation of a device but it is far more difficult to know which fraction of the heat flows out through the case top, versus the part that flows through the leads, and versus the part that flows through the air gap under the package.

Theta‑JC and Theta‑JB are generally used as inputs for thermal simulation tools, which calculate which fraction of the heat flows out through the top and the bottom of the device.

**Parent topic:**[STM32 thermal parameters](AN5036_STM32-thermal-parameters.md)

