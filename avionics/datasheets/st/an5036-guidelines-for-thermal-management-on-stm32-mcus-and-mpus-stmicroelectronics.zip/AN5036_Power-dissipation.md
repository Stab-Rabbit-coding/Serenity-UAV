# Power dissipation {#id_7159}

There are two types of current consumed by the device:

-   The static current: also called leakage current, depends on the process, voltage, and junction temperature but does not depend on the activity
-   The dynamic current: depends on the process, voltage, and activity but does not depend on the junction temperature \(at least in first approximation\).

The static/leakage current grows exponentially with the junction temperature \(while the dynamic current does not significantly change\).

Therefore, the total current can be written as follows:

<math display="inline"><mrow><msub><mrow><mi>I</mi></mrow><mrow><mi>T</mi><mi>o</mi><mi>t</mi><mi>a</mi><mi>l</mi><mtext> </mtext></mrow></msub><mrow><mo>(</mo><mi>P</mi><mo>,</mo><mtext> </mtext><mi>V</mi><mo>,</mo><mtext> </mtext><msub><mrow><mi>T</mi></mrow><mrow><mi>j</mi><mtext> </mtext></mrow></msub><mo>,</mo><mtext> </mtext><mi>a</mi><mi>c</mi><mi>t</mi><mi>i</mi><mi>v</mi><mi>i</mi><mi>t</mi><mi>y</mi><mo>)</mo><mo>=</mo></mrow><msub><mrow><mi>I</mi></mrow><mrow><mi>s</mi><mi>t</mi><mi>a</mi><mi>t</mi><mi>i</mi><mi>c</mi><mtext> </mtext></mrow></msub><mo>(</mo><mi>P</mi><mo>,</mo><mtext> </mtext><mi>V</mi><mo>,</mo><mtext> </mtext><msub><mrow><mi>T</mi></mrow><mrow><mi>j</mi><mtext> </mtext></mrow></msub><mo>)</mo><mo>+</mo><msub><mrow><mi>I</mi></mrow><mrow><mi>D</mi><mi>y</mi><mi>n</mi><mi>a</mi><mi>m</mi><mi>i</mi><mi>c</mi></mrow></msub><mo>(</mo><mi>P</mi><mo>,</mo><mtext> </mtext><mi>V</mi><mo>,</mo><mi>a</mi><mi>c</mi><mi>t</mi><mi>i</mi><mi>v</mi><mi>i</mi><mi>t</mi><mi>y</mi><mo>)</mo></mrow></math>

The dissipated power varies with PVTA conditions. It is calculated as the product of the voltage generated across the device and the \(average\) current consumed.

The junction temperature increase above the ambient temperature is calculated as a product of the dissipated power and the junction-to-room thermal resistance.

The junction temperature must be kept lower than the maximum target given by the following equation:

<math display="inline"><mrow><msub><mrow><mi>T</mi></mrow><mrow><mi>j</mi></mrow></msub><mi></mi><mo>=</mo><mi></mi><msub><mrow><mi>T</mi></mrow><mrow><mi>r</mi><mi>o</mi><mi>o</mi><mi>m</mi></mrow></msub><mi></mi><mo>+</mo><mi></mi><msub><mrow><mi>P</mi></mrow><mrow><mi>d</mi><mi>i</mi><mi>s</mi><mi>s</mi></mrow></msub><mi></mi><mo>×</mo><mi></mi><mi>T</mi><mi>h</mi><mi>e</mi><mi>t</mi><mi>a</mi><mo>_</mo><mi>j</mi><mo>_</mo><mi>r</mi><mi>o</mi><mi>o</mi><mi>m</mi><mi></mi><mo>&lt;</mo><mi></mi><msub><mrow><mi>T</mi></mrow><mrow><mi>j</mi><mi>_</mi><mo>⁢</mo><mi>max</mi><mo>⁡</mo></mrow></msub></mrow></math>



**Important:** In this simplified formula used only for didactic purpose, Theta\_j\_room is a complex coefficient that is not a device characteristic but a system one \(device + other components + boards + casing\).

The following methods to keep the junction temperature below the ambient temperature are detailed in the next sections:

-   Limiting Pdiss
-   Limiting Theta\_j\_room \(cooling system, host board and casing design\)

**Parent topic:**[Power dissipation and cooling methods](AN5036_Power-dissipation-cooling.md)

