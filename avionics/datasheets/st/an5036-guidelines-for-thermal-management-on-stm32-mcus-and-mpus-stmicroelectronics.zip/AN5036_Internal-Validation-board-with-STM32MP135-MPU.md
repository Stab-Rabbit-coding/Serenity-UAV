# Internal validation board with STM32MP135 MPU {#id_50163 .concept}

This thermal analysis has been done on an internal validation board with an STM32MP135 device without casing.

This analysis is based on the use cases detailed in the table below. They correspond to CPU frequencies of 900 MHz and 1 GHz:

**Table 1. Use cases for STM32MP135 MPU**

<table>
<thead>
<tr>
<th>Name</th>
<th>Description</th>
<th>CPU load</th>
<th>DDR load</th>
</tr>
</thead>
<tbody>
<tr>
<td>cpuburn</td>
<td>-</td>
<td rowspan="2">100%</td>
<td>R = 3 Mbyte/s, W = 0 Mbyte/s, R&amp;W = 4 Mbyte/s</td>
</tr>
<tr>
<td>dd</td>
<td>Idle (weston launcher, netdata) + dual eth + USB hard drive + dd on hard drive (ETH cables unplugged)</td>
<td>R = 129 Mbyte/s, W = 40 Mbyte/s, R&amp;W = 169 Mbyte/s</td>
</tr>
</tbody>
</table>

-   **[STM32MP135 power dissipation](AN5036_STM32MP135-power-dissipation.md)**  

-   **[HDC at 25 °C and junction temperature](AN5036_HDC-at-25C-and-junction-temperature.md)**  

-   **[Maximum ambient temperature \(STM32MP135 MPU\)](AN5036_Max-ambient-temperature-STM32135.md)**  

-   **[Conclusion](AN5036_Conclusion-STM32MP135.md)**  


**Parent topic:**[Thermal analysis examples](AN5036_Thermal-analysis-example.md)

