# Use case about cpuburn {#id_50174 .concept}

As stated in [STM32 thermal parameters](AN5036_STM32-thermal-parameters.md), the dissipated power varies with TJ. The power consumption in this example is measured for different TJ values \(see the following tables and figure\).

**Table 1. STM32MP135 power dissipation versus T J at 900 MHz (cpuburn)**

|TJ \(°C\)|STM32MP135 power dissipation \(mW\) at 900 MHz|
|---------|----------------------------------------------|
|20.00|711.44|
|31.00|721.04|
|43.00|740.00|
|47.00|748.83|
|52.00|757.93|
|56.00|763.62|
|66.00|791.42|
|71.00|804.79|
|78.00|823.36|
|86.00|857.92|
|91.00|881.62|
|96.00|903.01|
|98.00|914.23|
|101.00|926.44|
|106.00|951.83|
|111.00|973.00|
|116.00|994.98|
|119.00|1014.19|
|129.00|1110.12|
|139.00|1238.89|

**Table 2. STM32MP135 power dissipation versus T J at 1 GHz (cpuburn)**

|TJ \(°C\)|STM32MP135 power dissipation \(mW\) at 1 GHz|
|:-------:|:------------------------------------------:|
|21.60|795.45|
|32.00|800.12|
|37.00|806.26|
|44.00|825.79|
|49.00|833.00|
|56.00|841.39|
|61.00|861.53|
|68.00|890.82|
|76.00|912.60|
|83.00|936.60|
|89.00|967.97|
|100.00|1014.80|
|110.00|1061.20|

**Table 3. STM32MP135 thermal measurements at T A = 25 °C (cpuburn)**

<table>
<thead>
<tr>
<th>Parameter</th>
<th>900 MHz</th>
<th>1 GHz</th>
<th>Unit</th>
</tr>
</thead>
<tbody>
<tr>
<td>TJ</td>
<td>47</td>
<td>49</td>
<td>[°C]</td>
</tr>
<tr>
<td>VCORE</td>
<td>1.32</td>
<td>1.332</td>
<td>[V]</td>
</tr>
<tr>
<td>ICORE</td>
<td>180</td>
<td>195</td>
<td>[mA]</td>
</tr>
<tr>
<td>PCORE</td>
<td>237</td>
<td>260</td>
<td>[mW]</td>
</tr>
<tr>
<td>VDD</td>
<td>3.33</td>
<td>3.321</td>
<td>[V]</td>
</tr>
<tr>
<td>IDD</td>
<td>13</td>
<td>19</td>
<td>[mA]</td>
</tr>
<tr>
<td>PDD</td>
<td>43</td>
<td>63</td>
<td>[mW]</td>
</tr>
<tr>
<td>VCPU</td>
<td>1.415</td>
<td>1.414</td>
<td>[V]</td>
</tr>
<tr>
<td>ICPU</td>
<td>306</td>
<td>331</td>
<td>[mA]</td>
</tr>
<tr>
<td>PCPU</td>
<td>432</td>
<td>468</td>
<td>[mW]</td>
</tr>
<tr>
<td>VDDR2</td>
<td>1.2</td>
<td>1.206</td>
<td>[V]</td>
</tr>
<tr>
<td>IDDR2</td>
<td>30</td>
<td>35.5</td>
<td>[mA]</td>
</tr>
<tr>
<td>PDDR2</td>
<td>36</td>
<td>43</td>
<td>[mW]</td>
</tr>
<tr>
<td rowspan="2">STM32MP135 power dissipation</td>
<td>748</td>
<td>834</td>
<td rowspan="2">[mW]</td>
</tr>
<tr>
<td colspan="2">+11%</td>
</tr>
</tbody>
</table>

![](DT71603.svg "Junction temperature-dependent dissipated power for STM32MP135 (cpuburn)")

**Parent topic:**[STM32MP135 power dissipation](AN5036_STM32MP135-power-dissipation.md)

