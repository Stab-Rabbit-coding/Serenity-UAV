# Forced convection {#AN5036_topic_10}

The term ‘forced convection’ is used when a fan is used in the casing.

**Parent topic:**[Main cooling methods](AN5036_Main-cooling-methods.md)

