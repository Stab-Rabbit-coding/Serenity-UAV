# Additional GND areas on outer layers {#AN5036_topic_14}

On the outer layers, some GND areas can be added wherever functional tracks are absent. Connect these areas to GND by a network of vias wherever possible.

These GND areas help in heat spreading and dissipation along the board. The figure below shows the principle of additional GND areas and vias to the GND plane.

![](DT60892.png "Principle of additional GND areas and vias to the GND plane")

**Parent topic:**[Bottom cooling - host PCB design](AN5036_Bottom-cooling-host-PCB-design.md)

