# HDC at 25 °C and junction temperature {#id_50213 .concept}

Once the design HDC is defined \(by measurement at 25 °C\), and assuming that this HDC is constant at 25 °C and 85 °C, the operating point of the design at 85 °C is given by translating the HDC at 85 °C as shown in the figure below.

![](DT71605.svg "MPU power dissipation")

**Parent topic:**[Internal validation board with STM32MP135 MPU](AN5036_Internal-Validation-board-with-STM32MP135-MPU.md)

