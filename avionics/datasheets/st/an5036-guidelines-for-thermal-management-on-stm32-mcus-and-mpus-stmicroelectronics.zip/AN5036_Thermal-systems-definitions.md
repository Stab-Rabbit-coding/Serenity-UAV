# Thermal systems definitions {#topic_xmq_kqx_fcb}

**Heat:**

The amount of energy exchanged between two different bodies spontaneously under the effect of their different temperatures.

**Temperature:**

A comparative measurement of how hot or cold a body is. The temperature of a given body increases as it absorbs heat and decreases as it releases heat.

**Temperature gradient:**

Refer to the uneven temperature distribution over one body. The temperature gradient magnitude reflects the difference in temperature from one location to another inside a body.

**Thermal resistance:**

The property of a material to conduct a certain amount of heat under a certain temperature gradient.

**Parent topic:**[Thermal systems definitions and basic concepts](AN5036_Thermal-systems-definitions-basic-concepts.md)

