# Power dissipation paths {#AN5036_topic_7}

The power dissipated by the die is extracted along the two following main paths:

-   top side: power dissipated from the top side, \(by a heat sink through an optional TIM, thermal interface material\)
-   bottom side: power dissipated from the bottom side by the PCB, \(by bottom metal plate through an optional TIM\)

![](DT60891.png "Power dissipation paths")

**Parent topic:**[Cooling](AN5036_Cooling.md)

