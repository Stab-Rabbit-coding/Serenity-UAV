# STM32 thermal parameters {#topic_xmq_kqx_fcb}

This section explains the STM32 thermal parameters as specified by their respective datasheets.

-   **[Ambient temperature](AN5036_Ambient-Temperature.md)**  

-   **[Junction temperature](AN5036_Junction-Temperature.md)**  

-   **[Ambient temperature versus junction temperature](AN5036_Ambient-temperature-versus-junction-temperature.md)**  

-   **[Case temperature](AN5036_Case-temperature.md)**  

-   **[Board temperature](AN5036_Board-temperature.md)**  

-   **[STM32 thermal parameters](AN5036_Thermal-parameters.md)**  


