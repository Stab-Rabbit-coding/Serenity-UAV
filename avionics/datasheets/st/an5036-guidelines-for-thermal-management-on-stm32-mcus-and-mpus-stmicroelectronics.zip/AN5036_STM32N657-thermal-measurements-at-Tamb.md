# STM32N657 thermal measurements at TA = 25 °C {#id_69334}

The figures and table below detail the thermal measurements performed at TA = 25 °C.

![](DT75955.svg "STM32N657 thermal measurements at TA = 25 °C")

**Table 1. STM32N657 thermal measurements at T A  = 25 °C.**

<table>
<thead>
<tr>
<th>TJ (°C)</th>
<th colspan="3">Thermal camera module measurement (°C)<p>Max</p></th>
<th>STM32N657 power consumption (mW)</th>
</tr>
</thead>
<tbody>
<tr>
<td>47<sup><a href="#fn1">1</a></sup></td>
<td colspan="3">48.7</td>
<td>1318</td>
</tr>
</tbody>
</table>

Once the heat dissipation capability \(HDC\) of the design has been defined \(by measurement at 25 °C\), and assuming that this HDC is constant at 25 °C and maximum ambient temperature, the operating point of the design at TJ = 125 °C is given by translating the HDC, as shown in the figure and table below.

![](DT75956.svg "HDC at 91 °C and junction temperature-dependent dissipated power for STM32N657")

**Table 2. Measurement interpolation at maximum ambient temperature for STM32N657**

|Parameter|Value|
|:-------:|:---:|
|TJ|125 °C|
|PTOT|2082 mW|
|Maximum ambient temperature|91 °C|

In conclusion, the STM32N657 device is safe, with no thermal runaway, and for TJ = 125 °C, the maximum ambient temperature TA = 91 °C.

**Parent topic:**[Discovery kit with STM32N657XOH3 MCU](AN5036_Discovery-board-with-STM32N657XOH3-MCU.md)

<a id="fn1"></a>

[^1]: Thermocouple measurement

