# STM32MP157 thermal measurements at TA = 25 °C {#id_7174}

The figures and table below detail the thermal measurements performed at TA = 25 °C.

![](DT61723.png "STM32MP157 thermal measurements at TA = 25 °C")

**Table 1. STM32MP157 thermal measurements at T A = 25 °C**

<table>
<thead>
<tr>
<th rowspan="2">TJ (°C)</th>
<th colspan="3">Thermal camera measurement (°C)</th>
<th rowspan="2">STM32MP157 power consumption (mW)</th>
<th rowspan="2">Total power consumption (mW)</th>
</tr>
<tr>
<th>Avg</th>
<th>Min</th>
<th>Max</th>
</tr>
</thead>
<tbody>
<tr>
<td>46</td>
<td>46.2</td>
<td>40.52</td>
<td>51.4</td>
<td>974</td>
<td>2000</td>
</tr>
</tbody>
</table>

![](DT62067.svg "HDC at 25 °C and junction-temperature-dependent dissipated power for STM32MP157")

Once the HDC of the design is defined \(by measurement at 25 °C\), and assuming that this HDC is constant at 25 °C and 85 °C, the operating point of the design at 85 °C is given by translating the HDC at 85 °C as shown in the figure and table below.

![](DT61725.svg "HDC at 85 °C and junction-temperature-dependent dissipated power for STM32MP157")

**Table 2. Measurement interpolation at T A = 85 °C for STM32MP157**

|Parameter|Value|
|:-------:|:---:|
|TJ|110 °C|
|PTOT|2200 mW|

In conclusion, the STM32MP157 device is safe, with no thermal runaway, and TJ remaining < 125 °C.

**Parent topic:**[Evaluation board with STM32MP157 MPU](AN5036_evaluation-board-STM32MP157-MPU.md)

