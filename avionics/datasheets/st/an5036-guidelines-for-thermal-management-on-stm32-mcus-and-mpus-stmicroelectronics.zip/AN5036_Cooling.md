# Cooling {#AN5036_topic_6}

-   **[Power dissipation paths](AN5036_Power-dissipation-paths.md)**  

-   **[Main cooling methods](AN5036_Main-cooling-methods.md)**  

-   **[Bottom cooling - host PCB design](AN5036_Bottom-cooling-host-PCB-design.md)**  


