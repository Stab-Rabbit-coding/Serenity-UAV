# Case temperature {#topic_xmq_kqx_fcb}

The case temperature is the temperature of the top of the package used as a chip carrier for the die. The JEDEC standards specify that the temperature sensor must be placed at the center of the package top, using 1 mm of conductive epoxy.

If the package case-to-ambient thermal resistance is much higher than the package junction-to-case thermal resistance \(one order of magnitude at least\), and as most devices dissipated power goes through the board, the junction temperature can be conflated with case temperature if some uncertainty is acceptable.

**Parent topic:**[STM32 thermal parameters](AN5036_STM32-thermal-parameters.md)

