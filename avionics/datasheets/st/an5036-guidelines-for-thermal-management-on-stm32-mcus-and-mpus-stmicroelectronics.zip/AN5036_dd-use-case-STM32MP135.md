# Use case about dd {#id_50211 .concept}

As stated in [STM32 thermal parameters](AN5036_STM32-thermal-parameters.md), the dissipated power varies with the TJ. The power consumption in this example is measured for different TJ values \(see the following tables and figure\).

**Table 1. STM32MP135 power dissipation versus T J at 900 MHz (dd)**

|TJ \(°C\)|STM32MP135 power dissipation \(mW\) at 900 MHz|
|---------|----------------------------------------------|
|20|586.44|
|31|596.04|
|43|615.00|
|47|623.83|
|52|632.93|
|56|638.62|
|66|666.42|
|71|679.79|
|78|698.36|
|86|732.92|
|91|756.62|
|96|778.01|
|98|789.23|
|101|801.44|
|106|826.83|
|111|848.00|
|116|869.98|
|119|889.19|
|129|985.12|

**Table 2. STM32MP135 power dissipation versus T J at 1 GHz (dd)**

|TJ \(°C\)|STM32MP135 power dissipation \(mW\) at 1 GHz|
|---------|--------------------------------------------|
|21.6|670.45|
|32|675.12|
|37|681.26|
|46|700|
|49|708.00|
|56|716.39|
|61|736.53|
|68|765.82|
|76|787.60|
|83|811.60|
|89|842.97|
|100|889.80|
|110|936.20|

**Table 3. STM32MP135 thermal measurements at T A = 25 °C (dd)**

<table>
<thead>
<tr>
<th>Parameter</th>
<th>900 MHz</th>
<th>1 GHz</th>
<th>Unit</th>
</tr>
</thead>
<tbody>
<tr>
<td>TJ</td>
<td>43</td>
<td>46</td>
<td>[°C]</td>
</tr>
<tr>
<td>VCORE</td>
<td>1.32</td>
<td>1.32</td>
<td>[V]</td>
</tr>
<tr>
<td>ICORE</td>
<td>177</td>
<td>198</td>
<td>[mA]</td>
</tr>
<tr>
<td>PCORE</td>
<td>233</td>
<td>261</td>
<td>[mW]</td>
</tr>
<tr>
<td>VDD</td>
<td>3.33</td>
<td>3.33</td>
<td>[V]</td>
</tr>
<tr>
<td>IDD</td>
<td>13</td>
<td>19</td>
<td>[mA]</td>
</tr>
<tr>
<td>PDD</td>
<td>43</td>
<td>63</td>
<td>[mW]</td>
</tr>
<tr>
<td>VCPU</td>
<td>1.415</td>
<td>1.398</td>
<td>[V]</td>
</tr>
<tr>
<td>ICPU</td>
<td>173</td>
<td>199</td>
<td>[mA]</td>
</tr>
<tr>
<td>PCPU</td>
<td>244</td>
<td>278</td>
<td>[mW]</td>
</tr>
<tr>
<td>VDDR2</td>
<td>1.268</td>
<td>1.268</td>
<td>[V]</td>
</tr>
<tr>
<td>IDDR2</td>
<td>75</td>
<td>77</td>
<td>[mA]</td>
</tr>
<tr>
<td>PDDR2</td>
<td>95</td>
<td>97</td>
<td>[mW]</td>
</tr>
<tr>
<td rowspan="2">STM32MP135</td>
<td>615</td>
<td>700</td>
<td rowspan="2">[mW]</td>
</tr>
<tr>
<td colspan="2"><strong>+ 13%</strong></td>
</tr>
</tbody>
</table>

![](DT71604.svg "Junction temperature-dependent dissipated power for STM32MP135 (dd)")

**Parent topic:**[STM32MP135 power dissipation](AN5036_STM32MP135-power-dissipation.md)

