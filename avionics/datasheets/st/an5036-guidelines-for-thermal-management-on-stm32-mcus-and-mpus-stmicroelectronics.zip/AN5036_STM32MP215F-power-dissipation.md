# STM32MP215F power dissipation {#id_77577}

As stated in [STM32 thermal parameters](AN5036_STM32-thermal-parameters.md), the dissipated power varies with TJ. The power consumption in this example is measured for different TJ values \(as [Figure 1](#fig_zgc_rfx_qhc) below demonstrates\).

![](DT80404.svg "Junction-temperature-dependent dissipated power for STM32MP215F")

**Parent topic:**[Internal validation board with STM32MP215F MPU](AN5036_Internal-Validation-Board-with-STM32P215FMPU.md)

