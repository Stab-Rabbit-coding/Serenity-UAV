# Discovery kit with STM32H747XI MCU {#id_7169}

This thermal analysis has been done on a Discovery kit with an STM32H747XI device \(STM32H747I-DISCO\), without casing \(see the figure below\).

![](DT50372V2.png "STM32H747I-DISCO")

The test case is the following:

-   Run mode \(400 MHz\) data processing running from the flash memory
-   Cache ON
-   All peripherals enabled

The temperature sensor connected to the ADC3 VINP \[18\] input channel, is used for TJ measurement.

The TJ measurements are read via the USART2 using the DMA transfer, without CPU interruption.

-   **[STM32H7 power dissipation](AN5036_STM32H7-power-dissipation.md)**  

-   **[STM32H7 thermal measurements at TA = 25 °C](AN5036_STM32H7-thermal-measurements-at-Tamb.md)**  


**Parent topic:**[Thermal analysis examples](AN5036_Thermal-analysis-example.md)

