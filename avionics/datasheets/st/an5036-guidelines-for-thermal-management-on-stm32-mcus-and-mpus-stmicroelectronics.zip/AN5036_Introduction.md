# Introduction {#concept_vts_yqx_fcb .concept}

This document describes the thermal management guidelines for applications based on STM32 microcontrollers or microprocessors. These, like any silicon-based integrated circuits, have well-defined storage and operating temperature ranges.

Only the STM32 operating temperature ranges defined in their product datasheets are considered. These are: the maximum operating temperature range, and the product operating temperature range. The maximum operating temperature range defines the threshold temperature beyond which there is a high probability of permanent damage to the device. The operating temperature range defines the threshold temperature beyond which the electrical parameters are not guaranteed to be within the specification.

The STM32 maximum specified operating range refers to the junction temperature, whereas the operating temperature range refers to the ambient temperature, and possibly also to the junction temperature.

Specifying the operating temperature ranges by reference to the ambient, or to the junction, temperature is common practice in the semiconductor industry. Depending on the device and its power consumption, semiconductor vendors use either of these for product operating-temperature range specification.

