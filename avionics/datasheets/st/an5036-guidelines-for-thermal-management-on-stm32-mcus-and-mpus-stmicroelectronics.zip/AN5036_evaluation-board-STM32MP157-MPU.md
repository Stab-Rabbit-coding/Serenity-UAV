# Evaluation board with STM32MP157 MPU {#id_7172}

This thermal analysis has been done on an evaluation board with an STM32MP157 device, without casing \(see the figure below\).

![](DT61726.png "STM32MP157x-EV1")

While running commands, the script monitors the following:

-   The CPU load with `mpstat`
-   The board temperature via `/ sys / class / hwmon / hwmon0 / temp1_input`
-   The memory used via the free command

-   **[STM32MP157 power dissipation](AN5036_STM32MP157-power-dissipation.md)**  

-   **[STM32MP157 thermal measurements at TA = 25 °C](AN5036_STM32MP157-thermal-measurements.md)**  


**Parent topic:**[Thermal analysis examples](AN5036_Thermal-analysis-example.md)

