# Thermal analysis examples {#id_7168}

This section shows examples of thermal analysis performed on a discovery kit \(STM32H747XI MCU\), an evaluation board \(STM32MP157\), and an internal validation board \(STM32MP135 MPU\).

These analyses provide some answers to the following questions \(at maximum ambient temperature 85 °C\):

-   How much does the power dissipation admit the leakage?
-   Is TJ < 125 °C?
-   Is there a risk of thermal runaway?

-   **[Discovery kit with STM32H747XI MCU](AN5036_Discovery-board-with-STM32H7-MCU.md)**  

-   **[Evaluation board with STM32MP157 MPU](AN5036_evaluation-board-STM32MP157-MPU.md)**  

-   **[Internal validation board with STM32MP135 MPU](AN5036_Internal-Validation-board-with-STM32MP135-MPU.md)**  

-   **[Internal validation board with STM32MP257 MPU](AN5036_Internal-Validation-board-with-STM32MP257-MPU.md)**  

-   **[Discovery kit with STM32N657XOH3 MCU](AN5036_Discovery-board-with-STM32N657XOH3-MCU.md)**  

-   **[Internal validation board with STM32MP215F MPU](AN5036_Internal-Validation-Board-with-STM32P215FMPU.md)**  


