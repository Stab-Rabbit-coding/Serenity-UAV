# Power dissipation variation with junction temperature {#AN5036_topic_4}

In this section, process, voltage, and activity factors are kept constant, and there is a focus on the effect of the junction temperature.

The static/leakage current grows exponentially with the junction temperature \(while the dynamic current does not significantly change\).

The power dissipation variation with junction temperature has the following main consequences:

-   A cooling solution must be implemented to limit the junction temperature below 125 °C \(maximum junction temperature\).
-   If the cooling system is not efficient enough, the device can go into thermal runaway that may be destructive.

When performing system-level thermal simulations in the design phase, it is fundamental to input junction temperature dependent power dissipation.

**Parent topic:**[Power dissipation and cooling methods](AN5036_Power-dissipation-cooling.md)

