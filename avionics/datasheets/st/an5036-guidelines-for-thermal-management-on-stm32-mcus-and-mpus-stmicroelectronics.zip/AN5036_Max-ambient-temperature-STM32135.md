# Maximum ambient temperature \(STM32MP135 MPU\) {#id_50216 .concept}

The maximum ambient temperature for the cpuburn and dd use cases are given in the figures below.

![](DT71606.svg "Maximum ambient temperature(Cpuburn)")

![](DT71607.svg "Maximum ambient temperature (dd)")

**Parent topic:**[Internal validation board with STM32MP135 MPU](AN5036_Internal-Validation-board-with-STM32MP135-MPU.md)

