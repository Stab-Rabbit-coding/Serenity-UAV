# Thermal system study {#topic_xmq_kqx_fcb}

Thermal systems are designed with complex thermal models and advanced simulation software tools. These models and tools are used to obtain accurate results.

To resolve a thermal system with an acceptable accuracy and with limited computation effort, many simplifying hypotheses can be used \(such as considering the thermal resistance to be temperature independent\). Using these hypotheses, the study of thermal systems is analogous to the study of electrical systems, where the heat is equivalent to the electrical current, the temperature is equivalent to the voltage, and the thermal resistance is equivalent to the electrical resistance.

![](DT50492.svg "Analogy between electrical and thermal system domains")

This model is widely accepted by the electronic industry. Most semiconductor vendors provide thermal resistance parameters of their packaged products based on this simplified model, in accordance with certain standardization bodies \(like JEDEC EIA/JESD 51‑X standards\). Designers consider the provided thermal resistance parameters when dealing with heat dissipation in their application, or at least, at an earlier stage, when selecting the right package for a given product.

**Parent topic:**[Thermal systems definitions and basic concepts](AN5036_Thermal-systems-definitions-basic-concepts.md)

