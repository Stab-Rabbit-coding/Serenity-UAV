# Discovery kit with STM32N657XOH3 MCU {#id_69315}

This thermal analysis was done on a Discovery kit with an STM32N657XOH3 device without casing.

The test case is the following:

-   Internal VDD\_core
-   voshigh-trusted.bin configuration
-   CPU frequency = 800 MHz
-   NPU frequency = 1000 MHz
-   NPU RAM frequency = 900 MHz

STM32N6 max load application firmware:

-   Use DCMI and VENC in YUV2 \(camera board MB1723C with OV5640 sensor\)
-   Use NPU inference
-   Stream video on LTDC using GPUD2 accelerator

-   **[STM32N657 power dissipation](AN5036_STM32N657-power-dissipation.md)**  

-   **[STM32N657 thermal measurements at TA = 25 °C](AN5036_STM32N657-thermal-measurements-at-Tamb.md)**  


**Parent topic:**[Thermal analysis examples](AN5036_Thermal-analysis-example.md)

