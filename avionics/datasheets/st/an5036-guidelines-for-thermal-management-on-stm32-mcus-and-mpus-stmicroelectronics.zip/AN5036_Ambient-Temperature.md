# Ambient temperature {#topic_xmq_kqx_fcb}

In the electronic field, there is no consensus about a standard and unified definition of the ambient temperature. What is sure is that the ambient temperature is the temperature of the device surroundings, but there are many different ways to measure it. Measurement parameters such as the distance between the measurement point and the device, if the surrounding air is steady or not, the volume of the test environment, can severely impact later interpretation of the results.

JEDEC provides a standard definition for ambient temperature but that definition is limited to the JEDEC test environment used when determining package thermal characteristics.

Most of the time, the application operating conditions differ significantly from the JEDEC environment, making the JEDEC defined thermal resistance from junction-to-ambient temperature \(Θ-JA\) not practically usable for high-performance high-power-dissipation devices.

**Parent topic:**[STM32 thermal parameters](AN5036_STM32-thermal-parameters.md)

