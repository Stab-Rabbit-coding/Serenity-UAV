# STM32MP257 thermal measurements at TA = 25 °C {#id_65650}

The figures and table below detail the thermal measurements performed at TA = 25 °C.

![](DT61723.png "STM32MP257 thermal measurements at TA = 25 °C")

**Table 1. STM32MP257 thermal measurements at T A = 25 °C.**

<table>
<thead>
<tr>
<th rowspan="2">TJ (°C)</th>
<th colspan="3">Thermal camera module measurement (°C)</th>
<th rowspan="2">STM32MP257 power consumption (mW)</th>
</tr>
<tr>
<th>Avg</th>
<th>Min</th>
<th>Max</th>
</tr>
</thead>
<tbody>
<tr>
<td>47.5 <sup><a href="#fn1">1</a></sup></td>
<td>40.24</td>
<td>31.5</td>
<td>48.7</td>
<td>2164.77</td>
</tr>
</tbody>
</table>

Once the HDC of the design is defined \(by measurement at 25 °C\), and assuming that this HDC is constant at 25 °C and 85 °C, the operating point of the design at 85 °C is given by translating the HDC at 85 °C as shown in [Figure 2](#fig_lr1_lr3_ygb) and [Table 2](#table_jh5_2fk_5bc).

![](DT75051.png "HDC at 85 °C and junction temperature-dependent dissipated power for STM32MP257")

**Table 2. Measurement interpolation at T A = 85 °C for STM32MP257**

|Parameter|Value|
|:-------:|:---:|
|TJ|115 °C|
|PTOT|2886.5 mW|

In conclusion, the STM32MP257 device is safe, with no thermal runaway, and TJ remaining < 125 °C.

**Parent topic:**[Internal validation board with STM32MP257 MPU](AN5036_Internal-Validation-board-with-STM32MP257-MPU.md)

<a id="fn1"></a>

[^1]: Thermocouple measurement

