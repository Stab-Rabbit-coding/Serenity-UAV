# Internal validation board with STM32MP257 MPU {#id_65626 .concept}

This thermal analysis has been done on an internal validation board with an STM32MP257 device without casing. The test case is the following:

-   Glmark2-es2-drm
-   Video decoder
-   Endecoder
-   Memtester1
-   Memtester2

-   **[STM32MP257 power dissipation](AN5036_STM32MP257-Power-dissipation.md)**  

-   **[STM32MP257 thermal measurements at TA = 25 °C](AN5036_STM32MP257-thermal-measurements.md)**  


**Parent topic:**[Thermal analysis examples](AN5036_Thermal-analysis-example.md)

