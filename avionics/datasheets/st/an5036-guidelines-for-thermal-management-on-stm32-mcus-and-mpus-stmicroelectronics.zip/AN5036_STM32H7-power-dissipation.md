# STM32H7 power dissipation {#id_7170}

As stated in [STM32 thermal parameters](AN5036_STM32-thermal-parameters.md#), the dissipated power varies with TJ. The power consumption in this example is measured for different TJ values \(see the table and the figure below\).

**Table 1. STM32H747XI power dissipation versus T j**

<table>
<thead>
<tr>
<th rowspan="2">TJ (°C)</th>
<th colspan="2">STM32H747I-DISCO (supplied with 5 V)</th>
<th rowspan="2">STM32H747XI power dissipation (mW)</th>
</tr>
<tr>
<th>Current consumption (A)</th>
<th>Power consumption (mW)</th>
</tr>
</thead>
<tbody>
<tr>
<td>46.9</td>
<td>0.395</td>
<td>1975</td>
<td>737</td>
</tr>
<tr>
<td>51.8</td>
<td>0.405</td>
<td>2025</td>
<td>769</td>
</tr>
<tr>
<td>55.8</td>
<td>0.412</td>
<td>2060</td>
<td>788</td>
</tr>
<tr>
<td>61.5</td>
<td>0.423</td>
<td>2115</td>
<td>824</td>
</tr>
<tr>
<td>65.7</td>
<td>0.430</td>
<td>2150</td>
<td>852</td>
</tr>
<tr>
<td>71</td>
<td>0.442</td>
<td>2210</td>
<td>888</td>
</tr>
<tr>
<td>77.3</td>
<td>0.452</td>
<td>2260</td>
<td>920</td>
</tr>
<tr>
<td>81.9</td>
<td>0.465</td>
<td>2325</td>
<td>965</td>
</tr>
<tr>
<td>87.5</td>
<td>0.480</td>
<td>2400</td>
<td>1010</td>
</tr>
<tr>
<td>92</td>
<td>0.490</td>
<td>2450</td>
<td>1056</td>
</tr>
<tr>
<td>96.8</td>
<td>0.509</td>
<td>2545</td>
<td>1104</td>
</tr>
<tr>
<td>102.5</td>
<td>0.534</td>
<td>2670</td>
<td>1179</td>
</tr>
<tr>
<td>106.3</td>
<td>0.550</td>
<td>2750</td>
<td>1229</td>
</tr>
<tr>
<td>111.3</td>
<td>0.571</td>
<td>2855</td>
<td>1298</td>
</tr>
<tr>
<td>116.9</td>
<td>0.600</td>
<td>3000</td>
<td>1387</td>
</tr>
<tr>
<td>123</td>
<td>0.635</td>
<td>3175</td>
<td>1499</td>
</tr>
<tr>
<td>125</td>
<td>0.650</td>
<td>3250</td>
<td>1559</td>
</tr>
</tbody>
</table>

![](DT62098.svg "Junction-temperature-dependent dissipated power for STM32H7 ")

**Parent topic:**[Discovery kit with STM32H747XI MCU](AN5036_Discovery-board-with-STM32H7-MCU.md)

