# General information {#ID07-6D056E7E2311140}

This document applies to STM32 Arm®‑based devices.

**Note:** Arm is a registered trademark of Arm Limited \(or its subsidiaries\) in the US and/or elsewhere.

![](Arm_logo_black_no_frame.svg)

