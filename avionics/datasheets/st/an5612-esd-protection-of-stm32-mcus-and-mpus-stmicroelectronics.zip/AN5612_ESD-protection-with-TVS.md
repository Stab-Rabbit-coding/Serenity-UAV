# ESD protection with TVS {#ID02-18EEC3C7E551 .concept}

The rest of the document focuses on the ESD protection with TVS and in particular with ST TVS devices.

TVS devices offer a very fast response time, a sharp voltage-current characteristic, and robustness with ESDs. Additionally, their destruction upon an excess of their maximum allowed current usually transforms them into a short circuit. This is generally better than an open circuit leaving the equipment unprotected.

Unidirectional TVS devices typically protect electronic equipment \(or an IC\) supplied from positive voltage only, such as 3.3 V. Bidirectional TVS devices typically protect electronic equipment supplied from positive and negative voltages, such as 3.3 V and -3.3 V.

![](DT64514.svg "Unidirectional TVS voltage-current characteristic")

![](DT64515.svg "Bidirectional TVS voltage-current characteristic")

**Parent topic:**[Choosing an optimum ESD protection method](AN5612_Choosing-correct-ESD-protection.md)

