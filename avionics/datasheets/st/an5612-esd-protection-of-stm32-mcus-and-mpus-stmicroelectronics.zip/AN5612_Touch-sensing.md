# Touch sensing {#ID02-18EEC3C7E563 .concept}

For touch sensing application, refer to [\[2\]](AN5612_General-info.md#ref_2).

**Parent topic:**[Human interface](AN5612_Human-interface.md)

