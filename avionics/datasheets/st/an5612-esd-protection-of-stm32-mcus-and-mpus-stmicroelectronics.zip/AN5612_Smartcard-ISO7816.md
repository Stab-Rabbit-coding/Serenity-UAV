# Smartcard \(ISO-7816\) {#ID02-18EEC3C7E5136 .concept}

![](DT64532.png "Smartcard interface ESD protection")

Refer to [3-line EMI filter and ESD protection for SIM card interfaces \(EMIF03-SIM02M8\)](https://www.st.com/en/product/emif03-sim02m8) and [Single-line unidirectional ESD protection for high speed interface \(ESDAULC6-1U2\)](https://www.st.com/en/product/esdaulc6-1u2) pages on [www.st.com](http://www.st.com) for more information on these ESD protection devices.

**Note:** On STM32 devices, the I/Os to protect against ESD are those of the USART peripheral.

**Parent topic:**[Storage](AN5612_Storage.md)

