# General information {#id_30228 .reference}

This document applies to Arm®-based MCUs and MPUs.

**Note:** Arm is a registered trademark of Arm Limited \(or its subsidiaries\) in the US and/or elsewhere.

![](Arm_logo_black_no_frame.svg)

**Table 1. Glossary of terms**

|Term|Developed form|
|:--:|:-------------|
|ANSI|American national standards institute|
|BLE|Bluetooth® Low Energy|
|CDM|Charged-device model|
|CSI|Camera serial interface|
|DSI|Display serial interface|
|D-PHY|Physical layer option set by MIPI alliance|
|ECMF|EMI/RFI common mode filter|
|EMIF|Electromagnetic interference filter|
|ESDA|ESD association|
|ESD|Electrostatic discharge|
|GPIO|General purpose input/output|
|JEDEC|Joint electron device engineering council|
|JTAG|Joint test action group|
|HBM|Human body model|
|IEC|International electrotechnical commission|
|MM|Machine model|
|MIPI|Mobile industry processor interface|
|MOV|Metal oxide varistor|
|NFC|Near-field communication|
|PCB|Printed circuit board|
|SMC|Surface mounted component|
|SMPS|Switch mode power supply|
|SWD|Serial wire debug|
|TVS|Transient voltage suppressor|
|VBR|Voltage breakdown|

**Table 2. Reference documents**

|Reference number|Document title|
|:--------------:|:-------------|
|\[1\]|*EMC design guide for STM8, STM32 and Legacy MCUs*, [AN1709](https://www.st.com/en/product/stm32g484me)|
|\[2\]|*ESD considerations for touch sensing applications on MCUs*, [AN3960](https://www.st.com/resource/en/application_note/DM00035396.pdf)|

**Table 3. Complementary literature available on www.st.com**

<table>
<thead>
<tr>
<th>Category</th>
<th>Document</th>
</tr>
</thead>
<tbody>
<tr>
<td rowspan="4">EMIF</td>
<td><em>HDMI ESD protection and signal conditioning products for STBs</em>, <a href="https://www.st.com/resource/en/application_note/DM00460966.pdf">AN5121</a></td>
</tr>
<tr>
<td><em>IEC 61000-4-2 standard testing</em>, <a href="https://www.st.com/resource/en/application_note/DM00023467.pdf">AN3353</a></td>
</tr>
<tr>
<td><em>EMI filters for SD3.0 card high-speed SD card protection and filtering devices</em>, <a href="https://www.st.com/resource/en/application_note/DM00121661.pdf">AN4541</a></td>
</tr>
<tr>
<td><em>LC filters for mobile phone LCD and camera links</em>, <a href="https://www.st.com/resource/en/application_note/CD00262504.pdf">AN3141</a></td>
</tr>
<tr>
<td rowspan="4">ECMF</td>
<td><em>USB Type-C protection and filtering</em>, <a href="https://www.st.com/resource/en/application_note/DM00294046.pdf">AN4871</a></td>
</tr>
<tr>
<td><em>Antenna desense on handheld equipment</em>, <a href="https://www.st.com/resource/en/application_note/DM00095431.pdf">AN4356</a></td>
</tr>
<tr>
<td><em>IEC 61000-4-2 standard testing</em>, <a href="https://www.st.com/resource/en/application_note/DM00023467.pdf">AN3353</a></td>
</tr>
<tr>
<td><em>Common mode filters</em>, <a href="https://www.st.com/resource/en/application_note/DM00119609.pdf">AN4511</a></td>
</tr>
<tr>
<td rowspan="7">Protection</td>
<td><em>Increasing the ST25DV-I2C series Dynamic NFC Tags ESD robustness on antenna using an external ESD protection</em>, <a href="https://www.st.com/resource/en/application_note/DM00670720.pdf">AN5425</a></td>
</tr>
<tr>
<td><em>3.3 V RS485 compatible with 1.8 V I/Os and selectable speed 20 Mbps or 250 kbps</em>, <a href="https://www.st.com/resource/en/application_note/DM00554495.pdf">AN5245</a></td>
</tr>
<tr>
<td><em>Increasing the M24LRXXE-R family ESD robustness on antenna using an external ESD protection</em>, <a href="https://www.st.com/resource/en/application_note/DM00089924.pdf">AN4326</a></td>
</tr>
<tr>
<td><em>Fundamentals of ESD protection at system level</em>, <a href="https://www.st.com/resource/en/application_note/DM00548138.pdf">AN5241</a></td>
</tr>
<tr>
<td><em>USB Type-C protection and filtering</em>, <a href="https://www.st.com/resource/en/application_note/DM00294046.pdf">AN4871</a></td>
</tr>
<tr>
<td><em>HDMI ESD protection and signal conditioning products for STBs</em>, <a href="https://www.st.com/resource/en/application_note/DM00460966.pdf">AN5121</a></td>
</tr>
<tr>
<td><em>IEC 61000-4-2 standard testing</em>, <a href="https://www.st.com/resource/en/application_note/DM00023467.pdf">AN3353</a></td>
</tr>
</tbody>
</table>

