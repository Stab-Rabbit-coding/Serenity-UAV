# Multimedia {#ID02-18EEC3C7E5106}

The following sections pertain to ESD protection solutions for MIPI D-PHY, parallel display interface, HDMI, USB 2.0 Full or High speed, and USB Type-C.

-   **[MIPI D-PHY \(DSI and CSI\)](AN5612_MIPI-D-PHY-DSI-CSI.md)**  

-   **[Parallel display interface](AN5612_Parallel-interface.md)**  

-   **[HDMI](AN5612_HDMI.md)**  

-   **[USB](AN5612_USB-2.0-and-USB-Type-C.md)**  


**Parent topic:**[ESD solutions in application](AN5612_ESD-solutions-in-application.md)

