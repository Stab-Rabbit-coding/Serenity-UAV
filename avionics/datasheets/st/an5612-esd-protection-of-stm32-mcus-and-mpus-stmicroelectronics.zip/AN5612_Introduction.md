# Introduction {#id_28518 .concept}

Electronic equipment using microcontrollers and microprocessors is more and more often exposed to a harsh electromagnetic environment. The designs become more complex and more integrated. The increasing number of interfaces through which the MCUs and MPUs interact with the external world multiply the paths for the interference to reach them. This raises plenty of design challenges in building robust equipment.

Among other electromagnetic disturbances, an electrostatic discharge \(ESD\) is one of the most harmful effects that designers must consider since the beginning of the design process.

STM32 MCU and MPU devices embed protection against ESD events during the device handling and assembly. Their ESD immunity is characterized according to ANSI/JEDEC standards and specified in their datasheet. The equipment manufacturing process must prevent them from any ESD stress exceeding that specification.

The electronic equipment design measures that allow protecting sensitive parts such as MCUs and MPUs include casing, shielding, wiring, filtering, PCB routing, and adequate protection components to dissipate ESD stress and keep it far from the sensitive parts. The MCU or MPU internal ESD protection then absorbs the remaining stress that might reach the device. EMC-aware design of an electronic equipment considers all paths for the ESD stress to reach components and provides an appropriate protective solution to each of them.

