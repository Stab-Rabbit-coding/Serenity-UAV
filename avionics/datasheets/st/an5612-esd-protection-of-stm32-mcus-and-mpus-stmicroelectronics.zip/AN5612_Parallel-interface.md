# Parallel display interface {#ID02-18EEC3C7E5109 .concept}

![](DT66156.svg "Parallel display port ESD protection")

Refer to [8-line L-C EMI filter and ESD protection for display interfaces \(EMIF08-LCD04M16\)](https://www.st.com/en/product/EMIF08-LCD04M16) page on [www.st.com](http://www.st.com) for more information on this ESD protection device.

**Parent topic:**[Multimedia](AN5612_Multimedia.md)

