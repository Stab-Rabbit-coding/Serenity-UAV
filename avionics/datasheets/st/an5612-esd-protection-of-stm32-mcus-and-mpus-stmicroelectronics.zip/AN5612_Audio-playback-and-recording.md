# Audio playback and recording {#ID02-18EEC3C7E574 .concept}

Consumer applications often provide an audio receptacle to plug a headphone or an external amplifier, and a microphone or another audio source. The STM32 device can be connected to an audio codec device that drives the audio signal externally. At the same time, the application can monitor the acoustic environment through analog or MEMS microphones to detect or cancel noise. As these signal lines face the environment through connectors, speakers, or microphones, they must be ESD-protected.

![](DT64521.png "ESD protection of audio application with jack connectors")

![](DT66151.svg "ESD protection of audio amplifier application with speakers")

Refer to [QUAD BIDIRECTIONAL TRANSIL SUPPRESSOR FOR ESD PROTECTION \(ESDA6V1-4BC6\)](https://www.st.com/en/product/esda6v1-4bc6) page on [www.st.com](http://www.st.com) for information on the appropriate protection device for this application.

![](DT66152.svg "ESD protection of audio application with ECM")

Refer to [Single-line low capacitance Transil™ for ESD protection \(ESDALC6V1-1U2\)](https://www.st.com/en/product/ESDALC6V1-1U2) page on [www.st.com](http://www.st.com) for information on the appropriate protection device for this application.

![](DT66153.svg "ESD protection of audio application with digital microphone")

Refer to [QUAD TRANSIL ARRAY FOR ESD PROTECTION \(ESDALC6V1W\)](https://www.st.com/en/product/ESDALC6V1W) page on [www.st.com](http://www.st.com) for more information on this ESD protection device.

**Note:** The STM32 peripherals involved are: ADC, OPAMP, COMP, DAC, DFSDM, SPDIF, SAI, and I2S.

**Parent topic:**[Analog and power](AN5612_Analog-and-power.md)

