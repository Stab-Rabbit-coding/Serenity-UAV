# Human interface {#ID02-18EEC3C7E557}

Most ESDs are caused by humans. The following sections pertain to ESD protection solutions for joystick, press button, and touch sensing.

**Note:** The STM32 peripherals involved are: ADC and GPIOs.

-   **[Joystick](AN5612_Joystick.md)**  

-   **[Press button](AN5612_Press-button.md)**  

-   **[Touch sensing](AN5612_Touch-sensing.md)**  


**Parent topic:**[ESD solutions in application](AN5612_ESD-solutions-in-application.md)

