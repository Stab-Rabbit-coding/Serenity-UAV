# Ethernet {#ID02-18EEC3C7E594 .concept}

![](DT64524.svg "Ethernet port ESD protection")

Refer to [Very low capacitance ESD protection \(USBLC6-4SC6\)](https://www.st.com/en/product/usblc6-4) and [4-line ESD protection for high-speed lines \(HSP053-4M5\)](https://www.st.com/en/product/HSP053-4M5) pages on [www.st.com](http://www.st.com) for more information on these ESD protection devices. Consider the latter for gigabit Ethernet ports.

**Note:** The STM32 peripheral involved is the Ethernet MAC.

**Parent topic:**[Wired communication](AN5612_Wired-communication.md)

