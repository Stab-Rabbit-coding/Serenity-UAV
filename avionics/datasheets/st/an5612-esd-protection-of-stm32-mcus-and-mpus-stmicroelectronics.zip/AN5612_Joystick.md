# Joystick {#ID02-18EEC3C7E559 .concept}

A five-line protection component is ideal for the five buttons of a joystick. When the STM32 MCU is supplied from its maximum operating voltage 3.6 V, the absolute maximum voltage of the joystick sensing I/Os is well above the VBR of the protection component \(here 6.1 V\). This headroom allows the use of a protection component with parasitic capacitance.

![](DT64518.svg "Joystick port ESD protection")

Refer to [Transil™ \(TVS\) array for ESD protection \(ESDA6V1-5SC6\)](https://www.st.com/en/product/esda6v1-5sc6) page on [www.st.com](http://www.st.com) for more information on this ESD protection device.

**Parent topic:**[Human interface](AN5612_Human-interface.md)

