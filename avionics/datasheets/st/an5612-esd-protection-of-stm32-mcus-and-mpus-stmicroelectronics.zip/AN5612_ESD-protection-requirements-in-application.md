# ESD protection requirements in application {#ID02-18EEC3C7E530 .concept}

The electronic equipment must comply with applicable industry standards in term of robustness with stress induced by ESDs. The protection requirements for military and healthcare applications are more strict than to consumer applications.

The following table lists the ESD protection levels defined by IEC 61000-4-2 \(HBM\) and their equivalent test voltages.

**Table 1. Sensitivity classification for the HBM (IEC 61000-4-2)**

<table>
<thead>
<tr>
<th>Test type</th>
<th>Level</th>
<th>Test voltage</th>
</tr>
</thead>
<tbody>
<tr>
<td rowspan="4">Contact discharge</td>
<td>1</td>
<td>2 kV</td>
</tr>
<tr>
<td>2</td>
<td>4 kV</td>
</tr>
<tr>
<td>3</td>
<td>6 kV</td>
</tr>
<tr>
<td>4</td>
<td>8 kV</td>
</tr>
<tr>
<td rowspan="4">Air discharge</td>
<td>1</td>
<td>2 kV</td>
</tr>
<tr>
<td>2</td>
<td>4 kV</td>
</tr>
<tr>
<td>3</td>
<td>8 kV</td>
</tr>
<tr>
<td>4</td>
<td>15 kV</td>
</tr>
</tbody>
</table>

The air discharge model is generally used when the contact cannot be characterized.

**Table 2. ST classification of ESD consequences**

|Class A|Class B|Class C|Class D|
|:-----:|:-----:|:-----:|:-----:|
|No failure detected|Failure detected but self-recovery after disturbance|Need an external user action to recover normal functionality|Normal functionality cannot be recovered|

ESD protection cost and footprint are minor with regard to costs related to handling product failures in the field. Therefore, the equipment makers have the interest to assess the ESD exposure of their products and adequately protect them.

**Parent topic:**[Electrostatic discharge \(ESD\)](AN5612_Electrostatic-discharge.md)

