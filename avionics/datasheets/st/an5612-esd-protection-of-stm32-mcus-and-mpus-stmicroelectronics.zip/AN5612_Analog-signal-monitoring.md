# Analog signal monitoring {#ID02-18EEC3C7E568 .concept}

Analog signals and lines such as the battery voltage can be monitored by an ADC. The battery monitoring line, often coming from a mezzanine board, is sensitive to ESD and the input of the STM32 ADC must be protected.

![](DT64520.svg "Analog signal monitoring port ESD protection")

Refer to [Single-line low capacitance Transil™ for bidirectional ESD protection \(ESDALC6V1-1BU2\)](https://www.st.com/en/product/esdal) page on [www.st.com](http://www.st.com) for more information on this ESD protection device.

**Note:** The STM32 peripherals involved are: ADC, OPAMP, COMP, and DAC.

**Parent topic:**[Analog and power](AN5612_Analog-and-power.md)

