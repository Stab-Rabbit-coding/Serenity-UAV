# ESD protection methods {#ID02-18EEC3C7E534 .concept}

## Using clamping diodes { .section}

Clamping diodes are most commonly used as IC ESD protection devices. Microcontrollers, digital signal controllers, and processors usually integrate ESD clamping diodes.

ICs without the embedded ESD protection can be protected with external clamping diodes, as shown in the following figure. For a standard GPIO, diodes clamping to VDD and VSS shunt the ESD stress to VDD \(positive polarity\) or GND \(negative polarity\). A diode clamping to VDD on a 5 V tolerant I/O prevents the I/O from being used as such.

Place a capacitor \(for example 1 µF\) between VDD and GND and as close as possible to the diodes, to absorb the ESD current.

![](DT64534.svg "Clamping diodes as ESD protection devices")

## Using a varistor { .section}

The resistance of a varistor varies with the voltage across - the higher the voltage, the lower the resistance. This property makes them behave as clamps when exposed to ESD. Furthermore, varistors are low-capacity and low-cost devices. Their weak point is that their clamping voltage is usually too high to protect an I/O. Another drawback is that by their construction, these metal-oxide varistors \(MOV\) degrade when exposed to ESDs.

![](DT64535.svg "Varistor as ESD protection device")

## Using a capacitor { .section}

ESD is most commonly caused by humans, upon touching the electronic equipment. The IEC 61000-4-2 standard \(HBM\) categorizes the electronic equipment resistance to a 330 pF capacitor discharge, without damage. The 330pF value is considered as an equivalent of human body capacitance. The resistance is expressed in levels or in capacitor voltage prior to the discharge. It spans up to 8 kV.

Electrical terminals can be protected with a capacitor \(usually 100 nF or more\) that absorbs the charge of the human body transferred to the equipment upon the ESD. It scales down the voltage with the ratio of the two capacitances. For the protection to be effective, the protection capacitor must have a very low parasitic inductance, which is the property of high-frequency capacitors.

The solution is well adapted for protecting static ports such as power terminals, where a capacitor is also required for decoupling. To improve its ESD protection efficacy, a small transient voltage suppression \(TVS\) device added in parallel with the decoupling capacitor then suppresses peaks due to parasitic inductance.

The method is not suitable for protecting data ports as it degrades data rate or prevents data interfaces from operating.

![](DT64536.svg "Capacitor as ESD protection device")

## Using a resistor in series { .section}

Resistors in series limit the current induced by the ESD. A resistor of several kΩ can effectively protect an I/O terminal of an IC. However, this solution is often inadequate to protect data transfer I/Os and it is not applicable to powering terminals. Standard resistors are not designed to sustain high voltage. Repetitive exposure to ESDs may alter their properties, which then can reduce their protective efficacy or impair the electronic equipment functionality. The application of a serial resistor as an ESD protection device must therefore properly be tested.

![](DT64537.svg "Resistor in series as ESD protection device")

## Using a transient voltage suppressor { .section}

Transient voltage suppressor \(TVS\) such as Transil™ is high-impedance until the voltage across reaches a breakdown level. Once its breakdown voltage is reached, the TVS acts as a clamp with a very short reaction time. There are unidirectional \(see [Figure 1](AN5612_ESD-protection-with-TVS.md#fig_transil_ESD_2)\) and bidirectional \(see [Figure 2](AN5612_ESD-protection-with-TVS.md#fig_transil_ESD_1)\) TVS devices.

A bidirectional TVS has a symmetrical voltage-current characteristic, presenting the same breakdown voltage on the negative and positive side of the voltage axis. It is well suited for protecting analog unbiased lines.

A unidirectional TVS has an asymmetrical voltage-current characteristic similar to a Zener diode. As it clamps negative disturbance to a lower level than a bidirectional TVS, it is better adapted for protecting terminals that only bear positive voltages.

![](DT64538.svg "TVS as ESD protection device")

**Parent topic:**[Choosing an optimum ESD protection method](AN5612_Choosing-correct-ESD-protection.md)

