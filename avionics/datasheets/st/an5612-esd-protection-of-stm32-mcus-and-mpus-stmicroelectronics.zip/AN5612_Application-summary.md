# Summary {#AN5612_Summary .reference}

The following table summarizes the ESD protection components presented in the previous sections.

<table>
<thead>
<tr>
<th>Application</th>
<th>ESD protection device</th>
</tr>
</thead>
<tbody>
<tr>
<td colspan="2">Human interface</td>
</tr>
<tr>
<td>Joystick or Keypad</td>
<td><a href="https://www.st.com/resource/en/datasheet/esda6v1-5sc6.pdf">ESDA6V1-5SC6</a></td>
</tr>
<tr>
<td>Press button (one button)</td>
<td><a href="https://www.st.com/resource/en/datasheet/esdalc6v1-1u2.pdf">ESDALC6V1-1U2</a></td>
</tr>
<tr>
<td>Press button (two buttons)</td>
<td><a href="https://www.st.com/resource/en/datasheet/esdal.pdf">ESDAL</a></td>
</tr>
<tr>
<td colspan="2">Analog and power</td>
</tr>
<tr>
<td>Analog signal monitoring (positive-only)</td>
<td><a href="https://www.st.com/resource/en/datasheet/esdalc6v1-1u2.pdf">ESDALC6V1-1U2</a></td>
</tr>
<tr>
<td>Analog signal monitoring (bi-directional)</td>
<td><a href="https://www.st.com/resource/en/datasheet/esdalc6v1-1bu2.pdf">ESDALC6V1-1BU2</a></td>
</tr>
<tr>
<td>Audio application with two jack connectors or speakers</td>
<td><a href="https://www.st.com/resource/en/datasheet/esda6v1-4bc6.pdf">ESDA6V1-4BC6</a></td>
</tr>
<tr>
<td>Audio application with ECM</td>
<td><a href="https://www.st.com/resource/en/datasheet/esdalc6v1-1u2.pdf">ESDALC6V1-1U2</a></td>
</tr>
<tr>
<td>Audio application with digital microphone</td>
<td><a href="https://www.st.com/resource/en/datasheet/esdalc6v1w.pdf">ESDALC6V1W5</a></td>
</tr>
<tr>
<td>Power line</td>
<td><a href="https://www.st.com/resource/en/datasheet/esda7p120-1u1m.pdf">ESDA7P120-1U1M</a></td>
</tr>
<tr>
<td colspan="2">Wired communication</td>
</tr>
<tr>
<td>CAN port</td>
<td><a href="https://www.st.com/resource/en/datasheet/esdcan03-2bwy.pdf">ESDCANxx-2BWY</a></td>
</tr>
<tr>
<td>Ethernet port</td>
<td><p><a href="https://www.st.com/resource/en/datasheet/usblc6-4.pdf">USBLC6-4</a><br/>
 <a href="https://www.st.com/resource/en/datasheet/hsp053-4m5.pdf">HSP053-4M5</a></p></td>
</tr>
<tr>
<td>RS-232 / RS-485 port</td>
<td><a href="https://www.st.com/resource/en/datasheet/esdaxxxp6.pdf">ESDAxxxP6</a></td>
</tr>
<tr>
<td>Other serial interfaces</td>
<td><a href="https://www.st.com/resource/en/datasheet/usblc6-4.pdf">USBLC6-4</a></td>
</tr>
<tr>
<td colspan="2">Multimedia</td>
</tr>
<tr>
<td>MIPI D-PHY (DSI / CSI)</td>
<td><p><a href="https://www.st.com/resource/en/datasheet/ecmf04-4hswm10.pdf">ECMF04-4HSWM10</a><br/>
 <a href="https://www.st.com/resource/en/datasheet/usblc6-4.pdf">USBLC6-4</a></p></td>
</tr>
<tr>
<td>Parallel display interface</td>
<td><a href="https://www.st.com/resource/en/datasheet/emif08-lcd04m16.pdf">EMIF08-LCD04M16</a></td>
</tr>
<tr>
<td>HDMI</td>
<td><p><a href="https://www.st.com/resource/en/datasheet/ecmf04-4hswm10.pdf">ECMF04-4HSWM10</a> (data lines, with common mode choke)<br/>
 <a href="https://www.st.com/resource/en/datasheet/hsp053-4m5.pdf">HSP053-4M5</a> (data lines, protection only)<br/>
 <a href="https://www.st.com/resource/en/datasheet/esdalc6v1-5m6.pdf">ESDALC6V1-5M6</a> (CEC lines)</p></td>
</tr>
<tr>
<td>USB 2.0 FS</td>
<td><a href="https://www.st.com/resource/en/datasheet/usblc6-2.pdf">USBLC6-2</a></td>
</tr>
<tr>
<td>USB 2.0 FS OTG</td>
<td><a href="https://www.st.com/resource/en/datasheet/usblc6-4.pdf">USBLC6-4</a></td>
</tr>
<tr>
<td>USB 2.0 HS</td>
<td><a href="https://www.st.com/resource/en/datasheet/ecmf02-2amx6.pdf">ECMF02-2AMX6</a></td>
</tr>
<tr>
<td colspan="2">Storage</td>
</tr>
<tr>
<td>SD card 2.0</td>
<td><a href="https://www.st.com/resource/en/datasheet/emif06-msd02n16.pdf">EMIF06-MSD02N16</a></td>
</tr>
<tr>
<td>SD card 3.0</td>
<td><a href="https://www.st.com/resource/en/datasheet/usblc6-4.pdf">USBLC6-4</a></td>
</tr>
<tr>
<td>Smartcard (ISO-7816)</td>
<td><p><a href="https://www.st.com/resource/en/datasheet/emif03-sim02m8.pdf">EMIF03-SIM02M8</a> (with filter)<br/>
 <a href="https://www.st.com/resource/en/datasheet/esdalc6v1w.pdf">ESDALC6V1W5</a> (without filter)<br/>
 <a href="https://www.st.com/resource/en/datasheet/esdaulc6-1u2.pdf">ESDAULC6-1U2</a></p></td>
</tr>
<tr>
<td colspan="2">Debug interfaces</td>
</tr>
<tr>
<td>SWD</td>
<td><p><a href="https://www.st.com/resource/en/datasheet/smlvt3v3.pdf">SMLVT3V3</a><br/>
 <a href="https://www.st.com/resource/en/datasheet/esdalc6v1w.pdf">ESDALC6V1W5</a></p></td>
</tr>
<tr>
<td>JTAG</td>
<td><p><a href="https://www.st.com/resource/en/datasheet/smlvt3v3.pdf">SMLVT3V3</a><br/>
 <a href="https://www.st.com/resource/en/datasheet/esdalc6v1-5m6.pdf">ESDALC6V1-5M6</a></p></td>
</tr>
<tr>
<td colspan="2">RF interfaces</td>
</tr>
<tr>
<td>NFC tag</td>
<td><a href="https://www.st.com/resource/en/datasheet/dsilc6-4xx.pdf">DSILC6-4xx</a></td>
</tr>
<tr>
<td>NFC reader</td>
<td><a href="https://www.st.com/resource/en/datasheet/esdaxlc18-1bf4.pdf">ESDAXLC18-1BF4</a></td>
</tr>
<tr>
<td>Bluetooth, Sub-GHz (SigFox, LoRa, 169-433 MHz)</td>
<td><a href="https://www.st.com/resource/en/datasheet/esdarf02-1bu2ck.pdf">ESDARF02-1BU2CK</a></td>
</tr>
</tbody>
</table>

**Note:** The list is not exhaustive. For more information on ST ESD protection components, refer to [http://www.st.com](http://www.st.com) and/or contact your local ST sales office.

**Parent topic:**[ESD solutions in application](AN5612_ESD-solutions-in-application.md)

