# ESD solutions in application {#ID02-18EEC3C7E556}

This section pertains to ESD protection solutions in various applications such as human interface, wired communication, or multimedia.

![](DT66150.png "Protection and filters around an MCU")

-   **[Human interface](AN5612_Human-interface.md)**  

-   **[Analog and power](AN5612_Analog-and-power.md)**  

-   **[Wired communication](AN5612_Wired-communication.md)**  

-   **[Multimedia](AN5612_Multimedia.md)**  

-   **[Storage](AN5612_Storage.md)**  

-   **[Debug and programming](AN5612_Debug-and-programming.md)**  

-   **[Summary](AN5612_Application-summary.md)**  


