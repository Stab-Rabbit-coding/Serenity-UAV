# Debug and programming {#ID02-18EEC3C7E5140}

This sections pertain to ESD protecting SWD and JTAG interfaces.

-   **[SWD](AN5612_SWD.md)**  

-   **[JTAG](AN5612_JTAG.md)**  


**Parent topic:**[ESD solutions in application](AN5612_ESD-solutions-in-application.md)

