# SWD {#ID02-18EEC3C7E5141 .concept}

![](DT64533.png "SWD interface ESD protection")

Refer to [600 W, 3.3 V TVS in SMB \(SMLVT3V3\)](https://www.st.com/en/product/smlvt3v3) and [QUAD TRANSIL ARRAY FOR ESD PROTECTION \(ESDALC6V1W\)](https://www.st.com/en/product/ESDALC6V1W) pages on [www.st.com](http://www.st.com) for more information on this ESD protection device.

**Parent topic:**[Debug and programming](AN5612_Debug-and-programming.md)

