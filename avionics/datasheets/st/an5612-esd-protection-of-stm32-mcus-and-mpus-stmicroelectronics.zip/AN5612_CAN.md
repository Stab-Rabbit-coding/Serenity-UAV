# CAN {#ID02-18EEC3C7E589 .concept}

![](DT64523.svg "CAN port ESD protection")

Refer to [Automotive dual-line TVS in SOT323-3L for CAN bus \(12 V system\) \(ESDCAN03-2BWY\)](https://www.st.com/en/product/esdcan03-2bwy) page on [www.st.com](http://www.st.com) for more information on this ESD protection device.

**Note:** The STM32 peripherals involved are: CAN and FDCAN.

**Parent topic:**[Wired communication](AN5612_Wired-communication.md)

