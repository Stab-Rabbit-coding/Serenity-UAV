# Optimizing the application for ESD protection {#ID02-18EEC3C7E553 .concept}

If the protection device is too far from the discharge point, the discharge current may induce an excessive electric field. The induced electrical field can disturb other parts of the system by coupling phenomena. Keep the TVS device as close as possible to the expected point of electrostatic discharge.

The voltage of the TVS-protected point during an ESD is a sum of:

-   VBR - the TVS device breakdown voltage
-   VR - voltage across a parasitic serial resistance Rd: VR = Rd x IESD.
-   VL - voltage across a parasitic inductance L: VL = L x di/dt.

The main challenge for a PCB routing is to ensure that most of the current flows through the TVS protection, thus unloading the ESD protection embedded in the STM32.

As every single track has an inherent inductance, the system can be schematized as follows:

![](DT64516.png "Schematic diagram of a TVS protected system")

The inductance of the TVS path is L1 + L2 + L3 while the one towards the protected IC is L1 + L4. For the ESD current to flow to the TVS device, it is important to keep L2 and L3 as small as possible and the L4 greater than L1.

The following figure shows the principal PCB layout measures to reach that goal. With an optimized layout, the TVS device is placed directly on the PCB signal and ground tracks. In this way, it minimizes L2 and L3 parasitic inductances. Also, it is closer to the ESD source than to the IC to protect, thus maximizing the L4/L1 ratio.

![](DT64517.svg "Optimizing PCB layout")

**Parent topic:**[Electrostatic discharge \(ESD\)](AN5612_Electrostatic-discharge.md)

