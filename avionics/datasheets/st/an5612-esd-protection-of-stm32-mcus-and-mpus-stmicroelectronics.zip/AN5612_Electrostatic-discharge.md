# Electrostatic discharge \(ESD\) {#ID02-18EEC3C7E53}

This section describes the electrostatic discharge phenomenon, its consequences to ICs and standards pertaining to ESD.

-   **[ESD phenomenon](AN5612_ESD-phenomenon.md)**  

-   **[ESD protection level quantification](AN5612_ESD-protection-level-quantification.md)**  

-   **[ESD protection requirements in application](AN5612_ESD-protection-requirements-in-application.md)**  

-   **[Choosing an optimum ESD protection method](AN5612_Choosing-correct-ESD-protection.md)**  

-   **[Optimizing the application for ESD protection](AN5612_Optimizing-PCB.md)**  


