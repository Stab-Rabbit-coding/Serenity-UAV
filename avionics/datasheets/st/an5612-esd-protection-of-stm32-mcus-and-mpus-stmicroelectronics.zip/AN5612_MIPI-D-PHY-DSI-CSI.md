# MIPI D-PHY \(DSI and CSI\) {#ID02-18EEC3C7E5107 .concept}

![](DT66155.png "MIPI port ESD protection")

Refer to [Common mode filter with ESD protection in QFN-10L \(ECMF04-4HSWM10\)](https://www.st.com/en/product/ecmf04-4hswm10) and [Very low capacitance ESD protection \(USBLC6-4\)](https://www.st.com/en/product/usblc6-4) pages on [www.st.com](http://www.st.com) for more information on these ESD protection devices.

**Parent topic:**[Multimedia](AN5612_Multimedia.md)

