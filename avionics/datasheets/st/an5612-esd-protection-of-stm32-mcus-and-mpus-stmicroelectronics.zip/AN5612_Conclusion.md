# Conclusion {#ID02-18EEC3C7E5143 .concept}

This document, in parallel with [\[1\]](AN5612_General-info.md#ref_1), the product data sheet, and the IEC61000-4-2 standard, helps designers in the selection of adequate ESD protection components to protect effectively the STM32 device.

Many parameters come into account for protecting a system against ESD, such as PCB housing, board shielding and coating, and PCB routing and technology. However, TVS is the most effective and easy-to-implement protection device for the majority of applications.

