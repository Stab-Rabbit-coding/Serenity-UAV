# ESD protection level quantification {#ID02-18EEC3C7E58 .concept}

International standards pertaining to the ESD protection come from the following bodies:

-   *American national standards institute \(ANSI\)*
-   *International electrotechnical commission \(IEC\)*
-   *ESD association \(ESDA\)*
-   *Joint electron device engineering council \(JEDEC\)*

There are three commonly used models:

-   **Human body model \(HBM\)**, representing the manipulation of the product by humans
-   **Charged-device model \(CDM\)**, representing conditions of manufacturing environment such as mechanical device handling
-   **Machine model \(MM\)**, becoming obsolete due to similarity with HBM.

The JEDEC standard pertains to the manufacturing environment. It aims at protecting parts against ESD from the production machinery \(CDM\) and human manipulation \(HBM\).

The IEC 61000-4-2 standard aims at ensuring that the parts sustain the stress that they face in the electronic equipment in operation.

The great variety of different STM32 applications can expose the STM32 devices to very different conditions from the ESD stress perspective. It is not possible to compare system ESD robustness from an IC standpoint in such conditions. To guide users in targeting an IEC 61000-4-2 class, the device datasheet provides a value based on an estimated typical usage and PCB shapes. Relevant details are available in [\[1\]](AN5612_General-info.md#ref_1).

The STM32 device datasheet provides two types of data:

-   **Absolute maximum rating:** based on JEDEC, performed on unpowered devices, functionality validated afterwards.
-   **Functional susceptibility test:** based on IEC 61000-4-2, performed on devices in operation, highlighting the effective operation or self-recovery capabilities of a system.

Check for more details in [\[1\]](AN5612_General-info.md#ref_1).

**Parent topic:**[Electrostatic discharge \(ESD\)](AN5612_Electrostatic-discharge.md)

