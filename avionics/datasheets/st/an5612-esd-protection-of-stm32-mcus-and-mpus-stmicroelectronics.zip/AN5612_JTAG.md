# JTAG {#id_29557 .concept}

![](DT66159.svg "JTAG interface ESD protection")

Refer to [600 W, 3.3 V TVS in SMB \(SMLVT3V3\)](https://www.st.com/en/product/smlvt3v3) and [5-line low capacitance Transil™ arrays for ESD protection \(ESDALC6V1-5M6\)](https://www.st.com/en/product/esdalc6V1-5m6) pages on [www.st.com](http://www.st.com) for more information on this ESD protection device.

**Parent topic:**[Debug and programming](AN5612_Debug-and-programming.md)

