# Storage {#ID02-18EEC3C7E5130}

The following sections pertain to ESD protecting SD card and smartcard.

-   **[SD card 2.0](AN5612_SD-card-2.0.md)**  

-   **[SD card 3.0](AN5612_SD-card-3.0.md)**  

-   **[Smartcard \(ISO-7816\)](AN5612_Smartcard-ISO7816.md)**  


**Parent topic:**[ESD solutions in application](AN5612_ESD-solutions-in-application.md)

