# Power {#ID02-18EEC3C7E581 .concept}

The SMC30J Transil series protects sensitive equipment against surges below 3000 W \(10/1000 μs\) and against ESD according to IEC 61000-4-2, and MIL STD 883, method 3015. It is compatible with high-end equipment and switch mode power supply \(SMPS\). These applications require an ESD protection component with low leakage current that is reliable and long-lasting at high junction temperature. SMC30J is packaged in a package with SMC footprint compliant with the IPC 7531 standard.

![](DT64522.svg "Power supply line ESD protection")

Refer to [High-power transient voltage supressor \(TVS\) \(ESDA7P120-1U1M\)](https://www.st.com/en/product/ESDA7P120-1U1M) page on [www.st.com](http://www.st.com) for more information on this ESD protection device.

**Note:** The STM32 peripherals involved are: BOR, PVD, and PVM.

**Parent topic:**[Analog and power](AN5612_Analog-and-power.md)

