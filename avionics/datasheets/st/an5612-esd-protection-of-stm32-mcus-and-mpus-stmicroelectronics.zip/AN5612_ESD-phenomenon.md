# ESD phenomenon {#ID02-18EEC3C7E54 .concept}

Electrostatic discharge \(ESD\) is a sudden and momentary flow of electric current between two electrically charged objects. It is triggered upon contact, an electrical short, or dielectric breakdown.

On an electrical appliance, the most common entry points for ESD are interfaces such as connectors or human interface devices.

The ESD current induces high voltage spikes harmful to sensitive electronic devices such as microcontrollers. An ESD protection method or device adapted to their operating environment is used to prevent them from damage.

Electrostatic discharges exceeding the protective capabilities of the ESD protection may cause multiple types of failure, such as metallization defect, oxide breakdown, and burn defect.

## Metallization defect { .section}

An excessive current through a metal track causes a local hot spot and melts the metal. This can create open circuits or/and shorts between metal tracks.

![](DT64510.svg "Example of metallization defect")

## Oxide breakdown defect { .section}

An excessive electric field damages the dielectric. This occurs when the voltage across the dielectric thickness exceeds 80-100 V. The damage to the dielectric usually causes permanent leakage that may induce sequential failures.

![](DT64511.svg "Example of oxide breakdown defect")

## Burn defect { .section}

Hot metal from the bonding pad, melted due to an ESD, leaks, and burns the silicon, bonding, or the pad.

![](DT64512.svg "Example of burn defect")

These defects may cause the MCU/MPU to behave abnormally \(soft failure\) or to stop operating \(hard failure\). Damage in the device can be such as:

-   short or open connection
-   shift of impedances
-   extra leakage
-   overconsumption due to a resistive path to the ground or another internal structure

As a consequence, the application may lose a part of its functionality, or be completely down. The effect can be immediate or delayed, for example few power on/off cycles after the ESD stress.

STM32 devices embed protection to sustain standard factory manipulation and basic protection of external input/output pads. Embedded ESD protection consumes significant silicon area. At system level, it is sufficient to protect only the ESD entry points, as close as possible to the ESD source. Specific devices \(from simple resistor to more complex low-impedance structure\) are used to shunt the ESD current and protect the application circuitry, without impacting the application behavior.

The following figure shows two variants of a simple application with two user buttons, one protected, the other not protected. As the buttons are in direct contact with the user, they are a possible source of ESD.

![](DT64513.svg "Application variants with protected and unprotected STM32 device")

**Parent topic:**[Electrostatic discharge \(ESD\)](AN5612_Electrostatic-discharge.md)

