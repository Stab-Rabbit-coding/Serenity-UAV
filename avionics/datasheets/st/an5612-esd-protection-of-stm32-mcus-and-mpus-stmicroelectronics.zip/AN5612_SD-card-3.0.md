# SD card 3.0 {#id_45622 .concept}

![](DT66160.svg "SD card 3.0 port ESD protection")

Refer to [Very low capacitance ESD protection \(USBLC6-4\)](https://www.st.com/en/product/usblc6-4) page on [www.st.com](http://www.st.com) for more information on this ESD protection device.

**Note:** On STM32 devices, the I/Os to protect against ESD are those of the SDMMC peripheral.

**Parent topic:**[Storage](AN5612_Storage.md)

