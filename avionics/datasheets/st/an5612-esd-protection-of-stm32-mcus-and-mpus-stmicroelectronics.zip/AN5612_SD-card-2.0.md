# SD card 2.0 {#id_45621 .concept}

![](DT64531.svg "SD card 2.0 port ESD protection")

Refer to [6-line EMI filter and ESD protection for T-Flash and micro SD card™ interfaces \(EMIF06-MSD02N16\)](https://www.st.com/en/product/emif06-msd02n16) page on [www.st.com](http://www.st.com) for more information on this ESD protection device.

**Note:** On STM32 devices, the I/Os to protect against ESD are those of the SDMMC peripheral.

**Parent topic:**[Storage](AN5612_Storage.md)

