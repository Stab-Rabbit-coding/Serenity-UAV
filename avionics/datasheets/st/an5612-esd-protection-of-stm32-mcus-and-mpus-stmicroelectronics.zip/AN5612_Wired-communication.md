# Wired communication {#ID02-18EEC3C7E588}

The following sections pertain to ESD protection solutions for CAN, Ethernet, serial interface protocols, RS-232 and RS-485.

-   **[CAN](AN5612_CAN.md)**  

-   **[Ethernet](AN5612_Ethernet.md)**  

-   **[RS-232 and RS-485](AN5612_RS232-RS485.md)**  

-   **[Other serial interfaces](AN5612_Other-serial-interfaces.md)**  


**Parent topic:**[ESD solutions in application](AN5612_ESD-solutions-in-application.md)

