# Press button {#ID02-18EEC3C7E561 .concept}

For signal always at VDD, use a low leakage protection component. This protection component respects the maximum voltage and frequency for a press button application, leaving a good margin on VBR.

![](DT64519.svg "Press button port ESD protection (two buttons)")

Refer to [DUAL TRANSIL ARRAY FOR ESD PROTECTION \(ESDAL\)](https://www.st.com/en/product/esdal) \(for two-button application\) and [Single-line low capacitance Transil™ for ESD protection \(ESDALC6V1-1U2\)](https://www.st.com/en/product/ESDALC6V1-1U2) \(for one-button application\) pages on [www.st.com](http://www.st.com) for more information on these ESD protection devices.

**Parent topic:**[Human interface](AN5612_Human-interface.md)

