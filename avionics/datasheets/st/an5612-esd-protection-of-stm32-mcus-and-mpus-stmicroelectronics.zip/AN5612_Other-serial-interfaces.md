# Other serial interfaces {#ID02-18EEC3C7E599 .concept}

![](DT64525.svg "I2C-bus port ESD protection")

Refer to [Very low capacitance ESD protection \(USBLC6-4SC6\)](https://www.st.com/en/product/usblc6-4) page on [www.st.com](http://www.st.com) for more information on this ESD protection device.

**Note:** Other STM32 peripherals such as FMP I2C, I2C, SPI, QUADSPI, OCTOSPI, UART, USART, and LPUART can be protected based on this example.

**Parent topic:**[Wired communication](AN5612_Wired-communication.md)

