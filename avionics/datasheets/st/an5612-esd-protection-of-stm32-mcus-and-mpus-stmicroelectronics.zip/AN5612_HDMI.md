# HDMI {#ID02-18EEC3C7E5112 .concept}

![](DT64527.png "HDMI port ESD protection")

Refer to [Common mode filter with ESD protection in QFN-10L \(ECMF04-4HSWM10\)](https://www.st.com/en/product/ecmf04-4hswm10) and [5-line low capacitance Transil™ arrays for ESD protection \(ESDALC6V1-5M6\)](https://www.st.com/en/product/esdalc6V1-5m6) pages on [www.st.com](http://www.st.com) for more information on these ESD protection devices.

**Note:** On STM32 devices, the I/Os to protect against ESD are those of the HDMI CEC port.

**Parent topic:**[Multimedia](AN5612_Multimedia.md)

