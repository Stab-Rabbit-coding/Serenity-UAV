# Choosing an optimum ESD protection method {#ID02-18EEC3C7E531 .concept}

MCU and MPU pins exposed to ESD from the external world require protection. These include inputs and outputs for interfaces such as:

-   USB, HDMI, USART, Ethernet
-   audio line, microphone, speaker
-   joystick, touch sensor, mouse
-   RF antenna, power plug

This section describes possible ESD protection methods, then focuses on the TVS devices.

-   **[ESD protection methods](AN5612_ESD-protection-methods.md)**  

-   **[ESD protection with TVS](AN5612_ESD-protection-with-TVS.md)**  


**Parent topic:**[Electrostatic discharge \(ESD\)](AN5612_Electrostatic-discharge.md)

