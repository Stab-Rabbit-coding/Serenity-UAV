# X-CUBE-RTC for synchronization application {#id_33499}

X-CUBE-RTC shows an implementation of the RTC calendar synchronization with the HSE \(provided by an external signal: HSE bypass feature used\)

\(STM32CubeExpansion\_AN4759\_RTC\_STM32L\_Vx.y.z\\Projects\\NUCLEO-L552ZE-Q\\RTC\_Synchronization\).

The firmware implements:

-   TIM1 in Master mode with update interrupt activated to generate an interruption each second. It is configured to exploit an external 16 MHz signal thanks to the bypass of HSE clock. A PLL is also used for the timer to be clocked by a 100 MHz signal.
-   the RTC with the SHIFTR register programming
-   GPIO: RTC\_OUT CALIB to check if the RTC 1 Hz output frequency is really 1 Hz \(synchronization does not affect the RTC\_OUT CALIB output but this signal needs to be as close as possible to 1 Hz for the synchronization to work\)

    The user LED2 \(PB7\) is used to visualize the 1-s period and the good working of the application.


**Parent topic:**[STM32L5 API and synchronization application example](AN4759_STM32L5-API-synchro-application-example.md)

