# Smooth calibration application example \(STM32L5\) {#id_33492}

-   **[Hardware setup](AN4759_HW-setup-L5-dig-calib.md)**  

-   **[Software setup](AN4759_SW-setup-L5-dig-calib.md)**  

-   **[Smooth calibration principle](AN4759_Digital-calib-block-diag-L5.md)**  

-   **[Run time observations](AN4759_Run-time-observations-L5-dig-calib.md)**  


**Parent topic:**[STM32L5 API and smooth digital calibration application example](AN4759_STM32L5-API-dig-smooth-calib.md)

