# RTC clock configuration {#id_33180}

## RTC clock source { .section}

The RTC calendar can be driven by one of three possible clock sources LSE, LSI or HSE.

If the HSE is selected, a prescaler must be selected. The user can refer to the product reference manual to know its possible values and configurations.

Moreover, the choice of the RTC clock source is done thanks to the RTCSEL\[1:0\] in a RCC register. This register depends on the product and this information can also be found in the product reference manual.

## How to adjust the RTC calendar clock { .section}

The RTC features several prescalers that allow delivering a 1 Hz clock to the calendar unit, regardless of the clock source.

For the RTC3 type, the BCD or mixed mode is considered. In binary mode \(available only on RTC3\), the calendar is not functional.

![](DT19527.svg "Prescalers from RTC clock source to calendar unit")

**Important:** The calendar unit is linked to ck\_spre but belongs to the ck\_apre \(asynchronous prescaler\) clock domain. The choice of ck\_apre can help to optimize power consumption.

The formula to calculate ck\_spre is:

<math id="math_ibw_bqw_qpb" display="inline"><mrow><mi>c</mi><mi>k</mi><mi>_</mi><mi>s</mi><mi>p</mi><mi>r</mi><mi>e</mi><mo>⁢</mo><mo>=</mo><mtext> </mtext><mrow><mfrac><mrow><mi>R</mi><mi>T</mi><mi>C</mi><mi>C</mi><mi>L</mi><mi>K</mi></mrow><mrow><mo>(</mo><mi>P</mi><mi>R</mi><mi>E</mi><mi>D</mi><mi>I</mi><mi>V</mi><mi>_</mi><mi>A</mi><mo>⁢</mo><mo>+</mo><mn>1</mn><mo>)</mo><mo>×</mo><mo>(</mo><mi>P</mi><mi>R</mi><mi>E</mi><mi>D</mi><mi>I</mi><mi>V</mi><mi>_</mi><mi>S</mi><mo>+</mo><mn>1</mn><mo>)</mo></mrow></mfrac></mrow></mrow></math>

where:

-   RTCCLK is any clock source \(HSE\_RTC, LSE or LSI\).
-   PREDIV\_A is any number from 1 to 127.
-   PREDIV\_S is any number from 0 to 32767.

The table below shows several ways to obtain the calendar clock ck\_spre = 1 Hz.

Other PREDIV\_A\[6:0\]/PREDIV\_S\[14:0\] values are possible. The user must always prefer the combination where PREDIV\_A\[6:0\] is the highest for the needed accuracy and for lower consumption.

**Table 1. Calendar clock ck_spre= 1 Hz with various clock source**

<table>
<thead>
<tr>
<th rowspan="2">RTCCLK clock source</th>
<th colspan="2">Prescalers</th>
</tr>
<tr>
<th>PREDIV_A[6:0]</th>
<th>PREDIV_S[14:0]</th>
</tr>
</thead>
<tbody>
<tr>
<td>HSE_RTC = 1 MHz</td>
<td>124 (div 125)</td>
<td>7999 (div 8000)</td>
</tr>
<tr>
<td>LSE = 32.768 kHz</td>
<td>127 (div 128)</td>
<td>255 (div 256)</td>
</tr>
<tr>
<td>LSI = 32 kHz</td>
<td>127 (div 128)</td>
<td>249 (div 250)</td>
</tr>
<tr>
<td>LSI = 37 kHz</td>
<td>124 (div 125)</td>
<td>295 (div 296)</td>
</tr>
<tr>
<td>LSI = 40 kHz</td>
<td>127 (div 128)</td>
<td>311 (div 312)</td>
</tr>
</tbody>
</table>

**Parent topic:**[RTC calendar](AN4759_RTC-calendar.md)

