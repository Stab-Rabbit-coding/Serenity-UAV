# Level detection on tamper input {#id_33227}

Setting TAMPFLT\[1:0\] to a value other than zero means that the tamper input triggers when a selected level \(high or low\) is observed on the corresponding input pin RTC\_TAMPx \(RTC2\)/TAMP\_INx \(RTC3\).

A tamper detection event is generated when either two, four or eight \(depending on the TAMPFLT value\) consecutive samples are observed at the selected level.

![](DT30114.svg "Tamper with level detection")

Using the level detection \(TAMPFLT\[1:0\] ≠ 0\), the tamper input pin can be precharged by resetting TAMPPUDIS through an internal resistance before sampling its state. In order to support the different capacitance values, the length of the pulse during which the internal pull-up is applied can be one, two, four or eight RTCCLK cycles \(see TAMPPRCH\[1:0\]\).

![](DT30115.svg "Tamper sampling with precharge pulse")

**Note:** When the internal pull-up is not applied, the I/O Schmitt triggers are disabled in order to avoid an extra consumption if the tamper switch is open.

The trade-off between the tamper detection latency and the power consumption through the weak pull-up or external pull-down can be reduced by using a tamper sampling frequency feature. The tamper sampling frequency is determined by configuring TAMPFREQ\[2:0\] in RTC\_TAMPCR \(RTC2\)/TAMP\_FLTCR \(RTC3\) register. When using the LSE at 32768 Hz as the RTC clock source, the sampling frequency can be 1, 2, 4, 8, 16, 32, 64, or 128 Hz.

**Table 1. Tamper features (level detection)**

|What|How|Comment|
|----|---|-------|
|Enable tamper.|Set to 1 TAMPxE in RTC\_TAMPCR \(RTC2\)/TAMP\_CR1 \(RTC3\).|-|
|Configure tamper filter count.|Configure TAMPFLT bits in RTC\_TAMPCR \(RTC2\)/TAMP\_FLTCR \(RTC3\).|-|
|Configure tamper sampling frequency .|Configure TAMPFREQ bits in RTC\_TAMPCR \(RTC2\)/TAMP\_FLTCR \(RTC3\).|Default value is 1Hz.|
|Configure tamper internal pull-up and precharge duration.|Configure TAMPPUDIS and TAMPPPRCH in RTC\_TAMPCR \(RTC2\)/TAMP\_FLTCR \(RTC3\).|-|
|Select tamper active edge/level detection.|Select with RTC\_TAMPCR \(RTC2\)/TAMP\_CR2 \(RTC3\).|Edge or level depends on tamper filter configuration.|
|Detect a tamper event by interrupt.|Set TAMPIE or TAMPxIE in RTC\_TAMPCR \(RTC2\)/TAMP\_IER \(RTC3\).|An interrupt is generated when tamper detection event occurs.|
|Detect a tamper event by polling.|Poll TAMPxF in RTC\_ISR \(RTC2\)/TAMP\_SR \(RTC3\).|To clear the flag, write zero in TAMPxF.|

**Parent topic:**[RTC tamper detection function](AN4759_RTC-tamper-detection.md)

