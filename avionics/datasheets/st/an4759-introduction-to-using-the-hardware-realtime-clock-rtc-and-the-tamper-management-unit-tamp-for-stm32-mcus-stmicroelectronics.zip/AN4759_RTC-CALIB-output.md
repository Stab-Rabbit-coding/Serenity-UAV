# RTC\_CALIB output {#id_33245}

The RTC\_CALIB output can be used to generate a 1 Hz or 512 Hz signal, and to measure the RTC clock deviation when compared to a more precise clock.

## Setting 512 Hz as output signal { .section}

1.  Select LSE at 32768 Hz as RTC clock source.
2.  Set the asynchronous prescaler to the default value 128.
3.  Enable the output calibration by setting COE = 1.
4.  Select 512 Hz as the calibration output by setting COSEL = 0.

## Setting 1 Hz as the output signal { .section}

1.  Select LSE at 32768 Hz as the RTC clock source.
2.  Set the asynchronous prescaler to the default value 128.
3.  Set the synchronous prescaler to the default value 256.
4.  Enable the output calibration by setting COE = 1.
5.  Select 1 Hz as the calibration output by setting COSEL = 1.

**Note:** Refer to figures in [RTC calibration methodology](AN4759_RTC-calibration-methodology.md).

## Maximum and minimum RTC\_CALIB 512 Hz output frequency { .section}

The RTC\_CALIB output can also be used to generate a variable-frequency signal. Depending on the user application, this signal can play the role of a source clock for an external device, or can be connected to a buzzer to generate sound.

The signal frequency is configured using the 6 LSB bits \(PREDIV\_A \[5:0\]\) of the asynchronous prescaler PREDIV\_A\[6:0\].

**Table 1. RTC_CALIB output frequency versus clock source**

<table>
<thead>
<tr>
<th rowspan="2">RTC clock source</th>
<th colspan="2">RTC_CALIB output frequency</th>
</tr>
<tr>
<th>Minimum <p>PREDIV_A[5:0] = 111111 (div64)</p></th>
<th>Maximum <p>PREDIV_A[5:0] = 100000<sup><a href="#fn1">1</a></sup> (div32)</p></th>
</tr>
</thead>
<tbody>
<tr>
<td>HSE_RTC = 1 MHz</td>
<td>15.625 kHz</td>
<td>30.303 kHz</td>
</tr>
<tr>
<td>LSE = 32768 Hz</td>
<td>512 Hz <p>(default output frequency)</p></td>
<td>993 Hz</td>
</tr>
<tr>
<td>LSI = 32 kHz</td>
<td>500 Hz</td>
<td>969 Hz</td>
</tr>
<tr>
<td>LSI = 37 kHz</td>
<td>578 Hz</td>
<td>1.121 kHz</td>
</tr>
<tr>
<td>LSI = 40 kHz</td>
<td>625 Hz</td>
<td>1.212 kHz</td>
</tr>
</tbody>
</table>

**Parent topic:**[Alternate function RTC outputs](AN4759_Alternate-function-RTC-outputs.md)

<a id="fn1"></a>

[^1]: PREDIV\_A\[5\] must be set to 1 to enable the RTC\_CALIB output signal generation. If PREDIV\_A\[5\] = 0, no signal is output on RTC\_CALIB.

