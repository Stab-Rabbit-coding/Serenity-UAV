# Enter/exit initialization mode {#id_33251}

The RTC can operate in two modes:

-   Initialization mode \(counters stopped\)
-   Free-running mode \(counters running\)

The calendar cannot be updated while the counters are running. The RTC must consequently be switched to the Initialization mode before updating the time and date. When operating in this mode, the counters are stopped and they start counting from the new value when the RTC enters Free-running mode.

The INIT bit in RTC\_ISR \(RTC2\)/RTC\_ICSR \(RTC3\) enables the user to switch from one mode to another. The INITF bit in the same register can be used to check the RTC current mode.

The RTC must be in Initialization mode to program the time and date registers \(RTC\_TR and RTC\_DR\) and the prescalers register \(RTC\_PRER\). This is done by setting INIT = 1 and waiting until INITF flag is set.

To return to the Free-running mode and restart counting, the RTC must exit the Initialization mode \(done by resetting INIT = 0\).

Only a power-on reset can reset the calendar on MCUs without the VBAT pin. A system reset does not affect the calendar but resets the shadow registers \(APB registers clocked by the APB bus clock\) that are read by the application. These registers are updated again when RSF = 1 in RTC\_ISR \(RTC2\)/RTC\_ICSR \(RTC3\).

After a system reset, the application can use the INITS status flag in RTC\_ISR \(RTC2\)/RTC\_ICSR \(RTC3\) to check if the calendar is already initialized. This flag is reset when the calendar year field is set to 0x00 \(power-on reset value\), meaning that the calendar must be initialized. The calendar can also be reset by setting BDRST = 1 in the RCC, even when VBAT is present.

The LSE clock initialization is not always needed after a system reset. It is recommended to check LSERDY in RCC\_BDCR and to initialize LSE only if this flag is not already set.

**Parent topic:**[RTC safety aspects](AN4759_RTC-safety-aspects.md)

