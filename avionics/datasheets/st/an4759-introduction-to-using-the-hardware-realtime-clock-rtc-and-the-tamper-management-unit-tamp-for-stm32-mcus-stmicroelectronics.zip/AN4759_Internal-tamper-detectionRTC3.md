# Internal tamper detection \(RTC3 only\) {#id_33234}

The internal tamper detection feature allows the detection of transient and environmental perturbations. An internal tamper event is enabled with ITAMPxE in TAMP\_CR1. The interrupt is enabled by setting ITAMPxIE in TAMP\_IER. Then, if the event occurs, ITAMPxF is set in TAMP\_SR, and ITAMPxMF is set in TAMP\_MISR if the interrupt has been enabled.

To clear both flags \(polling and interrupt mode\), the corresponding bit in TAMP\_SCR must be set.

The STM32 MCUs implement some of the internal tampers listed below \(refer to product reference manual\):

-   ITAMP1: supply voltage monitoring \(or backup domain voltage monitor\)
-   ITAMP2: temperature monitoring
-   ITAMP3: LSE monitoring \(CSS\)
-   ITAMP4: HSE monitoring \(CSS\)
-   ITAMP5: RTC calendar overflow
-   ITAMP6: JTAG/SWD access when RDP \> 0 \(or NVSTATE != open in STM32H5\)
-   ITAMP7: ADC analog watchdog monitoring 1
-   ITAMP8: monotonic counter 1 overflow
-   ITAMP9: cryptographic peripheral fault \(SAES, AES, PKA or RNG\)
-   ITAMP10: reserved
-   ITAMP11: IDWG reset when tamper flag is set \(potential tamper timeout\)
-   ITAMP12: ADC analog watchdog monitoring 2
-   ITAMP13: ADC analog watchdog monitoring 3
-   ITAMP14: reserved
-   ITAMP15: system fault
-   ITAMP16: reserved

Moreover, the electrical characteristics for each event depend on the device. Refer to the datasheet to get precise values and conditions on event triggering \(example: voltage value threshold for voltage monitoring\).

As for every tamper detection features, the internal tamper events allow attacks to be detected on the MCU. For instance, some attacks consist in going back in time in the RTC calendar to execute specific code. Since the user can only increment the RTC physically, going back in time can be done by making it overflow. This justifies the existence of the ITAMP5 signal.

A firmware example exploiting the ITAMP5 event is provided in the X-CUBE-RTC and detailed in [STM32L5 API and internal tamper detection application example](AN4759_STM32L5-API-internal-tamper-detection.md).

The RTC3 tamper detection unit embeds also a monotonic counter implemented in TAMP\_COUNTR register \(called TAMP\_COUNT1R on some products\) and associated to ITAMP8. See [Table 1](AN4759_Adv-RTC-features.md#table_clz_c42_rpb) and [AN4759\_Adv-RTC-features.md\#table\_hqc\_shf\_rpb](AN4759_Adv-RTC-features.md#table_hqc_shf_rpb) for the availability in the product. This register can be read and is incremented each time the user writes it whatever the written value. TAMP\_COUNTR cannot roll-over and is frozen when reaching its maximum. This register can be used in the application as a low-power counter robust to system reset. For example, it can count the number of time a sensitive part of code is executed to verify it does not exceed a limit. In that case, ITAMP8 can be used to trigger a tamper event.

ITAMP7, ITAMP12 and ITAMP13 are associated to analog watchdogs and are used to consider that an ADC channel going out of a configured voltage range is a tamper event \(see the documentation of the products featuring this internal tamper for more details\).

**Parent topic:**[RTC tamper detection function](AN4759_RTC-tamper-detection.md)

