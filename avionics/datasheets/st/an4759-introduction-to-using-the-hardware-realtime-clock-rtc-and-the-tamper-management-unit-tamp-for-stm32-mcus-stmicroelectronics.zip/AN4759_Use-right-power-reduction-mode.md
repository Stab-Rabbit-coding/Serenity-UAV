# Use the right power reduction mode {#id_33254}

The RTC can be active in the following low-power modes \(from the biggest current consumer to the smallest\):

-   Sleep mode
-   Stop mode if the RTC clock is provided by LSE or LSI
-   Standby mode if the RTC clock is provided by LSE or LSI
-   Shutdown mode if the RTC clock is provided by LSE

The precise list of modes compatible with the product and their consumption are listed in product reference manual and datasheet.

Thanks to the RTC wakeup unit, the user can wake up the STM32 MCU from this mode. Depending on the application needs in term of low-power phases and current consumption target, the adequate low-power mode and wakeup frequency must be selected.

**Parent topic:**[Reduce power consumption](AN4759_Reduce-power-consumption.md)

