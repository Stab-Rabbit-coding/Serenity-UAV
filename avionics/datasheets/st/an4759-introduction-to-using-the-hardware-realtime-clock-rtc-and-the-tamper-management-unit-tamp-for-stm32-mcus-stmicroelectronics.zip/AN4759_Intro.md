# Introduction {#id_33163 .concept}

A real-time clock \(RTC\) is a computer clock that tracks the current time. Although the RTCs are often used in personal computers, servers and embedded systems, they are also present in almost any electronic device that requires an accurate time keeping. The microcontrollers supporting the RTC can be used for chronometers, alarm clocks, watches, small electronic agendas, and many other devices.

This application note describes the RTC features and how to configure it to implement several use cases such as calendar, alarm, wakeup, timestamp, tamper detection, or calibration.

Depending on the RTC type, the product documentation may refer to an independent TAMP that is also detailed in this application note.

Software examples are then detailed in this document to show how to use the RTC in the low-power modes, and how to ensure the tamper detection and timestamp while the main supply is switched off and the MCU is supplied by an alternate battery. Other examples are also presented to illustrate the following features: smooth calibration, synchronization, reference clock detection and internal tamper.

The dedicated software is provided through the X-CUBE-RTC Expansion Package delivered with this application note. This software contains the source code of these examples and all the embedded software modules required to run the examples.

In this document, the STM32 microcontroller terminology applies to the products listed in the table below.

**Table 1. Applicable products**

|Type|Products|
|:--:|--------|
|Expansion Package|X-CUBE-RTC|
|Microcontrollers|STM32C0 series, STM32F0 series, STM32F2 series, STM32F3 series, STM32F4 series, STM32F7 series, STM32G0 series, STM32G4 series, STM32H5 series, STM32H7 series, STM32L0 series, STM32L1 series, STM32L4 series, STM32L4+ series, STM32L5 series, STM32N6 series, STM32U0 series, STM32U3 series, STM32U5 series, STM32WB series, STM32WB0 series, STM32WBA series, STM32WL series|

