# Tamper detection when main power supply is off {#id_33269}

If the user supplies the VBAT pin with the external CR1220 battery \(JP12 on BAT position\), the tamper event can be detected even if the main power supply is off, with the following steps:

-   Remove the JP17 jumper.
-   Open PA0.
-   Tie PA0 to GND \(simulating that the end-user takes care to close the box containing the electronics before supplying it again\).
-   Set JP17 on STlk.
-   The LD1 lights showing that a tamper event has been detected during the power-down. On TFT, the tamper date and tamper time are updated with the timestamp of the tamper event

**Note:** If the user supplies the VBAT pin with 3 V \(JP12 on VDD position\), the RTC is no longer supplied when the main power supply is switched off. The application is no longer able to detect the tampering event while the main power supply is off.

**Parent topic:**[Tamper detection application example \(STM32L4\)](AN4759_Tamper-detection-application-example-L4.md)

