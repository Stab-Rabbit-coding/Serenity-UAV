# Revision history {#id_33165 .reference}

**Table 1. Document revision history**

<table>
<thead>
<tr>
<th>Date</th>
<th>Version</th>
<th>Changes</th>
</tr>
</thead>
<tbody>
<tr>
<td>26-May-2016</td>
<td>1</td>
<td>Initial release.</td>
</tr>
<tr>
<td>25-Oct-2016</td>
<td>2</td>
<td>Updated:<ul>
<li>Table 1: Applicable products adding product series and part number.</li>
<li>Figure 3: STM32F2, STM32F4, STM32L0 and STM32L1 Series RTC clock sources.</li>
<li>Figure 4: STM32F0, STM32F3, STM32F7, STM32L4 and STM32WB Series RTC clock sources</li>
<li>Table 3: Calendar clock equal to 1 Hz with different clock sources</li>
<li>Section 1.4: Digital smooth calibration adding the RTC calibration basics</li>
<li>Table 14: Advanced RTC features</li>
<li>Section 4.3.3: LED meaning</li>
<li>new Section 5: STM32L4 API and digital smooth calibration application example</li>
<li>Section 6.3.1: Hardware setup</li>
<li>Section 6.3.2: Software setup</li>
<li>Section 7: Reference documentation</li>
</ul></td>
</tr>
<tr>
<td>11-May-2017</td>
<td>3</td>
<td>Updated:<ul>
<li>Figure 4: STM32F0, STM32F3, STM32F7, STM32L4 and STM32WB Series RTC clock sources</li>
<li>Table 3: Calendar clock equal to 1 Hz with different clock sources adding note</li>
<li>Section 1.4.1: RTC calibration basics</li>
<li>Section 1.11.1: RTC register write protection</li>
<li>Table 14: Advanced RTC features RTC calibration for STM32F2 Series</li>
</ul></td>
</tr>
<tr>
<td>11-Feb-2019</td>
<td>4</td>
<td>Updated:<ul>
<li>Table 1 with the STM32WB Series</li>
<li>Section 1: Overview of the STM32 MCUs advanced RTC</li>
<li>Figure 4: STM32F0, STM32F3, STM32F7, STM32L4 and STM32WB Series RTC clock sources</li>
<li>Advanced RTC features table</li>
</ul>
Removed Section 7. Reference documentation.</td>
</tr>
<tr>
<td>12-Feb-2020</td>
<td>5</td>
<td>Updated:<ul>
<li>Introduction</li>
<li>Table 1: Applicable products</li>
<li>Section 1: Overview of the STM32 MCUs advanced RTC: new Table 2: RTC/TAMP types versus features and new Table 3: RTC type versus STM32 products</li>
<li>Table 4: Advanced RTC2 features</li>
<li>new Table 5: Advanced RTC3 features</li>
<li>Table 6: Steps to initialize the calendar</li>
<li>Footnote Table 7: Calendar clock equal to 1 Hz with different clock sources</li>
<li>Section 2.1.4: RTC clock configuration</li>
<li>Table 8: Steps to configure the alarm</li>
<li>Section 2.3.2: Alarm sub-second configuration</li>
<li>Section 2.4: RTC periodic wakeup unit</li>
<li>Table 11: Steps to configure the auto-wakeup unit</li>
<li>Section 2.5.2: Methodology paragraph and Figure 10: Smooth calibration block for RTC3 with LPCAL=1</li>
<li>Section 2.9: Timestamp function</li>
<li>Section 2.10: RTC tamper detection function</li>
<li>Section 2.11: Backup registers</li>
<li>Section 2.12: Alternate function RTC outputs</li>
<li>Section 2.13: RTC safety aspects</li>
<li>Section 2.14: Reducing power consumption</li>
</ul></td>
</tr>
<tr>
<td>12-Feb-2020 (cont'd)</td>
<td>5</td>
<td>Added:<ul>
<li>Section 2.1.5: Calendar firmware examples</li>
<li>Section 2.4.3: Wakeup firmware examples</li>
<li>Section 2.8: RTC prescaler adjustment with LSI measurements</li>
<li>Section 2.10.4: Active tamper detection (RTC3 only)</li>
<li>Figure 17: Tamper detection</li>
<li>Section 2.10.7: Tamper detection firmware examples</li>
<li>Section 6: STM32L5 API and digital smooth calibration application example</li>
<li>Section 7: STM32L5 API and synchronization application example</li>
<li>Section 8: STM32L5 API and reference clock detection application example</li>
<li>Section 9: STM32L5 API and internal tamper detection application example</li>
</ul></td>
</tr>
<tr>
<td>4-Jun-2021</td>
<td>6</td>
<td>Updated with the STM32U5 Series:<ul>
<li>Introduction</li>
<li>Table 2. RTC/TAMP types</li>
<li>Table 3. RTC type on STM32 MCUs</li>
<li>STM32H7 in Table 4. Advanced features for RTC2 type</li>
<li>STM32U5 in Table 5. Advanced features of RTC3 type</li>
<li>Notes in Figure 1. RTC calendar fields</li>
<li>Example in Section 2.3.1.2 Configure the alarm behavior using the MSKx bits</li>
<li>Note in Section 2.3.2 Alarm subsecond configuration</li>
<li>Note in Section 2.4.2.3 Periodic timebase/wakeup configuration for clock configuration 3</li>
<li>Caution in Section 2.6 Synchronize the RTC</li>
<li>Section 2.10.3 Action on tamper detection event</li>
<li>Section 2.10.5 Internal tamper detection (RTC3 only)</li>
<li>Section 2.11 Backup registers</li>
<li>Section 2.13.2 Enter/exit initialization mode</li>
<li>Titles and structure of to Section 3 to Section 9</li>
</ul>
<p>Added:</p>
<ul>
<li>Section 2.2 Binary and mixed modes (RTC3 only)</li>
<li>Section 2.10.6 Potential detection management (RTC3 only)</li>
</ul></td>
</tr>
<tr>
<td>20-Sep-2021</td>
<td>7</td>
<td>Updated:<ul>
<li><a href="AN4759_Calendar-FW-examples.md">Calendar firmware examples</a></li>
<li><a href="AN4759_RTC-calibration-methodology.md#fig_rdg_41n_5pb">Figure 1</a></li>
</ul></td>
</tr>
<tr>
<td>08-Nov-2022</td>
<td>8</td>
<td>Updated:<ul>
<li><a href="AN4759_Intro.md">Introduction</a> to add the STM32C0 and the STM32H5 Series.</li>
<li><a href="AN4759_Adv-RTC-features.md">Advanced RTC features</a> to add data for STM32U5, STM32L5, STM32L41/42/4P5/4Q5, STM32G4, STM32G0, STM32H7A3/7B3, STM32H5 and STM32C0 in Table 5. Advanced features of RTC3 type.</li>
<li><a href="AN4759_Internal-tamper-detectionRTC3.md">Internal tamper detection (RTC3 only)</a> to update the internal tamper list.</li>
<li><a href="AN4759_Tamper-detection-FW-examples.md">Tamper detection firmware examples</a></li>
<li><a href="AN4759_Low-power-managt-FW-examples.md">Low-power management firmware examples</a></li>
</ul></td>
</tr>
<tr>
<td>12-Mar-2024</td>
<td>9</td>
<td>Updated:<ul>
<li>Document title</li>
<li><a href="AN4759_Intro.md#table_w2h_ztr_qpb">Table 1</a></li>
<li><a href="AN4759_Overview-STM32-MCUs.md#table_ubz_3zr_qpb">Table 2</a></li>
<li><a href="AN4759_Adv-RTC-features.md#table_clz_c42_rpb">Table 1</a></li>
<li><a href="AN4759_Adv-RTC-features.md#table_hqc_shf_rpb">AN4759_Adv-RTC-features.md#table_hqc_shf_rpb</a></li>
<li><a href="AN4759_RTC-clock-synchro.md">RTC clock synchronization</a></li>
</ul></td>
</tr>
<tr>
<td>30-Jan-2025</td>
<td>10</td>
<td>Updated:<ul>
<li><a href="AN4759_Intro.md#table_w2h_ztr_qpb">Table 1</a></li>
<li><a href="AN4759_Overview-STM32-MCUs.md#table_ubz_3zr_qpb">Table 2</a></li>
<li><a href="AN4759_Adv-RTC-features.md#table_clz_c42_rpb">Table 1</a> and <a href="AN4759_Adv-RTC-features.md#table_hqc_shf_rpb">AN4759_Adv-RTC-features.md#table_hqc_shf_rpb</a></li>
<li><a href="AN4759_RTC-prescaler-adjust.md">RTC prescaler adjustment with LSI measurements</a></li>
<li><a href="AN4759_backup-registers.md">Backup registers</a></li>
<li><a href="AN4759_Low-power-managt-FW-examples.md">Low-power management firmware examples</a></li>
</ul></td>
</tr>
<tr>
<td>17-Feb-2026</td>
<td>11</td>
<td><p>Updated:</p>
<ul>
<li><a href="AN4759_Adv-RTC-features-landscape.md#table_hqc_shf_rpb">Table 1</a></li>
<li><a href="AN4759_RTC-clock-synchro.md">RTC clock synchronization</a></li>
<li><a href="AN4759_External-optimization-factors.md">External optimization factors</a></li>
</ul></td>
</tr>
</tbody>
</table>

<a id="fn1"></a>

[^1]: Erasing part of SRAM is also possible.<a id="fn2"></a>

[^2]: Erasing of part of SRAM, caches and cryptographic registers is also possible.<a id="fn3"></a>

[^3]:  Filtering, sampling and precharge configuration, internal pull-up.<a id="fn4"></a>

[^4]: Only two for STM32L4 devices.<a id="fn5"></a>

[^5]:  Depends on device category.<a id="fn6"></a>

[^6]: This feature is not available for STM32H503.

