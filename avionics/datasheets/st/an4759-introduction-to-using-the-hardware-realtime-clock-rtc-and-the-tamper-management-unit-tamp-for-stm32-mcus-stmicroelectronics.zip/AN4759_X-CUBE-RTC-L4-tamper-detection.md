# X-CUBE-RTC for tamper detection {#id_33263}

X-CUBE-RTC shows an example where a real-time clock must be maintained alive while using as low power as possible \(STM32CubeExpansion\_AN4759\_RTC\_STM32L\_Vx.y.z\\Projects\\STM32L476G\_EVAL\\RTC\_TamperVBATT\).

The firmware implements:

-   Hints to ensure a low current consumption
-   A display in the debugger \(date and time, timestamp date and time\) and on LEDs \(power-up events, reset events, tamper events, error\)
-   A display on the TFT screen, using STemWin library
-   Tampering detection capability, both when the main power supply \(VDD\) is present and when the RTC is battery powered
-   The ability to timestamp the tampering event
-   The ability to erase the backup registers that may contain sensitive data upon tamper detection

The application flowchart is shown in the figure below.

![](DT41083.svg "Application example flowchart")

**Parent topic:**[STM32L4 API and tamper detection application example](AN4759_STM32L4-API-tamper-detection-example.md)

