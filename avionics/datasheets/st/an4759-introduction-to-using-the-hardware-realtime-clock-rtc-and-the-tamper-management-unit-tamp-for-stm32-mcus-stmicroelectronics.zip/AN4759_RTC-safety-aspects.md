# RTC safety aspects {#id_33249}

-   **[RTC register write protection](AN4759_RTC-register-write-protection.md)**  

-   **[Enter/exit initialization mode](AN4759_Enter-exit-initialization-mode.md)**  

-   **[RTC clock synchronization](AN4759_RTC-clock-synchro.md)**  


**Parent topic:**[Advanced RTC features](AN4759_Adv-RTC-features.md)

