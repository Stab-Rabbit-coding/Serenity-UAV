# Action on tamper detection event {#id_33228}

By setting TAMPTS = 1, any tamper event \(with edge or level detection\) causes a timestamp to occur. The timestamp and timestamp overflow flags are then set when the tamper flag is set and work in the same manner as when a normal timestamp event occurs.

**Note:** It is not necessary to enable or disable the timestamp function when using this feature.

Other actions than a timestamp can be triggered by a tamper detection depending on the product used. Refer to the product documentation for a complete list of actions.

For example, a tamper detection can:

-   Erase the backup registers, SRAMs content or specific peripheral registers
-   Generate an interrupt that can wake up the device from low-power modes
-   Generate an hardware trigger for a low-power timer or a RTC timestamp event \(see TAMPTS bit mentioned before\)

On some product, the protection of specific device assets can be enabled/disabled thanks to the ERCFGy bit in TAMP\_ERCFGR. If this bit is set, in case of a tamper detection or when BKBLOCK = 1 in TAMP\_CR2, the read/write accesses to the concerned device assets are blocked.

**Parent topic:**[RTC tamper detection function](AN4759_RTC-tamper-detection.md)

