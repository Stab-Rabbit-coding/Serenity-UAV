# RTC alarm configuration {#id_33184}

The RTC embeds two equivalent alarms: alarm A and alarm B. An alarm can be generated at a given time or/and date programmed by the user. The RTC provides a rich combination of alarm settings, and offers many features to make them easy to configure and display.

Each alarm unit provides the following features:

-   Fully programmable alarm: subsecond, second, minute, hour and date fields can be independently selected or masked to provide a rich combination of alarms.
-   The device can be wake up from low-power modes when the alarm occurs.
-   The alarm event can be routed to a specific output pin with configurable polarity.
-   Dedicated alarm flags and interrupt are available.

![](DT19528.svg "Alarm A fields")

The time configuration bitfields of the alarm configuration register are mapped into the same bit offsets as those on the RTC\_TR time register, for easier software manipulation. When the RTC time counter reaches the value programmed in the alarm register, a flag is set to indicate that an alarm event occurred \(ALRAF‑or‑ALRBF‑in‑RTC\_SR\).

The RTC alarm can be configured by hardware to generate different types of alarms. For more details, refer to [Table 1](AN4759_Configure-alarm-behavior-MSKx.md#table_m3k_czw_qpb).

-   **[Program the alarm](AN4759_Program-alarm.md)**  

-   **[Configure the alarm behavior using the MSKx bits](AN4759_Configure-alarm-behavior-MSKx.md)**  


**Parent topic:**[RTC alarms](AN4759_RTC-alarms.md)

