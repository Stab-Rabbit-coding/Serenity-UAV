# STM32CubeL0 firmware libraries {#id_33280}

The RTC comes with:

-   A firmware driver API abstracting RTC features for the end-user

    Refer to stm32l0xx\_hal\_rtc.c and stm32l0xx\_hal\_rtc\_ex.c files in \\STM32Cube\_FW\_L0\_Vx.y.z\\Drivers\\STM32L0xx\_HAL\_Driver\\

-   A set of example projects in \\STM32Cube\_FW\_L0\_Vx.y.z\\Projects\\STM32L053R8-Nucleo\\Examples\\RTC

**Parent topic:**[STM32L0 API and tampering detection application example](AN4759_STM32L0-API-tamper-detection.md)

