# Software setup {#id_33284}

Open the project under the user favorite IDE \(integrated development environment\). For IAR Embedded Workbench, open the project.eww file. For Keil MDK-ARM, open the project.uvprojx file, compile and launch the debug session. For SW4STM32, open the SW4STM32 toolchain, browse to the SW4STM32 workspace directory, select and import the project RTC\_Tamper.

Compile and launch the debug session. This loads the program in the internal Flash memory and executes it.

In IAR Embedded Workbench debug session, the user can view the calendar and tamper event timestamp \(time and date\) by opening a *Live watch* window \(View\\Live watch\) and observe the following global variables:

-   aShowTime
-   aShowDate
-   aShowTimeStampTime
-   aShowTimeStampDate

The user can add and follow these private variables with:

-   LED1\_Green\_Tamper\_event\_detected
-   LED2\_Red\_Power\_On\_Reset\_occurred
-   LED3\_Red\_Error
-   LED4\_Blue\_Reset\_occurred

The same observation can be done using MDK-ARM development tools. To open the *Watch1* window, do View\\Watch Windows\\Watch1.

**Parent topic:**[Tamper detection application example \(STM32L0\)](AN4759_tamper-detec-application-example-L0.md)

