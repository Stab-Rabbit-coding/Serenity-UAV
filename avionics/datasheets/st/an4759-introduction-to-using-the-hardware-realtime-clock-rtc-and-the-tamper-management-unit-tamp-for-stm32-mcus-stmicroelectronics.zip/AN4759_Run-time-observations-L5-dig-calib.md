# Run time observations {#id_33497}

The following steps are needed to check the correct functionality:

1.  Modify the 1 Hz reference clock \(for instance by forcing 1.0001 Hz\).
2.  Wait 2 x 32 s.
3.  Measure the output frequency. Depending on the accuracy of the generator and the measurement device used, the user can see around 1 ppm accuracy.

The user can also monitor in Debug mode:

-   CALP and CALM\[8:0\] in RTC\_CALR
-   TIM2\_CCR1 register \(contains the number of CLK\_RTC cycles within a 32 s window\)

**Parent topic:**[Smooth calibration application example \(STM32L5\)](AN4759_Digital-calib-application-example-L5.md)

