# X-CUBE-RTC for smooth calibration {#id_33273}

X-CUBE-RTC shows an implementation of the smooth digital calibration feature of the RTC \(using also the GPTIMER HAL API\).

In this example, the RTC\_CLK is smoothly calibrated based on an external 1 Hz reference \(STM32CubeExpansion\_AN4759\_RTC\_STM32L\_Vx.y.z\\Projects\\STM32L476RG\_Nucleo\\RTC\_SmoothCalib\).

The firmware implements:

-   A GPTIMER \(general-purpose timer\) in Master mode using channel 1 in output compare mode \(and using an external trigger clock\)
-   A GPTIMER in Master mode using channel 1 in input capture mode and channel 2 in output compare mode

    This timer is also configured to use the LSE clock thanks to the TIM option register.

-   The RTC with the CALR register programming
-   GPIOs to connect the input 1 Hz reference clock and the “corrected” RTC\_OUT\_CALIB clock

**Parent topic:**[STM32L4 API and smooth digital calibration application example](AN4759_STM32L4-API-digital-smooth-calibration.md)

