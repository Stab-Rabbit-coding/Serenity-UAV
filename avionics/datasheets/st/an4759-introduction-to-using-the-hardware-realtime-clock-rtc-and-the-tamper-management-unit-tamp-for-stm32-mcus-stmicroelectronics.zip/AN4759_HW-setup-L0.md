# Hardware setup {#id_33283}

In order to use the application example project, the user needs a STM32L053R8 Nucleo board \(NUCLEO-L053R8\).

![](DT41076.svg "NUCLEO-L053R8 board")

Supply the board using the USB cable. In this example, the B1 push button is used to simulate the external tamper event. The user can observe the software "private variables" on LED LD2 and CN5 pin 6 \(SCK/D13\). Details regarding the LED LD2 behavior are available in main.c file.

![](DT41079.svg "LED LD2 behavior")

**Parent topic:**[Tamper detection application example \(STM32L0\)](AN4759_tamper-detec-application-example-L0.md)

