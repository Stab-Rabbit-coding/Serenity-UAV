# Periodic timebase/wakeup configuration for clock configuration 3 {#id_33200}

For this configuration, the resolution is the same as for configuration 2. However, the timebase/wakeup counter down counts starting from 0x1FFFF to 0x00000 \(instead of 0xFFFF to 0x0000 for configuration 2\).

If ck\_spre is adjusted to 1 Hz, then:

-   The minimum timebase/wakeup period is \(0x10000 + 1\) x 1 s = 65537 s \(18 hours + 1 s\).
-   The maximum timebase/wakeup period is \(0x1FFFF+ 1\) x 1 s = 131072 s \(36 hours\).

**Note:** In binary or mixed modes, ck\_spre is replaced by the clock used to update the calendar \(as defined by BCDU bits in RTC\_ICSR\). See [Binary and mixed modes \(RTC3 only\)](AN4759_Binary-mixed-modesRTC3.md) for more details on BCDU\).

**Parent topic:**[Maximum and minimum RTC wakeup period](AN4759_Max-min-RTC-wakup-period.md)

