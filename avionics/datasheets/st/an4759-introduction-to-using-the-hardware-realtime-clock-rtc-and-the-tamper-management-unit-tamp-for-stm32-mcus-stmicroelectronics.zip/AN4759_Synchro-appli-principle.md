# Synchronization application principle {#id_33505}

This application is based on the following steps:

1.  TIM1 is configured and launched to generate an interruption each second \(APB2 timer clock = 100 MHz\).
2.  RTC is configured and launched including its calendar \(RTC clock = LSE\).
3.  The 1-second period counted by the TIM1 interruptions allows a more precise time base than with RTC \(the external HSE bypass signal must be more precise than LSE\).
4.  With this time base and thanks to the subsecond register, the advance/delay of the RTC clock can be analysed on the TIM1 1-second period.
5.  With the SHIFTR register, this advance or delay is compensated.

The synchronization is continuous.

**Parent topic:**[Synchronization application example \(STM32L5\)](AN4759_Synchro-application-example-L5.md)

