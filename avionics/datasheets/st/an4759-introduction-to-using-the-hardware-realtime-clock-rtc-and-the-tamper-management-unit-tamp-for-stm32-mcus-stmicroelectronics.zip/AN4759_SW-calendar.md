# Software calendar {#id_33175}

A software calendar is a software counter \(usually 32-bit long\) that represents the number of seconds. The software routines convert the counter value to hours, minutes, day of the month, day of the week, month and year. This data can be converted to BCD format and displayed on a standard LCD. Conversion routines use a significant program memory space and are CPU-time consuming, that may be critical in certain real-time applications.

**Parent topic:**[RTC calendar](AN4759_RTC-calendar.md)

