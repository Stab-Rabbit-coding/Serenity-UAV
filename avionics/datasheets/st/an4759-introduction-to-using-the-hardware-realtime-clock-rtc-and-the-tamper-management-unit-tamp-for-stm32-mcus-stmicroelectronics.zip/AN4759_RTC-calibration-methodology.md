# RTC calibration methodology {#id_33208}

The RTC clock frequency can be corrected using a series of small adjustments by adding or subtracting individual ck\_cal \(smooth calibration clock\) pulses.

For RTC2 type, ck\_cal is always RTCCLK.

For RTC3 type, if LPCAL = 0 in RTC\_CALR, ck\_cal = RTCCLK. If LPCAL = 1, ck\_cal = ck\_apre \(clock output by the RTC asynchronous prescaler\). Moreover, when setting LPCAL to 1 and choosing ck\_apre, the calibration consumption decreases, its accuracy remains the same and the calibration window changes to about 220 x PREDIV\_A x RTCCLK pulses \(instead of 220 RTCCLK pulses when LPCAL = 0\).

The RTC clock can be calibrated with a resolution of about 0.954 ppm with a range from -487.1 ppm to +488.5 ppm.

This smooth digital calibration is designed to compensate the inaccuracy of crystal oscillators \(due to temperature or crystal aging\).

![](DT30112.svg "Smooth calibration block for RTC2 type")

![](DT63430.svg "Smooth calibration block for RTC3 type (LPCAL = 1)")

The user can compute the clock deviation using the RTC\_CALIB signal, then update the calibration block. It is also possible to input an external 1 Hz reference and make the adequate processing inside the MCU to correct the RTC clock. The user finds such example in [STM32L4 API and smooth digital calibration application example](AN4759_STM32L4-API-digital-smooth-calibration.md) and in [STM32L5 API and smooth digital calibration application example](AN4759_STM32L5-API-dig-smooth-calib.md).

The calibration result can be checked by using the calibration output 512 Hz or 1 Hz for the RTC\_CALIB signal. Refer to [Table 1](AN4759_Adv-RTC-features.md#table_clz_c42_rpb) and [AN4759\_Adv-RTC-features.md\#table\_hqc\_shf\_rpb](AN4759_Adv-RTC-features.md#table_hqc_shf_rpb).

A smooth calibration consists of masking and adding N \(configurable\) 32 kHz-frequency pulses that are well distributed in a configurable window \(8 s, 16 s or 32 s\).

The number of masked or added pulses is defined using CALP and CALM\[8:0\] in RTC\_CALR register.

By default, when the input frequency is 32768 Hz, the calibration window duration is 32 seconds \(considering LPCAL = 0 for RTC3\). It can be reduced to 8 or 16 seconds by setting CALW8 or CALW16 in RTC\_CALR.

**Note:** The 0.954 ppm accuracy of the smooth calibration is only achievable by 32 s calibration window, for 16 s, the best accuracy is \(0.954 x 2\), and for 8 s is \(0.954 x 4\).

## Example 1 { .section}

Setting CALM\[0\] = 1, CALP = 0 and using 32 s calibration window, results in exactly one pulse being masked for 32 s.

## Example 2 { .section}

Setting CALM\[2\] = 1, CALP = 0 and using 32 s calibration window, results in exactly four pulses being masked for 32 s.

**Note:** Both CALM\[8:0\] and CALP can be used. In this case, an offset ranging from -511 to +512 pulses can be added for 32 s \(calibration window\).

When the asynchronous prescaler is less than 3, CALP cannot be set to 1.

The formula to calculate the effective calibrated frequency \(FCAL\), given the input frequency FRTCCLK, is:

FCAL = FRTCCLK x \[1 + \(CALP x 512 - CALM\) / \(220 + CALM - CALP x 512\)\]

A smooth calibration can be performed on-the-fly, changed when the temperature changes or if other factors are detected.

## Check the smooth calibration { .section}

The smooth calibration effect on the calendar clock \(RTC clock\) can be checked by calibration using one of the following:

-   RTC\_CALIB output \(1 Hz\)
-   Subsecond alarms
-   Wake-up timer

**Parent topic:**[Smooth digital calibration](AN4759_Smooth-dig-calibration.md)

