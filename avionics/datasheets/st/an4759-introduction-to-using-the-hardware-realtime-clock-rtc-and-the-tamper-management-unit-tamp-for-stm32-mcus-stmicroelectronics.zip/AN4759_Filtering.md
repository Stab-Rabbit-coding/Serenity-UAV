# Filtering {#id_33231}

As for passive tamper detections \(not active ones\), the input can be filtered by setting FLTEN = 1. With this action, a tamper event is triggered when two comparisons among four are false \(received message different from the sent one\).

**Parent topic:**[Active tamper detection \(RTC3 only\)](AN4759_Active-tamper-detectionRTC3.md)

