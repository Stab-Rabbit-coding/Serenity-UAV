# Hardware setup {#id_33275}

In order to use the application example project, the user needs a STM32L476RG Nucleo board \(NUCLEO‑L476RG\).

![](DT42055.svg "NUCLEO-L476RG board")

Supply the board using the USB cable and perform the following actions:

-   Connect PD2 to a signal generator driving 1 Hz clock with 3.3 V amplitude. It is advised to control the generated frequency at few ppm.
-   Connect PB2 to an oscilloscope \(the accuracy of the frequency measurement is ideally in the range of 1 ppm\).

**Parent topic:**[Smooth calibration application example \(STM32L4\)](AN4759_Digital-calib-application-example-L4.md)

