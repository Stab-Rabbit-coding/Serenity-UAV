# Configure the alarm behavior using the MSKx bits {#id_33186}

The alarm behavior can be configured using the MSKx bits \(x = 1, 2, 3, 4\) of RTC\_ALRMAR for alarm A \(RTC\_ALRMBR for alarm B\). The table below shows all possible alarm settings.

**Table 1. Alarm combinations**

<table>
<thead>
<tr>
<th>MSK4</th>
<th>MSK3</th>
<th>MSK2</th>
<th>MSK1</th>
<th>Alarm behavior</th>
</tr>
</thead>
<tbody>
<tr>
<td>0</td>
<td>0</td>
<td>0</td>
<td>0</td>
<td>All fields are used in the alarm comparison.<p>Example: the alarm occurs at 23:15:07, each Monday.</p></td>
</tr>
<tr>
<td>0</td>
<td>0</td>
<td>0</td>
<td>1</td>
<td>Seconds do not matter in the alarm comparison.<p>Example: the alarm occurs every second of 23:15, each Monday.</p></td>
</tr>
<tr>
<td>0</td>
<td>0</td>
<td>1</td>
<td>0</td>
<td>Minutes do not matter in the alarm comparison.<p>Example: the alarm occurs at the 7th second of every minute of 23:XX, each Monday.</p></td>
</tr>
<tr>
<td>0</td>
<td>0</td>
<td>1</td>
<td>1</td>
<td>Minutes and seconds do not matter in the alarm comparison.</td>
</tr>
<tr>
<td>0</td>
<td>1</td>
<td>0</td>
<td>0</td>
<td>Hours do not matter in the alarm comparison.</td>
</tr>
<tr>
<td>0</td>
<td>1</td>
<td>0</td>
<td>1</td>
<td>Hours and seconds do not matter in the alarm comparison.</td>
</tr>
<tr>
<td>0</td>
<td>1</td>
<td>1</td>
<td>0</td>
<td>Hours and minutes do not matter in the alarm comparison.</td>
</tr>
<tr>
<td>0</td>
<td>1</td>
<td>1</td>
<td>1</td>
<td>Hours, minutes and seconds do not matter in the alarm comparison.<p>Example: the alarm is set every second, each Monday, during the whole day.</p></td>
</tr>
<tr>
<td>1</td>
<td>0</td>
<td>0</td>
<td>0</td>
<td>Week day (or date, if selected) do not matter in the alarm comparison.<p>Example: the alarm occurs all the days at 23:15:07.</p></td>
</tr>
<tr>
<td>1</td>
<td>0</td>
<td>0</td>
<td>1</td>
<td>Week day and seconds do not matter in the alarm comparison.</td>
</tr>
<tr>
<td>1</td>
<td>0</td>
<td>1</td>
<td>0</td>
<td>Week day and minutes do not matter in the alarm comparison.</td>
</tr>
<tr>
<td>1</td>
<td>0</td>
<td>1</td>
<td>1</td>
<td>Week day, minutes and seconds do not matter in the alarm comparison.</td>
</tr>
<tr>
<td>1</td>
<td>1</td>
<td>0</td>
<td>0</td>
<td>Week day and hours do not matter in the alarm comparison.</td>
</tr>
<tr>
<td>1</td>
<td>1</td>
<td>0</td>
<td>1</td>
<td>Week day, hours and seconds do not matter in the alarm comparison.</td>
</tr>
<tr>
<td>1</td>
<td>1</td>
<td>1</td>
<td>0</td>
<td>Week day, hours and minutes do not matter in the alarm comparison.</td>
</tr>
<tr>
<td>1</td>
<td>1</td>
<td>1</td>
<td>1</td>
<td>The alarm occurs every second.</td>
</tr>
</tbody>
</table>

## Example { .section}

To configure the alarm time to 23:15:07 on Monday assuming WDSEL = 1, configure all MSKx to zero with DU\[3:0\] = 0001 \(Monday\), HT\[1:0\] = 10, HU\[3:0\] = 0011, MNT\[2:0\] = 001, MNU\[3:0\] = 0101, ST\[2:0\] = 000, SU\[3:0\] = 0111 \(23:15:07\), PM = 0 \(24h format\) in RTC\_ALRMAR \(resp. RTC\_ALRMBR\) .

When WDSEL = 0, an alarm occurs on the day number specified in DT and DU bitfields in RTC\_ALRMxR, instead of the day of the week. To get this alarm once a month at 23:15:07, on the 14th day, RTC\_ALRMxR bitfields must be set as follows: all MSKx = 0, WDSEL = 0, DT\[1:0\] = 01, DU\[3:0\] = 0100, HT\[1:0\] = 10, HU\[3:0\] = 0011, MNT\[2:0\] = 001, MNU\[3:0\] = 0101, ST\[2:0\] = 000, SU\[3:0\] = 0111, PM = 0.

CAUTION:

If the second field is selected \(MSK1 reset in RTC\_ALRMAR or RTC\_ALRMBR\), the synchronous prescaler division factor PREDIV\_S\[14:0\] \(set in RTC\_PRER\) must be at least 3 to ensure a correct behavior.

**Parent topic:**[RTC alarm configuration](AN4759_RTC-alarm-config.md)

