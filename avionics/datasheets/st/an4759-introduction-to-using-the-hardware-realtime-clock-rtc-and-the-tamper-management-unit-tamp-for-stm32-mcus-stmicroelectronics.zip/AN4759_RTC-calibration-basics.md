# RTC calibration basics {#id_33205}

The “quartz-accurate” term describes the accuracy of many time-keeping functions. The quartz oscillators provide a far superior accuracy versus other conventional oscillator designs, but they are not perfect, as the quartz crystals are sensitive to temperature variations. [Figure 1](#fig_dv4_vym_5pb) shows the relationship between accuracy \(acc\), temperature \(T\) and curvature \(K\) for a typical 32.768 kHz crystal, following the general formula:

<math id="math_wfr_l3x_qpb" display="inline"><mrow><mi>a</mi><mi>c</mi><mi>c</mi><mo>⁢</mo><mo>=</mo><mtext> </mtext><mi>K</mi><mo>×</mo><msup><mrow><mo>(</mo><mi>T</mi><mo>−</mo><msub><mrow><mi>T</mi></mrow><mrow><mn>0</mn></mrow></msub><mo>)</mo></mrow><mrow><mn>2</mn></mrow></msup></mrow></math>

where To = 25 °C ± 5 °C and K = –0.032 ppm/°C2.

**Note:** The K variable is crystal-dependent. The value indicated here is for the crystal mounted on the STM32L476RG-Nucleo board. Refer to the crystal manufacturer for more details on this parameter.

The clocks used in most applications require a high degree of accuracy, and there are several factors involved in achieving this accuracy.

Two major approaches exist to compensate an oscillation frequency deviation of an oscillator when the generated signal is used to clock a time-keeping logic:

-   Analog approach

    The oscillator is built with embedded capacitor banks on both input and output of the oscillator. To adjust the oscillation frequency, the software needs to configure the oscillator to switch on or off some of the embedded load capacitors to adjust the overall load capacitance seen by the crystal resonator.

    Note that the two external load capacitors are always needed even with this kind of oscillators. The two external load capacitors make the dominant part of the load capacitance of the crystal resonator. The oscillator embedded capacitor banks are only intended to compensate for the capacitance value dispersion of the two external load capacitors; or to compensate for the temperature variation. This approach suffers from most of drawbacks that generally analog circuits suffer from, such as relatively important value dispersion from one chip to another.

-   Digital approach

    The oscillation frequency deviation is not compensated at oscillator level. The compensation is made at time-keeping logic/function level. The time-keeping logic either adds or removes few clock cycles to/from the deviating clock signal that feeds its counter. The main advantage of this approach is the deterministic compensation effect from one device to another. This approach is adopted to compensate the LSE oscillation frequency deviation when LSE is used to clock the RTC. The RTC is built with a dedicated register to configure the number of clock cycles to add or remove from the feeding clock signal.


![](DT69135.svg "Typical crystal accuracy plotted against temperature")

**Parent topic:**[Smooth digital calibration](AN4759_Smooth-dig-calibration.md)

