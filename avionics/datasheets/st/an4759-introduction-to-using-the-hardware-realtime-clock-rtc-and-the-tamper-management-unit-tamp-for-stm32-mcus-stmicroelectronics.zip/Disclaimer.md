# Disclaimer {#disclaimer_public .reference}

<table>
<tbody>
<tr>
<td colspan="1"> </td>
</tr>
<tr>
<td colspan="1"> </td>
</tr>
<tr>
<td colspan="1"><p><strong>IMPORTANT NOTICE – READ CAREFULLY</strong></p></td>
</tr>
<tr>
<td colspan="1">STMicroelectronics NV and its subsidiaries (“ST”) reserve the right to make changes, corrections, enhancements, modifications, and improvements to ST products and/or to this document at any time without notice.</td>
</tr>
<tr>
<td colspan="1">In the event of any conflict between the provisions of this document and the provisions of any contractual arrangement in force between the purchasers and ST, the provisions of such contractual arrangement shall prevail.</td>
</tr>
<tr>
<td colspan="1">The purchasers should obtain the latest relevant information on ST products before placing orders. ST products are sold pursuant to ST’s terms and conditions of sale in place at the time of order acknowledgment.</td>
</tr>
<tr>
<td colspan="1">The purchasers are solely responsible for the choice, selection, and use of ST products and ST assumes no liability for application assistance or the design of the purchasers’ products.</td>
</tr>
<tr>
<td colspan="1">No license, express or implied, to any intellectual property right is granted by ST herein.</td>
</tr>
<tr>
<td colspan="1">Resale of ST products with provisions different from the information set forth herein shall void any warranty granted by ST for such product.</td>
</tr>
<tr>
<td colspan="1">If the purchasers identify an ST product that meets their functional and performance requirements but that is not designated for the purchasers' market segment, the purchasers shall contact ST for more information.</td>
</tr>
<tr>
<td colspan="1">ST and the ST logo are trademarks of ST. For additional information about ST trademarks, refer to <a href="http://www.st.com/trademarks">www.st.com/trademarks</a>. All other product or service names are the property of their respective owners.</td>
</tr>
<tr>
<td colspan="1">Information in this document supersedes and replaces information previously supplied in any prior versions of this document.</td>
</tr>
<tr>
<td colspan="1">© 2026 STMicroelectronics – All rights reserved</td>
</tr>
</tbody>
</table>

