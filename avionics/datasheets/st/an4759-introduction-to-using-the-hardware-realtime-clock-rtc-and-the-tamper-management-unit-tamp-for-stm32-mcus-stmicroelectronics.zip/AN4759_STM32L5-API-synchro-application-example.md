# STM32L5 API and synchronization application example {#id_33498}

STM32CubeL5 firmware libraries are the same as in [STM32CubeL5 firmware libraries for smooth calibration application](AN4759_STM32CubeL5-FW-libraries.md).

-   **[X-CUBE-RTC for synchronization application](AN4759_X-CUBE-RTC-L5-synchro.md)**  

-   **[Synchronization application example \(STM32L5\)](AN4759_Synchro-application-example-L5.md)**  


