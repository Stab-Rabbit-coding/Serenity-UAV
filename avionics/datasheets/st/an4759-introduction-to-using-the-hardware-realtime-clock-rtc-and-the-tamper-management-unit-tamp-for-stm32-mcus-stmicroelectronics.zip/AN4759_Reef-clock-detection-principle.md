# Reference clock detection principle {#id_33514}

This application performs the following steps:

1.  TIM1 is configured and launched to generate an interruption each second \(APB2 timer clock = 100 MHz\).
2.  RTC is configured and launched including its calendar and reference clock detection feature \(RTC clock = LSE\).
3.  When the 50/60 Hz signal is available on PB15, the RTC automatically aligns the rising edges of this reference clock with the ones of the output of the synchronous RTC prescaler \(1 Hz clock\). Thus, the RTC 1 Hz clock is synchronized with the signal provided by the user.
4.  The 1-second period counted by the TIM1 interruptions allows the measure of the RTC period. The HSI \(TIM1 clock source\) is less precise than the LSE \(RTC clock source\). The LSE is synchronized with an even more precised reference clock by the way. Thus, this measure is made for testing the application.

The reference clock detection and synchronization are continuous. If the reference is lost, the RTC is still clocked by LSE.

**Parent topic:**[Reference clock detection application example](AN4759_Ref-clock-detection.md)

