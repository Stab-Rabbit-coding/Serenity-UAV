# Tamper detection application example \(STM32L4\) {#id_33264}

-   **[Hardware setup](AN4759_HW-setup-L4-tamp-detec.md)**  

-   **[Software setup](AN4759_SW-setup-L4-tamp-detec.md)**  

-   **[LED meaning](AN4759_LED-meaning-L4-tamper-detec.md)**  

-   **[Tamper detection during normal operation](AN4759_Tamper-detection-normal-operation-L4.md)**  

-   **[Tamper detection when main power supply is off](AN4759_Tamper-detection-power-supply-off-L4.md)**  


**Parent topic:**[STM32L4 API and tamper detection application example](AN4759_STM32L4-API-tamper-detection-example.md)

