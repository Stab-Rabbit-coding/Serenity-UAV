# RTC hardware calendar {#id_33176}

When using the RTC calendar, the software conversion routines are no longer needed because their functions are performed by hardware.

The STM32 RTC calendar is provided in BCD format. This avoids binary to BCD software conversion routines, that save system resources.

![](DT62044.svg "Example of calendar displayed on an LCD")

**Parent topic:**[RTC calendar](AN4759_RTC-calendar.md)

