# STM32L4 API and tamper detection application example {#id_33261}

-   **[STM32CubeL4 firmware libraries for tamper detection](AN4759_STM32CubeL4-FW-lib-tamper-detection.md)**  

-   **[X-CUBE-RTC for tamper detection](AN4759_X-CUBE-RTC-L4-tamper-detection.md)**  

-   **[Tamper detection application example \(STM32L4\)](AN4759_Tamper-detection-application-example-L4.md)**  


