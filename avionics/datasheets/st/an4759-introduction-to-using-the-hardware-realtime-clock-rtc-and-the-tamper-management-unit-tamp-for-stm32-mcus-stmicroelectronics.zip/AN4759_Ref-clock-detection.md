# Reference clock detection application example {#id_33512}

-   **[Hardware setup](AN4759_HW-setup-L5-ref-clock-detection.md)**  

-   **[Software setup](AN4759_SW-setup-L5-ref-clock-detection.md)**  

-   **[Reference clock detection principle](AN4759_Reef-clock-detection-principle.md)**  

-   **[Run time observations](AN4759_Run-time-observations-L5-ref-clock-detection.md)**  


**Parent topic:**[STM32L5 API and reference clock detection application example](AN4759_STM32L5-API-ref-clock-detection.md)

