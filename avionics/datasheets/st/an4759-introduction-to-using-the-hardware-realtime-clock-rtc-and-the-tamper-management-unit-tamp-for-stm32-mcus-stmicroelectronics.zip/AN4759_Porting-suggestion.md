# Porting suggestions {#id_37119}

The software example expects that the TIM2 is more than 20 bit, 32 bit in case of L476RB. With products featuring only 16-bit timers it is recommended to keep track of 16-bit timer overflows using the software and perform the calibration with 16-th overflow to compensate for the missing 4 bits.

**Parent topic:**[Smooth calibration application example \(STM32L4\)](AN4759_Digital-calib-application-example-L4.md)

