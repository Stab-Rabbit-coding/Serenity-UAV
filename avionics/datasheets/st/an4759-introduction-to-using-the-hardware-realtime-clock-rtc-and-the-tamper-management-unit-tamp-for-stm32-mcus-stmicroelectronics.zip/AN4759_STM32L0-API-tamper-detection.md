# STM32L0 API and tampering detection application example {#id_33279}

-   **[STM32CubeL0 firmware libraries](AN4759_STM32CubeL0-FW-lib.md)**  

-   **[X-CUBE-RTC for tamper detection](AN4759_X-CUBE-RTC-L0.md)**  

-   **[Tamper detection application example \(STM32L0\)](AN4759_tamper-detec-application-example-L0.md)**  


