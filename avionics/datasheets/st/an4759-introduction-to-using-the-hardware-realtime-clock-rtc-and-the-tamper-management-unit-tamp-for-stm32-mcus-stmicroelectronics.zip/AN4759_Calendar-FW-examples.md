# Calendar firmware examples {#id_33181}

The RTC comes with a set of example projects so that the user can quickly become familiar with this peripheral. Refer to the X-CUBE-RTC Expansion Package for a complete projects list.

For example, the user can find the following projects concerning calendar:

-   For the NUCLEO-L412RB-P equipped with an RTC3:
    -   STM32Cube\_FW\_L4\_Vx.y.z\\Projects\\NUCLEO-L412RB-P\\Examples\\RTC\\RTC\_Calendar
    -   STM32Cube\_FW\_L4\_Vx.y.z\\Projects\\NUCLEO-L412RB-P\\Examples\_LL\\RTC\\RTC\_Calendar
-   For the P-NUCLEO-WB55 equipped with an RTC2:
    -   STM32Cube\_FW\_WB\_Vx.y.z\\Projects\\P‑NUCLEO‑WB55.Nucleo\\ Examples\_LL\\RTC\\RTC\_Calendar\_Init

If one example is not available in the X-CUBE-RTC for a given STM32 MCU, the user can adapt it.

**Parent topic:**[RTC calendar](AN4759_RTC-calendar.md)

