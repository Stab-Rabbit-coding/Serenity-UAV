# Maximum and minimum RTC wakeup period {#id_33193}

The wakeup unit clock is configured through WUCKSEL\[2:0\] in RTC\_CR. Three different configurations are possible:

-   Configuration 1: WUCKSEL\[2:0\] = 0xx for short wakeup periods \(see [Periodic timebase/wakeup configuration for clock configuration 1](AN4759_Periodic-wkup-config1.md)\)
-   Configuration 2: WUCKSEL\[2:0\] = 10x for medium wakeup periods \(see [Periodic timebase/wakeup configuration for clock configuration 2](AN4759_Periodic-wkup-config2.md)\)
-   Configuration 3: WUCKSEL\[2:0\] = 11x for long wakeup periods \(see [Periodic timebase/wakeup configuration for clock configuration 3](AN4759_Periodic-wkup-config3.md)\)

-   **[Periodic timebase/wakeup configuration for clock configuration 1](AN4759_Periodic-wkup-config1.md)**  

-   **[Periodic timebase/wakeup configuration for clock configuration 2](AN4759_Periodic-wkup-config2.md)**  

-   **[Periodic timebase/wakeup configuration for clock configuration 3](AN4759_Periodic-wkup-config3.md)**  

-   **[Summary of timebase/wakeup period extrema](AN4759_Summary-wkup-period-extrema.md)**  


**Parent topic:**[RTC periodic wakeup unit](AN4759_RTC-periodic-wakeup.md)

