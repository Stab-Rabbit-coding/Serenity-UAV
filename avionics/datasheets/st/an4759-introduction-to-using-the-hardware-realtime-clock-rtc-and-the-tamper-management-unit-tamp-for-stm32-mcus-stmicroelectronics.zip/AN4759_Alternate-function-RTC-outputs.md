# Alternate function RTC outputs {#id_33244}

The RTC has two outputs:

-   RTC\_CALIB \(RTC2\)/CALIB \(RTC3\), used to generate an external clock
-   RTC\_ALARM \(RTC2\)/TAMPALARM \(RTC3\), unique output resulting from the multiplexing of the RTC alarm and wakeup events \(and also tamper detection events for RTC3 type\)

For RTC3 type, these outputs can be associated to two pins against one pin for RTC2 type. Refer to OUT2EN in RTC\_CR of RTC3 type to choose which function is output on which pin.

-   **[RTC\_CALIB output](AN4759_RTC-CALIB-output.md)**  

-   **[RTC\_ALARM \(RTC2\)/TAMPALRM \(RTC3\) output](AN4759_RTC-ALARM-TAMPALRM-output.md)**  


**Parent topic:**[Advanced RTC features](AN4759_Adv-RTC-features.md)

