# RTC periodic wakeup unit {#id_33189}

The STM32 MCUs provide several low-power modes to reduce the power consumption. The RTC features a periodic timebase and a wakeup unit that is able to wake up the system from low-power modes. This unit is a programmable down-counting auto-reload timer. When this counter reaches zero, a flag and an interrupt \(if enabled\) are generated.

The wakeup unit has the following features:

-   Programmable down-counting auto-reload timer
-   Specific flag and interrupt capable of waking up the device from low-power modes
-   Wakeup alternate function output that can be routed to the RTC\_ALARM output for RTC2 and the TAMPALRM output for RTC3 \(unique pad for alarm A, alarm B or wakeup events\) with configurable polarity
-   Full set of prescalers to select the desired waiting period

-   **[Program the auto-wakeup unit](AN4759_Program-auto-wkup.md)**  

-   **[Maximum and minimum RTC wakeup period](AN4759_Max-min-RTC-wakup-period.md)**  

-   **[Wakeup firmware examples](AN4759_Wakeup-FW-examples.md)**  


**Parent topic:**[Advanced RTC features](AN4759_Adv-RTC-features.md)

