# Edge detection on tamper input {#id_33219}

When TAMPFLT\[1:0\] = 00, the tamper input detection triggers when a rising edge or a falling edge \(depending on TAMPxTRG\) is observed on the input pin RTC\_TAMPx \(RTC2\)/TAMP\_INx \(RTC3\).

![](DT30113.svg "Tamper with edge detection")

**Note:** With the edge detection, the sampling and precharge features are deactivated.

**Table 1. Tamper features (edge detection)**

<table>
<thead>
<tr>
<th>What</th>
<th>How</th>
<th>Comment</th>
</tr>
</thead>
<tbody>
<tr>
<td>Enable tamper.</td>
<td>Set TAMPxE = 1 in RTC_TAMPCR (RTC2)/TAMP_CR1 (RTC3).</td>
<td>-</td>
</tr>
<tr>
<td>Select tamper active edge detection.</td>
<td>Select with TAMPxTRG in RTC_TAMPCR (RTC2)/TAMP_CR2 (RTC3).</td>
<td>The default edge is rising edge.</td>
</tr>
<tr>
<td>Detect a tamper event by interrupt.</td>
<td>Set TAMPIE or TAMPxIE in RTC_TAMPCR (RTC2)/TAMP_IER (RTC3) register</td>
<td>An interrupt is generated when a tamper detection event occurs.</td>
</tr>
<tr>
<td>Detect a tamper event by polling.</td>
<td>Poll TAMPxF in the RTC_ISR (RTC2)/TAMP_SR (RTC3).</td>
<td>RTC2: To clear the flag, write zero in TAMPxF.<p>RTC3: Write 1 in CTAMPxF in TAMP_SCR clears TAMPxF in TAMP_SR.</p></td>
</tr>
</tbody>
</table>

**Parent topic:**[RTC tamper detection function](AN4759_RTC-tamper-detection.md)

