# Summary of timebase/wakeup period extrema {#id_33201}

When RTCCLK= 32768 Hz and ck\_spre \(synchronous prescaler output clock\) is adjusted to 1 Hz, the minimum and maximum period values are listed in the table below.

**Table 1. Min. and max. timebase/wakeup period when RTCCLK= 32768**

|Configuration|Minimum period|Maximum period|
|:-----------:|:------------:|:------------:|
|1|122.07 µs|32 s|
|2|1 s|18 hours|
|3|18 hours +1 s|36 hours|

**Parent topic:**[Maximum and minimum RTC wakeup period](AN4759_Max-min-RTC-wakup-period.md)

