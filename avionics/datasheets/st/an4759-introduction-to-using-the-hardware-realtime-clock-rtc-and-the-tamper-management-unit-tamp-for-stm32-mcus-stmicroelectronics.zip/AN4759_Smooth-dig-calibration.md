# Smooth digital calibration {#id_33204}

-   **[RTC calibration basics](AN4759_RTC-calibration-basics.md)**  

-   **[RTC calibration methodology](AN4759_RTC-calibration-methodology.md)**  


**Parent topic:**[Advanced RTC features](AN4759_Adv-RTC-features.md)

