# RTC tamper detection function {#id_33220}

The RTC includes several tamper detection inputs. The tamper inputs can be configured to detect different types of tamper events. Each tamper input has an individual flag \(TAMPxF in RTC\_ISR \(RTC2\)/TAMP\_SR \(RTC3\)\).

A tamper detection event generates an interrupt when TAMPIE or TAMPxIE is set in RTC\_TAMPCR \(RTC2\)/TAMP\_IER \(RTC3\).

The configuration of the tamper filter, TAMPFLT\[1:0\] in TAMP\_FLTCR, defines whether the tamper detection is activated on edge \(set TAMPFLT\[1:0\] = 00\), or on level \(TAMPFLT\[1:0\] ≠ 00\).

The number of tamper inputs depends on product packages. Each input has a TAMPxF individual flag in RTC\_ISR \(RTC2\)/TAMP\_SR \(RTC3\).

The DBP bit \(the register associated depends on the product\), must be set to allow write access to any TAMP registers after a system reset.

-   **[Edge detection on tamper input](AN4759_Edge-detection-tamper-input.md)**  

-   **[Level detection on tamper input](AN4759_Level-detection-tamper-input.md)**  

-   **[Action on tamper detection event](AN4759_Action-tamper-detection-event.md)**  

-   **[Active tamper detection \(RTC3 only\)](AN4759_Active-tamper-detectionRTC3.md)**  

-   **[Internal tamper detection \(RTC3 only\)](AN4759_Internal-tamper-detectionRTC3.md)**  

-   **[Potential detection management \(RTC3 only\)](AN4759_Potential-detection-magtRTC3.md)**  

-   **[Tamper detection firmware examples](AN4759_Tamper-detection-FW-examples.md)**  


**Parent topic:**[Advanced RTC features](AN4759_Adv-RTC-features.md)

