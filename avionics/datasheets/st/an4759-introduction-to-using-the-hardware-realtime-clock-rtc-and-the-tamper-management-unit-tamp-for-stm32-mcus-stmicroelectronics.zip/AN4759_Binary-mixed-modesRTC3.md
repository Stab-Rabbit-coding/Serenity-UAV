# Binary and mixed modes \(RTC3 only\) {#id_33182}

For the RTC3 type, a binary mode is available. In this mode, the time and date BCD calendar are disabled but the RTC sub‑second register \(SSR\) is extended to 32 bits \(16 bits in normal mode\) and is used as a binary down-counter.

Thanks to this feature, a 32-bit counter is available in low-power mode \(modes compatibilities are the same than for the other RTC features\) and a BCD-to-binary conversion is no more needed \(when required by an application\).

The binary mode implementation is simple:

1.  Initialization: Set INIT = 1 in RTC\_ICSR and wait for INITF to be set.
2.  Define the asynchronous prescaler value in RTC\_PRER to clock the binary counter.
3.  Set BIN\[1:0\] = 01 in RTC\_ICSR: the RTC\_SSR register is initialized to 0xFFFF FFFF.
4.  After exiting initialization \(INIT bit cleared\), the counter start to count down from the RTC\_SSR initial value.
5.  The counter is clocked by the RTC asynchronous prescaler output. When it reaches 0, it is reloaded with 0xFFFF FFFF.

In binary mode, the RTC\_ALRABINR register is used to program the subsecond field of the alarm.

The mixed mode \(also offered by RTC3 type\) allows both the 32-bit binary down-counter and the BCD calendar. In this mode, the user can choose when the calendar is incremented by 1 second with BCDU\[2:0\] in RTC\_ICSR. These bits code how many least significant bits from SSR \(subsecond register\) need to be at 0 for the calendar to be incremented by 1 second.

A shadow register exists for RTC\_SSR. It can be bypassed when BYPSHAD = 1 in RTC\_CR. See [RTC clock synchronization](AN4759_RTC-clock-synchro.md) for more details on BYPSHAD use and associated cautions to take.

**Parent topic:**[Advanced RTC features](AN4759_Adv-RTC-features.md)

