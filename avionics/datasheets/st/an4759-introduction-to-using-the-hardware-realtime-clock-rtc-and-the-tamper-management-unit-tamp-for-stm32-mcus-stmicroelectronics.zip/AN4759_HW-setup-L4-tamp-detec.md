# Hardware setup {#id_33265}

In order to use the application example project, the user needs a STM32L476G evaluation board \(STM32L476G‑EVAL\).

![](DT44206.svg "STM32L476G-EVAL board")

Supply the board using the USB cable and tie PA0 \(tamper pin 2\) to 0, with the following actions:

-   Remove the jumper JP7.
-   Connect the CN7 pin 37 to GND.

**Note:** PC13 \(tamper pin 1\) connected to the blue push-button is not used in this demonstration firmware as it is connected to an external pull-down resistor preventing the use of the tamper detection on level with internal pull-up \(the lowest consumption mode\).

For more information, refer to the user manual *Evaluation board with STM32L476ZGT6 MCU* \(UM1855\).

**Parent topic:**[Tamper detection application example \(STM32L4\)](AN4759_Tamper-detection-application-example-L4.md)

