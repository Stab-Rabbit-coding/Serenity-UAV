# RTC clock synchronization {#id_33252}

When the application reads the calendar, it accesses shadow registers that contain a copy of the real calendar time and date clocked by the RTC clock \(RTCCLK\). There is a shadow register associated to RTC\_TR, RTC\_DR and RTC\_SSR. RSF is set in RTC\_ISR \(RTC2\)/RTC\_ICSR \(RTC3\) each time the calendar time and date shadow registers are updated with the real calendar value. The copy is performed every RTCCLK cycle, synchronized with the APB bus clock \(APB bus by which the RTC is accessed\). After a system reset or after exiting the Initialization mode, the application must wait for the RSF bit to be set before reading the calendar shadow registers.

When the system is woken up from low-power modes \(SYSCLK was off, consequently, the APB clock was off too\), the application must first clear RSF, and then wait until RSF is set again before reading the calendar registers. This ensures that the value read by the application is the current calendar value, and not the value before entering the low-power mode.

By setting BYPSHAD = 1 in RTC\_CR, the calendar values are taken directly from the calendar counters instead of reading the shadow register. In this case, it is not mandatory to wait for the synchronization time, but the calendar registers consistency must be checked by the software. The user must read the required calendar field values. The read operation must then be performed again. The results of the two read sequences are compared. If the results match, the read result is correct. If the values differ, repeat the process until the results match.

**Note:** After setting BYPSHAD = 0, the shadow registers may be incorrect until the next synchronization. In this case, the software must clear RSF = 0, wait for the synchronization \(RSF must be set\), and finally read the shadow registers.

**Parent topic:**[RTC safety aspects](AN4759_RTC-safety-aspects.md)

