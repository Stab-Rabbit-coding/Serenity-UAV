# Tamper detection application example \(STM32L0\) {#id_33282}

-   **[Hardware setup](AN4759_HW-setup-L0.md)**  

-   **[Software setup](AN4759_SW-setup-L0.md)**  

-   **[LED meaning](AN4759_LED-meaning-L0.md)**  

-   **[Tampering detection during normal operation](AN4759_Tamper-detection-normal-operation-L0.md)**  


**Parent topic:**[STM32L0 API and tampering detection application example](AN4759_STM32L0-API-tamper-detection.md)

