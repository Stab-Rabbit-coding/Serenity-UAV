# Set RTC prescalers {#id_33257}

The prescalers used for the calendar are divided into an asynchronous and a synchronous prescalers. Increasing the PREDIV\_A value of the asynchronous prescaler while reducing the synchronous prescaler accordingly to keep the 1 Hz output, reduces the RTC power consumption.

On RTC3 type, the RTC dynamic consumption is optimized for LPCAL = 1 and PREDIV\_A + 1 being a power of two \(considering the RTC as the only peripheral using LSE\).

**Parent topic:**[Reduce power consumption](AN4759_Reduce-power-consumption.md)

