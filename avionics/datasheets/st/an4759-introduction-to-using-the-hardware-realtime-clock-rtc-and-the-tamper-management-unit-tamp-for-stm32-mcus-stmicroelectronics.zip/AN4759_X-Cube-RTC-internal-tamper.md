# X-CUBE-RTC for internal tamper detection application {#id_33519}

X-CUBE-RTC shows an implementation of the internal tamper detection in the folder:

STM32CubeExpansion\_AN4759\_RTC\_STM32L\_Vx.y.z\\Projects\\NUCLEO-L552ZE‑Q \\RTC\_InternalTamperCalOvf

This example uses the RTC firmware driver API mentioned in [STM32L5 API and smooth digital calibration application example](AN4759_STM32L5-API-dig-smooth-calib.md) and [STM32L5 API and synchronization application example](AN4759_STM32L5-API-synchro-application-example.md). It is developed for the NUCLEO-L552ZE-Q board and exploits the ITAMP5 signal associated to a RTC calendar overflow event.

The user must supply the Nucleo board via USB, then compile and run the firmware with the preferred IDE. For IAR Embedded Workbench, open the RTC\_Synchronization.eww file. For MDK-ARM, open the RTC\_Synchronization.uvprojx file. For STM32CubeIDE, open the .cproject file.

The X-CUBE-RTC simply configures the RTC calendar at 23:59:30 on the 31st of December of the year xx99 and activates the internal tamper 5. The user can choose the polling mode or interrupt mode with the ITAMP\_INTERRUPT constant in main.h: 1 is interrupt mode, 0 is polling mode.

When the seconds pass 59, the internal tamper event occurs and the green user led 1 PC7 if in polling mode, or the blue user LED2 PB7 if in interrupt mode, is turned on.

RTC\_DR and RTC\_TR allow the contents of the RTC calendar to be observed in debug mode.

The user can easily modify this example to exploit all the others internal tamper event sources.

**Parent topic:**[STM32L5 API and internal tamper detection application example](AN4759_STM32L5-API-internal-tamper-detection.md)

