# STM32L5 API and smooth digital calibration application example {#id_33486}

-   **[STM32CubeL5 firmware libraries for smooth calibration application](AN4759_STM32CubeL5-FW-libraries.md)**  

-   **[X-CUBE-RTC for smooth calibration](AN4759_X-CUBE-RTC-L5-dig-calib.md)**  

-   **[Smooth calibration application example \(STM32L5\)](AN4759_Digital-calib-application-example-L5.md)**  


