# RTC3 secure and privileged protection modes {#id_33260}

Some STM32 MCUs can run in secure or nonsecure mode. Each mode having its own environment, allowing a trustful zone, not accessible in nonsecure mode, to be maintained in secure mode \(TrustZone® feature\).

A second level of restriction and security is available with part of each environment associated to a privileged or unprivileged mode.

On some products \(see [Table 1](AN4759_Adv-RTC-features.md#table_clz_c42_rpb) and [AN4759\_Adv-RTC-features.md\#table\_hqc\_shf\_rpb](AN4759_Adv-RTC-features.md#table_hqc_shf_rpb)\), the registers programming allow the user to restrict the read/write operation on RTC/TAMP registers to secure or privileged modes. Some configuration bits establish the restriction only for some RTC registers. These registers/bits to program are product dependent, then not detailed here \(refer to the product reference manual\).

**Note:** The backup registers and the monotonic counter have their own protection mode settings.

**Parent topic:**[Advanced RTC features](AN4759_Adv-RTC-features.md)

