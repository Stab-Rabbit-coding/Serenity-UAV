# LED meaning {#id_33267}

-   LD1 \(green\): tamper event detected

    TFT displays: the tamper date and tamper time are different from their initialization state.

-   LD2 \(orange\): power-on reset occurred

    TFT displays: the tamper date and tamper time are at their initialization state.

-   LD3 \(red\): error \(RTC or RCC configuration error, backup registers not erased\)

    TFT displays: “error occurred” is displayed.

-   LD4 \(blue\): reset occurred

    TFT displays: the tamper date and tamper time are at their initialization state.


**Parent topic:**[Tamper detection application example \(STM32L4\)](AN4759_Tamper-detection-application-example-L4.md)

