#  {#id_33173}

**Table 1. Advanced features of RTC3 type.**

<table>
<thead>
<tr>
<th colspan="3">Features</th>
<th>STM32C0</th>
<th>STM32C5</th>
<th>STM32G0</th>
<th>STM32G4</th>
<th>STM32H5</th>
<th>STM32H7A3/7B3</th>
<th>STM32L41/42/4P5/4Q5</th>
<th>STM32L5</th>
<th>STM32N6</th>
<th>STM32H7Rx/7Sx</th>
<th>STM32U0</th>
<th>STM32U3</th>
<th>STM32U5</th>
<th>STM32WBA</th>
<th>STM32WL</th>
</tr>
</thead>
<tbody>
<tr>
<td colspan="3">RTC clock source (LSE, LSI, HSE with prescaler)</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
</tr>
<tr>
<td colspan="3">Binary mode</td>
<td>N/A</td>
<td>X</td>
<td>N/A</td>
<td>N/A</td>
<td>X</td>
<td>N/A</td>
<td>N/A</td>
<td>N/A</td>
<td>X</td>
<td>N/A</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
</tr>
<tr>
<td colspan="3">Mixed mode (BCD and binary)</td>
<td>N/A</td>
<td>X</td>
<td>N/A</td>
<td>N/A</td>
<td>X</td>
<td>N/A</td>
<td>N/A</td>
<td>N/A</td>
<td>X</td>
<td>N/A</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
</tr>
<tr>
<td rowspan="2">Prescalers</td>
<td colspan="2">Asynchronous (number of bits)</td>
<td>X (7)</td>
<td>X (7)</td>
<td>X (7)</td>
<td>X (7)</td>
<td>X (7)</td>
<td>X (7)</td>
<td>X (7)</td>
<td>X (7)</td>
<td>X (7)</td>
<td>X (7)</td>
<td>X (7)</td>
<td>X (7)</td>
<td>X (7)</td>
<td>X (7)</td>
<td>X (7)</td>
</tr>
<tr>
<td colspan="2">Synchronous (number of bits)</td>
<td>X (15)</td>
<td>X (15)</td>
<td>X (15)</td>
<td>X (15)</td>
<td>X (15)</td>
<td>X (15)</td>
<td>X (15)</td>
<td>X (15)</td>
<td>X (15)</td>
<td>X (15)</td>
<td>X (15)</td>
<td>X (15)</td>
<td>X (15)</td>
<td>X (15)</td>
<td>X (15)</td>
</tr>
<tr>
<td rowspan="7">Calendar</td>
<td rowspan="3">Time</td>
<td>12 h/24 h format</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
</tr>
<tr>
<td>Hour, minute, second</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
</tr>
<tr>
<td>Subsecond</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
</tr>
<tr>
<td colspan="2">Date</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
</tr>
<tr>
<td colspan="2">Daylight operation</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
</tr>
<tr>
<td colspan="2">Bypass the shadow registers</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
</tr>
<tr>
<td colspan="2">Power optimization mode</td>
<td>N/A</td>
<td>X</td>
<td>N/A</td>
<td>N/A</td>
<td>X</td>
<td>N/A</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
</tr>
<tr>
<td rowspan="7">Alarm</td>
<td rowspan="2">Alarms available</td>
<td>Alarm A</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
</tr>
<tr>
<td>Alarm B</td>
<td>N/A</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
</tr>
<tr>
<td rowspan="3">Time</td>
<td>12 h/24 h format</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
</tr>
<tr>
<td>Hour, minute, second</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
</tr>
<tr>
<td>Subsecond</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
</tr>
<tr>
<td colspan="2">Date or week day</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
</tr>
<tr>
<td colspan="2">Binary mode alarm</td>
<td>N/A</td>
<td>X</td>
<td>N/A</td>
<td>N/A</td>
<td>X</td>
<td>N/A</td>
<td>N/A</td>
<td>N/A</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
</tr>
<tr>
<td rowspan="19">Tamper detection</td>
<td rowspan="3">Tamper reactions</td>
<td>Backup registers erasing</td>
<td>N/A</td>
<td>X<sup><a href="#fn2">2</a></sup></td>
<td>X</td>
<td>X</td>
<td>X<sup><a href="#fn2">2</a></sup></td>
<td>X<sup><a href="#fn1">1</a></sup></td>
<td>X</td>
<td>X<sup><a href="#fn1">1</a></sup></td>
<td>X<sup><a href="#fn2">2</a></sup></td>
<td>X<sup><a href="#fn1">1</a></sup></td>
<td>X<sup><a href="#fn1">1</a></sup></td>
<td>X<sup><a href="#fn2">2</a></sup></td>
<td>X<sup><a href="#fn2">2</a></sup></td>
<td>X<sup><a href="#fn2">2</a></sup></td>
<td>X<sup><a href="#fn1">1</a></sup></td>
</tr>
<tr>
<td>Interruption</td>
<td>N/A</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
</tr>
<tr>
<td>Trigger for low-power timer</td>
<td>N/A</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
</tr>
<tr>
<td colspan="2">Configurable edge detection</td>
<td>N/A</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
</tr>
<tr>
<td colspan="2">Configurable level detection<sup><a href="#fn3">3</a></sup></td>
<td>N/A</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
</tr>
<tr>
<td colspan="2">Number of internal tamper events</td>
<td>N/A</td>
<td>6</td>
<td>4</td>
<td>4</td>
<td>13</td>
<td>7</td>
<td>N/A</td>
<td>5</td>
<td>10</td>
<td>11</td>
<td>4</td>
<td>9</td>
<td>11</td>
<td>9</td>
<td>4</td>
</tr>
<tr>
<td colspan="2">Number of external tamper inputs</td>
<td>N/A</td>
<td>3</td>
<td>2</td>
<td>3</td>
<td>8 (11 pins)</td>
<td>3</td>
<td>3 <sup><a href="#fn4">4</a></sup></td>
<td>8</td>
<td>7</td>
<td>8</td>
<td>5</td>
<td>5</td>
<td>8</td>
<td>6 (6 pins)</td>
<td>3</td>
</tr>
<tr>
<td colspan="2">VBAT mode pins</td>
<td>N/A</td>
<td>N/A</td>
<td>N/A</td>
<td>N/A</td>
<td><p>TAMP_IN[8:1], TAMP_OUT[8:1], RTC_TS, RTC_OUT1/2</p></td>
<td><p>RTC_TS, RTC_OUT1/2</p></td>
<td><p>RTC_TAMP1/2/3, RTC_TS, RTC_OUT for STM32L441/42. RTC_TS, RTC_OUT1 for STM32L4P5/Q5</p></td>
<td><p>TAMP_IN1/2/3, TAMP_OUT2</p></td>
<td>TAMP_IN[4:1], TAMP_OUT[2:1], RTC_OUT1, RTC_TS</td>
<td>TAMP_IN[3:1], TAMP_OUT2, RTC_TS, RTC_OUT1/2</td>
<td>TAMP_IN[5:0], RTC_TS, RTC_OUT1</td>
<td>RTC_OUT1, RTC_TS, TAMP_IN[5:1]</td>
<td><p>TAMP_IN[8:1], TAMP_OUT[8:1], RTC_TS, RTC_OUT1/2</p></td>
<td>N/A</td>
<td><p>RTC_TS, RTC_OUT1</p></td>
</tr>
<tr>
<td colspan="2">NOERASE mode</td>
<td>N/A</td>
<td>N/A</td>
<td>N/A</td>
<td>N/A</td>
<td>X</td>
<td>N/A</td>
<td>X</td>
<td>N/A</td>
<td>X</td>
<td>N/A</td>
<td>N/A</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>N/A</td>
</tr>
<tr>
<td colspan="2">Independent watchdog linked to an internal tamper for false detection timeout</td>
<td>N/A</td>
<td>N/A</td>
<td>N/A</td>
<td>N/A</td>
<td>X</td>
<td>N/A</td>
<td>N/A</td>
<td>N/A</td>
<td>X</td>
<td>N/A</td>
<td>N/A</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>N/A</td>
</tr>
<tr>
<td colspan="2">Active tamper</td>
<td>N/A</td>
<td>N/A</td>
<td>N/A</td>
<td>N/A</td>
<td>X</td>
<td>X</td>
<td>N/A</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>N/A</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>N/A</td>
</tr>
<tr>
<td colspan="2">Monotonic counter</td>
<td>N/A</td>
<td>N/A</td>
<td>N/A</td>
<td>N/A</td>
<td>X</td>
<td>X</td>
<td>N/A</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>N/A</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
</tr>
<tr>
<td rowspan="4">LP mode effect on TAMP</td>
<td>Sleep</td>
<td>N/A</td>
<td colspan="14">No effect</td>
</tr>
<tr>
<td>Stop</td>
<td>N/A</td>
<td colspan="14" rowspan="2">No effect except for filtered level detection and active tamper if clock source is not LSE or LSI</td>
</tr>
<tr>
<td>Standby</td>
<td>N/A</td>
</tr>
<tr>
<td>Shutdown</td>
<td>N/A</td>
<td>X</td>
<td colspan="1">No effect except for filtered level detection and active tamper if clock source is not LSE</td>
<td>N/A</td>
<td colspan="2">No effect except for filtered level detection and active tamper if clock source is not LSE</td>
<td>N/A</td>
<td> </td>
<td> </td>
<td> </td>
<td>No effect except for filtered level detection and active tamper if clock source is not LSE</td>
<td>No effect except for filtered level detection and active tamper if clock source is not LSE or LSI</td>
<td> </td>
</tr>
<tr>
<td colspan="2">SAES key storage protection</td>
<td>N/A</td>
<td>N/A</td>
<td>N/A</td>
<td>N/A</td>
<td>X</td>
<td>N/A</td>
<td>N/A</td>
<td>N/A</td>
<td>X</td>
<td>N/A</td>
<td>N/A</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>N/A</td>
</tr>
<tr>
<td colspan="2">Secure protection modes</td>
<td>N/A</td>
<td>N/A</td>
<td>N/A</td>
<td>N/A</td>
<td>X<sup><a href="#fn6">6</a></sup></td>
<td>N/A</td>
<td>N/A</td>
<td>X</td>
<td>X</td>
<td>N/A</td>
<td>N/A</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>N/A</td>
</tr>
<tr>
<td colspan="2">Privileged protection mode</td>
<td>N/A</td>
<td>N/A</td>
<td>N/A</td>
<td>N/A</td>
<td>X<sup><a href="#fn6">6</a></sup></td>
<td>N/A</td>
<td>N/A</td>
<td>X</td>
<td>X</td>
<td>N/A</td>
<td>N/A</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>N/A</td>
</tr>
<tr>
<td rowspan="6">Timestamp</td>
<td colspan="2">Configurable input mapping</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
</tr>
<tr>
<td rowspan="2">Time</td>
<td>Hour, minute, second</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
</tr>
<tr>
<td>Subsecond</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
</tr>
<tr>
<td colspan="2">Date (day, month)</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
</tr>
<tr>
<td colspan="2">Timestamp on tamper detection event</td>
<td>N/A</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
</tr>
<tr>
<td colspan="2">Timestamp on switch to VBAT mode</td>
<td>N/A</td>
<td>N/A</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>N/A</td>
<td>X</td>
</tr>
<tr>
<td rowspan="2">Wakeup unit</td>
<td colspan="2">Clock source available</td>
<td>N/A</td>
<td colspan="14">RTC clock divided by 2, 4, 8, 16 or RTC synchronous prescaler output</td>
</tr>
<tr>
<td colspan="2">Hardware automatic flag clearing</td>
<td>N/A</td>
<td>X</td>
<td>N/A</td>
<td>N/A</td>
<td>X</td>
<td>N/A</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
</tr>
<tr>
<td rowspan="6">RTC outputs</td>
<td colspan="2">Number of outputs</td>
<td>2</td>
<td>2</td>
<td>2</td>
<td>2</td>
<td>2</td>
<td>2</td>
<td>2</td>
<td>2</td>
<td>2</td>
<td>2</td>
<td>2</td>
<td>X</td>
<td>2</td>
<td>2</td>
<td>2</td>
</tr>
<tr>
<td rowspan="3">TAMP<p>ALRM</p></td>
<td>Alarm event</td>
<td>X</td>
<td>2</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
</tr>
<tr>
<td>Wakeup event</td>
<td>N/A</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
</tr>
<tr>
<td>Tamper event</td>
<td>N/A</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
</tr>
<tr>
<td rowspan="2">CALIB</td>
<td>512 Hz</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
</tr>
<tr>
<td>1 Hz</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
</tr>
<tr>
<td rowspan="2">Digital calibration</td>
<td colspan="2">Smooth calibration</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
</tr>
<tr>
<td colspan="2">Ultra-low-power mode</td>
<td>N/A</td>
<td>X</td>
<td>N/A</td>
<td>N/A</td>
<td>X</td>
<td>N/A</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>N/A</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
</tr>
<tr>
<td colspan="3">RTC synchronization</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
</tr>
<tr>
<td colspan="3">Reference clock detection</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
</tr>
<tr>
<td rowspan="4">Backup registers</td>
<td colspan="2">Powered on VBAT</td>
<td>N/A</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>N/A</td>
<td>X</td>
</tr>
<tr>
<td colspan="2">Reset on a tamper detection</td>
<td>N/A</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
</tr>
<tr>
<td colspan="2">Reset when flash memory readout protection is disabled</td>
<td>N/A</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
</tr>
<tr>
<td colspan="2">Number of backup registers (size in bits)</td>
<td>4 (32) (within PWR)</td>
<td>32 (32)</td>
<td>5 (32)</td>
<td>32 or 16 (32)<sup><a href="#fn5">5</a></sup></td>
<td>32 (32)</td>
<td>32 (32)</td>
<td>32 (32)</td>
<td>32 (32)</td>
<td>32 (32)</td>
<td>32 (32)</td>
<td>9 (32)</td>
<td>32 (32)</td>
<td>32 (32)</td>
<td>32 (32)</td>
<td>20 (32)</td>
</tr>
<tr>
<td rowspan="4">LP mode effect on RTC</td>
<td colspan="2">Sleep</td>
<td>RTC interrupts may exit sleep mode</td>
<td>No effect; RTC interrupts may exit Sleep mode</td>
<td colspan="7">No effect</td>
<td colspan="2">No effect; RTC interrupts may exit Sleep mode</td>
<td colspan="2">No effect</td>
<td>No effect; RTC interrupts may exit Sleep mode</td>
<td>No effect</td>
</tr>
<tr>
<td colspan="2">Stop</td>
<td><p>Active if</p>
 <p>RTC is</p>
 <p>clocked</p>
 <p>by LSE</p>
 <p>or LSI</p></td>
<td colspan="14" rowspan="2">Active if RTC is clocked by LSE or LSI</td>
</tr>
<tr>
<td colspan="2">Standby</td>
<td><p>RTC</p>
 <p>powered</p>
 <p>down</p>
 <p>and must</p>
 <p>be</p>
 <p>reinitializ</p>
 <p>ed</p></td>
</tr>
<tr>
<td colspan="2">Shutdown</td>
<td>N/A</td>
<td>N/A</td>
<td colspan="1">Active if RTC is clocked by LSE</td>
<td>N/A</td>
<td colspan="2">Active if RTC is clocked by LSE</td>
<td>N/A</td>
<td>N/A</td>
<td>N/A</td>
<td colspan="2">Active if RTC is clocked by LSE</td>
<td>N/A</td>
<td>Active if RTC is clocked by LSE</td>
</tr>
<tr>
<td colspan="3">RTC secure protection mode</td>
<td>N/A</td>
<td>N/A</td>
<td>N/A</td>
<td>N/A</td>
<td>X<sup><a href="#fn6">6</a></sup></td>
<td>N/A</td>
<td>N/A</td>
<td>X</td>
<td>X</td>
<td>N/A</td>
<td>N/A</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>N/A</td>
</tr>
<tr>
<td colspan="3">RTC privilege protection mode</td>
<td>N/A</td>
<td>N/A</td>
<td>N/A</td>
<td>N/A</td>
<td>X<sup><a href="#fn6">6</a></sup></td>
<td>N/A</td>
<td>N/A</td>
<td>X</td>
<td>X</td>
<td>N/A</td>
<td> </td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>N/A</td>
</tr>
</tbody>
</table>

**Parent topic:**[Advanced RTC features](AN4759_Adv-RTC-features.md)

<a id="fn1"></a>

[^1]: Erasing part of SRAM is also possible.<a id="fn2"></a>

[^2]: Erasing of part of SRAM, caches and cryptographic registers is also possible.<a id="fn3"></a>

[^3]:  Filtering, sampling and precharge configuration, internal pull-up.<a id="fn4"></a>

[^4]: Only two for STM32L4 devices.<a id="fn5"></a>

[^5]:  Depends on device category.<a id="fn6"></a>

[^6]: This feature is not available for STM32H503.

