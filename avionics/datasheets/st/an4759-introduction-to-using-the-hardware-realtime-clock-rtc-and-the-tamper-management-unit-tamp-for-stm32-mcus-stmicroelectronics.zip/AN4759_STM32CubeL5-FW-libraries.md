# STM32CubeL5 firmware libraries for smooth calibration application {#id_33489}

The timer peripheral \(TIM\) comes with:

-   A firmware driver API abstracting TIM features for the end-user

    Refer to stm32l5xx\_hal\_tim.c and stm32l5xx\_hal\_tim\_ex.c files in \\STM32Cube\_FW\_L5\_Vx.y.z\\Drivers\\STM32L5xx\_HAL\_Driver\\

-   A set of example projects in \\STM32Cube\_FW\_L5\_Vx.y.z\\Projects\\ NUCLEO-L552ZE-Q\\Examples\\TIM

The RTC comes with:

-   A firmware driver API abstracting TIM features for the end-user

    Refer to stm32l5xx\_hal\_rtc.c and stm32l5xx\_hal\_rtc\_ex.c files in \\STM32Cube\_FW\_L5\_Vx.y.z\\Drivers\\STM32L5xx\_HAL\_Driver\\

-   A set of example projects in \\STM32Cube\_FW\_L5\_Vx.y.z\\Projects\\ NUCLEO-L552ZE-Q\\Examples\\RTC

**Parent topic:**[STM32L5 API and smooth digital calibration application example](AN4759_STM32L5-API-dig-smooth-calib.md)

