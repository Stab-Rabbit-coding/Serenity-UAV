# Active tamper detection \(RTC3 only\) {#id_33229}

The tamper detection can be made robust against tamper pin being externally opened or shorted. That is done thanks to the active tamper.

The principle is to set TAMP\_OUTy output pins to deliver a random message, and TAMP\_INx input pins to receive it. If the message sent is not the one received, it is considered that a tamper event occurred: TAMPxF is set in TAMP\_SR for the TAMP\_INx pin detecting the error. Depending on the tamper pins available, several organizations can be configured. For example, for eight tamper pins, the user can have four outputs and four inputs with four different messages, or seven inputs with one output and one message exchanged.

![](DT65100.svg "Tamper detection")

-   **[Active pin IN/OUT association](AN4759_Active-pins-association.md)**  

-   **[Filtering](AN4759_Filtering.md)**  

-   **[Message randomization](AN4759_Message-randomization.md)**  

-   **[Initialization](AN4759_Initialization.md)**  


**Parent topic:**[RTC tamper detection function](AN4759_RTC-tamper-detection.md)

