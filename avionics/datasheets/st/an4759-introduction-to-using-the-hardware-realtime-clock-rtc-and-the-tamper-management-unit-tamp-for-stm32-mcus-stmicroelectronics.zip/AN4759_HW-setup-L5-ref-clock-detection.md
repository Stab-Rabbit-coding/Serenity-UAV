# Hardware setup {#id_33513}

In order to use the application example project, the user needs a STM32L552ZE-Q Nucleo board \(NUCLEO‑L552ZE-Q\). Supply the board using the USB cable.

As indicated by the application name, a reference clock must be delivered to the STM32 for this application. For this goal, the user has to take a 50/60 Hz signal more precise than the LSE clock of the Nucleo board, and to inject it on the PB15 pin \(position 26 on CN12 of the Nucleo board\).

The user can check that the RTC prescalers are well configured for the board by verifying a 1 Hz signal is output on PB2 \(RTC\_OUT CALIB output\).

**Parent topic:**[Reference clock detection application example](AN4759_Ref-clock-detection.md)

