# Timestamp firmware examples {#id_33218}

The RTC comes with a set of example projects so that the user can quickly become familiar with this peripheral. Refer to the STM32Cube MCU Package of the product for a complete projects list.

For example, the user can find the following projects concerning timestamp:

-   For the NUCLEO-L412RB-P equipped with an RTC3:

    STM32Cube\_FW\_L4\_Vx.y.z\\Projects\\NUCLEO-L412RB-P\\Examples\\RTC\\RTC\_TimeStamp

-   For the NUCLEO-G071RB equipped with an RTC3:

    STM32Cube\_FW\_G0\_Vx.y.z\\Projects\\NUCLEO-G071RB\\Examples\_LL\\RTC\\RTC\_TimeStamp\_Init


If an example is not available in the STM32Cube for a given STM32 MCU, the user can adapt it.

**Parent topic:**[Timestamp function](AN4759_Timestamp-function.md)

