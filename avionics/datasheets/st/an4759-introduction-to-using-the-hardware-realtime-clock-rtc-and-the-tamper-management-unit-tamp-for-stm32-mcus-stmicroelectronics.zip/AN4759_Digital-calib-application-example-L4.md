# Smooth calibration application example \(STM32L4\) {#id_33274}

-   **[Hardware setup](AN4759_HW-setup-L4-dig-calib.md)**  

-   **[Software setup](AN4759_SW-setup-L4-dig-calib.md)**  

-   **[Smooth calibration application principle](AN4759_Digital-calib-block-diagram-L4.md)**  

-   **[Run time observations](AN4759_Run-time-observations-L4.md)**  

-   **[Porting suggestions](AN4759_Porting-suggestion.md)**  


**Parent topic:**[STM32L4 API and smooth digital calibration application example](AN4759_STM32L4-API-digital-smooth-calibration.md)

