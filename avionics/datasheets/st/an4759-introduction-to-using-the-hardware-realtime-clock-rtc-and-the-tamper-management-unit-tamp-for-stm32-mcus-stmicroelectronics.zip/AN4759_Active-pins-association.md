# Active pin IN/OUT association {#id_33230}

The user configures TAMP\_INx as active input pins by setting TAMPxAM = 1 in TAMP\_ATCR1.

By default, when TAMP\_INx is activated as active tamper pins, the TAMP\_OUTx pin is associated to it to implement the active tamper detection mechanism.

If other TAMP\_INy pins need to be associated to TAMP\_OUTx pin \(the one mentioned above\) for the application, the ATOSHARE \(active tamper output share\) bit can be used to make all the TAMP\_OUT pins, including TAMP\_OUTx, sharable.

When ATOSHARE = 1, ATOSELi \(active tamper output selection\) allows the choice of the new TAMP\_OUT pin associated to TAMP\_INi.

Example: considering there are at least two active tamper pins on the product, TAMP\_OUT1 can be used for comparison with TAMP\_IN1 and TAMP\_IN2 by configuring and enabling both TAMP\_IN1 and TAMP\_2 in active mode, with ATOSHARE = 1, ATOSEL1 = 0 and ATOSEL2 = 0.

**Note:** ATOSHARE and ATOSELi bits are respectively in TAMP\_ATCR1 and TAMP\_ATCR2.

**Parent topic:**[Active tamper detection \(RTC3 only\)](AN4759_Active-tamper-detectionRTC3.md)

