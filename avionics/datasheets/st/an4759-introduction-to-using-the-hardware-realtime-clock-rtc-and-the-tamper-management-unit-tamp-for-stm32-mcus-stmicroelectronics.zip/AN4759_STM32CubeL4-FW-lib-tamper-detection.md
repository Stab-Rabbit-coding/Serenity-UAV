# STM32CubeL4 firmware libraries for tamper detection {#id_33262}

The RTC comes with:

-   A firmware driver API abstracting the RTC features for the end user

    Refer to stm32l4xx\_hal\_rtc.c and stm32l4xx\_hal\_rtc\_ex.c files in \\STM32Cube\_FW\_L4\_Vx.y.z\\Drivers\\STM32L4xx\_HAL\_Driver\\

-   A set of example projects in \\STM32Cube\_FW\_L4\_Vx.y.z\\Projects\\STM32L476RG-Eval\\Examples\\RTC

**Parent topic:**[STM32L4 API and tamper detection application example](AN4759_STM32L4-API-tamper-detection-example.md)

