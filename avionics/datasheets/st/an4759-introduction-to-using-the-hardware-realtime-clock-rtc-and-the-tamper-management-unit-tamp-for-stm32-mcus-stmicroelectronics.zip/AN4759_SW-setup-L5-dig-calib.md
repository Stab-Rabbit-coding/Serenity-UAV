# Software setup {#id_33495}

Open the project under the user favorite IDE. For IAR Embedded Workbench, open the RTC\_SmoothCalib.eww file. For MDK-ARM, open the RTC\_SmoothCalib.uvprojx file. For STM32CubeIDE, open the .cproject file.

Compile and launch the debug session. It loads the program in the internal Flash memory and executes it.

After a maximum of 64 seconds, make a frequency measurement of the CALIB\_OUT clock on PB2. The user gets a frequency accurate at 1 ppm compared to the 1 Hz reference clock sent on PE2.

The user can then modify the PE2 clock by few ppm, wait 64 seconds, and check that the PB2 clock has been changed accordingly.

Under debugger, the user can monitor the evolution of the CALR register fields \(CALP and CALM\).

**Parent topic:**[Smooth calibration application example \(STM32L5\)](AN4759_Digital-calib-application-example-L5.md)

