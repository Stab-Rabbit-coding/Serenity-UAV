# RTC reference clock detection {#id_33213}

For RTC3 type, this feature is available only in BCD mode \(BIN = 00\).

The reference clock \(50 Hz or 60 Hz\) must have a higher precision than the 32.768 kHz LSE clock. This is why the RTC provides a reference clock input \(RTC\_REFIN pin\) that can be used to compensate the imprecision of the calendar frequency \(1 Hz\). The RTC\_REFIN pin must be configured in input floating mode.

This mechanism enables the calendar to be as precise as the reference clock.

The reference clock detection is enabled by setting REFCKON in RTC\_CR. When the reference clock detection is enabled, PREDIV\_A and PREDIV\_S must be set to their default values \(PREDIV\_A = 0x007F and PREDIV\_S = 0x00FF\).

**Note:** This feature is only valid with the RTC clock from LSE oscillator oscillating at 32.768 kHz due to this requirement.

When the reference clock detection is enabled, each 1 Hz clock edge is compared to the nearest reference clock edge \(if one is found within a given time window\). In most cases, the two clock edges are properly aligned. When the 1 Hz clock becomes misaligned due to the imprecision of the LSE clock, the RTC shifts the 1 Hz clock a bit so that future 1 Hz clock edges are aligned. The update window is three ck\_apre periods.

If the reference clock halts, the calendar is updated continuously based only on the LSE clock. The RTC waits for the reference clock using a detection window centered on the ck\_spre \(synchronous prescaler output clock\) edge. The detection window is seven ck\_apre periods.

The reference clock can have a large local deviation \(for instance in the range of 500 ppm\), but in the long term it must be much more precise than 32 kHz quartz.

The detection system is used only when the reference clock needs to be detected back after a loss. As the detection window is a bit larger than the reference clock period, this detection system brings an uncertainty of one ck\_ref period \(20 ms for a 50 Hz reference clock\) because it is possible to have two ck\_ref edges in the detection window. The update window is then used, which brings no error as it is smaller than the reference clock period.

Assuming that ck\_ref is not lost more than once a day, the total uncertainty per month is 20 ms x 1x 30 = 0.6 s, which is much less than the uncertainty of a typical quartz \(53 s/month for ±20 ppm quartz\).

![](DT19545.svg "RTC reference clock detection")

**Note:** The reference clock calibration and the RTC synchronization \(shift feature\) cannot be used together. The reference clock calibration is the best \(ensures a high calibrated time\) if the 50 Hz is always available. If the 50 Hz input is lost, the RTC accuracy is provided by the LSE crystal. The reference clock detection cannot be used in VBAT mode. The reference clock calibration can only be used if the user provides a precise 50 or 60 Hz input.

An example for this feature is provided in the X-CUBE-RTC \(see [STM32L5 API and reference clock detection application example](AN4759_STM32L5-API-ref-clock-detection.md) for more details\).

**Parent topic:**[Advanced RTC features](AN4759_Adv-RTC-features.md)

