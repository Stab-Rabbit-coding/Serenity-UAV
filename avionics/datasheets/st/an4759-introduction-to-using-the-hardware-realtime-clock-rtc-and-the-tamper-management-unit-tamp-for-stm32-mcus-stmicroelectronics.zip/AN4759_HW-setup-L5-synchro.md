# Hardware setup {#id_33503}

In order to use the application example project, the user needs a STM32L552ZE-Q Nucleo board \(NUCLEO‑L552ZE-Q\). Supply the board using the USB cable.

The TIM1 clock source is HSE. However, the X3 crystal associated to HSE is not implemented by default on the Nucleo board. Then, the application exploits the HSE bypass functionality of the STM32 to input an external 16 MHz signal to substitute the crystal \(for this feature, the user must have SB142 ON, SB145 ON, SB143 OFF, SB6 OFF, SB7 OFF\). This signal must be generated on PH0 \(position 29 on CN11, right next to the connection A1 of CN9\).

The internal HSI clock is not used since it is less precise than the LSE oscillator that clocks the RTC. Moreover, the HSE external 16 MHz signal must be more precise than the LSE.

The user can check that the RTC prescalers are well configured for the board by verifying a 1 Hz signal is output on PB2 \(RTC\_OUT CALIB output\).

**Parent topic:**[Synchronization application example \(STM32L5\)](AN4759_Synchro-application-example-L5.md)

