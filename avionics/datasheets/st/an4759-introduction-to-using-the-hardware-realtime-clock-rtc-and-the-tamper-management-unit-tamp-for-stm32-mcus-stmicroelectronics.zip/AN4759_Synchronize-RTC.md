# Synchronize the RTC {#id_33211}

The RTC calendar can be synchronized to a more precise clock, “remote clock”, using the RTC shift feature. After reading the RTC subsecond field, a calculation of the precise offset between the time being maintained by the remote clock and the RTC is made. The RTC can be adjusted by removing this offset with a fine adjustment using the shift register control.

![](DT30111.svg "RTC shift register")

The synchronization shift function cannot be checked using the RTC\_CALIB output since the shift operation has no impact on the RTC clock \(except adding or subtracting a few fractions from the calendar counter\).

## Correct the RTC calendar time { .section}

If the RTC clock is advanced compared to the remote clock by n fractions of seconds, the offset value must be written in SUBFS\[14:0\] in RTC\_SHIFTR, that is added to the synchronous prescaler counter. As this counter counts down, this operation effectively subtracts from \(delays\) the clock by:

Delay \(seconds\) = SUBFS / \(PREDIV\_S + 1\)

If the RTC is delayed compared to the remote clock by n fractions of seconds, the offset value can effectively be added to the clock \(advancing the clock\) when ADD1S in RTC\_SHIFTR is used in conjunction with SUBFS, effectively advancing the clock by:

Advance \(seconds\) = \(1 - \(SUBFS / \(PREDIV\_S + 1\)\)\).

CAUTION:

For RTC3 type, ADD1S has no effect in binary mode. In mixed mode, the SUBFS\[14:BCDU+8\] must be written with 0. Before initiating a shift operation in BCD mode, the user must check that SS\[15\] = 0 in order to ensure that no overflow occurs. In mixed mode, the user must check that the bit SS\[BCDU+8\] = 0.

An example for this feature is provided in the X-CUBE-RTC \(see [STM32L5 API and synchronization application example](AN4759_STM32L5-API-synchro-application-example.md) for more details\).

**Parent topic:**[Advanced RTC features](AN4759_Adv-RTC-features.md)

