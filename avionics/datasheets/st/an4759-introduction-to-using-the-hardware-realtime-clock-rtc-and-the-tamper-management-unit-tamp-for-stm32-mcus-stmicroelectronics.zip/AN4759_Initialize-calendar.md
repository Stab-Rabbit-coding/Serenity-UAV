# Initialize the calendar {#id_33177}

the table below describes the steps required to correctly configure the calendar time and date.

**Table 1. Steps to initialize the calendar**

<table>
<thead>
<tr>
<th>Step</th>
<th>What</th>
<th>How</th>
<th>Comments</th>
</tr>
</thead>
<tbody>
<tr>
<td>1</td>
<td>Disable the RTC registers write protection.</td>
<td>Write 0xCA and then 0x53 into RTC_WPR.</td>
<td>RTC registers can be modified.</td>
</tr>
<tr>
<td>2</td>
<td>Enter initialization mode.</td>
<td>Set INIT = 1 in RTC_ISR (RTC2)/RTC_ICSR (RTC3) register</td>
<td>The calendar counter is stopped to allow its update.</td>
</tr>
<tr>
<td>3</td>
<td>Wait for the confirmation of initialization mode (clock synchronization).</td>
<td>Poll INITF bit of in RTC_ISR (RTC2)/RTC_ICSR (RTC3) until it is set.</td>
<td><ul>
<li>For RTC2: It takes around two RTCCLK clock cycles due to clock synchronization.</li>
<li>For RTC3: If LPCAL = 0, INITF is set around two RTCLK cycles after INIT is set. If LPCAL = 1, INITF is set up to two ck_apre cycles after INIT is set.</li>
</ul></td>
</tr>
<tr>
<td>4</td>
<td>Program the prescaler values (if needed).</td>
<td>In RTC_PRER, write first the synchronous value, and then write the asynchronous value. <p>For RTC3, program also BIN and BCDU in RTC_ICSR, if in binary or mixed mode.</p></td>
<td>By default (in BCD mode for RTC3), RTC_PRER is initialized to provide 1 Hz to the calendar unit (when RTCCLK = 32768 Hz).</td>
</tr>
<tr>
<td>5</td>
<td>Load time and date values in the shadow registers.</td>
<td>Set RTC_TR and RTC_DR.</td>
<td>-</td>
</tr>
<tr>
<td>6</td>
<td>Configure the time format (12 h or 24 h)</td>
<td>Set FMT bit in RTC_CR.</td>
<td>If FMT = 0, the format is 24 hour/day.<p>If FMT = 1, the format is 12 h am/pm.</p></td>
</tr>
<tr>
<td>7</td>
<td>Exit initialization mode.</td>
<td>Clear INIT in RTC_ISR (RTC2)/RTC_ICSR (RTC3).</td>
<td>For RTC2: The current calendar counter is automatically loaded and the counting restarts after four RTCCLK clock cycles.<p>For RTC3: If LPCAL = 0, the counting restarts after four RTCCLK clock cycles. If LPCAL = 1, the counting restarts after up to two RTCCLK + 1 ck_apre cycles.</p></td>
</tr>
<tr>
<td>8</td>
<td>Enable write protection of the RTC registers.</td>
<td>Write 0xFF into RTC_WPR.</td>
<td>The RTC registers can no longer be modified.</td>
</tr>
</tbody>
</table>

**Parent topic:**[RTC calendar](AN4759_RTC-calendar.md)

