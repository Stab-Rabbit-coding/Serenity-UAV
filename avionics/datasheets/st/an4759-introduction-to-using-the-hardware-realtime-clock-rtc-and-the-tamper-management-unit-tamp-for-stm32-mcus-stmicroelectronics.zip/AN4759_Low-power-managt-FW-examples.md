# Low-power management firmware examples {#id_33259}

The RTC comes with a set of example projects so that the user can quickly become familiar with this peripheral. Refer to the STM32Cube MCU Package of the product for a complete projects list.

For example, for the small STM32L4 product line, the user can find the following projects concerning low-power management:

-   For NUCLEO-L412RB-P:

    STM32Cube\_FW\_L4\_Vx.y.z\\Projects\\NUCLEO-L412RB-P\\Examples\\RTC\\RTC\_LowPower\_STANDBY

-   For NUCLEO-L412KB:

    STM32Cube\_FW\_L4\_Vx.y.z\\Projects\\NUCLEO-L412KB\\Examples\\PWR\\PWR\_STANDBY\_RTC

    STM32Cube\_FW\_L4\_Vx.y.z\\Projects\\NUCLEO-L412KB\\Examples\\PWR\\PWR\_STOP1\_RTC

    STM32Cube\_FW\_L4\_Vx.y.z\\Projects\\NUCLEO-L412KB\\Examples\\PWR\\PWR\_STOP2\_RTC


Analogous examples are available for STM32F0, STM32F2, STM32F3, STM32F4, STM32F7, STM32G4, STM32H7, STM32L0, STM32L1, STM32U3, STM32U5, STM32WB and STM32WL. If one example is not available in the STM32Cube for a given STM32 MCU, the user can adapt it.

**Parent topic:**[Reduce power consumption](AN4759_Reduce-power-consumption.md)

