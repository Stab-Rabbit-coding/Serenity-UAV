# Periodic timebase/wakeup configuration for clock configuration 2 {#id_33199}

The figure below shows the prescaler connection to the timebase/wakeup unit corresponding to configuration 2 and 3.

![](DT19530.svg "Prescalers connected to the wakeup unit for configurations 2 and 3")

If ck\_spre \(synchronous prescaler output clock\) is adjusted to 1 Hz, then:

-   The minimum timebase/wakeup period is \(0x0000 + 1\) x 1 s = 1 s.
-   The maximum timebase/wakeup period is \(0xFFFF+ 1\) x 1 s = 65536 s \(18 hours\).

**Parent topic:**[Maximum and minimum RTC wakeup period](AN4759_Max-min-RTC-wakup-period.md)

