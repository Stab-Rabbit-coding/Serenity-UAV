# RTC prescaler adjustment with LSI measurements {#id_33215}

When the LSI is selected as RTC clock source, a timer can be used to measure its frequency and adjust the RTC synchronous prescaler depending on the result got. The goal is to improve the observed LSI accuracy.

The LSI clock signal is connected to the input capture of one of the STM32 timers \(see the timers connected to LSI in the product reference manual\). For each LSI period, the timer must count the number of system core clock periods elapsed between two LSI rising edges associated. The software exploits the number of periods counted by comparing it with the amount expected, and adjust the RTC synchronous prescaler value in order to improve the RTC accuracy.

A firmware example is available in the STM32CubeL4 MCU Package for NUCLEO-L412RB-P \(RTC3 type\): STM32Cube\_FW\_L4\_Vx.y.z\\Projects\\NUCLEO-L412RB-P\\Examples\\RTC\\RTC\_LSI

If one example is not available in the STM32Cube for a given STM32 MCU, the user can adapt it.

**Parent topic:**[Advanced RTC features](AN4759_Adv-RTC-features.md)

