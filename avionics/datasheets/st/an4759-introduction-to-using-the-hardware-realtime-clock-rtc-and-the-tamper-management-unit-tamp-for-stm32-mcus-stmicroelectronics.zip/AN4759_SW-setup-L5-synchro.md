# Software setup {#id_33504}

Open the project under the user favorite IDE. For IAR Embedded Workbench, open the RTC\_Synchronization.eww file. For MDK-ARM, open the RTC\_Synchronization.uvprojx file. For STM32CubeIDE, open the .cproject file.

Compile and launch the debug session. It loads the program in the internal Flash memory and executes it.

**Parent topic:**[Synchronization application example \(STM32L5\)](AN4759_Synchro-application-example-L5.md)

