# STM32CubeL4 firmware libraries for smooth calibration {#id_33271}

The timer peripheral comes with:

-   A firmware driver API abstracting the timer features for the end-user

    Refer to stm32l4xx\_hal\_tim.c and stm32l4xx\_hal\_tim\_ex.c files in \\STM32Cube\_FW\_L4\_Vx.y.z\\Drivers\\STM32L4xx\_HAL\_Driver\\

-   A set of example projects in \\STM32Cube\_FW\_L4\_Vx.y.z\\Projects\\STM32L476RG-Nucleo\\Examples\\TIM

The RTC comes with:

-   A firmware driver API abstracting the RTC features for the end-user

    Refer to stm32l4xx\_hal\_rtc.c and stm32l4xx\_hal\_rtc\_ex.c files in \\STM32Cube\_FW\_L4\_Vx.y.z\\Drivers\\STM32L4xx\_HAL\_Driver\\

-   A set of example projects in \\STM32Cube\_FW\_L4\_Vx.y.z\\Projects\\STM32L476RG-Nucleo\\Examples\\RTC

**Parent topic:**[STM32L4 API and smooth digital calibration application example](AN4759_STM32L4-API-digital-smooth-calibration.md)

