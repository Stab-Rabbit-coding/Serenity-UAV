# Use internal pull-up resistor on tamper pin {#id_33255}

The internal pull-up resistor in the tamper input pad is only applied for a short period of time \(1, 2, 4 or 8 RTCCLK cycles\). Using this RTC internal pull-up resistor instead of standard I/O pull-up/pull-down or external pull-up/pull-down ensures a lowest power consumption.

The trade-off between the tamper detection latency and the power consumption by the RTC internal pull-up can be optimized using TAMPFREQ\[2:0\], that determines the frequency of the tamper sampling from 128 Hz to 1 Hz when RTCCLK equals 32768 Hz.

**Note:** Refer to the product datasheet/reference manual for the availability/electrical characteristics of the pull‑up resistors.

**Parent topic:**[Reduce power consumption](AN4759_Reduce-power-consumption.md)

