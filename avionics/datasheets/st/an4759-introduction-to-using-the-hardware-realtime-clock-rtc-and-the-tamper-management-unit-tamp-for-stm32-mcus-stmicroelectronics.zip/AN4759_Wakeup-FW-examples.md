# Wakeup firmware examples {#id_33202}

The RTC comes with a set of example projects so that the user can quickly become familiar with this peripheral. Refer to the X-CUBE-RTC Expansion Package for a complete projects list.

For example, the user can find the following projects concerning wakeup:

-   For the NUCLEO-L412RB-P equipped with an RTC3:

    STM32Cube\_FW\_L4\_Vx.y.z\\Projects\\NUCLEO-L412RB-P\\Examples\_LL\\RTC\\RTC\_ExitStandbyWithWakeUpTimer

-   For the NUCLEO-G071RB equipped with an RTC3:

    STM32Cube\_FW\_G0\_Vx.y.z\\Projects\\NUCLEO-G071RB\\Examples\_LL\\RTC\\RTC\_ExitStandbyWithWakeUpTimer\_Init

-   For the NUCLEO-G431RB equipped with an RTC3:

    STM32Cube\_FW\_G4\_Vx.y.z\\Projects\\NUCLEO-G431RB\\Examples\_LL\\RTC\\RTC\_ProgrammingTheWakeUpTime


If one example is not available in the X-CUBE-RTC for a given STM32 MCU, the user can adapt it.

**Parent topic:**[RTC periodic wakeup unit](AN4759_RTC-periodic-wakeup.md)

