# Alarm firmware examples {#id_33188}

The RTC comes with a set of example projects so that the user can quickly become familiar with this peripheral. Refer to the X-CUBE-RTC Expansion Package for a complete projects list.

For example, the user can find the following projects concerning alarms:

-   For the NUCLEO-L412RB-P equipped with an RTC3:
    -   STM32Cube\_FW\_L4\_Vx.y.z\\Projects\\NUCLEO-L412RB-P\\Examples\\ RTC\\RTC\_Alarm
    -   STM32Cube\_FW\_L4\_Vx.y.z\\Projects\\NUCLEO-L412RB-P\\Examples\_LL\\RTC\\RTC\_Alarm
    -   STM32Cube\_FW\_L4\_Vx.y.z\\Projects\\NUCLEO-L412RB-P\\Examples\_LL\\RTC\\RTC\_Alarm\_Init

If one example is not available in the X-CUBE-RTC for a given STM32 MCU, the user can adapt it.

**Parent topic:**[RTC alarms](AN4759_RTC-alarms.md)

