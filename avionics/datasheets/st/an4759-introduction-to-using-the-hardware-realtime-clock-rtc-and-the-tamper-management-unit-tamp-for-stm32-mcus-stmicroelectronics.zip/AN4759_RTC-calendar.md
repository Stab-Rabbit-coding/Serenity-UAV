# RTC calendar {#id_33174}

A calendar keeps track of the time \(hours, minutes and seconds\) and date \(day, week, month, year\). The RTC calendar offers the following features to easily configure and display the calendar data fields:

-   Calendar with subseconds \(not programmable\), seconds, minutes, hours \(12 h/24 h format\), day of the week \(day\), day of the month \(date\), month, year
-   Calendar in BCD format
-   Automatic management of 28-, 29- \(leap year\), 30-, and 31-day months
-   Daylight saving time adjustment programmable by software

![](DT19524.svg "RTC calendar fields")

-   **[Software calendar](AN4759_SW-calendar.md)**  

-   **[RTC hardware calendar](AN4759_RTC-HW-calendar.md)**  

-   **[Initialize the calendar](AN4759_Initialize-calendar.md)**  

-   **[RTC clock configuration](AN4759_RTC-clock-configuration.md)**  

-   **[Calendar firmware examples](AN4759_Calendar-FW-examples.md)**  


**Parent topic:**[Advanced RTC features](AN4759_Adv-RTC-features.md)

