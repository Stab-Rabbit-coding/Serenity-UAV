# RTC alarms {#id_33183}

-   **[RTC alarm configuration](AN4759_RTC-alarm-config.md)**  

-   **[Alarm subsecond configuration](AN4759_Alarm-subsecond-config.md)**  

-   **[Alarm firmware examples](AN4759_Alarm-FW-examples.md)**  


**Parent topic:**[Advanced RTC features](AN4759_Adv-RTC-features.md)

