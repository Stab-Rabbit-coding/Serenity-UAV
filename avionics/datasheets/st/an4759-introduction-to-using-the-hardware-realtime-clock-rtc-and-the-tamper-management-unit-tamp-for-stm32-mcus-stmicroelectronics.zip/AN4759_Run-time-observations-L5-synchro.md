# Run time observations {#id_33507}

The following steps are needed to check the correct functionality:

-   Set the SYNCHRO\_ACTIVATED to 0 and observe the `time_elapsed` variable deriving \(getting away from 255/1 sec\). The user can monitor it in Debug mode.
-   Set the SYNCHRO\_ACTIVATED to 1 and observe that the `time_elapsed` variable derivation is less important.

`time_elapsed` embodies the 1-second period measured for RTC.

**Note:** A typical quartz has an uncertainty of 53 s/month. This uncertainty must be attenuated with synchronization that is efficient if the clock used \(external 16 MHz in the present case\) has a better uncertainty. Using an HSE X3 crystal is not so efficient if the LSE crystal has the same uncertainty.

To check that the application runs properly, the user can also visualize the user LED2 blinking each second and the RTC\_OUT CALIB output on the PB2 pin \(these two observations do not witness the efficiency of the synchronization but can help the user to understand what happens\).

**Parent topic:**[Synchronization application example \(STM32L5\)](AN4759_Synchro-application-example-L5.md)

