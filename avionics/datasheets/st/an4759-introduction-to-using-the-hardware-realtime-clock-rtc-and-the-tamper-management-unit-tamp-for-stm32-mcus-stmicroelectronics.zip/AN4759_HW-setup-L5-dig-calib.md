# Hardware setup {#id_33494}

In order to use the application example project, the user needs a STM32L552ZE-Q Nucleo board \(NUCLEO‑L552ZE-Q\)

![](DT63431.svg "NUCLEO-L552ZE-Q board")

Supply the board using the USB cable and perform the following actions:

-   Connect PE2 to a signal generator driving 1 Hz clock with 3.3 V amplitude. It is advised to control the generated frequency at few ppm.
-   Connect PB2 to an oscilloscope \(the accuracy of the frequency measurement is ideally in the range of 1 ppm\).

**Parent topic:**[Smooth calibration application example \(STM32L5\)](AN4759_Digital-calib-application-example-L5.md)

