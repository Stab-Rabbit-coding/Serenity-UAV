# LED meaning {#id_33285}

Only one LED \(LD2\) is available on the STM32L053R8 Nucleo board. To match with the STM32L4 examples, described in [Tamper detection application example \(STM32L4\)](AN4759_Tamper-detection-application-example-L4.md), LED1, LED2, LED3 and LED4 are replaced by the following integers:

-   `uint32_t LED1_Green_Tamper_event_detected`: set when tamper1 event is detected \(LED1 equivalent\)
-   `uint32_t LED2_Red_Power_On_Reset_occurred`: set when power-on reset is detected \(LED2 equivalent\)
-   `uint32_t LED3_Red_Error`: set in errors cases \(LED3 equivalent\)
-   `uint32_t LED4_Blue_Reset_occurred`: set when reset is detected \(B2 black push button, LED4 equivalent\)

The user can observe these private variables using the live watch feature in the debugger, or on LED LD2 and CN5 pin 6 \(SCK/D13\). Regarding the LED LD2 behavior, see details in main.c file.

**Parent topic:**[Tamper detection application example \(STM32L0\)](AN4759_tamper-detec-application-example-L0.md)

