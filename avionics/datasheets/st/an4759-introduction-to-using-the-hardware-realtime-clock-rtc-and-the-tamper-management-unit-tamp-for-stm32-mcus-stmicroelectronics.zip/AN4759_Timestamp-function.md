# Timestamp function {#id_33217}

The timestamp feature is used to automatically save the current calendar when some specific events occur.

![](DT19532.svg "Timestamp event procedure")

When this function is enabled, the calendar is saved in the timestamp registers \(RTC\_TSTR, RTC\_TSDR, RTC\_TSSSR\) when an internal or external timestamp event is detected. When a timestamp event occurs, the timestamp flag bit \(TSF\) is set in RTC\_ISR \(RTC2\)/RTC\_SR \(RTC3\).

The following events can generate a timestamp:

-   Edge detection on the RTC\_TS I/O
-   Tamper event detection \(from all RTC\_TAMP I/Os\)
-   Switch to VBAT when the main supply if powered off \(available for example on STM32L4 series, see the product reference manual and datasheet to verify availability for other products\)

**Table 1. Timestamp features**

<table>
<thead>
<tr>
<th>What</th>
<th>How</th>
<th>Comments</th>
</tr>
</thead>
<tbody>
<tr>
<td>Enable timestamp.</td>
<td>Set to 1 TSE, ITSE or TAMPTS in RTC_CR.</td>
<td>TAMPTS is only available on RTC3 to allow tamper events to trigger timestamp.</td>
</tr>
<tr>
<td>Detect a timestamp event by interrupt.</td>
<td>Set TSIE in RTC_CR.</td>
<td>An interrupt is generated when a timestamp event occurs.</td>
</tr>
<tr>
<td>Detect a timestamp event by polling.</td>
<td>Poll on the timestamp flags (TSF or ITSF<sup><a href="#fn1">1</a></sup>) in RTC_ISR (RC2)/RTC_SR (RTC3).</td>
<td>To clear the flag, write zero on TSF or ITSF<sup><a href="#fn2">2</a></sup>.</td>
</tr>
<tr>
<td>Detect a timestamp overflow event.<sup><a href="#fn3">3</a></sup></td>
<td>Check on TSOVF<sup><a href="#fn4">4</a></sup>) in RTC_ISR (RC2)/RTC_SR (RTC3).</td>
<td><ul>
<li>To clear the flag, write zero in TSOVF.</li>
<li>RTC_TSTR, RTC_TSDR, and RTC_TSSSR maintain the results of the previous event.</li>
<li>If a timestamp event occurs immediately after TSF is supposed to be cleared, then both TSF and TSOVF are set.</li>
</ul></td>
</tr>
</tbody>
</table>

-   **[Timestamp firmware examples](AN4759_Timestamp-FW-examples.md)**  


**Parent topic:**[Advanced RTC features](AN4759_Adv-RTC-features.md)

<a id="fn1"></a>

[^1]: TSF is set two ck\_apre cycles after the timestamp event occurs, due to the synchronization process.<a id="fn2"></a>

[^2]: To avoid masking a timestamp event occurring at the same moment, the application must not write 0 into TSF unless the software already read this bit at 1.<a id="fn3"></a>

[^3]: The timestamp overflow event is not connected to an interrupt.<a id="fn4"></a>

[^4]: There is no delay in TSOVF setting: if two timestamp events are close to each other, TSOVF can be seen as 1 while TSF is still 0. It is then recommended to poll TSOVF only after TSF has been set.

