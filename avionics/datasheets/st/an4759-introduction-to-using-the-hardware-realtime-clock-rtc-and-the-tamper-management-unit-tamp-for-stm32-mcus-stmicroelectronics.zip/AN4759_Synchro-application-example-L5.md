# Synchronization application example \(STM32L5\) {#id_33502}

-   **[Hardware setup](AN4759_HW-setup-L5-synchro.md)**  

-   **[Software setup](AN4759_SW-setup-L5-synchro.md)**  

-   **[Synchronization application principle](AN4759_Synchro-appli-principle.md)**  

-   **[Run time observations](AN4759_Run-time-observations-L5-synchro.md)**  


**Parent topic:**[STM32L5 API and synchronization application example](AN4759_STM32L5-API-synchro-application-example.md)

