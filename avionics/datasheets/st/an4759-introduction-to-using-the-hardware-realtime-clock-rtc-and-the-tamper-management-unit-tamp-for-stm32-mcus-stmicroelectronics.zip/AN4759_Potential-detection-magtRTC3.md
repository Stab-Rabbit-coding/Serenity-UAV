# Potential detection management \(RTC3 only\) {#id_33238}

If TAMPxNOER = 0 in TAMP\_CR2 or ITAMPxNOER = 0 in TAMP\_CR3, the backup registers and other device secrets are automatically erased by hardware on an external \(passive or active\) or internal tamper event.

In order to perform software filtering of the tamper event, the user must configure these bits to 1. In this case, the backup registers and device secrets are not erased but their read/write access is blocked as long as at least one of the tamper flag is set \(TAMPxF and ITAMPxF\). These tamper events are considered as potential tampers, and the user can investigate if the tamper event corresponds to a true or to a false tamper, and then take the necessary actions.

If the user confirms it is a true tamper detection, backup registers and device secrets can be erased by setting BKERASE = 1 in TAMP\_CR2. If the tamper is not confirmed and is considered a false detection, the user must clear the tamper status flag. When all tamper flags are cleared, the access to backup registers and device secrets is possible again.

By associating the NOERASE feature with the IWDG \(independent watchdog\), a timeout can be implemented to automatically launch hardware erasing after a potential tamper detection. On some products, the ITAMP11 is associated to the IWDG reset. In this case, if a tamper event in NOERASE configuration is detected, and if a IWDG reset occurs before the software has cleared the tamper flag, the backup registers and device secrets are automatically erased by hardware. The probability that a software issue, preventing from refreshing the watchdog, occurs at the same time than a tamper detection is very low so the hardware considers it is a real attack.

**Parent topic:**[RTC tamper detection function](AN4759_RTC-tamper-detection.md)

