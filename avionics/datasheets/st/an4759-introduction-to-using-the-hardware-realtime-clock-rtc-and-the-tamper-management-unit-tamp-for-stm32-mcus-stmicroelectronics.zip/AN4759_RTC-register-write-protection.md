# RTC register write protection {#id_33250}

To protect the RTC registers against possible unintentional write accesses after reset, the RTC registers are initially locked after a Backup domain reset. These registers must be unlocked to update the current calendar time and date.

The write access to the RTC registers is enabled by writing a key in RTC\_WPR, **only** with the following sequence:

1.  Write 0xCA in RTC\_WPR.
2.  Write 0x53 in RTC\_WPR.

Any other write access sequence to RTC\_WPR activates the write-protection mechanism for the RTC registers.

**Parent topic:**[RTC safety aspects](AN4759_RTC-safety-aspects.md)

