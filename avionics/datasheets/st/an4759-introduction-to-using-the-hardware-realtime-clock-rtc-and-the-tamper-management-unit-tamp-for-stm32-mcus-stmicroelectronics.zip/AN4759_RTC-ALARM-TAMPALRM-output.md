# RTC\_ALARM \(RTC2\)/TAMPALRM \(RTC3\) output {#id_33246}

The alarm, wakeup and tamper flags can be routed to the RTC outputs \(one output for RTC2 type, three for RTC3 type\) thanks to OSEL\[1:0\] in RTC\_CR.

## For RTC2 type { .section}

-   OSEL\[1:0\] = 01 roots alarm A to the RTC\_ALARM output.
-   OSEL\[1:0\] = 10 roots alarm B to the RTC\_ALARM output.
-   OSEL\[1:0\] = 11 roots wakeup flag to the RTC\_ALARM output.

Once OSEL\[1:0\] is fixed, the output reflects the selected flag stored in RTC\_ISR.

## For RTC3 type { .section}

The OSEL\[1:0\] selection follows the same principle as for RTC2 but, when TAMPOE = 1 in RTC\_CR, tamper flags are ORed with the flag already selected \(alarm A, alarm B or wakeup\) before the OR result to be rooted to the TAMPALRM output.

If TAMPOE = 1 and OSEL\[1:0\] = 00, TAMPALRM output reflects only the tamper flags.

For both RTC2 and RTC3 types, the output pin polarity is selected with POL in RTC\_CR. When POL = 1, the opposite state of the flag concerned is output on RTC\_ALARM \(RTC2\)/TAMPALRM \(RTC3\). The pin can also be configured as open drain or push-pull with the ALARMOUTTYPE \(RTC2\)/TAMPALRM\_TYPE \(RTC3\) bit of the same register \(0 for push-pull, 1 for open-drain\).

For RTC3, an internal pull-up can be added to the output pin by setting TAMPALRM\_PU = 1 in RTC\_CR.

**Parent topic:**[Alternate function RTC outputs](AN4759_Alternate-function-RTC-outputs.md)

