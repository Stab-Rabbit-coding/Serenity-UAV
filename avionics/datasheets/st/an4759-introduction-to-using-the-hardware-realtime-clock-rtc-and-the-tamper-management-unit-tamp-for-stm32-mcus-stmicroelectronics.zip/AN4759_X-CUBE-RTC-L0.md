# X-CUBE-RTC for tamper detection {#id_33281}

X-CUBE-RTC shows an example where a real-time clock must be maintained alive while using as less power as possible \(STM32CubeExpansion\_AN4759\_RTC\_STM32L\_Vx.y.z\\Projects\\STM32L053R8-Nucleo\\RTC\_Tamper.

The firmware implements:

-   A few hints order to ensure a low current consumption
-   A display in the debugger \(date and time, timestamp date and time\) and on a single LED \(power-up events, reset events, tamper events, error\)
-   Tampering detection capability
-   The ability to timestamp the tampering event
-   The ability to erase the backup registers that may contain sensitive data upon tamper detection

The application flowchart is shown in [Figure 1](AN4759_X-CUBE-RTC-L4-tamper-detection.md#fig_t2r_h5n_5pb).

**Parent topic:**[STM32L0 API and tampering detection application example](AN4759_STM32L0-API-tamper-detection.md)

