# Overview of the STM32 MCUs advanced RTC {#id_33172}

The RTC is embedded in STM32 Arm® Cortex®-based MCUs.

![](Arm_logo_black_no_frame.svg)

**Note:**

Arm and Cortex are registered trademarks of Arm Limited \(or its subsidiaries or affiliates\) in the US and/or elsewhere.

Arm and TrustZone are registered trademarks of Arm Limited \(or its subsidiaries or affiliates\) in the US and/or elsewhere.

The Arm word and logo are trademarks of Arm Limited \(or its subsidiaries\) in the US and/or elsewhere. All rights reserved.

The RTC provides a full-featured calendar, alarm, periodic wakeup unit, digital calibration, synchronization, timestamp, and advanced tamper detection.

The RTC features and their implementation can be significantly different \(regarding the registers map for example\) depending on the product. Two RTC types, RTC2 and RTC3, are distinguished and characterized in the table below. These types affect the information presented in the rest of this application note.

**Table 1. RTC/TAMP types**

<table>
<thead>
<tr>
<th colspan="3">Features</th>
<th>RTC2</th>
<th>RTC3</th>
</tr>
</thead>
<tbody>
<tr>
<td colspan="3">RTC clock source (LSE, LSI, HSE with prescaler)</td>
<td>X</td>
<td>X</td>
</tr>
<tr>
<td colspan="3">Binary mode</td>
<td>-</td>
<td>X</td>
</tr>
<tr>
<td colspan="3">Mixed mode (BCD and binary)</td>
<td>-</td>
<td>X</td>
</tr>
<tr>
<td rowspan="2">Prescalers</td>
<td colspan="2">Asynchronous</td>
<td>X</td>
<td>X</td>
</tr>
<tr>
<td colspan="2">Synchronous</td>
<td>X</td>
<td>X</td>
</tr>
<tr>
<td rowspan="7">Calendar</td>
<td rowspan="3">Time</td>
<td>12 h/24 h format</td>
<td>X</td>
<td>X</td>
</tr>
<tr>
<td>Hour, minute, second</td>
<td>X</td>
<td>X</td>
</tr>
<tr>
<td>Subsecond</td>
<td>X</td>
<td>X</td>
</tr>
<tr>
<td colspan="2">Date</td>
<td>X</td>
<td>X</td>
</tr>
<tr>
<td colspan="2">Daylight operation</td>
<td>X</td>
<td>X</td>
</tr>
<tr>
<td colspan="2">Bypass the shadow registers</td>
<td>X</td>
<td>X</td>
</tr>
<tr>
<td colspan="2">Power optimization mode</td>
<td>-</td>
<td>X</td>
</tr>
<tr>
<td rowspan="7">Alarm</td>
<td rowspan="2">Alarms available</td>
<td>Alarm A</td>
<td>X</td>
<td>X</td>
</tr>
<tr>
<td>Alarm B</td>
<td>X</td>
<td>X</td>
</tr>
<tr>
<td rowspan="3">Time</td>
<td>12 h/24 h format</td>
<td>X</td>
<td>X</td>
</tr>
<tr>
<td>Hour, minutes, seconds</td>
<td>X</td>
<td>X</td>
</tr>
<tr>
<td>Subseconds</td>
<td>X</td>
<td>X</td>
</tr>
<tr>
<td colspan="2">Date or week day</td>
<td>X</td>
<td>X</td>
</tr>
<tr>
<td colspan="2">Binary mode alarm</td>
<td>-</td>
<td>X</td>
</tr>
<tr>
<td rowspan="15">Tamper detection</td>
<td rowspan="3">Tamper effects</td>
<td>Backup registers erase<sup><a href="#fn1">1</a></sup></td>
<td>X</td>
<td>X</td>
</tr>
<tr>
<td>Interruption</td>
<td>X</td>
<td>X</td>
</tr>
<tr>
<td>Trigger for low-power timer</td>
<td>X</td>
<td>X</td>
</tr>
<tr>
<td colspan="2">Configurable edge detection</td>
<td>X</td>
<td>X</td>
</tr>
<tr>
<td colspan="2">Configurable level detection (filtering, sampling and precharge configuration, internal pull-up)</td>
<td>X</td>
<td>X</td>
</tr>
<tr>
<td colspan="2">Internal tamper events</td>
<td>-</td>
<td>X</td>
</tr>
<tr>
<td colspan="2">External tamper inputs</td>
<td>X</td>
<td>X</td>
</tr>
<tr>
<td colspan="2">VBAT mode pins</td>
<td>X</td>
<td>X</td>
</tr>
<tr>
<td colspan="2">NOERASE mode</td>
<td>X</td>
<td>X</td>
</tr>
<tr>
<td colspan="2">Independent watchdog linked to an internal tamper for potential detection timeout</td>
<td>-</td>
<td>X</td>
</tr>
<tr>
<td colspan="2">Active tamper</td>
<td>-</td>
<td>X</td>
</tr>
<tr>
<td colspan="2">Monotonic counter</td>
<td>-</td>
<td>X</td>
</tr>
<tr>
<td colspan="2">SAES key storage</td>
<td>-</td>
<td>X</td>
</tr>
<tr>
<td colspan="2">Secure protection modes</td>
<td>-</td>
<td>X</td>
</tr>
<tr>
<td colspan="2">Privileged protection mode</td>
<td>-</td>
<td>X</td>
</tr>
<tr>
<td rowspan="6">Timestamp</td>
<td colspan="2">Configurable input mapping</td>
<td>X</td>
<td>X</td>
</tr>
<tr>
<td rowspan="2">Time</td>
<td>Hour, minute, second</td>
<td>X</td>
<td>X</td>
</tr>
<tr>
<td>Subsecond</td>
<td>X</td>
<td>X</td>
</tr>
<tr>
<td colspan="2">Date (day, month)</td>
<td>X</td>
<td>X</td>
</tr>
<tr>
<td colspan="2">Timestamp on tamper detection event</td>
<td>X</td>
<td>X</td>
</tr>
<tr>
<td colspan="2">Timestamp on switch to VBAT mode</td>
<td>X</td>
<td>X</td>
</tr>
<tr>
<td rowspan="2">Wakeup unit</td>
<td colspan="2">Clock source available</td>
<td>X</td>
<td>X</td>
</tr>
<tr>
<td colspan="2">Hardware automatic flag clearance</td>
<td>X</td>
<td>X</td>
</tr>
<tr>
<td rowspan="5">RTC outputs</td>
<td rowspan="3">TAMPALRM</td>
<td>Alarm event</td>
<td>X</td>
<td>X</td>
</tr>
<tr>
<td>Wakeup event</td>
<td>X</td>
<td>X</td>
</tr>
<tr>
<td>Tamper event</td>
<td>-</td>
<td>X</td>
</tr>
<tr>
<td rowspan="2">CALIB</td>
<td>512 Hz</td>
<td>X</td>
<td>X</td>
</tr>
<tr>
<td>1 Hz</td>
<td>X</td>
<td>X</td>
</tr>
<tr>
<td rowspan="2">Smooth digital calibration</td>
<td colspan="2">Smooth calibration</td>
<td>X</td>
<td>X</td>
</tr>
<tr>
<td colspan="2">Power optimization mode</td>
<td>-</td>
<td>X</td>
</tr>
<tr>
<td colspan="3">RTC synchronization</td>
<td>X</td>
<td>X</td>
</tr>
<tr>
<td colspan="3">Reference clock detection</td>
<td>X</td>
<td>X</td>
</tr>
<tr>
<td rowspan="2">Backup registers</td>
<td colspan="2">Reset on a tamper detection</td>
<td>X</td>
<td>X</td>
</tr>
<tr>
<td colspan="2">Reset when Flash memory readout protection is disabled</td>
<td>X</td>
<td>X</td>
</tr>
<tr>
<td colspan="3">RTC secure protection mode</td>
<td>-</td>
<td>X</td>
</tr>
<tr>
<td colspan="3">RTC privileged protection mode</td>
<td>-</td>
<td>X</td>
</tr>
</tbody>
</table>

The RTC acts as an independent binary-coded decimal \(BCD\) timer/counter. For the RTC3 type, a binary and a mixed \(both binary and BCD\) modes are available.

A given feature can be available for a RTC type but not implemented on all products \(see [Table 1](AN4759_Adv-RTC-features.md#table_clz_c42_rpb) and [AN4759\_Adv-RTC-features.md\#table\_hqc\_shf\_rpb](AN4759_Adv-RTC-features.md#table_hqc_shf_rpb) for more details\).

The table below specifies which RTC type is implemented on which product.

**Table 2. RTC type on STM32 MCUs**

|RTC type|STM32 MCUs|
|:------:|----------|
|RTC2|STM32F0 series, STM32F2 series, STM32F3 series, STM32F4 series, STM32F7 series, STM32H72/H73/H74/H75xxx, STM32L0 series, STM32L1 series, STM32L43/L44/L45/46/47/48xxx, STM32L4R5/Q5 line, STM32L4R7/S7 line, STM32L4R9/S9 line, STM32WB series, STM32WB0 series|
|RTC3|STM32C0 series, STM32G0 series, STM32G4 series, STM32H5 series, STM32H7A3/7B3 line, STM32H7Rx/7Sx line, STM32L41/L42xxx, STM32L4P5/Q5 line, STM32L5 series, STM32N6 series, STM32U0 series, STM32U3 series, STM32U5 series, STM32WL series, STM32WBA series|

<a id="fn1"></a>

[^1]: Depending on devices, other resources can also be erased.

