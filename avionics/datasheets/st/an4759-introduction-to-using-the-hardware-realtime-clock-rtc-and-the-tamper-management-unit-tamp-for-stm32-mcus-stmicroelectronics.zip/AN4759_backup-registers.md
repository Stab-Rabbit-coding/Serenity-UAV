# Backup registers {#id_33243}

The 32-bit backup registers \(RTC\_BKPxR\) are reset when a tamper detection event occurs. These registers are powered-on by VBAT when VDD is switched off \(some products do not implement this feature, like STM32L0 series and STM32L1 series. Refer to [Table 1](AN4759_Adv-RTC-features.md#table_clz_c42_rpb) and [AN4759\_Adv-RTC-features.md\#table\_hqc\_shf\_rpb](AN4759_Adv-RTC-features.md#table_hqc_shf_rpb). They are not reset by a system reset, and their contents remain valid when the device operates in low-power mode.

For RTC2 type on STM32L0, STM32L4, and STM32F7 series, the 32-bit backup registers \(RTC\_BKPxR\) are not reset if TAMPxNOERASE = 1 or if TAMPxMF = 1 in RTC\_TAMPCR.

For RTC3 type, the 32-bit backup registers \(TAMP\_BKPxR\) are not reset if TAMPxNOER = 1 or if TAMPxMSK = 1 in TAMP\_CR3.

For RTC2 and RTC3, disabling the backup register reset feature allows an LPTIM event to be triggered from the tamper pin without erasing the backup registers. The application can then take benefit of the tamper input digital filtering, either to generate triggers or to generate interrupts.

**Note:** The VBAT availability, the LPTIM availability and the number of backup registers depend on the product. Refer to [Table 1](AN4759_Adv-RTC-features.md#table_clz_c42_rpb) and [AN4759\_Adv-RTC-features.md\#table\_hqc\_shf\_rpb](AN4759_Adv-RTC-features.md#table_hqc_shf_rpb).

The RTC3 backup registers can be protected against nonsecure or unprivileged accesses \(see [Reduce power consumption](AN4759_Reduce-power-consumption.md)\).

BKPRWDPROT\[7:0\] and BKPWDPROT\[7:0\] in TAMP\_SMCR \(except for the STM32U3 and STM32U5 series: BKPRWSEC\[7:0\] and BKPWSEC\[7:0\] in TAMP\_SECCFGR\) are used to program the backup registers offset, delimiting three protection zones for the backup registers:

-   Zone 1: read and write secure
-   Zone 2: read nonsecure and write secure
-   Zone 3: read and write nonsecure

## Secure AES boot hardware key \(RTC3 only\) {#section_g33_13d_vpb .section}

**Note:** This section is valid only for products embedding a SAES.

The backup registers can be used to store the BHK \(boot hardware key\) of the SAES \(secure AES\). If the device supports Arm® TrustZone® security, the eight first backup registers \(TAMP\_BKP0R to TAMP\_BKP7R\) must be configured as belonging to the zone 1 \(r/w secure\) by setting BKPRWSEC ≥ 8 in TAMP\_SECCFGR.

Once the registers are written with the key, BHKLOCK must be set to 1 in TAMP\_SECCFGR to definitively block the read/write accesses to these registers \(any reading returns 0 and any writing is ignored\). BHKLOCK can only be cleared by hardware after a tamper event or when readout protection is disabled. In these two case, the backup registers are also erased. After BHKLOCK is set, the SAES coprocessor can use the BHK thanks to a private hardware bus \(see the SAES section in the product reference manual and more precisely KEYSEL bits in the SAES control register\).

**Parent topic:**[Advanced RTC features](AN4759_Adv-RTC-features.md)

