# Tamper detection firmware examples {#id_33240}

The RTC comes with a set of example projects so that the user can quickly become familiar with this peripheral. Refer to the STM32Cube MCU Package of the product for a complete projects list.

For example, the user can find the following projects concerning tamper detection:

-   For most microcontrollers equipped with either an RTC2 or an RTC3:

    STM32Cube\_FW\_product\_Vx.y.z\\Projects\\board\\Examples\\RTC\\RTC\_Tamper

-   For many products equipped with either an RTC2 or an RTC3:

    STM32Cube\_FW\_product\_Vx.y.z\\Projects\\board\\Examples\_LL\\RTC\\RTC\_Tamper\_Init

-   For the STM32L552E evaluation board, the STM32H7B3I evaluation board and the STM32U575ZI Nucleo board equipped with an RTC3:

    STM32Cube\_FW\_product\_Vx.y.z\\Projects\\board\\Examples\\RTC\\RTC\_ActiveTamper


If an example is not available in the STM32Cube for a given STM32 MCU, the user can adapt it from a similar example.

**Parent topic:**[RTC tamper detection function](AN4759_RTC-tamper-detection.md)

