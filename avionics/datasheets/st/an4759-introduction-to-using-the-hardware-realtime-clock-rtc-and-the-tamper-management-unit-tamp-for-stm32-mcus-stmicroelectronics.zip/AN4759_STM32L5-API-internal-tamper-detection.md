# STM32L5 API and internal tamper detection application example {#id_33517}

-   **[X-CUBE-RTC for internal tamper detection application](AN4759_X-Cube-RTC-internal-tamper.md)**  


