# X-CUBE-RTC for reference clock detection application {#id_33511}

X-CUBE-RTC shows an implementation of the reference clock detection \(STM32CubeExpansion\_AN4759\_RTC\_STM32L\_Vx.y.z\\Projects\\NUCLEO-L552ZE-Q\\RTC\_RefClockDetection\).

The firmware implements:

-   TIM1 in Master mode with update interrupt activated to generate an interruption each second. It is configured to use the HSI clock through a PLL to be clocked by a 100 MHz signal \(HSI is less precise than the LSE clocking the RTC but allows the measure of the RTC period without the need to inject another signal than the 50/60 Hz one\).
-   the RTC with the activation of the reference clock detection feature
-   GPIO: RTC\_OUT CALIB \(PB2\) to check if the RTC 1 Hz output frequency is really 1 Hz. The user LED2 \(PB7\) to visualize the 1-second period and the good working of the application. The RTC\_REFIN pin \(PB15\) to host the 50/60 Hz signal used as the reference clock detected.

**Parent topic:**[STM32L5 API and reference clock detection application example](AN4759_STM32L5-API-ref-clock-detection.md)

