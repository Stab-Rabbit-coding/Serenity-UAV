# Periodic timebase/wakeup configuration for clock configuration 1 {#id_33197}

The figure below shows the prescaler connection to the timebase/wakeup unit and the table below gives the timebase/wakeup clock resolutions corresponding to configuration 1.

The prescaler depends on the wakeup clock selection as follows:

-   WUCKSEL\[2:0\] =000: RTCCLK/16 clock selected
-   WUCKSEL\[2:0\] =001: RTCCLK/8 clock selected
-   WUCKSEL\[2:0\] =010: RTCCLK/4 clock selected
-   WUCKSEL\[2:0\] =011: RTCCLK/2 clock selected

![](DT19529.svg "Prescalers connected to the timebase/wakeup unit for configuration 1")

**Table 1. Timebase/wakeup unit period resolution with clock configuration 1**

<table>
<thead>
<tr>
<th rowspan="2">Clock source</th>
<th colspan="2">Wakeup period resolution</th>
</tr>
<tr>
<th>WUCKSEL[2:0] = 000 (div16)</th>
<th>WUCKSEL[2:0] = 011 (div2)</th>
</tr>
</thead>
<tbody>
<tr>
<td>LSE = 32 768 Hz</td>
<td>488.28 µs</td>
<td>61.035 µs</td>
</tr>
</tbody>
</table>

When RTCCLK= 32768 Hz, the minimum timebase/wakeup resolution is 61.035 µs, and the maximum resolution is 488.28 µs. As a result:

-   The minimum timebase/wakeup period is \(0x0001 + 1\) x 61.035 µs = 122.07 µs.

    The timebase/wakeup timer counter WUT\[15:0\] cannot be set to 0x0000 with WUCKSEL\[2:0\] = 011 \(fRTCCLK/2\) because this configuration is prohibited. Refer to the product reference manuals for more details.

-   The maximum timebase/wakeup period is \(0xFFFF+ 1\) x 488.28 µs = 32 s.

**Parent topic:**[Maximum and minimum RTC wakeup period](AN4759_Max-min-RTC-wakup-period.md)

