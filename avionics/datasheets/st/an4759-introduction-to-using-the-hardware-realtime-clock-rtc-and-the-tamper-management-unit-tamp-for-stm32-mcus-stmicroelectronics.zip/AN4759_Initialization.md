# Initialization {#id_33233}

If INITS is not set in TAMP\_ATOR register, the active tamper initialization must be done:

-   Configure the active tamper clock prescaler with ATCKSEL in TAMP\_ATCR1. Set the filter and associate TAMP in and out pins as needed \(explained above\).
-   Enable tamper pins used in TAMP\_CR1 register \(all in the same write access\).
-   Feed the PRNG and wait for SEEDF to be cleared. Then backup registers are protected by active tamper.

If INITS is set, the tamper active feature is already initialized. The user only must update the PRNG seed for a more robust randomization.

**Parent topic:**[Active tamper detection \(RTC3 only\)](AN4759_Active-tamper-detectionRTC3.md)

