# Reduce power consumption {#id_33253}

The RTC is designed to minimize the power consumption and can be configured to optimize further its consumption.

-   **[Use the right power reduction mode](AN4759_Use-right-power-reduction-mode.md)**  

-   **[Use internal pull-up resistor on tamper pin](AN4759_Use-internal-pullup-resistor-tamper-pin.md)**  

-   **[Set RTC prescalers](AN4759_Set-RTC-prescalers.md)**  

-   **[External optimization factors](AN4759_External-optimization-factors.md)**  

-   **[Low-power management firmware examples](AN4759_Low-power-managt-FW-examples.md)**  


**Parent topic:**[Advanced RTC features](AN4759_Adv-RTC-features.md)

