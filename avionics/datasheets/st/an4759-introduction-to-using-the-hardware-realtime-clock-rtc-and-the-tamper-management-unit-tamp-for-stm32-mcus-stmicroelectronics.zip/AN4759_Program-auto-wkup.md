# Program the auto-wakeup unit {#id_33191}

The table below describes the steps required to configure the auto-wakeup unit.

**Table 1. Steps to configure the auto-wakeup unit**

<table>
<thead>
<tr>
<th>Step</th>
<th>What</th>
<th>How</th>
<th>Comment</th>
</tr>
</thead>
<tbody>
<tr>
<td>1</td>
<td>Disable write protection on RTC registers.</td>
<td>Write 0xCA and then 0x53 into RTC_WPR.</td>
<td>The RTC registers can be modified.</td>
</tr>
<tr>
<td>2</td>
<td>Disable the wakeup timer.</td>
<td>Clear WUTE bit in RTC_CR.</td>
<td>-</td>
</tr>
<tr>
<td>3</td>
<td>Ensure access to wakeup auto-reload counter and WUCKSEL[2:0] are allowed.</td>
<td>Poll WUTWF until it is set in RTC_ISR (RTC2)/RTC_ICSR (RTC3)</td>
<td><ul>
<li>For RTC2: It takes around two RTCCLK clock cycles due to clock synchronization.</li>
<li>For RTC3<sup><a href="#fn1">1</a></sup>:<ul>
<li>If WUCKSEL[2] = 0, WUTWF is set. It takes around 1 ck_wut + 1 RTCCLK cycles after WUTE is cleared.</li>
<li>If WUCKSEL[2] = 1, WUTWF is set. It takes up to 1 ck_apre + 1 RTCCLK cycles after WUTE is cleared.</li>
</ul>
</li>
</ul></td>
</tr>
<tr>
<td>4</td>
<td>Program the value into the wakeup timer.</td>
<td>Set WUT[15:0] in RTC_WUTR.<p>For RTC3, the user must also program WUTOCLR[15:0]<sup><a href="#fn2">2</a></sup>in RTC_WUCR</p></td>
<td rowspan="2">See <a href="AN4759_Max-min-RTC-wakup-period.md">Maximum and minimum RTC wakeup period</a>.</td>
</tr>
<tr>
<td>5</td>
<td>Select the desired clock source.</td>
<td>Program WUCKSEL[2:0] in RTC_CR.</td>
</tr>
<tr>
<td>6</td>
<td>Re-enable the wakeup timer.</td>
<td>Set WUTE in RTC_CR.</td>
<td>The wakeup timer restarts counting down.</td>
</tr>
<tr>
<td>7</td>
<td>Enable write protection on RTC registers.</td>
<td>Write 0xFF into the RTC_WPR.</td>
<td>The RTC registers cannot be modified.</td>
</tr>
</tbody>
</table>

**Parent topic:**[RTC periodic wakeup unit](AN4759_RTC-periodic-wakeup.md)

<a id="fn1"></a>

[^1]: ck\_wut is the wakeup timer clock input, and ck\_spre the clock output by the RTC synchronous prescaler \(usually 1 Hz\).<a id="fn2"></a>

[^2]: WUTOCLR bits are only available on RTC3 type. They are used to choose if the WUTF flag is cleared by software \(WUTOCLR = 0x0000\) or automatically cleared by hardware when the auto-reload down counter reaches WUTOCLR value \(0x0000 < WUTOCLR ≤ WUT\). For RTC2 type, WUTF must always be cleared by software.

