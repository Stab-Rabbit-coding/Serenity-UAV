# STM32L5 API and reference clock detection application example {#id_33510}

STM32CubeL5 firmware libraries are the same as in [STM32CubeL5 firmware libraries for smooth calibration application](AN4759_STM32CubeL5-FW-libraries.md).

-   **[X-CUBE-RTC for reference clock detection application](AN4759_X-CUBE-RTC-L5-ref-clock-detection.md)**  

-   **[Reference clock detection application example](AN4759_Ref-clock-detection.md)**  


