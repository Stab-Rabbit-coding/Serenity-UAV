# External optimization factors {#id_33258}

The prescaler linked to the LSI clock can also optimize the consumption. The user needs to select the LSI as RTC clock source. This prescaler divides LSI by 128 to get a rough 250 Hz clock instead of the former 32 kHz. This is activated by LSIPRE in RCC\_CSR.

Concerning the LSE, users can select a crystal that allows setting the driving strength to the lowest level. The driving strength is determined by the chosen crystal parameters, such as load capacitance, ESR, and shunt capacitance, which define a critical transconductance \(gmcrit\). For more information, see *AN2867*.

Reducing the driving strength to the lowest level can lower consumption to a typical 250 nA, compared to 630 nA for high drive capability.

Set LSEDRV to 00 in RCC\_BDCR to select the lowest driving strength.

**Parent topic:**[Reduce power consumption](AN4759_Reduce-power-consumption.md)

