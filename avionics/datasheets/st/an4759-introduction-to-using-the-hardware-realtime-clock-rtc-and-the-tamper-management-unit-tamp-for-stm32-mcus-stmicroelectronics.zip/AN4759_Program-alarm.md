# Program the alarm {#id_33185}

The table below describes the steps required to configure alarm A.

**Table 1. Steps to confirm alarm A**

|Step|What|How|Comment|
|:--:|----|---|-------|
|1|Disable write protection on RTC registers.|Write 0xCA and then 0x53 into RTC\_WPR.|The RTC registers can be modified.|
|2|Disable alarm A.|Clear ALRAE[^1] in RTC\_CR[^2].|-|
|3[^3]|Check that RTC\_ALRMAR can be accessed.|Poll ALRAWF[^4] until it is set in RTC\_ISR.|It takes around two RTCCLK clock cycles due to clock synchronization.|
|4|Configure the alarm.|Configure RTC\_ALRMAR[^5].|The alarm hour format must be the same[^6] as the RTC calendar in RTC\_ALRMAR[^5].|
|5|Re-enable alarm A.|Set ALRAE[^7] in RTC\_CR.|-|
|6|Enable write protection on the RTC registers.|Write 0xFF into RTC\_WPR.|The RTC registers can no longer be modified.|

**Parent topic:**[RTC alarm configuration](AN4759_RTC-alarm-config.md)

<a id="fn1"></a>

[^1]: Respectively ALRBE for alarm B.<a id="fn2"></a>

[^2]: RTC alarm registers can only be written when the corresponding RTC alarm is disabled, or during RTC initialization mode.<a id="fn3"></a>

[^3]: Only required for RTC2 type.<a id="fn4"></a>

[^4]: Resp. ALRBWF for alarm B. ALRAWF and ALRBWF does not exist on RTC3 type.<a id="fn5"></a>

[^5]: Respectively RTC\_ALRMBR for alarm B.<a id="fn6"></a>

[^6]: As an example, if the alarm is configured to occur at 3:00:00 PM, the alarm does not occur even if the calendar time is 15:00:00, because the RTC calendar is 24-hour format and the alarm is 12-hour format.<a id="fn7"></a>

[^7]: Respectively ALRBE for alarm B.

