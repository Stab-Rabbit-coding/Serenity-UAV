# Advanced RTC features {#id_33173}

The following tables summarize the RTC features available on each STM32 MCU.

**Table 1. Advanced features for RTC2 type**

<table>
<thead>
<tr>
<th colspan="3" rowspan="2">Features</th>
<th rowspan="2">STM32F0</th>
<th rowspan="2">STM32F2</th>
<th rowspan="2">STM32F3</th>
<th rowspan="2">STM32F4</th>
<th rowspan="2">STM32F7</th>
<th rowspan="2">STM32L0</th>
<th colspan="2">STM32L1</th>
<th rowspan="2">STM32L4<sup><a href="#fn1">1</a></sup> - STM32L4+<sup><a href="#fn2">2</a></sup></th>
<th rowspan="2">STM32H72/H73/H74/H75</th>
<th rowspan="2">STM32WB</th>
<th rowspan="2">STM32WB0</th>
</tr>
<tr>
<th>Cat. 2/3/4/5/6</th>
<th>Cat. 1</th>
</tr>
</thead>
<tbody>
<tr>
<td colspan="3">RTC clock source (LSE, LSI, HSE with prescaler)</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
</tr>
<tr>
<td rowspan="2">Prescalers</td>
<td colspan="2">Asynchronous (number of bits)</td>
<td>X (7)</td>
<td>X (7)</td>
<td>X (7)</td>
<td>X (7)</td>
<td>X (7)</td>
<td>X (7)</td>
<td>X (7)</td>
<td>X (7)</td>
<td>X (7)</td>
<td>X (7)</td>
<td>X (7)</td>
<td>X (7)</td>
</tr>
<tr>
<td colspan="2">Synchronous (number of bits)</td>
<td>X (15)</td>
<td>X (13)</td>
<td>X (15)</td>
<td>X (15)</td>
<td>X (15)</td>
<td>X (15)</td>
<td>X (15)</td>
<td>X (13)</td>
<td>X (15)</td>
<td>X (15)</td>
<td>X (15)</td>
<td>X (15)</td>
</tr>
<tr>
<td rowspan="7">Calendar</td>
<td rowspan="3">Time</td>
<td>12 h/24 h format</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
</tr>
<tr>
<td>Hour, minute, second</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
</tr>
<tr>
<td>Subsecond</td>
<td>X</td>
<td>N/A</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>N/A</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
</tr>
<tr>
<td colspan="2">Date</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
</tr>
<tr>
<td colspan="2">Daylight operation</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
</tr>
<tr>
<td colspan="2">Bypass shadow registers</td>
<td>X</td>
<td>N/A</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>N/A</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
</tr>
<tr>
<td colspan="2">VBAT mode</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>N/A</td>
<td>N/A</td>
<td>N/A</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
</tr>
<tr>
<td rowspan="6">Alarm</td>
<td rowspan="2">Alarms available</td>
<td>Alarm A</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
</tr>
<tr>
<td>Alarm B</td>
<td>N/A</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>N/A</td>
</tr>
<tr>
<td rowspan="3">Time</td>
<td>12 h/24 h format</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
</tr>
<tr>
<td>Hour, minute, second</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
</tr>
<tr>
<td>Subsecond</td>
<td>X</td>
<td>N/A</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>N/A</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
</tr>
<tr>
<td colspan="2">Date or week day</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
</tr>
<tr>
<td rowspan="6">Tamper detection</td>
<td colspan="2">Configurable input mapping</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>N/A</td>
<td>N/A</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
</tr>
<tr>
<td colspan="2">Configurable edge detection</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>N/A</td>
</tr>
<tr>
<td colspan="2">Configurable level detection (filtering, sampling, and precharge configuration on tamper input)</td>
<td>X</td>
<td>N/A</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>N/A</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>N/A</td>
</tr>
<tr>
<td colspan="2">Number of tamper inputs</td>
<td>2<sup><a href="#fn3">3</a></sup></td>
<td>2</td>
<td>2</td>
<td>2</td>
<td>3</td>
<td>3</td>
<td>3</td>
<td>1</td>
<td>3</td>
<td>3</td>
<td>3</td>
<td>N/A</td>
</tr>
<tr>
<td colspan="2">Number of tamper events</td>
<td>0</td>
<td>1</td>
<td>2</td>
<td>2</td>
<td>3</td>
<td>3</td>
<td>3</td>
<td>1</td>
<td>3</td>
<td>3</td>
<td>3</td>
<td>N/A</td>
</tr>
<tr>
<td colspan="2">VBAT mode pins (inputs)</td>
<td>1</td>
<td>1</td>
<td>1</td>
<td>2</td>
<td>2</td>
<td>N/A</td>
<td>N/A</td>
<td>N/A</td>
<td>3</td>
<td>3</td>
<td>3</td>
<td>N/A</td>
</tr>
<tr>
<td rowspan="6">Timestamp</td>
<td colspan="2">Configurable input mapping</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X<sup><a href="#fn4">4</a></sup></td>
<td>N/A</td>
<td>N/A</td>
<td>X<sup><a href="#fn4">4</a></sup></td>
<td>X</td>
<td>X<sup><a href="#fn4">4</a></sup></td>
<td>N/A</td>
</tr>
<tr>
<td rowspan="2">Time</td>
<td>Hour, minute, second</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>N/A</td>
</tr>
<tr>
<td>Subseconds</td>
<td>X</td>
<td>N/A</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>N/A</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>N/A</td>
</tr>
<tr>
<td colspan="2">Date (day, month)</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>N/A</td>
</tr>
<tr>
<td colspan="2">Timestamp on tamper detection event</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>N/A</td>
</tr>
<tr>
<td colspan="2">Timestamp on switch to VBAT mode</td>
<td>N/A</td>
<td>N/A</td>
<td>N/A</td>
<td>N/A</td>
<td>X</td>
<td>N/A</td>
<td>N/A</td>
<td>N/A</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>N/A</td>
</tr>
<tr>
<td rowspan="4">RTC outputs</td>
<td rowspan="2">RTC_ ALARM</td>
<td>Alarm event</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
</tr>
<tr>
<td>Wakeup event</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
</tr>
<tr>
<td rowspan="2">RTC_ CALIB</td>
<td>512 Hz</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
</tr>
<tr>
<td>1 Hz</td>
<td>X</td>
<td>N/A</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>N/A</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
</tr>
<tr>
<td rowspan="2">RTC<p>calibration</p></td>
<td colspan="2">Coarse calibration</td>
<td>N/A<sup><a href="#fn5">5</a></sup></td>
<td>X</td>
<td>N/A<sup><a href="#fn5">5</a></sup></td>
<td>X</td>
<td>N/A<sup><a href="#fn5">5</a></sup></td>
<td>N/A<sup><a href="#fn5">5</a></sup></td>
<td>X</td>
<td>X</td>
<td>N/A<sup><a href="#fn5">5</a></sup></td>
<td>N/A<sup><a href="#fn5">5</a></sup></td>
<td>N/A<sup><a href="#fn5">5</a></sup></td>
<td>N/A<sup><a href="#fn5">5</a></sup></td>
</tr>
<tr>
<td colspan="2">Smooth calibration</td>
<td>X</td>
<td>N/A</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>N/A</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
</tr>
<tr>
<td colspan="3">Synchronizing the RTC</td>
<td>X</td>
<td>N/A</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>N/A</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
</tr>
<tr>
<td colspan="3">Reference clock detection</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
</tr>
<tr>
<td rowspan="4">Backup registers</td>
<td colspan="2">Powered-on VBAT</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>N/A</td>
<td>N/A</td>
<td>N/A</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>VDD12</td>
</tr>
<tr>
<td colspan="2">Reset on a tamper detection</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>N/A</td>
</tr>
<tr>
<td colspan="2">Reset when flash memory readout protection is disabled</td>
<td>X</td>
<td>N/A</td>
<td>X</td>
<td>N/A</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>N/A</td>
</tr>
<tr>
<td colspan="2">Number of backup registers</td>
<td>5</td>
<td>20</td>
<td>16</td>
<td>20</td>
<td>32</td>
<td>5</td>
<td>32<sup><a href="#fn6">6</a></sup></td>
<td>20</td>
<td>20<sup><a href="#fn7">7</a></sup></td>
<td>32</td>
<td>20</td>
<td>5</td>
</tr>
</tbody>
</table>

-   **[](AN4759_Adv-RTC-features-landscape.md)**  

-   **[RTC calendar](AN4759_RTC-calendar.md)**  

-   **[Binary and mixed modes \(RTC3 only\)](AN4759_Binary-mixed-modesRTC3.md)**  

-   **[RTC alarms](AN4759_RTC-alarms.md)**  

-   **[RTC periodic wakeup unit](AN4759_RTC-periodic-wakeup.md)**  

-   **[Smooth digital calibration](AN4759_Smooth-dig-calibration.md)**  

-   **[Synchronize the RTC](AN4759_Synchronize-RTC.md)**  

-   **[RTC reference clock detection](AN4759_RTC-reference-clock-detection.md)**  

-   **[RTC prescaler adjustment with LSI measurements](AN4759_RTC-prescaler-adjust.md)**  

-   **[Timestamp function](AN4759_Timestamp-function.md)**  

-   **[RTC tamper detection function](AN4759_RTC-tamper-detection.md)**  

-   **[Backup registers](AN4759_backup-registers.md)**  

-   **[Alternate function RTC outputs](AN4759_Alternate-function-RTC-outputs.md)**  

-   **[RTC safety aspects](AN4759_RTC-safety-aspects.md)**  

-   **[Reduce power consumption](AN4759_Reduce-power-consumption.md)**  

-   **[RTC3 secure and privileged protection modes](AN4759_RTC3-secure-privileged-protection-modes.md)**  


<a id="fn1"></a>

[^1]: Except STM32L41/42xxx.<a id="fn2"></a>

[^2]: Except STM32L4P5/Q5 line.<a id="fn3"></a>

[^3]: 3 inputs for STM32F07/F09x.<a id="fn4"></a>

[^4]: Thanks to timestamp on tamper event.<a id="fn5"></a>

[^5]: Obsolete, replaced by smooth calibration.<a id="fn6"></a>

[^6]: Only 20 for Cat 2.<a id="fn7"></a>

[^7]: 32 for STM32L4R/4S line.

