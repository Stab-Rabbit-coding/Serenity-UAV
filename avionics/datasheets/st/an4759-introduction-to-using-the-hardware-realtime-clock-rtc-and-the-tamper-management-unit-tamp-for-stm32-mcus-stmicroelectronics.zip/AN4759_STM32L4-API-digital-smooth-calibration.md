# STM32L4 API and smooth digital calibration application example {#id_33270}

-   **[STM32CubeL4 firmware libraries for smooth calibration](AN4759_STM32CubeL4-FW-lib-digital-calib.md)**  

-   **[X-CUBE-RTC for smooth calibration](AN4759_X-CUBE-RTC-L4-digital-calibration.md)**  

-   **[Smooth calibration application example \(STM32L4\)](AN4759_Digital-calib-application-example-L4.md)**  


