# Run time observations {#id_33515}

The following steps are needed to check the correct functionality:

-   Set the CLK\_REF\_ACTIVATED to 0 and observe the `time_elapsed` variable deriving \(getting away from 255/1 s\). The user can monitor it in Debug mode.
-   Set the CLK\_REF \_ACTIVATED to 1 and observe that the `time_elapsed` variable derivation is less important.

`time_elapsed` embodies the 1-second period measured for RTC.

**Note:** A typical quartz has an uncertainty of 53 s/month. This uncertainty must be attenuated with the reference clock detection and synchronization.

Moreover, to check that the application runs properly, the user can also visualize the user LED2 blinking each second and the RTC\_OUT CALIB output on PB2 pin \(these two observations do not witness the efficiency of the reference synchronization\).

**Parent topic:**[Reference clock detection application example](AN4759_Ref-clock-detection.md)

