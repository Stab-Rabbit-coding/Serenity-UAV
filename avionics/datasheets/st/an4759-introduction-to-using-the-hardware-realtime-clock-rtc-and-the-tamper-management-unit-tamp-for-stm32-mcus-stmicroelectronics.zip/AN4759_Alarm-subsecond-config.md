# Alarm subsecond configuration {#id_33187}

Only RTC3 type with BCD or mixed mode is considered in this section.

The RTC provides similar programmable alarms, subsecond A and B. They generate alarms with a high resolution \(for the second division\). The value programmed in the alarm subsecond register is compared to the content of the subsecond field in the calendar unit.

The subsecond field counter counts down from the value configured in the synchronous prescaler to zero, and then reloads a value from RTC\_SPRE.

![](DT30110.svg "Alarm subsecond field")

**Note:** Mask ss is the most significant bit in the subsecond alarm. This bit is compared to the synchronous prescaler register. Mask ss is 4-bit length \(from 0 to 15\) for RTC2 type, and can be up to 6-bit length \(from 0 to 31\) for RTC3 type \(RTC\_SSR always 16-bit length for RTC2 type, and can be expanded to 32 bits on some RTC3 type\).

The subsecond alarm is configured using MASKSS\[5:0\] in RTC\_ALRMASSR \(resp. RTC\_ALRMBSSR\). The table below shows the configuration possibilities for the mask register and provides an example with the following settings:

-   LSE selected as RTC clock source \(for example LSE = 32768 Hz\)
-   Asynchronous prescaler = 127
-   Synchronous prescaler = 255 \(calendar clock = 1 Hz\)
-   Alarm A subsecond = 255 \(SS\[14:0\] = 255\)

**Table 1. Alarm subsecond mask combinations (RTC2 type)**

<table>
<thead>
<tr>
<th>MASKSS[5:0]</th>
<th>Alarm A subsecond behavior</th>
<th>Example result</th>
</tr>
</thead>
<tbody>
<tr>
<td>0</td>
<td>No comparison on subsecond for alarm<p>The alarm is activated when the second unit is incremented.</p></td>
<td>Alarm activated every 1 s</td>
</tr>
<tr>
<td>1</td>
<td>Only the AlarmA_SS[0] bit is compared to RTC_SSR.</td>
<td>Alarm activated every 1/128 s</td>
</tr>
<tr>
<td>2</td>
<td>Only the AlarmA_SS[1:0] bits are compared to RTC_SSR.</td>
<td>Alarm activated every 1/64 s</td>
</tr>
<tr>
<td>3</td>
<td>Only the AlarmA_SS[2:0] bits are compared to RTC_SSR.</td>
<td>Alarm activated every 1/32 s</td>
</tr>
<tr>
<td>4</td>
<td>Only the AlarmA_SS[3:0] bits are compared to RTC_SSR.</td>
<td>Alarm activated every 1/16 s</td>
</tr>
<tr>
<td>5</td>
<td>Only the AlarmA_SS[4:0] bits are compared to RTC_SSR.</td>
<td>Alarm activated every 125 ms</td>
</tr>
<tr>
<td>6</td>
<td>Only the AlarmA_SS[5:0] bits are compared to RTC_SSR.</td>
<td>Alarm activated every 250 ms</td>
</tr>
<tr>
<td>7</td>
<td>Only the AlarmA_SS[6:0] bits are compared to RTC_SSR.</td>
<td>Alarm activated every 500 ms</td>
</tr>
<tr>
<td>8</td>
<td>Only the AlarmA_SS[7:0] bits are compared to RTC_SSR.</td>
<td>Alarm activated every 1 s</td>
</tr>
<tr>
<td>9</td>
<td>Only the AlarmA_SS[8:0] bits are compared to RTC_SSR.</td>
<td>Alarm activated every 1 s</td>
</tr>
<tr>
<td>10</td>
<td>Only the AlarmA_SS[9:0] bits are compared to RTC_SSR.</td>
<td>Alarm activated every 1 s</td>
</tr>
<tr>
<td>11</td>
<td>Only the AlarmA_SS[10:0] bits are compared to RTC_SSR.</td>
<td>Alarm activated every 1 s</td>
</tr>
<tr>
<td>12</td>
<td>Only the AlarmA_SS[11:0] bits are compared to RTC_SSR.</td>
<td>Alarm activated every 1 s</td>
</tr>
<tr>
<td>13</td>
<td>Only the AlarmA_SS[12:0] bits are compared to RTC_SSR.</td>
<td>Alarm activated every 1 s</td>
</tr>
<tr>
<td>14</td>
<td>Only the AlarmA_SS[13:0] bits are compared to RTC_SSR.</td>
<td>Alarm activated every 1 s</td>
</tr>
<tr>
<td>15</td>
<td>Only the AlarmA_SS[14:0] bits are compared to RTC_SSR.</td>
<td>Alarm activated every 1 s</td>
</tr>
</tbody>
</table>

**Note:** For RTC3 type, this table can be completed up to MASKSS equal to 31 and the SS\[31:16\] value is given by RTC\_ALRABINR \(resp. RTC\_ALRBBINR\).

The overflow bit in the subsecond register \(bit 15 for RTC2 and 31 for RTC3\) is never compared.

**Parent topic:**[RTC alarms](AN4759_RTC-alarms.md)

