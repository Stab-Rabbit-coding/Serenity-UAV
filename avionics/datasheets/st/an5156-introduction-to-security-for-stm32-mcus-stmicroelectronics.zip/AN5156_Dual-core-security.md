# Dual-core architecture {#id_25618}

In dual-core products, one core can act as secure while the other is nonsecure. Some products, such as dual‑core STM32WL devices in particular, feature a hardware support to propagate the secure attribute to memory and peripherals, ensuring that robust runtime isolation implementation is possible.

A dedicated security controller is added to the dual-core STM32WL devices to facilitate the isolation.

Instead of using attribution units, the secure NV memory dedicated to securable CPU2 is defined in the flash memory interface configuration. Key peripherals such as the DMA must convey the secure context \(refer to the user manual *Getting started with STM32CubeWL for STM32WL series* \(UM2643\) for details about this hybrid architecture\).

![](DT67318.svg "Simplified diagram of dual-core system architecture")

**Parent topic:**[Device protections](AN5156_Device-protections.md)

