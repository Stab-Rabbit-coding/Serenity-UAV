# AES accelerator \(AES/SAES\) {#id_81820}

The AES is an industry-standard symmetric encryption and decryption algorithm.

The base peripheral improves AES efficiency by providing hardware support for various block and chaining modes, such as ECB, CBC, CTR, and GCM, as well as for different key lengths and DMA operation. Its main advantages are faster processing and lower power consumption. However, developers must still pay close attention to key management to maintain security.

When AES is used for encryption or decryption, access to the registers containing the key must be protected, and the key material must be erased after use. The MPU can be configured to restrict access to memory containing keys.

SAES provides a higher level of security, partly because its computation is obfuscated to resist more advanced side-channel attacks and partly because, when DHUK is used, the actual encryption key can be hidden so that it never appears in addressable memory in plain form. On applicable devices, SAES can also use keys directly from OBK.

**Parent topic:**[STM32 security features](AN5156_Stm32-security-features.md)

