# Memory protections {#memory_protections}

Storage containing sensitive code and data must not be accessible from any unexpected interface \(debugging port\) or an unauthorized process \(internal threat\).

Depending on the asset to be protected \(code or data\), various mechanisms can be set to establish protections at the source of the unauthorized access \(external port, internal process\) or on the memory type to be protected \(flash, SRAM, or external memory\).

Part of the access filtering can be performed by the memory interfaces \(like flash controller\), the bus controller peripheral \(firewall, RIF, and more\), or through the core MPU if it is available. Where applicable, Armv8 security isolation features are used. Details on proprietary protections \(secure hide protection, PCROP, WRP, RDP\) can be found in [STM32 security features](AN5156_Stm32-security-features.md).

Embedded flash memory, embedded SRAM, and external memories are designed for different purposes. Their respective protections mechanisms reflect these differences.

The figure below provides a simple view of memories access architecture in a microcontroller.

![](DT50948.svg "Memory types")

The table below summarizes the particularities of each type of memories and typical protection features.

**Table 1. Memory types and associated protection**

<table>
<thead>
<tr>
<th>Memory</th>
<th>Types</th>
<th>Description</th>
<th>Protections</th>
</tr>
</thead>
<tbody>
<tr>
<td>System flash memory</td>
<td><ul>
<li>Internal</li>
</ul></td>
<td>ROM part of the flash memory. Embeds device bootloader and other ST services.</td>
<td>Cannot be updated (erase/written).<p>A part may also be unreadable.</p></td>
</tr>
<tr>
<td>User flash memory</td>
<td><ul>
<li>Internal</li>
</ul></td>
<td>Flash memory for user application</td>
<td rowspan="2">Internal protections:<ul>
<li>RDP</li>
<li>WRP</li>
<li>TrustZone</li>
<li>PCROP (not for SRAM)</li>
<li>OTP (not in SRAM)</li>
<li>Firewall</li>
<li>Secure hide protection (not for SRAM)</li>
<li>MPU</li>
</ul></td>
</tr>
<tr>
<td>SRAM</td>
<td><ul>
<li>Internal</li>
</ul></td>
<td>Working memory for stack, heap or buffers. Can be used to execute the firmware downloaded from internal or external non-volatile memories.</td>
</tr>
<tr>
<td>NAND, NOR, octo‑SPI, or quad‑SPI flash memory</td>
<td><ul>
<li>External</li>
</ul></td>
<td>Additional memory for applications or data storage</td>
<td><ul>
<li>Cryptography (MCE, OTFDEC)</li>
</ul></td>
</tr>
<tr>
<td>SDRAM</td>
<td><ul>
<li>External</li>
</ul></td>
<td>Additional RAM for application execution</td>
<td>Cryptography (MCE)</td>
</tr>
</tbody>
</table>

-   **[System flash memory](AN5156_dev-prot-System-flash-memory.md)**  

-   **[User flash memory](AN5156_dev-prot-User-flash-memory.md)**  

-   **[Embedded SRAM](AN5156_Dev-prot-Embedded-sram.md)**  

-   **[External flash memories](AN5156_dev-prot-External-flash-memories.md)**  

-   **[STM32 memory protections](AN5156_dev-prot-Stm32-memory-protections-overview.md)**  


**Parent topic:**[Device protections](AN5156_Device-protections.md)

