# Configurations {#id_50727}

The ST proprietary SBSFU is very configurable. The most important configuration option is the choice to use a single or dual image handling of application code. Each has a separate example. Single image leaves more space for application code. Two or more images add some advanced features to the image handling.

The second most important option is the cryptographic scheme selection. There are usually the following choices:

-   ECDSA asymmetric cryptography for firmware verification with AES-CBC or AES-CTR symmetric cryptography for firmware encryption
-   ECDSA asymmetric cryptography for firmware verification without firmware encryption
-   X509 certificate-based ECDSA asymmetric cryptography for firmware verification without firmware encryption
-   AES-GCM symmetric cryptography for both firmware verification and encryption

For more details, see the document [AN5156\_General-Info.md\#entry\_nsy\_brz\_qvb](AN5156_General-Info.md#entry_nsy_brz_qvb) or the document *Integration guide for the X‑CUBE‑SBSFU STM32Cube Expansion Package* \(AN5056\).

**Parent topic:**[STMicroelectronics proprietary SBSFU solution](AN5156_ST-proprietary-SBSFU.md)

