# Public key accelerator \(PKA\) {#id_81821}

This coprocessor provides acceleration of RSA, DH, and ECC operations over GF\(p\), based on the Montgomery method for fast modular multiplications. Built-in inward and outward transformations in the Montgomery domain are used to implement the operations required by asymmetric cryptographic algorithms.

The operands are loaded into dedicated memory, and the hardware performs the requested transformation. As with the symmetric cryptography accelerator, the main security concern is that the software must handle key storage and copying.

**Parent topic:**[STM32 security features](AN5156_Stm32-security-features.md)

