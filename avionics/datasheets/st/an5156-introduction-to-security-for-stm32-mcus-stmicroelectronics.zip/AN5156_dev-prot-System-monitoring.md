# System monitoring {#system_monitoring}

The monitoring of the device power supply and environment can be set to avoid malfunction and to take corresponding countermeasures. Some mechanisms, like tamper detection, are dedicated to security. Other mechanisms are primarily used for safety reason but can serve security as well. For example, the detection of a power down or external clock disconnection can be unintentional \(safety\) but can also reveal an attack \(security\).

**Tamper detection** is used to detect system/board level intrusions. The opening of a consumer product enclosure can be detected on an MCU pin and trigger appropriate actions. Internal tamper sensors can detect irregular voltage, temperature, or other parameters.

**Clock security system** is used to protect against external oscillator failures. If a failure is detected on the external clock, the microcontroller switches to the internal clock to safely execute. The interrupt signal allows the firmware to react to the clock failure event.

**Power supply** and voltage level can be monitored to detect an abnormally low voltage level. Below a certain voltage value, the normal behavior cannot be ensured and it may be the sign of a fault injection attack.

**Device temperature** can be measured with an internal sensor. The information is fed back to the device through an internal ADC channel. A monitoring application can take appropriate actions according to the temperature range. Increased temperature may be part of a fault injection attack scheme.

Associated STM32 features:

-   Tamper protection \(with RTC component\)
-   Clock security system
-   Power supply supervision
-   Temperature sensor

**Parent topic:**[Device protections](AN5156_Device-protections.md)

