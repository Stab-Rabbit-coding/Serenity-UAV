# Hash algorithms {#hash_algorithms}

Hash algorithms guarantee the message integrity. They generate a unique fixed-length bitstream from a message called the digest. Any difference in the input message produces a totally different digest. The digest cannot be reversed to retrieve the input message.

Hashing can be used independently from message encryption.

![](DT50958.svg "Message hashing")

The difference with classic CRC is the robustness due to operations that are more complex and a much higher digest length: up to 512 bits instead of 16 or 32 bits. As an example, CRC are reserved for fast integrity checks during data transfers. Digest length makes them virtually unique and ensures that no collision occurs.

Typical algorithms are the MD5 \(128-bit digest\), SHA-1 \(160-bit digest\), SHA-2 \(224-, 256-,384-, or 512-bit digest\), and SHA-3 \(224-, 256-, 384-, or 512-bit digest\).

**Parent topic:**[Cryptography–Main concepts](AN5156_A-Crypto-main-concepts.md)

