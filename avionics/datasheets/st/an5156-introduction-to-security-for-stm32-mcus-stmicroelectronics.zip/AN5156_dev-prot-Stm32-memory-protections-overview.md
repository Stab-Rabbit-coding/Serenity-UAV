# STM32 memory protections {#stm32_memory_protections_overview}

Several STM32 features are available to cover the various cases considered. They are listed in the table below with their respective scope, and described in [STM32 security features](AN5156_Stm32-security-features.md#).

**Table 1. Scope of STM32 embedded memory protection features**

|Feature|External attack protection|Internal attack protection|Flash memory|SRAM|
|:-----:|:------------------------:|:------------------------:|:----------:|:--:|
|RDP, life cycle|Yes|No|Yes|Yes|
|Firewall|No|Yes|Yes|Yes|
|MPU|No|Yes|Yes|Yes|
|PCROP[^1]|Yes|Yes \(read/write\)|Yes|No|
|WRP[^2]|Yes|Yes|Yes|No|
|HDP|Yes|Yes|Yes|Yes \(for execution\)[^3]|
|TrustZone®, RIF|Yes|Yes|Yes|Yes|

**Parent topic:**[Memory protections](AN5156_Dev-prot-Memory-protections.md)

<a id="fn1"></a>

[^1]: Support of this feature in Armv6-M products is limited as constant data cannot be stored in NVM.<a id="fn2"></a>

[^2]: Write protection can be unset when RDP level ≠ 2.<a id="fn3"></a>

[^3]: The SRAM is protected by a secure area only at secure code execution. It must be cleaned before leaving the secure area.

