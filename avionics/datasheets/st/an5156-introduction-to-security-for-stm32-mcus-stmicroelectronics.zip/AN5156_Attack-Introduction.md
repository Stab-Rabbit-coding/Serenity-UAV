# Introduction to attack types {#introduction_1}

A key rule in security is that a successful attack is always possible.

First, there is no absolute protection against unexpected attack. Whatever the security measures taken to protect a system, it is possible that a security breach is found and exploited during the device lifetime. This last point makes it necessary to consider how the device firmware is updated to increase its security \(see [Secure firmware update \(SFU\)](AN5156_sec-appl-Secure-firmware-update.md)\).

Secondly, in laboratory conditions with proper equipment, it is possible to retrieve microcontroller content, or even its design architecture details. These techniques are briefly presented in [Hardware attacks](AN5156_Attack-Hardware-attacks.md#).

From an attacker's point of view, an attack is most profitable if the ratio expected revenue/attack cost is as high as possible. The revenue depends on the stolen asset value, and on the repeatability of the attack. The cost depends on time, the acquisition of the necessary skills by the attacker, and on money \(equipment\) spent to succeed.

 

## Attack types { .section}

While there are more detailed groups and categories of attack, the basic categories are the following ones:

-   **Software attacks** are carried by exploiting bugs, protocol weaknesses, or untrusted pieces of code among others. Attacks on communication channels \(interception or usurpation\) are part of this category. Software attacks represent the vast majority of cases. Their cost may be very low. They can be widely spread and repeated with huge damage. It is not necessary to have a physical access to the device. The attack can be executed remotely.
-   **Hardware attacks** need physical access to the device. The most obvious one exploits the debug port, if it is not protected. However, in general, hardware attacks are sophisticated and can be very expensive. They are carried out with specific materials and require electronics engineering skills. A distinction is made between noninvasive attacks \(carried out at board or chip level without device destruction\), and invasive attacks \(carried out at device-silicon level with package destruction\). In most cases, such an attack is only profitable if it reveals information that leads to a new and widely applicable remote attack.

The table below gives an overview of the cost and techniques used for each type of attack.

**Table 1. Attacks types and costs**

<table>
<thead>
<tr>
<th>Attacks types</th>
<th>Non-invasive</th>
<th>Semi–invasive</th>
<th>Invasive</th>
</tr>
</thead>
<tbody>
<tr>
<td>-</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>Scope</td>
<td>Remote or local</td>
<td>Local board and device level</td>
<td>Local device level</td>
</tr>
<tr>
<td>Techniques</td>
<td>Software bugs<p>Protocol weaknesses</p>
<p>Trojan horse</p>
<p>Eavesdropping</p></td>
<td>Debug port<p>Power glitches</p>
<p>Fault injection</p>
<p>Side-channels analysis</p></td>
<td>Probing<p>Laser</p>
<p>FIB</p>
<p>Reverse engineering</p></td>
</tr>
<tr>
<td>Cost/expertise</td>
<td>From very low to high, depending on the security failure targeted</td>
<td>Quite low cost. Need only moderately sophisticated equipment and knowledge to implement.</td>
<td>Very expensive. Need dedicated equipment and very specific skills.</td>
</tr>
<tr>
<td>Objectives</td>
<td>Access to confidential assets (code and data).<p>Usurpation</p>
<p>Denial of service</p></td>
<td>Access to secret data or device internal behavior (algorithm).</td>
<td>Reverse engineering of the device (silicon intellectual property)<p>Access to hidden hardware and software secrets (flash memory access)</p></td>
</tr>
</tbody>
</table>

**Parent topic:**[Attack types](AN5156_attack-types.md)

