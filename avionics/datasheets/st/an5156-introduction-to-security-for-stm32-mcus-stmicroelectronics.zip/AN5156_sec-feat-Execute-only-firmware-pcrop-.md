# Execute-only firmware \(PCROP\) {#execute_only_firmware__pcrop_}

Part of the STM32 flash memory can be configured with an 'execute-only' attribute. The firmware stored in such configured area can only be fetched by the CPU instruction bus. Any attempt to read or write this area is forbidden. The protection applies against both internal \(firmware\) accesses as well as external \(debug port\) accesses. In an STM32 device, this feature is named proprietary code readout protection \(PCROP\).

The PCROP is a static protection set by option bytes. The number of protected areas and their granularity depends on the STM32 device \(see [Security features by STM32 devices](AN5156_Security-features-by-STM32.md)\). When the PCROP is in use, care must be taken to compile the firmware with the execute-only attribute \(refer to user compiler options\). Refer to the document [AN5156\_General-Info.md\#entry\_jh2\_brz\_qvb](AN5156_General-Info.md#entry_jh2_brz_qvb) for more details.

In particular, the ARMv6-M instruction set has difficulty working with this constraint. The compiler must be set not to place constants and literal pools within the program, otherwise even the code execution can eventually trigger the protection.

**When to use the PCROP**

The PCROP is used to protect third-party firmware \(intellectual property\), as well as the most sensitive parts of the user firmware.

**Note:** The PCROP is available on all STM32 devices listed in [Table 1](AN5156_Introduction.md#table_s42_tv4_mfb), except on TrustZone-enabled devices, where it is superseded by another protection mechanism.

**Parent topic:**[STM32 security features](AN5156_Stm32-security-features.md)

