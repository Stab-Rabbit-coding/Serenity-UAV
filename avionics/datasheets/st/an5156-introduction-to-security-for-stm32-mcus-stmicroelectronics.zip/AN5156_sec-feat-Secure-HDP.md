# Secure hide protection \(HDP\) {#secure_user_memory}

Some STM32 devices support the HDP memory concept. The HDP, named secure hide protection first on STM32L5 devices, is also known as secure user memory on STM32H7 devices, or securable memory on STM32G0 devices.

An HDP area is a part of the user flash memory that can be accessed only once, just after a device reset. The HDP targets sensitive applications that embed or manipulate confidential data, and that must be securely executed at boot. Once the transition is executed, the HDP area is closed, and cannot be accessed anymore by any means \(see the figure below\).

The code that facilitates the HDP transition is usually a STMicroelectronics code located in the RSS. Code in SRAM is an alternative.

![](DT50953.svg "HDP protected firmware access")

The HDP is a static protection configured by option bytes. Once set, the CPU boots on the firmware embedded in this area, independent of the boot configuration set by boot pin or boot address. HDP can be single stage or use a monotonic counter to gradually cover more memory as the secure boot progresses \(STM32H5\). Some devices implement a dynamic HDP expansion. This means that the HDP can be extended by the number of sectors using the register value, without programming the OB \(STM32H5, STM32U0\).

**When to use the HDP**

The HDP is suited for a code that must only be executed after reset, like secure boot for root of trust. It should be used in synergy with the boot lock feature.

**Note:** The HDP is available in STM32H7, STM32G0, STM32G4, STM32L5, STM32N6, STM32U0, STM32U3, STM32U5, and STM32H5 devices, with slight differences in its implementation and name \(refer to the reference manuals for details\).

**Parent topic:**[STM32 security features](AN5156_Stm32-security-features.md)

