# List of attack targets {#id_17560}

The following sections list the possible attack targets.

## Initial provisioning { .section}

The cryptographic data for root of trust for the chain of security must be injected to the SoC in a controlled trusted way. Whether it is a key, a certificate or a hash initial value, it must remain immutable and/or secret. Once programmed inside the device, the data protection mechanism must be enabled and only authorized process must have access to it.

-   *Risks*: firmware corruption or usurpation
-   *Countermeasures*:
    -   Trusted manufacturer environment
    -   Use of secure data provisioning services \(SFI\)
    -   Data protection mechanisms
    -   Secure application isolation
    -   Use of OTP memory

## Boot modification { .section}

The purpose of this attack is to use the bootloader to access to device content. The attack aims at modifying the boot mode and/or the boot address to preempt the user application and to take control of the CPU through the bootloader \(via USB DFU, I2C or SPI\), the debug port or through a firmware injected in RAM. The boot mode and the address are controlled by device configuration and/or input pin and must be protected.

-   *Risks*: full access of the microcontroller content
-   *Countermeasures*:
    -   Unique boot entry
    -   Bootloader, debug disabled \(see [Readout protection \(RDP\)](AN5156_sec-feat-read-out-protection-rdp-.md)\), and [Life cycle management–product state](AN5156_Lifecycle-management-product-state.md)\)
    -   Hide protection \(HDP\)

## Secure boot \(SB\) or Trusted Firmware-M \(TF-M\) { .section}

Robust systems rely on initial firmware integrity and authenticity check before starting the main application. As the root of trust of a device, this part of user firmware must be immutable and impossible to bypass.

A successful attack consists in executing a non-trusted application by bypassing the verification and by jumping directly to the malware. It can be done by hardware techniques such as fault-injection. It can also be done by replacing the expected hash value by the hash value of the malware \(refer to the *Initial provisioning* section at the beginning of this chapter\).

-   *Risks*: device spoofing or application modification
-   *Countermeasures*:
    -   Unique boot entry point to avoid verification bypass
    -   "Immutable code" to avoid SB code modification
    -   Secure storage of firmware signature and/or tag value
    -   Environment event detection \(such as power supply glitch, temperature, or clock speed\)

## Firmware update { .section}

The firmware update procedure allows a product owner to propose corrected version of the firmware to ensure the best user experience during device lifetime. However, a firmware update gives an attacker an opportunity to enter the device with its own firmware or a corrupted version of the existing firmware.

The process must be secured with firmware authentication and integrity verification. A successful attack requires an access to the cryptographic procedure and keys \(refer to the *Initial provisioning* section at the beginning of this chapter\).

-   *Risk*: device firmware corruption
-   *Countermeasure*: SFU application with authentication and integrity checks. Confidentiality can also be added by encrypting the firmware in addition to signature.

## Communication interfaces { .section .keepWithNext}

Serial interfaces \(such as SPI, I2C, or USART\) are used either by the bootloader or by applications to exchange data and/or commands with the device. The interception of a communication allows an attacker to use the interface as a device entry point. The firmware protocol can also be prone for bugs \(like overflow\).

-   *Risk*: Access to device content
-   *Countermeasures*:
    -   Make physical bus hard to reach on board.
    -   Isolate software communication stacks to prevent them from accessing critical data and operations.
    -   Use cryptography for data exchange.
    -   Disable I/F ports when not needed.
    -   Check inputs carefully.

## Debug port { .section}

The debug port provides access to the full content of the device: core and peripheral registers, flash memory, and SRAM content. Used for application development, it may be tempting to keep it alive for investigating future bugs. This is the first breach tried by an attacker with physical access to the device.

-   *Risk*: full access to the device
-   *Countermeasure*: Disable device debug capabilities \(see [Readout protection \(RDP\)](AN5156_sec-feat-read-out-protection-rdp-.md)\).
-   Debug authentication \(DA\)

## External peripheral access { .section}

An IoT device controls sensors and actuators depending on the global application. An attacker can divert the system by modifying data coming from sensors or by shunting output data going to actuators.

-   *Risk*: incorrect system behavior.
-   *Countermeasure*: anti-tamper to detect system intrusion at board level

## Sensitive firmware and data { .section}

Some parts of the firmware need special protection: for example the cryptographic algorithm or a third-party library. In addition, selected data may need enhanced protection if they are considered as valuable assets \(cryptographic keys\).

The internal memory content must be protected against external accesses \(such as communication interfaces\) and internal accesses \(other software processes\). The memory attributes and the firewall are the main protections for process and data isolation.

-   *Risks*: sensitive firmware copy or data theft
-   *Countermeasures*:
    -   Execute-only access right \(XO\)
    -   Firewall
    -   Memory protection unit
    -   Secure area
    -   Encryption of external memory

## SRAM { .section}

The SRAM is the device running memory. It embeds runtime buffers and variables \(such as stack or heap\) and can embed firmware and keys. While in the non-volatile memory, the secrets may be stored as encrypted, when loaded to the SRAM, they need to be present in plain view to be used. In the same time, the SRAM usually holds communication buffers. For these two reasons, an attacker may be tempted to focus his effort on the SRAM. At least three types of attack can be raised against this memory: code \(malware\) injection, memory corruption through buffer overflow and retrieval of secrets through temporary stored variables.

-   *Risks*: buffer overflow, data theft, or device control
-   *Countermeasures*:
    -   Firewall
    -   Memory protection unit
    -   Secure area

## Random number generation { .section .keepWithNext}

Random numbers are often used in cryptography for session key, cryptographic nonce, or initialization vector \(IV\) generation. Weak random generator may make any secure protocol vulnerable.

A software attack tries to exploit an hidden periodicity or structures of a random sequence to guess the secret key and break into communication confidentiality. An hardware attack attempts to disable the entropy source, or weaken the statistic randomness of the output.

A robust random generator depends on both the quality of the entropy source \(analog\) and the subsequent processing in digital.

-   *Risk*: reduced security of cryptographic protocols
-   *Countermeasure*:
    -   Use true hardware entropy generator.
    -   Use tests on the RNG output, and verify statistic properties of produced random numbers.
    -   Take full advantage of the error detection and heath check mechanisms available on the RNG.

## Communication stack { .section}

Connectivity protocols \(such as Bluetooth, Ethernet, Wi-Fi, or LoRa\) have complex communication firmware stacks. These stacks, often available in open source, must not always be considered as trusted. A potential weakness can be massively exploited.

-   *Risk*: device access \(content, control\) through network
-   *Countermeasures*: -
    -   Communication process isolation
    -   Server authentication
    -   Secure firmware update to patch bugs

## Communication eavesdrop { .section}

Data exchanges between a device and an IoT service can be eavesdropped, either directly by a compatible RF device or through the network. A hacker may seek for retrieving data, getting device IDs or accessing services.

Cryptography can be adopted by all communication protocols. Several encryption steps are often considered to protect the communication between all the different layers \(device, gateway, applications\).

-   *Risk*: observation and spoofing of network traffic
-   *Countermeasure*: use of cryptographic version of the communication stack \(like TLS for Ethernet\)

**Parent topic:**[Attack types](AN5156_attack-types.md)

