# Life cycle management–product state {#id_51207}

The addition of RDP 0.5 into the RDP mechanism used by the STM32 enabled the necessary isolation between secure and nonsecure development. However, the RDP does not allow going further in the user experience with the adoption of new development and OEM manufacturing models. The RDP has been replaced by the product state, a more refined life cycle management system, on the STM32H5 devices as a pilot project. The product state is also an answer to the needs of customers requesting a state that is effectively an RDP2 to the outside world and it allows them to perform a regression in the controlled environment. A similar provision was also added to the STM32U5 series, but the product state enabled finer control over delegating the debugging rights in TrustZone enabled products. It is sufficient for microcontrollers with no TrustZone isolation to use fewer states, for example, the STM32H7Rx/7Sx, which implement the product state this way.

The new life cycle management defines a set of permitted states, and the possible transition between them, just as in the case of the RDP, but there are more states defined for the following:

-   Provision with immutable root of trust code.
-   Clear separation of nonsecure and secure environment.
-   Use certificates for controlled regression.
-   Use certificates for temporary debug sessions.

For applications that do not need these new options, there are still product states corresponding to the original RDP values.

The main available product states are:

-   Open: roughly equivalent to RDP 0
-   Provisioning: marks an ongoing installation of iRoT
-   iRoT-provisioned: roughly comparable to RDP 0.5
-   TZ-closed: state in which debugging of nonsecure code is permitted
-   Closed: equivalent of RDP2, but the regression is possible \(only with a valid authorization\)
-   Locked: final state with no possibility of further transition \(like RDP2\)

**Parent topic:**[STM32 security features](AN5156_Stm32-security-features.md)

