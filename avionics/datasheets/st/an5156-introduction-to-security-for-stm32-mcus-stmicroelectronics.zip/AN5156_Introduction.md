# Introduction {#concept_vts_yqx_fcb .concept}

This application note presents the basics of security in STM32 microcontrollers.

Security in microcontrollers encompasses several aspects including protection of firmware intellectual property, protection of private data in the device, and guarantee of a service execution.

The context of IoT has made security even more important. The huge number of connected devices makes them an attractive target for attackers and several remote attacks have shown the vulnerabilities of device communication channels. With IoT, the security extends the requirements for confidentiality and authentication to communication channels, which often require encryption.

This document is intended to help the building of a secure system by applying countermeasures to different types of attack.

In the first part, after a quick overview of different types of threats, examples of typical attacks are presented to show how attackers exploit the different vulnerabilities in an embedded system.

The subsequent sections focus on the set of hardware and software protections that defend the system from these attacks.

The last sections list all security features available in the STM32 series, and guidelines are given to build a secure system.

**Table 1. Applicable products**

|Type|Product series|
|:--:|--------------|
|Microcontrollers|STM32C0, STM32C5, STM32F0, STM32F1, STM32F2, STM32F3, STM32F4, STM32F7, STM32G0, STM32G4, STM32H5, STM32H7, STM32L0, STM32L1, STM32L4, STM32L4+, STM32L5, STM32N6, STM32U0, STM32U3, STM32U5, STM32WB, STM32WBA, STM32WB0, STM32WL.|

