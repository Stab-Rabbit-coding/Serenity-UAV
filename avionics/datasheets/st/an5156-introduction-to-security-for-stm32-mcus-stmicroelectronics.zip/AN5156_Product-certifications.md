# Product certifications {#id_33978}

Different secure applications often require certain certifications to prove their capability to perform in a secure manner. Independent or government agencies grant certification status to either an MCU application or a combination of MCUs with secure firmware after testing them against evaluation goals.

The certifications and evaluations related to STM32 microcontrollers include, but are not limited to:

-   PSA Certified \(platform security architecture\), governed by Arm, focused on IoT security, MCU certification, three levels of assessment
    -   STM32L4, STM32G0, and STM32G4 devices are certified up to level 1.
    -   STM32L5 devices with TF-M are certified PSA level 2, SESIP level 3.
    -   STM32C0, STM32C5, STM32U0, and STM32H7RS are PSA level 3 and SESIP level 3 certified or certifiable and under evaluation in their scope of secure boot features despite not having TrustZone® isolation
    -   STM32U5, STM32H7S, STM32U0, STM32U3, and STM32H5 devices with TF-M are certifiable up to level 3.
    -   To achieve Arm PSA certifiable security level, refer to the user manual *STM32U585 security guidance for PSA Certified level 3 with SESIP profile* \(UM2852\). Details of the particular PSA certificates are available online at https://products.psacertified.org/
-   SESIP \(security evaluation standard for IoT platforms\), international methodology adopted by several major security evaluation labs, five levels
    -   Systems using SBSFU or TF-M are compliant to level 3 with STM32L4, STM32L4+, STM32L5, STM32H5, STM32N6, and STM32U5 devices.
-   PCI \(payment card information\), an important security standard focusing on point of sale \(POS\) applications
    -   Good record of successful evaluation of systems, using, for example, STM32L4 devices

**Note:** FIPS \(Federal Information Processing Standards\) is a set of standards published by NIST, some of which \(FIPS 140, SP800\) are related to security or cryptography.

**Table 1. Certifications coverage**

<table>
<thead>
<tr>
<th>MCU series</th>
<th>Crypto conformance certification</th>
<th>Security system certification</th>
<th>Security system certification with physical resistance (invasive)</th>
</tr>
</thead>
<tbody>
<tr>
<td><p>STM32G0/</p>
STM32G4</td>
<td rowspan="2">FIPS CAVP, SP800-90A</td>
<td rowspan="4">PSA L1</td>
<td rowspan="5">-</td>
</tr>
<tr>
<td>STM32L4</td>
</tr>
<tr>
<td>STM32L4+</td>
<td rowspan="7">FIPS CAVP, SP800-90B</td>
</tr>
<tr>
<td>STM32H7</td>
</tr>
<tr>
<td>STM32L5</td>
<td>PSA L1, SESIP L3</td>
</tr>
<tr>
<td>STM32WBA</td>
<td rowspan="4">Yes</td>
<td rowspan="2">PSA L3, SESIP L3 (with TF-M)</td>
</tr>
<tr>
<td>STM32U5</td>
</tr>
<tr>
<td>STM32H5</td>
<td>PSA L3, SESIP L3 (with Secure Manager)</td>
</tr>
<tr>
<td>STM32H7Sx, STM32C0, STM32C5, STM32U0</td>
<td>PSA L3, SESIP L3 (using iRoT)</td>
</tr>
</tbody>
</table>

For detailed and most recent evaluation status, refer to the official certificate listings:

-   SESIP: [https://www.trustcb.com/iot/sesip/sesip-certificates/](https://www.trustcb.com/iot/sesip/sesip-certificates/)
-   PSA: [https://products.psacertified.org/](https://products.psacertified.org/)
-   NIST: [https://csrc.nist.gov/projects/cryptographic-module-validation-program/](https://csrc.nist.gov/projects/cryptographic-module-validation-program/)

**Parent topic:**[Secure applications](AN5156_secure-applications.md)

