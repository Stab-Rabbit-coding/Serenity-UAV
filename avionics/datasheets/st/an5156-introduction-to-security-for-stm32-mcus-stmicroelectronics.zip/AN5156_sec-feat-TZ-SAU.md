# Secure attribution unit \(SAU\) {#id_12499}

The SAU is a hardware unit coupled to the core \(as the MPU\). The SAU is responsible for setting the security attribute of the AHB/AXI transaction. The security attribute of a transaction is fixed by the targeted address of a memory-mapped resource \(memory areas or peripherals\). Depending on the SAU configuration, an address is tagged as secure, nonsecure callable \(NSC\), or nonsecure. The NSC is a subdomain of the secure domain that allows a gateway to be defined for nonsecure code to access the secure domain at a specific entry point.

The SAU is configurable by secure firmware. It can be configured at boot for a fixed configuration, or can be dynamically modified by a secure firmware.

**Note:** A security attribute cannot be modified to be less secure \(by security order: secure \> NSC \> nonsecure\) than a default attribute set by hardware through an IDAU \(implementation defined secure attribute\). Refer to implementation details of each device in the reference manual.

**Address aliasing**

The security attribute is set depending on the fixed resource address. However, a memory‑mapped resource can be set either as secure or nonsecure, depending on the application. To overcome this apparent contradiction, two addresses are assigned to each memory-mapped resource: one used when the resource must be accessed in secure mode, one used in nonsecure mode. This mechanism is called address aliasing.

The address aliasing also allows all peripheral accesses to be grouped in only two regions instead of multiple scattered regions. Finally, the IDAU splits the memory-mapped resources in the following regions:

-   Peripherals secure/nonsecure regions
-   Flash memory secure/nonsecure regions
-   SRAM secure/nonsecure regions

Refer to device reference manual for the detailed configuration.

**Parent topic:**[TrustZone](AN5156_sec-feat-TrustZone.md)

