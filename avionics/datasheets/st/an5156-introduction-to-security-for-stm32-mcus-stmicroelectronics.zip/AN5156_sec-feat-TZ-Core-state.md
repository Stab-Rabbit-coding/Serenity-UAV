# Core state {#id_12498}

The core state depends on the region of the current running code. When the code runs from a secure region, the core is in secure state. Otherwise, the core is in nonsecure state.

**Parent topic:**[TrustZone](AN5156_sec-feat-TrustZone.md)

