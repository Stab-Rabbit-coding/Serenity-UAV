# Power monitoring \(PVD\) {#power_monitoring}

Some attacks target the MCU power supply to cause errors that lead to a failure of security countermeasures. A loss of power supply sometimes denotes an attempt to freeze the device state in order to access the internal memory content.

The STM32 devices embed a programmable voltage detector \(PVD\) that can detect a drop of power. The PVD allows the configuration of a minimum voltage threshold, below which an interrupt is generated, so that appropriate actions are implemented.

**When to use the PVD**

The PVD must be used as soon as a sensitive application runs, and is likely to leave some confidential data in the working memory \(SRAM\). A memory cleaning can be launched in case of power down detection.

**Note:** The PVD is available on all STM32 devices.

**Parent topic:**[STM32 security features](AN5156_Stm32-security-features.md)

