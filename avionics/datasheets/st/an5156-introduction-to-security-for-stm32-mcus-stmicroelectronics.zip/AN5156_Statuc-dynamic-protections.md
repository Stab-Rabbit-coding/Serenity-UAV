# Static and dynamic protections {#id_51268}

A distinction can be made depending on whether protection features are static or dynamic:

-   **Static** protections refer to features that are set with option bytes. Their configuration is retained at power off.

    Static protections are RDP \(or product state\), PCROP, WRP, BOR, OTP, and secure hide protection \(when available\).

-   **Dynamic** \(or run time\) protections do not retain their status at reset. They have to be configured at each boot \(for example during [Secure boot \(SB\)](AN5156_sec-appl-Secure-boot.md) \).

    Dynamic protections provided by STM32 include MPU, tamper detection, and firewall.

    Other dynamic protections are related to both security and safety. An abnormal environment behavior may be accidental \(safety\) or intentional, in order to carry out an attack. These protections include clock and power monitoring systems, memory integrity bits, and independent watchdog \(IWDG\).


**Parent topic:**[Overview of security features](AN5156_sec-feat-Overview.md)

