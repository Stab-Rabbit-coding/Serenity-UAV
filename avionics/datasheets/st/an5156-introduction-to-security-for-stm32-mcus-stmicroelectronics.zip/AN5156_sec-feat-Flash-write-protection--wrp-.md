# Flash memory write protection \(WRP\) {#write_protection__wrp_}

The write protection feature is used to protect the content of the specified memory area against erase or update.

For flash memory technology, an update must be considered as filling with zeros.

For instance, the write protection can be set on a page or a sector of a flash memory to prevent its alteration during a firmware or data update. It can also be set by default on the unused memory area to prevent any malware injection. Its granularity is linked to the page or sector size.

**When to use the WRP**

This protection must be used, in particular when write operations are foreseen within the application. This is the case if data storage or code update operations are expected. The WRP prevents wrong accesses due to unsafe functions causing unexpected overflows.

**Note:** The WRP is available on all STM32 devices with internal flash memory.

**Parent topic:**[STM32 security features](AN5156_Stm32-security-features.md)

