# Cryptography {#cryptography_implementation}

As described in [Secure applications](AN5156_secure-applications.md), cryptography is essential to secure an embedded system. The cryptography enables confidentiality, integrity, and authentication of data or code. For efficiently supporting these functions, most STM32 series include products with hardware cryptography peripherals. These peripherals allow cryptographic computations \(such as hashing or symmetric algorithms\) to be accelerated. For devices with no such specific hardware acceleration, the STM32 cryptographic firmware library \(CryptoLib\) provides a software implementation of a large set of cryptographic algorithms.

The cryptography related features for each product can be identified via their root part number, specifically on the second number or letter after the series identifier. For example the STM32L4**8**6 and STM32H7**B**3 devices have crypto hardware while the STM32L4**7**6 and STM32H7**A**3 have to use software library to implement cryptography, and it can be known by their naming.

**Parent topic:**[STM32 security features](AN5156_Stm32-security-features.md)

