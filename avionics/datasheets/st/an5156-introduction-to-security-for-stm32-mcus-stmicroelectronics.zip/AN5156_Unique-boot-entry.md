# Unique boot entry {#id_62804}

If the secure boot firmware is located in the user flash, it is important to prevent the attacker from diverting the boot sequence from the intended progression. This is the goal of the unique boot entry or BOOT\_LOCK.

The RDP2 on some products prevent booting from other memory. The BOOT\_LOCK goes further by also working in RDP1 and working with the product state life-cycle management. In some devices the BOOT\_LOCK allows the possibility to lock the boot to a specific address.

Even if RDP2 is set; the unique boot entry provides additional security assurance against glitch attacks.

A unique boot entry is available on STM32Ux, STM32Gx, STM32Hx, STM32Cx series, and in STM32WBA wireless devices. Implementation details are available in each device reference manual, on the sections about boot configuration and flash.

**Parent topic:**[STM32 security features](AN5156_Stm32-security-features.md)

