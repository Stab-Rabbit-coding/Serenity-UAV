# True random generator \(TRNG\) {#id_81819}

The ability to generate unpredictable numbers with appropriate statistical properties is essential for cryptographic security. Most STM32 MCUs feature a hardware-based peripheral based on a physical noise source. It can be used to feed a DRNG with a seed, or directly for random numbers, depending on device. Depending on the device, it can be used to seed a DRNG or to generate random numbers directly.

**Note:** For more details about the RNG validation, refer to the application note "Introduction to random number generation validation using the NIST statistical test suite for STM32 MCUs and MPUs" \(AN4230\).

**Parent topic:**[STM32 security features](AN5156_Stm32-security-features.md)

