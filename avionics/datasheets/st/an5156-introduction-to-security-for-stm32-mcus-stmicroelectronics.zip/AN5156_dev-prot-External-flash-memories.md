# External flash memories {#external_flash_memories}

The external flash memories are connected to the microcontroller through dedicated interfaces \(NAND, NOR, Octo-SPI, or Quad-SPI\). As the embedded flash memory, the external ones contain code and data, but the external storage raises the problem of confidentiality \(content protection\) and authentication \(device protection\). The hardware protection is limited to a write lock, to avoid content erasing or modification. Further protection is brought by cryptography algorithms. The content must be at least signed to avoid execution of unauthenticated firmware. Encryption is required only if the content is confidential.

The embedded code can be either executed in-place or loaded into the SRAM before execution. Execution in-place of encrypted firmware is possible only if the device has on-the-fly decryption capabilities. In the other case, the firmware must be decrypted when loaded into SRAM. If the decrypted code or parts of it are not protected from readout \(RDP2\), then the confidentiality of the code is violated. It is also recommended to combine encryption with integrity protection.

*Associated protection:* OTFDEC, MCE

**Parent topic:**[Memory protections](AN5156_Dev-prot-Memory-protections.md)

