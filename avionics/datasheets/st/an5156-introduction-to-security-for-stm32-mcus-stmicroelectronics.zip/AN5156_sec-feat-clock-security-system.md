# Clock security system \(CSS\) {#clock_security_system}

The CSS is designed to detect a failure of an external clock source \(a crystal for example\). A loss of clock source is intentional or not. In any case, the device must take appropriate actions to recover. The CSS triggers an interrupt to the core in such event.

If the external clock source drives the main system clock, the CSS switches the system to an internal clock source.

**When to use the CSS**

The CSS must be used when an external clock is used.

**Note:** The CSS is available on all STM32 devices.

**Parent topic:**[STM32 security features](AN5156_Stm32-security-features.md)

