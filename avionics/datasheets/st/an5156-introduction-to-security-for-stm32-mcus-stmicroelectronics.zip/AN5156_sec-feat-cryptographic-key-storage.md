# Customer key storage \(CKS\) {#id_7071}

STM32WB series are dual-core devices with one core \(CPU1\) for user application, and another core \(CPU2\) dedicated to the wireless real-time aspect execution \(either Bluetooth® LE, ZigBee, or thread protocols\). The flash memory used by CPU2 is isolated from the CPU1 or external access. Communication between the two cores is ensured by a mailbox and an interprocess channel control hardware block \(IPCC\).

In addition to the wireless stack execution, the CPU2 offers a secure storage service for cryptographic keys used with a dedicated AES hardware peripheral \(see [Figure 1](#fig_sqc_jgz_tgb)\). The AES key register is accessible only to the CPU2, preventing access to the key by an untrusted process running on the CPU1, or by the debug port.

After the keys have been provisioned inside the secure area, the user application can use them by calling a secure load service with an index referencing the key and no more the key itself.

![](DT61168.svg "Dual-core architecture with CKS service ")

**When to use the CKS**

The CKS must be used when a user application relies on AES encryption or decryption. Provisioned keys can be stored in a secure area, so that no other internal process or external access can read their value.

**Note:** The CKS is available on STM32WB series only.

**Parent topic:**[STM32 security features](AN5156_Stm32-security-features.md)

