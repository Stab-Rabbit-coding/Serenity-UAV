# Software isolation {#software_isolation}

The software isolation refers to a runtime mechanism protecting different processes from each other \(interprocess protection\). These processes can be executed sequentially or concurrently \(for example tasks of operating system\). The software isolation in the SRAM ensures that respective stack and working data of each process cannot be accessed by the other processes. This interprocess protection can be extended to the code in the flash memory and nonvolatile data as well.

Goals of the software isolation:

-   Prevent a process to spy the execution of another sensitive process.
-   Protect a process execution against a stack corruption due to memory leaks or overflow \(incorrect memory management implementation\).

This memory protection can be achieved through different mechanisms listed in the table below, and detailed in [STM32 security features](AN5156_Stm32-security-features.md).

**Table 1. Software isolation mechanism**

|Protection|Type|Isolation|
|:--------:|:--:|:-------:|
|MPU|Dynamic|By privilege attribute [^1]|
|Firewall|Static|By bus address hardware control|
|Secure hide protection \(HDP\)|Static|Process preemption at reset|
|Dual core|Static|By core ID[^2]|
|TrustZone®/Security attribute|Static and dynamic|By secure attribute propagated from the core to all resources|

**Parent topic:**[Device protections](AN5156_Device-protections.md)

<a id="fn1"></a>

[^1]: The attribute protection is only for CPU access and is not taken into account for other bus master \(such as DMA\).<a id="fn2"></a>

[^2]: Reading the CPUID indicates which CPU is currently executing code. An example can be found in the HAL\_GetCurrentCPUID function.

