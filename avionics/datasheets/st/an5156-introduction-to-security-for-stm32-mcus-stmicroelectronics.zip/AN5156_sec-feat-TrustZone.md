# TrustZone {#id_12491}

This section describes the main features of the TrustZone® architecture. For further information, refer to the application note *Arm® TrustZone® features on STM32L5 and STM32U5 series* \(AN5347\), and to the device reference manual.

The Armv8-M TrustZone® architecture defines two domains at system level: secure and nonsecure. The full memory-map space is split into secure and nonsecure areas. This includes all memory types \(flash memory, SRAM, and external memories\), as well as all peripherals that can be shared \(with specific context for each domain\) or dedicated to one domain or the other.

At system level, the isolation between secure and nonsecure domains relies on the following hardware mechanisms \(see [Figure 1](#fig_bml_3hd_1jb)\):

-   specific core architecture \(Armv8-M Cortex-M33\) with a dual execution domain for secure and nonsecure domains, and an implementation defined attribution unit \(IDAU\) to assert address range security status
-   secure attribution unit \(SAU\) is used to refine settings of the IDAU
-   bus infrastructure that propagates the secure and privilege attributes of any transaction \(AHB5\)
-   dedicated hardware blocks managing the split between the two domains \(GTZC to define security attribute for internal SRAMs and external FSMC/OCTOSPI memories, and peripherals\)

![](DT63688.svg "TrustZone implementation at system level")

-   **[Core state](AN5156_sec-feat-TZ-Core-state.md)**  

-   **[Secure attribution unit \(SAU\)](AN5156_sec-feat-TZ-SAU.md)**  

-   **[Memory and peripheral protections](AN5156_sec-feat-TZ-Mem-periph-protec.md)**  


**Parent topic:**[STM32 security features](AN5156_Stm32-security-features.md)

