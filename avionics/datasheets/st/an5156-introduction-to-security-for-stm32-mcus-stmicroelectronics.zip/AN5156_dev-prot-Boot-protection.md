# Boot protection {#boot_protection}

The boot protection secures the very first software instructions in a system. If an attacker succeeds in modifying the device boot address, he/she can execute his/her own code, to bypass initial dynamic protections configuration or to access unsecured bootloader applications that give access to the device memory.

A microcontroller usually allows the boot configuration in order to choose between starting at user application, at bootloader application, or at the SRAM located firmware. The boot protection relies on a single entry point to a trusted code that can be the user application, or a secure service area if available \(RSS\).

Associated STM32 features:

-   Read protection \(RDP\)/product state
-   Unique boot entry
-   Secure hide protection \(HDP\)
-   TrustZone
-   System flash security package \(SFSP\). See AN6014 [AN5156\_General-Info.md\#ph\_13](AN5156_General-Info.md#ph_13) for more details.

**Parent topic:**[Device protections](AN5156_Device-protections.md)

