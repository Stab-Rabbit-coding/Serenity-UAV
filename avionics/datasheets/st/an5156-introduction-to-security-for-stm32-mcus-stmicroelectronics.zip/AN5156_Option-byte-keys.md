# Option byte keys \(OBK\) {#id_67719}

Option byte keys are secure, nonvolatile storage intended for the protection of keys, specifically storage encryption keys. First introduced on the STM32H5, option byte keys are linked to a multilevel HDP boot progression. Each HDPL value increment closes access to keys used by lower levels, aiding in the implementation of a true secure boot.

The OBK was revised for the STM32H7RS where it is used for the same purpose, but with improved mechanisms of OBK storage management.

OBK is linked to usage of SAES and, in some cases, never allows the actual key to be revealed outside of the hardware storage \(hardware keys\).

*\(The OBK is included in STM32H5 and STM32H7R/S\)*

**Parent topic:**[STM32 security features](AN5156_Stm32-security-features.md)

