# General information {#concept_vts_yqx_fcb .concept}

This document applies to STM32 Arm® Cortex®-core based microcontrollers.

![](Arm_logo_black_no_frame.svg)

**Note:**

Arm and Cortex are registered trademarks of Arm Limited \(or its subsidiaries or affiliates\) in the US and/or elsewhere.

The Arm word and logo are trademarks of Arm Limited \(or its subsidiaries\) in the US and/or elsewhere. All rights reserved.

 

 

The table below presents a nonexhaustive list of the acronyms used in this document and their definitions.

**Table 1. Glossary**

|Term|Definition|
|:--:|----------|
|AES|Advanced encryption standard|
|CCM|Core-coupled memory \(SRAM\)|
|CPU|Central processing unit–core of the microcontroller|
|CSS|Clock security system|
|DoS|Denial of service \(attack\)|
|DRNG|Deterministic random number generator: generates pseudo-random number from input value|
|DPA|Differential power analysis|
|ECC|Error code correction|
|FIA|Fault injection attack|
|FIB|Focused ion beam|
|GTZC|Global TrustZone® controller|
|HDP|Secure hide protection|
|HUK|Hardware unique key|
|IAP|In-application programming|
|IAT|Initial attestation token|
|IoT|Internet of things|
|IV|Initialization vector \(cryptographic algorithms\)|
|IWDG|Independent watchdog|
|MAC|Message authentication code|
|MCU|Microcontroller unit \(STM32 Arm® Cortex®-M based devices\)|
|MPCBB|Memory protection block-based controller|
|MPCWM|Memory protection watermark-based controller|
|MPU|Memory protection unit|
|NSC|Nonsecure callable|
|NVM|Nonvolatile memory|
|OTFDEC|On-the-fly decryption|
|OTP|One-time programmable|
|PCROP|Proprietary code readout protection|
|PKA|Public key algorithm \(also named aka asymmetric algorithm\)|
|PSA|Platform security architecture|
|PVD|Programmable voltage detector|
|PWR|Power control|
|ROM|Read only memory–system flash memory in STM32|
|RoT|Root of trust|
|RDP|Read protection|
|RIF|Resource isolation framework|
|RSS|Root secure services|
|RTC|Real-time clock|
|SAU|Security attribution unit|
|SB|Secure boot|
|SCA|Side channel attack|
|SDRAM|Synchronous dynamic random access memory|
|SECDED|ECC mode of operation: single error correct, double error detect|
|SFI|Secure firmware installation|
|SFU|Secure firmware update|
|SPA|Simple power analysis|
|SPE|Secure processing environment|
|SRAM|Static random access memory \(volatile\)|
|SST|Secure storage|
|STSAFE|Secure element product from STMicroelectronics portfolio|
|SWD|Serial-wire debug|
|TF-M|Trusted firmware-M|
|WRP|Write protection|

**Documentation references**

The **reference manual** of each device gives details on the availability of security features. It also informs about memory protections implementation.

A **programming manual** is also available for each Arm® Cortex® version and can be used for an MPU \(memory protection unit\) description:

-   *STM32 Cortex®-M33 MCUs programming manual* \(PM0264\)
-   *STM32F7 series and STM32H7 series Cortex®-M7 processor programming manual* \(PM0253\)
-   *STM32 Cortex®-M4 MCUs and MPUs programming manual* \(PM0214\)
-   *STM32F10xxx/20xxx/21xxx/L1xxxx Cortex®-M3 programming manual* \(PM0056\)
-   *Cortex®-M0+ programming manual for STM32L0, STM32G0, STM32WL, STM32WB, and STM32WB0 series \(PM0223\)*

Refer to the following set of **user manuals** and **application notes** \(available on [*www.st.com*](https://www.st.com)\) for detailed description of security features:

<table>
<thead>
<tr>
<th>Ref.</th>
<th>Doc number</th>
<th>Title</th>
<th>Comment</th>
</tr>
</thead>
<tbody>
<tr>
<td>[1]</td>
<td>AN4246</td>
<td>Proprietary code readout protection on STM32L1 series MCUs</td>
<td rowspan="4">Explains how to set up and work with PCROP firmware for the specified MCUs, provided with the X‑CUBE‑PCROP expansion package.</td>
</tr>
<tr>
<td>[2]</td>
<td>AN4701</td>
<td>Proprietary code readout protection on STM32F4 series MCUs</td>
</tr>
<tr>
<td>[3]</td>
<td>AN4758</td>
<td>Proprietary code readout protection on STM32L4, STM32L4+, STM32G4, and STM32WB series MCUs</td>
</tr>
<tr>
<td>[4]</td>
<td>AN4968</td>
<td>Proprietary code readout protection on STM32F72/F73xx MCUs</td>
</tr>
<tr>
<td>[5]</td>
<td>AN4838</td>
<td>Managing memory protection unit (MPU) in STM32 MCUs</td>
<td>Describes how to manage the MPU in the STM32 products.</td>
</tr>
<tr>
<td>[6]</td>
<td>AN5185</td>
<td>STMicroelectronics firmware upgrade services for STM32WB series</td>
<td>-</td>
</tr>
<tr>
<td>[7]</td>
<td>AN5447</td>
<td>Overview of secure boot and secure firmware update solution on Arm® TrustZone® STM32 MCUs</td>
<td>-</td>
</tr>
<tr>
<td>[8]</td>
<td>UM1924</td>
<td>Legacy STM32 crypto library</td>
<td>Describes the API of the STM32 crypto library; provided with the X‑CUBE‑CRYPTOLIB expansion package.</td>
</tr>
<tr>
<td>[9]</td>
<td>UM2262</td>
<td>Getting started with the X-CUBE-SBSFU STM32Cube expansion package</td>
<td>Presents the SB (secure boot) and SFU (secure firmware update) STMicroelectronics solutions; provided with the X‑CUBE‑SBSFU expansion package.</td>
</tr>
<tr>
<td>[10]</td>
<td>AN4730</td>
<td>Using the firewall embedded in STM32L0/L4/L4+ series MCUs</td>
<td>Describes how to access securely sensitive parts of code and data</td>
</tr>
<tr>
<td>[11]</td>
<td>AN6205</td>
<td>Introduction to the use of PKA key wrapping with coupling and chaining bridge on STM32 MCUs</td>
<td>This AN focuses on use of CCB in STM32U3 series.</td>
</tr>
<tr>
<td>[12]</td>
<td>AN6008</td>
<td>Getting started with debug authentication (DA) for STM32 MCUs</td>
<td>Describes debugging selected STM32H5 and STM32H7 devices that support temporary opening on otherwise closed device.</td>
</tr>
<tr>
<td>[13]</td>
<td>AN6014</td>
<td>Introduction to SFSP versions for STM32H5 MCUs</td>
<td>System flash security package (SFSP) is available on selected devices of STM32H5 series.</td>
</tr>
<tr>
<td>[14]</td>
<td>AN6007</td>
<td>Getting started with STiRoT (ST immutable Root of Trust) for STM32H5 MCUs</td>
<td>Introductory document about STM32H5 secure boot solution.</td>
</tr>
<tr>
<td>[15]</td>
<td>AN5391</td>
<td>Introduction to SFI tools, bootloader, and RSS interface for STM32 MCUs</td>
<td>This SFI‑related application note is not publicly available. Contact your ST sales representative to request it.</td>
</tr>
<tr>
<td>[16]</td>
<td>AN5054</td>
<td>How to perform secure programming using STM32CubeProgrammer</td>
<td>-</td>
</tr>
<tr>
<td>[17]</td>
<td>AN4992</td>
<td>Introduction to secure firmware install (SFI) for STM32 MCUs</td>
<td>-</td>
</tr>
<tr>
<td>[18]</td>
<td>AN4657</td>
<td>STM32 in-application programming (IAP) using the USART</td>
<td>-</td>
</tr>
<tr>
<td>[19]</td>
<td>AN5056</td>
<td>How to integrate the X-CUBE-SBSFU STM32Cube Expansion Package</td>
<td>-</td>
</tr>
<tr>
<td>[20]</td>
<td>AN5544</td>
<td>Integration guide of SBSFU on STM32CubeWL (including KMS)</td>
<td>-</td>
</tr>
</tbody>
</table>

The ST wiki also offers vast resources on security topics, including detailed step-by-step guides on [https://wiki.st.com/stm32mcu/wiki/Category:Security](https://wiki.st.com/stm32mcu/wiki/Category:Security)

