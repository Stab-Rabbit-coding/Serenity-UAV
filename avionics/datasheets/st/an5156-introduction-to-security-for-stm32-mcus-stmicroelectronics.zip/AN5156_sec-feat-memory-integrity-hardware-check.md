# Memory integrity hardware check {#memory_integrity_hardware_check}

The error code correction \(ECC\) and parity checks are safety bits associated to the memory content:

-   The ECC is associated to the memory words, used to recover from a single-bit error, or to detect up to two erroneous bits on each flash memory or SRAM word \(32- to 256-bit word depending on the memory type\). Refer to the AN5342 for more details.
-   A simple parity check allows the detection of a single error bit on the SRAM words where ECC is not implemented.

**When to use ECC and parity check**

ECC and parity checks are mostly used for safety reasons. The ECC can also be used to prevent some invasive hardware attacks.

**Note:** This integrity protection is available on all devices except STM32F1 and STM32L1. STM32H7 devices are champion in ECC protection.

**Parent topic:**[STM32 security features](AN5156_Stm32-security-features.md)

