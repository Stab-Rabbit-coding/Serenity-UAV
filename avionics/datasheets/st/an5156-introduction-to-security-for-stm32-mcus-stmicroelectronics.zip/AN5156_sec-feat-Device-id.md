# Device ID {#device_id}

Each STM32 device has a unique 96-bit identifier providing an individual reference for any device in any context. These bits can never be altered by the user.

The unique device identifier can be used for direct device authentication, or for instance to derive a unique key from a master OEM key.

**Parent topic:**[STM32 security features](AN5156_Stm32-security-features.md)

