# Hardware attacks {#hardware_attacks}

Hardware attacks require a physical access to the device or, often, to several devices in parallel.

The two following types of attacks differ in cost, time, and necessary expertise:

-   Non-invasive attacks have only external access to the device \(board-level attack\) and are moderately expensive \(thousands to tens of thousands US dollars in equipment\).
-   Invasive attacks have direct access to device silicon \(after de-packing\). They are carried out with advanced equipment often found in specialized laboratories. They are very expensive \(more than 100k dollars, and often in the range of millions\) and target very valuable data \(Keys or IDs\) or even the protection technology itself.

General-purpose microcontrollers are not the best candidates to counter the most advanced physical attacks. If a highest protection level is required, consider pairing a secure element with the general-purpose microcontroller. Secure elements are dedicated microcontrollers certified as per the latest security standards with specific hardware.

Refer to [ST secure](https://www.st.com/en/secure-mcus.html) microcontrollers web page.

-   **[Non-invasive attacks](AN5156_Attack-Non-invasive-attacks.md)**  

-   **[Silicon invasive attacks](AN5156_Attack-Silicon-invasive-attacks.md)**  


**Parent topic:**[Attack types](AN5156_attack-types.md)

