# STMicroelectronics proprietary SBSFU solution {#id_17572}

Secure boot and secure firmware update are complementary security concepts. The associated model implementation can be found in the X-CUBE-SBSFU package.

-   **[Secure boot \(SB\)](AN5156_sec-appl-Secure-boot.md)**  

-   **[Secure firmware update \(SFU\)](AN5156_sec-appl-Secure-firmware-update.md)**  

-   **[Configurations](AN5156_configurations.md)**  


**Parent topic:**[Secure applications](AN5156_secure-applications.md)

