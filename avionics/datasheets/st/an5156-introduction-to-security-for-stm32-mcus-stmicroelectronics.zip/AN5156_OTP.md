# One-time programmable \(OTP\) {#id_24989}

The OTP is a dedicated, isolated area in the flash memory, which can be only written on or locked out, preventing any modification. It is usually a smaller area compared to the size of the user flash memory.

This feature is very useful for lifecycle management, provisioning, personalization, or configuration. Once the OTP is written, there is no method of erasing data without physically damaging the device. No restriction is implicitly put on reading written data.

**Note:** The OTP is available on most STM32 devices \(refer to [Overview](AN5156_Overview.md) for more details\).

**Parent topic:**[STM32 security features](AN5156_Stm32-security-features.md)

