# Secret key algorithms {#secret_key_algorithms}

This family of algorithms ensures confidentiality by ciphering a clear plain text with a secret key shared between the transmitter and the receiver. This technique is referred to as symmetric cryptography because the same key is used for ciphering and deciphering.

![](DT50955.svg "Symmetric cryptography")

The inherent weakness of these algorithms is the key sharing between both parties. It may not be an issue in secure environments \(such as manufacturing plants\), but when both parties are distant, the key transfer becomes a challenge.

Among all secret key algorithms, block-based algorithms are very common since they can be efficiently accelerated by hardware or software parallel implementations. Typical AES \(advanced encryption standard\) algorithms operate on clear blocks of 128 bits. They produce ciphered blocks of the same length using keys of 128, 192, or 256 bits. The different ways to chain consecutive blocks are called “mode of operations”. They include cipher block chaining \(CBC\), counter mode \(CTR\) and Galois counter mode \(GCM\).

Since these algorithms are deterministic, they always mix input data with a random value, known as nonce, used only for one session as initialization vector.

**Parent topic:**[Cryptography–Main concepts](AN5156_A-Crypto-main-concepts.md)

