# Cryptography–Main concepts {#cryptography___main_concepts}

## Integrity, authentication, and confidentiality { .section}

The objectives of cryptography are threefold:

-   Confidentiality: protection of sensitive data against unauthorized read access
-   Authentication: ensuring the identity of the message sender
-   Integrity: detection of any message corruption during transmission

To meet these objectives, all secure data flows rely on more or less complex combinations of the below algorithms:

-   Secret key/symmetric cryptography
-   Public key/asymmetric cryptography
-   Hashing

These algorithms are described in this appendix.

-   **[Secret key algorithms](AN5156_A-Secret-key-algorithms.md)**  

-   **[Public key algorithms \(PKA\)](AN5156_A-Public-key-algorithms--pka-.md)**  

-   **[Hash algorithms](AN5156_A-Hash-algorithms.md)**  

-   **[MAC or signature and certificate](AN5156_A-Mac-signature-certificate.md)**  


