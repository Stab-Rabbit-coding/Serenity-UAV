# Attack types {#attack_types}

This section presents the different types of attack that a microcontroller in finished product may have to face, from the most basic ones to very sophisticated and expensive ones. The last part presents typical examples of attacks targeting an IoT system.

Attacks on microcontroller are classified in one of the following types:

-   Software attack: exploits software vulnerabilities \(such as bug or protocol weaknesses\).
-   Hardware non-invasive attack: focuses on MCU interfaces and environment information.
-   Hardware invasive attack: destructive attack with direct access to silicon.

Separate category would be an attempt to compromise manufacturing security, where ST is helping by providing SFI \(secure firmware install\).

-   **[Introduction to attack types](AN5156_Attack-Introduction.md)**  

-   **[Software attacks](AN5156_Attack-Software-attacks.md)**  

-   **[Hardware attacks](AN5156_Attack-Hardware-attacks.md)**  

-   **[IoT system attack examples](AN5156_Attack-Iot-system-attack-examples.md)**  

-   **[List of attack targets](AN5156_list-of-attack-targets.md)**  


