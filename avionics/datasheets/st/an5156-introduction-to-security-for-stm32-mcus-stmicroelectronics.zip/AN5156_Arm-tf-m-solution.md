# Arm TF-M solution {#id_17564}

Arm trusted firmware existed for chips based on Cortex-A when the secure Cortex-M33 core was introduced with Armv8-M architecture. A more compact TF-M open-source implementation of PSA standard was provided as a reference secure firmware framework.

For STMicroelectronics MCUs that take advantage of the Armv8 architecture \(such as STM32H5, STM32L5, STM32U3, and STM32U5 devices\), the SBSFU is enhanced with the TF-M based solution.

For a documentation on TF-M itself, refer to the UM2851, and use Arm resources as well as the code comments.

For guidance on TF-M integration on the STM32L5 and STM32U5 devices, refer to the user manuals *Getting started with STM32CubeL5 TF-M application* \(UM2671\) or *Getting started with STM32CubeU5 TF-M application* \(UM2851\).

Refer to document [AN5156\_General-Info.md\#entry\_h2q\_brz\_qvb](AN5156_General-Info.md#entry_h2q_brz_qvb) for a detailed comparison when migrating from X-CUBE-SBSFU package SBSFU to TF-M.

**Table 1. Basic feature differences of TrustZone®-based secure software**

|Feature|SBSFU for TrustZone®|TF-M|
|:-----:|:------------------:|:--:|
|RoT services|Immutable RoT|Immutable RoT + updatable RoT|
|Cryptographic key management|Static keys only|Key storage hierarchy with HUK root key|
|Secure storage|Absent|Internal and external|
|NV counter|No|Yes|

Both alternatives are based on TF-M and MCU boot, but while SBSFU intends to replicate familiar features of X-CUBE-SBSFU while retaining most flash memory space for user code, TF-M offers more functionality. Some of that can be dropped to gain memory space. For the STM32H57x line, the Secure Manager, a closed-source implementation of TF-M, offers a convenient and express way to adopt certified secure solutions.

**Parent topic:**[Secure applications](AN5156_secure-applications.md)

