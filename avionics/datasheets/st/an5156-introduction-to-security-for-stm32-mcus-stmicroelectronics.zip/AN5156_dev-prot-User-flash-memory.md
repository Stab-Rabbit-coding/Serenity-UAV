# User flash memory {#user_flash_memory}

This is the main user memory, used to store firmware and non-volatile data. It is part of the embedded flash memory, and can be protected by a set of memory protection features available on all STM32 MCUs.

## External attacks { .section}

The embedded flash memory is easy to protect against external attacks, unlike external flash memories. Disabling the debugging port access with RDP and the controlled access of connectivity interface provide sufficient isolation from outside.

*Associated protection*: RDP, or closed state to disable debug access

## Internal attacks { .section}

An internal read or write access to the memory can come from a malware injected either in the device SRAM or inside an untrusted library, so that the critical code and data must only be accessible by authorized processes.

*Associated protections*: PCROP, MPU, firewall, secure hide protection, or TrustZone

## Protecting unused memory { .section}

Write protection must always be set by default on the flash memory, even on unused area, to prevent either code modification or injection. A good practice is to fill unused memory with known values such as software interrupt \(SWI\) op-codes, illegal op-codes, or NOPs.

*Associated protections*: MPU or WRP

## Error code correction \(ECC\) { .section}

The flash memory sometimes feature ECC that allows error detection and correction \(up to 2-bit error detection and 1-bit error correction\). More considered as a safety feature, it also works as a complementary protection against fault injection.

**Parent topic:**[Memory protections](AN5156_Dev-prot-Memory-protections.md)

