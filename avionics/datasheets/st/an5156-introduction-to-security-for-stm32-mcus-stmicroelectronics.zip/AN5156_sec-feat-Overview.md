# Overview of security features {#overview}

-   **[Static and dynamic protections](AN5156_Statuc-dynamic-protections.md)**  

-   **[Security features by STM32 devices](AN5156_Security-features-by-STM32.md)**  


**Parent topic:**[STM32 security features](AN5156_Stm32-security-features.md)

