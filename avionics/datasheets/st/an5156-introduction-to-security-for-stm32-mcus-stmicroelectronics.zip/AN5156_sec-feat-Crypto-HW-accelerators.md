# Hardware accelerators {#id_12487}

The following cryptographic peripherals are available in STM32 devices:

-   TRNG \(true random generator\)
    -   hardware-based peripheral providing a physical noise source. Used to feed a DRNG with a seed, or directly for random numbers, depending on device.

        *Note: For details about the RNG validation, refer to the application note 'STM32 microcontroller random number generation validation using the NIST statistical test suite' \(AN4230\).*

-   AES accelerator

    -   encryption/decryption
    -   128- or 256‑bit keys
    -   several modes of operation \(such as ECB, CBC, CTR, or GCM\)
    -   DMA support
    *Note: When the AES is used for encryption or decryption, the access to its registers containing the key must be protected and cleaned after use \(the MPU can be configured to restrict access to memory with keys\).*

-   PKA accelerator
    -   acceleration of RSA, DH, and ECC over GF\(p\) operations, based on the Montgomery method for fast modular multiplications
    -   built-in Montgomery domain inward and outward transformation
-   HASH accelerator
    -   MD5, SHA‑1, SHA‑2, and SHA‑3 \(SHA‑3 support is limited to the newest products only\)
    -   FIPS compliant \(FIPS Pub 180-2\)
    -   DMA support

**Note:** Many low-power STM32 devices feature hardware cryptography accelerators. The amount of energy needed to complete cryptographic computations with them is lower than the amount of energy required to treat them via software processing.

