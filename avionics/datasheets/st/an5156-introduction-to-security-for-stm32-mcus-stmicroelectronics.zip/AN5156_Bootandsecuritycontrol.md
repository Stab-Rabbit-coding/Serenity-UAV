# Boot and security control \(BSEC\) {#id_70899}

On the STM32N6 series flashless microcontroller, the boot security and product state management are implemented using a large \(12k\) array of OTP fuses and data.

It is connected via core logic with debug interface, crypto, system bus, ST boot ROM, and clock control.

This system allows setting a 128-bit strong protection on debug access and product state including protection of the external program memory.

The OTP nature means increased security compared to regular flash memory, with acceptable drawback of limiting the re-usability of once provisioned device. OTP password were also used in product state protection on other popular devices.

Boot security is implemented so that the STM32N6 always boots in the ST boot ROM, which uses the OTP settings to execute the boot progression in configured manner.

**Parent topic:**[STM32 security features](AN5156_Stm32-security-features.md)

