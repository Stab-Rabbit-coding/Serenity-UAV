# Conclusion {#conclusion}

No system can be made secure by simply enabling security features in the hardware. Security must be rooted in the architecture of the complete solution.

The threats must be identified, the countermeasures correctly designed and implemented in synergy with other security features.

As security demands considerable resources, it is important to correctly evaluate the risks, and spend the resources efficiently, keeping in mind the cost of attack and the value of the protected asset.

The concept of root of trust is pivotal because it uses a more hierarchic and centralized approach, as opposed to attempting to apply security ad hoc.

With the STM32 microcontrollers, the embedded and IoT security is very cost-effective and robust.

