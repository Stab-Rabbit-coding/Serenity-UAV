# Firewall {#firewall}

The firewall is a hardware protection peripheral controlling the bus transactions and filtering accesses to three particular areas: a code area \(flash memory\), a volatile data area \(SRAM\) and a nonvolatile data area \(flash memory\). The protected code is accessible through a single entry point \(the call-gate mechanism explained below\). Any attempt to jump and try to execute any of the functions included in the code section without passing through the entry point, generates a system reset.

The firewall is part of the dynamic protections. It must be set at startup \(for example by an SB application\).

## Call gate mechanism { .section}

The firewall is opened by calling a 'call-gate' mechanism: a single entry point that must be used to open the gate, and to execute the code protected by the firewall. If the protected code is accessed without passing through the call gate mechanism, then a system reset is generated. If any instruction is fetched outside the protected area, the firewall is closed \(see the figure below\).

![](DT50954.svg "Firewall FSM")

Since the only way to respect the call gate sequence is to pass through the single call gate entry point, a mechanism must be provided in order to support application calling multiple firewall-protected functions from unprotected code area \(such as encrypt and decrypt functions\). A parameter can be used to specify which function to execute \(such as `CallGate(F1_ID)` or `CallGate(F2_ID)`\). According to the parameter, the right function is internally called. This mechanism is represented in the figure below.

![](DT50961.svg "Firewall application example")

## When to use the firewall {#section_rm2_j1t_q1c .section}

The firewall protects both code and data. The protected code can always be called as long as a call gate mechanism is respected.

**Note:** A firewall is available on STM32L0 and STM32L4 devices only. Refer to the application note AN4730 for more details. The firewall functionality is replaced by TrustZone.

**Parent topic:**[STM32 security features](AN5156_Stm32-security-features.md)

