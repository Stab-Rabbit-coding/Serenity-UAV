# Antitamper \(TAMP\)/backup registers \(BKP\) {#anti_tamper}

The antitamper is a system level protection, used to detect physical tampering attempts on the system. An external tamper event is detected by a level transition on dedicated device pins. Internal tamper sensors can check voltage, temperature, or clock. This event can be used to wake up the core in order to take appropriate actions \(such as memory erase or alarm\).

This TAMP peripheral includes backup registers with contents preserved by VBAT, along with the real-time clock \(RTC\). These registers can be reset if a tamper attempt is detected.

On some STM32 devices, this peripheral is known as backup registers \(BKP\). On recent devices, it has evolved with additional features, such as monotonic counter, or secure section for TrustZone® secure area.

**When to use the antitamper**

It must be used for system intrusion detection \(in consumer products sealed enclosures for example\). The monotonic counter is a countermeasure against tampering with the RTC.

**Note:** The external tamper detection is available on all STM32 devices. More information about tamper functionality usage is available, for example, in AN4759.

**Parent topic:**[STM32 security features](AN5156_Stm32-security-features.md)

