# Embedded SRAM {#embedded_sram}

The embedded SRAM is the device working memory. It is used for stack, heap, global buffers, and variables at runtime. The SRAM can be accessed as bytes, half-words \(16 bits\), or full words \(32 bits\), at maximum system clock frequency without wait state.

## Code execution { .section}

The part of the firmware that requires faster performances can be downloaded from the user or the external flash memory, and executed from the SRAM. Another reason to execute code from the SRAM is when using encrypted external flash memory on devices without on-the-fly decryption: the code is decrypted inside the SRAM before its execution. Appropriate memory protections must then be enabled on the SRAM address range containing the code. When no code must be executed in the SRAM, it is advised to prevent any malware execution by setting the appropriate attribute \(execute never\) with the MPU.

*Associated protections*: MPU or firewall

## SRAM cleaning { .section}

The SRAM can contain sensitive data or temporary values allowing some secrets retrieving. A typical example is the transfer of a secret cryptographic key from protected flash memory area in clear text, inside the SRAM. It is highly recommended to clean explicitly the working buffers and variables immediately after the processing of functions manipulating sensitive data.

**Note:** In case of reset, the STM32 MCUs allow the automatic erase of the SRAM \(refer to the reference manual\). For some devices, part of the SRAM is protected against external access or untrusted boot \(SRAM boot\) when the RDP is set.

## Write protection { .section}

The write protection can be used to isolate part of the area from being corrupted by another process or by preventing an overflow attack. An overflow attack consists in writing more data than the targeted buffer size \(during a data transfer through interface ports for example\). If no boundary checks are performed, the memory address above the buffer is corrupted, and a malware can be injected this way. This protection is only featured by the SRAM regions, which are used primarily for code execution \(this protection is not practical for data\). The SRAM write protection is available for SRAM2 region on some STM32 MCUs only \(refer to [Overview of security features](AN5156_sec-feat-Overview.md) and to the reference manual\).

*Associated protections*: MPU, TrustZone, or SRAM write protection \(available on some STM32 devices only\)

## Parity check and ECC { .section}

The parity check on the SRAM allows the control of potential errors word-by-word \(32 bits\). One extra bit per byte is added to the memory content \(data bus width is 36 bits\) to increase its robustness, as required for instance by Class B or SIL norms. ECC is more sophisticated, with SECDED functionality, but only available for SRAM on certain MCU devices. Integrity protections based on redundancy often cannot be disabled.

**Parent topic:**[Memory protections](AN5156_Dev-prot-Memory-protections.md)

