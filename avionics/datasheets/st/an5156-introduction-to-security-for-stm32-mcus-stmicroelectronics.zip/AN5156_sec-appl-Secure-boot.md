# Secure boot \(SB\) {#secure_boot}

The SB application is executed at reset before the user application. It provides first stages of security, and is then responsible for ensuring the global chain of trust of the system.

SB main functionalities:

-   Check the STM32 security configuration and set up runtime protections.
-   Assert the integrity and authenticity of the user application images that are executed \(see the figure below\).

![](DT50950.svg "Secure boot FSM")

## Device security check { .section}

This part of the SB application checks if static configurations are correct, and sets the dynamic ones. Static secure configurations are defined by option bytes \(RDP, PCROP, WRP, and HDP\). Dynamic protections must be programmed \(firewall, MPU, tamper detection, and IWDG\).

## Integrity and authenticity check { .section}

The firmware integrity is performed by hashing the application image \(with MD5, SHA1, or SHA256 hash algorithms\), and comparing the digest with the expected one. This way, the application firmware is considered error-free.

An authenticity check is added if the expected tag is encrypted with a key shared between the firmware owner and the device. This key is stored in a protected area of the device.

## Protection attributes { .section}

The SB firmware must have the following attributes to fulfill its role:

-   It must be the device-unique entry point \(no bypass\).
-   Its code must be immutable.
-   It must have access to sensitive data \(such as certificates or application signatures\).

The most sensitive SB part takes benefit from process and data isolation features, like firewall, MPU, or secure hide protection. The implementation depends on the STM32 available features.

**Parent topic:**[STMicroelectronics proprietary SBSFU solution](AN5156_ST-proprietary-SBSFU.md)

