# Silicon invasive attacks {#silicon_invasive_attacks}

The cost of such attacks is very high; all means are considered to extract information of the device that is destroyed during the process. The attacker needs to obtain a substantial quantity of devices to be successful. Carried out with expensive equipments often found in specialized laboratories, they require a high level of skills and knowledge, as well as time.

Invasive attacks start with the removal of the device package. An initial analysis can be done without eliminating the passivation layer, however investigations with device interaction \(probing\) require its removal. De-packaging can be done by chemical etching, drilling or by a laser cutter. Once the device is opened, it is possible to perform probing or modification attacks.

Several ST microcontrollers dedicated to security offer robustness against such kind of treatments. These are not part of the STM32 family and are out of scope of this document. Refer to ST secure hardware platforms \(www.st.com/en/secure-mcus.html\).

## Reverse engineering { .section}

The goal is to understand the inner structure of the device and analyze its functionality. This is quite a challenging task with modern devices featuring millions of gates.

The first step is to create a map of the microcontroller. It can be done by using an optical microscope to produce a high-resolution photograph of the device surface. Deeper layers can then be analyzed in a second step, after the metal layers have been stripped off by etching the device.

## Reading the data { .section}

When using the electron microscope, the data, represented by an electric charge, becomes visible. It is possible to read the whole device memory.

## Micro probing and internal fault injection { .section}

Micro probing consists in interacting with the device at metal layer level. Thin electrodes are used to establish an electrical contact directly with the surface of the device so that the attacker can observe, manipulate, and interfere with it while the device is running.

## Device modification { .section}

More sophisticated tools can be used to perform attacks. FIB \(focused ion beam\) workstations, for example, simplify the manual probing of deep metal and polysilicon lines. They also can be used to modify the device structure by cutting existing or creating new interconnection lines and even new transistors.

**Parent topic:**[Hardware attacks](AN5156_Attack-Hardware-attacks.md)

