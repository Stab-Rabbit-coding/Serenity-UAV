# RAM and integrity secure area firewall \(RISAF\) {#id_79195}

RISAF controls access to a protected address space based on the target address and the bus master that initiates the access. It is controlled by the privileged secure domain.

Peripherals integrated in the MCU that can act as bus masters, such as complex DMA controllers, manage their own RIF alignment. Other resources have their RIF configuration defined by the RIFSC.

The IAC is invoked when an illegal access is detected. It manages the security exception with the secure framework.

**Parent topic:**[STM32 security features](AN5156_Stm32-security-features.md)

