# Non-invasive attacks {#non_invasive_attacks}

Non-invasive, or board-level attacks try to bypass the protection without physical damage \(device kept functional\). Only accessible interfaces and device environment are used. These attacks require moderately sophisticated equipment and engineering skills \(such as signal processing\).

## Debug port access { .section}

This is the most basic attack that can be carried out on a device. Disabling debug capability must be the first protection level to consider. Indeed, accessing to debug port or scan chain through JTAG or SWD protocol allows accessing the full internal resources of the device: CPU registers, embedded flash memory, RAM, and peripheral registers.

*Countermeasure:*

-   Debug port deactivation or fuse through [Readout protection \(RDP\)](AN5156_sec-feat-read-out-protection-rdp-.md)
-   Life-cycle management using product state \(where this technology succeeded the RDP\)

## Serial port access { .section}

Access to communication ports \(such as I2C or SPI\) may hide a weakness that can be exploited. Communication ports can be spied or used as a device entry point. Depending on how the associated protocols are implemented \(such as memory address access range, targeted peripherals or read/write operations\), an attacker can potentially gain access to the device resources.

*Countermeasures:*

-   Software:
    -   Associated protocol operations must be limited by the firmware level, so that no sensitive resources can be read or written.
    -   Isolate communication stack from sensitive data.
    -   Length of data transfer must be checked to avoid buffer overflows.
    -   Communication can be encrypted with a shared key between the device and the target.
-   Hardware:
    -   Physical communication port can be buried in multi-layer boards to make it more difficult to access.
    -   Unused interface port must be deactivated.

## Fault injection: clock and power disturbance/glitch attacks { .section}

Fault injection consists in using the device outside the parameters defined in the datasheet to generate malfunctions in the system. A successful attack can modify the program behavior in different ways such as corrupting program state, corrupting memory content, stopping process execution \(“stuck-at fault”\), skipping instruction, modifying conditional jump or providing unauthorized access.

The typical threats involve tampering with clock \(freezing or glitch\) and power \(under/over voltage or glitch\). Since fault may be non‑intentional, countermeasures are the same as the one used for safety: redundancy, error detection, and monitoring.

*Countermeasures:*

-   Software:
    -   Check function return values.
    -   Use strict comparisons when branching.
    -   Make sure that no code was skipped in critical parts by incrementing a dedicated variable in each branch with prime number and checking for the expected value.
    -   Use non-trivial values as true and false \(avoid comparing to 0 or -1, try complex values with high mutual hamming distance\).
-   Hardware:
    -   Use [Clock security system \(CSS\)](AN5156_sec-feat-clock-security-system.md) if available.
    -   Use internal clock sources.
    -   Use internal voltage regulators.
    -   Use memory error detection \(ECC and parity\).

## Side-channel attacks \(SCA\) { .section}

When a firmware is executed, an attacker can observe the device running characteristics \(such as power consumption, electromagnetic radiations, temperature or activity time\). This observation can bring enough information to retrieve secret assets such as data values and/or algorithms implementation. Side-channel based attacks are powerful against cryptographic devices in order to reveal the keys used by the system. SPA \(simple power analysis\) and DPA \(differential power analysis\) are typical examples of side-channel attack exploiting power consumption.

*Countermeasures:*

-   Software:
    -   Limit key usage: use session random keys when possible.
    -   Use protected cryptographic libraries with behavioral randomization \(such as delays or fake instructions\).
-   Hardware:
    -   Shields against monitoring can be found in secure elements \(STSAFE\), but there is usually no efficient hardware countermeasure embedded in general-purpose microcontrollers \(except for the SAES in STM32H5, STM32N6, STM32H7S, STM32WBA, STM32U3, and STM32U5 devices and CCB where featured, the hardware protection in limited in general-purpose microcontrollers. The protection level is reflected by the certification level achieved by the device. See [Product certifications](AN5156_Product-certifications.md) for more details\).

**Parent topic:**[Hardware attacks](AN5156_Attack-Hardware-attacks.md)

