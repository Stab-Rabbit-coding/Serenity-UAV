# Software attacks {#software_attacks}

Software attacks are carried out on the system by executing a piece of code, named a malware, by the CPU. The malware takes control of the device in order to get access to any resources of the system \(such as ID, RAM, and flash memory content or peripheral registers\), or to modify its functionality.

This type of attack represents most of device threats for the following reasons:

-   The attack cost is low since it does not need specific equipment but a personal computer.
-   Many hackers can put their effort together, sharing their expertise and tricks, so that a successful attack is likely to happen if a security breach exists. Furthermore, in case of success, the attack protocol may spread very quickly through the web.

The malware can be injected into the device or can already be present \(insider threat\) in main application firmware through a nonverified or untrustworthy library for example. Malwares are of many types and they can be very small and easy to hide.

Here are examples of what a malware can do:

-   Modify device configuration \(such as option bytes or memory attributes\).
-   Disable protections.
-   Read memory and dump its content for firmware and data cloning.
-   Trace or log device data.
-   Access to cryptographic items.
-   Open communication channel/interface.
-   Modify or block the device functionality.

Unless user application is fully trusted, bug-free, and isolated, without any means to communicate with external world, software attacks must be considered.

## Malware injection { .section}

There are various methods to inject a piece of code inside the system. The size of the malware depends on the target but may be very small \(few tens of bytes\). To be executed, the malware must be injected in the device memory \(RAM or flash memory\). Once injected, the challenge is to have it executed by the CPU, which means that the PC \(program counter\) must branch to it.

Methods of injecting malware can be categorized as follows:

-   basics device access/"open doors”:

    -   Debug port: JTAG or SWD interface.
    -   Bootloader: if accessible, can be used to read/write memory content through any available interface.
    -   Execution from external memory.
    These malware injections are easy to counter with simple hardware mechanisms that are described in [Device protections](AN5156_Device-protections.md).

-   Application download:

    -   Firmware update procedure: a malware can be transferred instead of a new FW.
    -   OS with capability to download new applications.
    This category countermeasure is based on authentication between the device and the server or directly with code authentication. Authentication relies on cryptography algorithms.

-   Weaknesses of communication ports and bugs exploitation:

    -   Execution of data. Sometimes it is possible to sneak the malware in as data, and to exploit incorrect boundary check to execute it.
    -   Stack-based buffer overflows, heap-based buffer overflows, jump-to-libc attacks, and data-only attacks.
    This third category is by definition difficult to circumvent. Most embedded system applications are coded using low-level languages such as C/C++. These languages are considered unsafe because they can lead to memory management errors leveraged by attackers \(such as stack, heap, or buffers overflow\). The general idea is to reduce as much as possible what is called the attack surface, by minimizing the untrusted or unverified part of firmware. One solution consists in isolating the execution and the resources of the different processes. For example, the TF-M includes such a mechanism.

-   Use of untrusted libraries with device back door:

    This last category is an intentional malware introduction that facilitates device corruption. Today, lot of firmware developments rely on software shared on the web and complex ones can hide Trojan horses. As in previous category, the way to countermeasure this threat is to reduce the surface attack by isolating as much as possible the process execution and protecting the critical code and data.


## Brute forcing { .section}

This type of attack targets the authentication based on a shared secret. A secure device may require a session authentication before accessing services \(in the cloud for example\) and a human machine interface \(HMI\) can be exploited with an automatic process in order to try successive passwords exhaustively.

Interesting countermeasures are listed below:

-   Limit the number of login trials with a monotonic counter \(implemented with a timer, or if possible, with a backup domain\).
-   Increase the delay between consecutive login attempts.
-   Add a challenge-response mechanism to break automatic trials.

**Parent topic:**[Attack types](AN5156_attack-types.md)

