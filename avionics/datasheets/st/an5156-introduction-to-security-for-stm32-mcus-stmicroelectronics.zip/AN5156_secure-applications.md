# Secure applications {#secure_applications}

To create a secure system, the hardware features must be used in a secure firmware architecture implementation. An industry-standard solution is the PSA, proposed by Arm for the IoT ecosystem. The STMicroelectronics proprietary solution is secure boot \(SB\) and secure firmware update \(SFU\). It is possible to use secure firmware installation \(SFI\) to securely provision blank devices in manufacturing.

This section defines the **root and chain of trust** concept before presenting the following typical secure applications implementing the features listed below:

-   Secure boot
-   Secure firmware update
-   Secure storage
-   Cryptographic services

These applications have a close link with cryptography. All cryptographic schemes are based on the three concepts of secret key, public key, and hashing. The basics of cryptography are explained in [Cryptography–Main concepts](AN5156_A-Crypto-main-concepts.md). [Cryptography–Main concepts](AN5156_A-Crypto-main-concepts.md).

**Note:**

-   The document [AN5156\_General-Info.md\#entry\_nsy\_brz\_qvb](AN5156_General-Info.md#entry_nsy_brz_qvb) provides an implementation example of SB and SFU \(www.st.com/en/product/x‑cube‑sbsfu\).
-   The user manual 'Getting started with STM32CubeL5 TF-M application' \(UM2671\) describes an example of TF-M implementation with the STM32L5 series MCU.
-   The user manual 'Getting started with STM32CubeU5 TF-M application' \(UM2851\) describes an example of TF-M implementation with the STM32U5 series MCU.
-   Secure Manager wiki article: [https://wiki.st.com/stm32mcu/wiki/Security:Secure\_Manager](https://wiki.st.com/stm32mcu/wiki/Security:Secure_Manager)

-   **[Secure firmware install \(SFI\)](AN5156_Secure-firmware-install.md)**  

-   **[Root and chain of trust](AN5156_sec-appl-Root-and-chain-of-trust.md)**  

-   **[STMicroelectronics proprietary SBSFU solution](AN5156_ST-proprietary-SBSFU.md)**  

-   **[Arm TF-M solution](AN5156_Arm-tf-m-solution.md)**  

-   **[Secure manager](AN5156_Secure-manager.md)**  

-   **[Product certifications](AN5156_Product-certifications.md)**  


