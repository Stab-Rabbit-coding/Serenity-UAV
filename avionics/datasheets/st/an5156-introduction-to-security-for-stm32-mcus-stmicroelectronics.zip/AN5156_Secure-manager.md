# Secure manager {#id_58145}

The goal of the Secure manager is to guide customers to a certified secure software solution. Secure manager implements the PSA secure APIs \(similar to the TF-M\) and by using them, the user nonsecure application can form a secure system with certified attack resistance.

The Secure manger application kit is distributed in the form of encrypted binary and is free to use on compatible STM32H5 MCUs.

Secure manager can expand its secure functionality by using modules.

**Parent topic:**[Secure applications](AN5156_secure-applications.md)

