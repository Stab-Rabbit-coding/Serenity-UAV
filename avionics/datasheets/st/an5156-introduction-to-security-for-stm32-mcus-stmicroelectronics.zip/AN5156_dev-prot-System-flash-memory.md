# System flash memory {#system_flash_memory}

In STM32 MCUs, the system memory is a read-only part \(ROM\) of the embedded flash memory. It is dedicated to the ST bootloader. Some devices include the root of trust chain link of the secure boot and additional root secure services \(RSS\) in this area. This part cannot be modified to guarantee its authenticity and integrity. The bootloader is readable since it does not contain any sensitive algorithm. Some parts of the system flash memory are not accessible or execute only and cannot be read by the user.

The protection attribute on the system flash memory cannot be modified.

**Parent topic:**[Memory protections](AN5156_Dev-prot-Memory-protections.md)

