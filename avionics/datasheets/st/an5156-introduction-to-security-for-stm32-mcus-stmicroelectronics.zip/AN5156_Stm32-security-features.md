# STM32 security features {#stm32_security_features}

This section presents all the STM32 features that can be used to meet the different security concepts presented in previous sections, and to achieve a high level of security.

-   **[Overview of security features](AN5156_sec-feat-Overview.md)**  

-   **[Readout protection \(RDP\)](AN5156_sec-feat-read-out-protection-rdp-.md)**  

-   **[Life cycle management–product state](AN5156_Lifecycle-management-product-state.md)**  

-   **[Unique boot entry](AN5156_Unique-boot-entry.md)**  

-   **[One-time programmable \(OTP\)](AN5156_OTP.md)**  

-   **[Boot and security control \(BSEC\)](AN5156_Bootandsecuritycontrol.md)**  

-   **[TrustZone](AN5156_sec-feat-TrustZone.md)**  

-   **[Flash memory write protection \(WRP\)](AN5156_sec-feat-Flash-write-protection--wrp-.md)**  

-   **[Execute-only firmware \(PCROP\)](AN5156_sec-feat-Execute-only-firmware-pcrop-.md)**  

-   **[Secure hide protection \(HDP\)](AN5156_sec-feat-Secure-HDP.md)**  

-   **[Firewall](AN5156_sec-feat-Firewall.md)**  

-   **[Memory protection unit \(MPU\)](AN5156_sec-feat-memory-protection-unit--mpu-.md)**  

-   **[Resource isolation framework \(RIF\)](AN5156_Resourceisolationframework.md)**  

-   **[RAM and integrity secure area firewall \(RISAF\)](AN5156_RISAF.md)**  

-   **[Customer key storage \(CKS\)](AN5156_sec-feat-cryptographic-key-storage.md)**  

-   **[Option byte keys \(OBK\)](AN5156_Option-byte-keys.md)**  

-   **[Antitamper \(TAMP\)/backup registers \(BKP\)](AN5156_sec-feat-Anti-tamper.md)**  

-   **[Clock security system \(CSS\)](AN5156_sec-feat-clock-security-system.md)**  

-   **[Power monitoring \(PVD\)](AN5156_sec-feat-power-monitoring.md)**  

-   **[Memory integrity hardware check](AN5156_sec-feat-memory-integrity-hardware-check.md)**  

-   **[Independent watchdog \(IWDG\)](AN5156_sec-feat-Iwdg.md)**  

-   **[Device ID](AN5156_sec-feat-Device-id.md)**  

-   **[Cryptography](AN5156_sec-feat-Cryptography.md)**  

-   **[True random generator \(TRNG\)](AN5156_TRNG.md)**  

-   **[AES accelerator \(AES/SAES\)](AN5156_AES_accelators.md)**  

-   **[Public key accelerator \(PKA\)](AN5156_PKA.md)**  

-   **[Coupling and chaining block \(CCB\)](AN5156_CCB.md)**  

-   **[HASH processor \(HASH\)](AN5156_HASH.md)**  

-   **[CryptoLib software library](AN5156_sec-feat-Crypto-SW-library.md)**  

-   **[On-the-fly decryption engine \(OTFDEC\)](AN5156_sec-feat-OTFDEC.md)**  

-   **[Memory crypto engine \(MCE\)](AN5156_Memory-crypto-engine.md)**  


