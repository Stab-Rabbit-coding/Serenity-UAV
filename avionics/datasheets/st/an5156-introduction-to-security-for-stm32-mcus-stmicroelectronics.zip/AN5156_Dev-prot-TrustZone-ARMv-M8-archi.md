# TrustZone® for Armv8-M architecture {#id_12490}

Microcontrollers based on Armv6 or Armv7 architecture \(Cortex-M0, M3, M4, and M7\) rely mostly on software implementations for firmware and resource isolation. These mechanisms, described later in the document, are robust but not capable of isolation of secure firmware like operating system from installed applications with nonsecure firmware.

The Armv8-M architecture brings a new security paradigm in Arm microcontrollers. It implements the TrustZone® technology at microcontroller system level, allowing the development of trusted firmware through a robust isolation at runtime.

The TrustZone® technology relies on a processor \(Cortex-M23, Cortex-M55 or Cortex-M33\) separation for secure and nonsecure domains and on a bus infrastructure \(AMBA®\) propagating secure attribute throughout the whole system \(peripherals and memories\).

The TrustZone® is made for robust and flexible security control at runtime. Switching from secure to nonsecure domain and vice versa is straightforward with few cycle penalties. There is no need for a Secure monitor as in TrustZone® for application processors Cortex‑A.

Secure modes are orthogonal to the existing modes, Thread and Handler. Thus, there can be a Thread or Handler mode in each secure mode \(see the figure below\).

![](DT63687.svg "Armv8-M TrustZone execution modes")

On typical firmware architecture running on Armv8 TrustZone®, the nonsecure domain executes the application and the OS tasks, while the secure domain executes the secure application and the system root-of-trust mechanisms.

**Parent topic:**[Device protections](AN5156_Device-protections.md)

