# Security features by STM32 devices {#id_51269}

The following tables are intended for reference and the prospects of secure code porting between STM32 products. The presence or absence of a particular feature may not be indicative of achievable security. For that reason, refer to the available security certifications for the particular product.

**Table 1. Security features for STM32C0/5, STM32F0/1/2/3/4, STM32G0/4 devices**

<table>
<thead>
<tr>
<th colspan="2">Feature</th>
<th>STM32C0</th>
<th>STM32C5</th>
<th>STM32F0</th>
<th>STM32F1</th>
<th>STM32F2</th>
<th>STM32F3</th>
<th>STM32F4</th>
<th>STM32G0</th>
<th>STM32G4</th>
</tr>
</thead>
<tbody>
<tr>
<td colspan="2">Cortex core</td>
<td>Cortex‑M0+</td>
<td>Cortex‑M33</td>
<td>Cortex‑M0</td>
<td>Cortex‑M3</td>
<td>Cortex‑M3</td>
<td>Cortex‑M4</td>
<td>Cortex‑M4</td>
<td>Cortex‑M0+</td>
<td>Cortex‑M4</td>
</tr>
<tr>
<td colspan="2">RDP additional protection</td>
<td>Bad OBL recovery</td>
<td>Backup registers, SRAM2, 2-level RDP only</td>
<td>Backup registers</td>
<td>2-level RDP only</td>
<td>Backup SRAM</td>
<td>Backup registers</td>
<td>Backup SRAM</td>
<td>Backup registers</td>
<td><p>Backup registers, CCMSRAM</p></td>
</tr>
<tr>
<td colspan="2">Flash WRP</td>
<td>By area with 2‑Kbyte granularity, two areas available</td>
<td>By pages (8 Kbytes)</td>
<td>By sectors (4 Kbytes)</td>
<td>By pages (4 K or 8 Kbytes)</td>
<td>By sectors (16 K, 64 K, or 128 Kbytes)</td>
<td>By sectors (4 Kbytes)</td>
<td>By sectors (16 K, 64 K, or 128 Kbytes)</td>
<td>By area with 2‑Kbyte granularity, two areas available</td>
<td>By page (2 K or 4 Kbytes)</td>
</tr>
<tr>
<td colspan="2">SRAM WRP</td>
<td>No</td>
<td>SRAM2, 1‑Kbyte granularity</td>
<td>No</td>
<td>No</td>
<td>No</td>
<td>No</td>
<td>No</td>
<td>No</td>
<td>CCM SRAM, with 1‑Kbyte granularity</td>
</tr>
<tr>
<td colspan="2">PCROP</td>
<td>By area with 256‑byte granularity, one area per bank</td>
<td>No</td>
<td>No</td>
<td>No</td>
<td>No</td>
<td>No</td>
<td>By sectors</td>
<td>By area with 512‑byte granularity, two areas available</td>
<td>By area with 64‑ or 128‑bit granularity, up to two areas</td>
</tr>
<tr>
<td colspan="2">HDP</td>
<td>Yes (securable memory area)</td>
<td>Yes, 3 levels</td>
<td>No</td>
<td>No</td>
<td>No</td>
<td>No</td>
<td>No</td>
<td colspan="2">Yes (securable memory area)</td>
</tr>
<tr>
<td colspan="2">Firewall</td>
<td>No</td>
<td>No</td>
<td>No</td>
<td>No</td>
<td>No</td>
<td>No</td>
<td>No</td>
<td>No</td>
<td>No</td>
</tr>
<tr>
<td colspan="2">MPU</td>
<td>Yes</td>
<td>Yes</td>
<td>No</td>
<td>Yes<sup><a href="#fn1">1</a></sup></td>
<td>Yes</td>
<td>Yes<sup><a href="#fn2">2</a></sup></td>
<td>Yes</td>
<td>Yes</td>
<td>Yes</td>
</tr>
<tr>
<td colspan="2">OTP</td>
<td>1 Kbyte</td>
<td>4.5 Kbyte</td>
<td>No</td>
<td>No</td>
<td>Yes</td>
<td>Yes</td>
<td>512 bytes</td>
<td>1 Kbyte</td>
<td>1 Kbyte</td>
</tr>
<tr>
<td colspan="2">UBE<sup><a href="#fn3">3</a></sup></td>
<td>Yes (boot lock feature)</td>
<td>Yes (boot lock feature)</td>
<td>No</td>
<td>No</td>
<td>No</td>
<td>No</td>
<td>No</td>
<td>Yes (boot lock feature)</td>
<td>Yes</td>
</tr>
<tr>
<td colspan="2">Internal tamper detection</td>
<td>No</td>
<td>Yes</td>
<td>No</td>
<td>No</td>
<td>No</td>
<td>No</td>
<td>No</td>
<td>Yes</td>
<td>Yes</td>
</tr>
<tr>
<td colspan="2">Hardware crypto<sup><a href="#fn4">4</a></sup></td>
<td>No</td>
<td>AES, HASH, SAES, PKA, CCB</td>
<td>No</td>
<td>No</td>
<td>AES, HASH</td>
<td>No</td>
<td>AES, HASH</td>
<td colspan="2">AES</td>
</tr>
<tr>
<td colspan="2">RNG</td>
<td>No</td>
<td>SP800‑90‑B</td>
<td>No</td>
<td>No</td>
<td>SP800‑90‑A</td>
<td>No</td>
<td colspan="3">SP800‑90‑A</td>
</tr>
<tr>
<td rowspan="3">Secure software</td>
<td>SBSFU</td>
<td>No</td>
<td>Yes</td>
<td>No</td>
<td>No</td>
<td>No</td>
<td>No</td>
<td>Yes</td>
<td>Yes</td>
<td>Yes</td>
</tr>
<tr>
<td>TF-M</td>
<td>No</td>
<td>No</td>
<td>No</td>
<td>No</td>
<td>No</td>
<td>No</td>
<td>No</td>
<td>No</td>
<td>No</td>
</tr>
<tr>
<td>KMS</td>
<td>No</td>
<td>No</td>
<td>No</td>
<td>No</td>
<td>No</td>
<td>No</td>
<td>No</td>
<td>No</td>
<td>No</td>
</tr>
</tbody>
</table>

**Table 2. Security features for STM32L0/1/4/4+ and STM32U0 devices**

<table>
<thead>
<tr>
<th colspan="2">Feature</th>
<th>STM32L0</th>
<th>STM32L1</th>
<th>STM32L4</th>
<th>STM32L4+</th>
<th>STM32U0</th>
</tr>
</thead>
<tbody>
<tr>
<td colspan="2">Cortex core</td>
<td>Cortex‑M0</td>
<td>Cortex‑M3</td>
<td colspan="2">Cortex‑M4</td>
<td>Cortex‑M0+</td>
</tr>
<tr>
<td colspan="2">RDP additional protection</td>
<td colspan="2">EEPROM</td>
<td colspan="2"><p>Backup registers, SRAM2</p></td>
<td>Backup registers, SRAM2</td>
</tr>
<tr>
<td colspan="2">Flash WRP</td>
<td colspan="2">By sectors (4 Kbytes)</td>
<td colspan="2">By area with 2‑Kbyte granularity, one area per bank</td>
<td>Two areas per bank defined by page range</td>
</tr>
<tr>
<td colspan="2">SRAM WRP</td>
<td>No</td>
<td>No</td>
<td colspan="2">SRAM2, with 1‑Kbyte granularity</td>
<td>No</td>
</tr>
<tr>
<td colspan="2">PCROP</td>
<td colspan="2">By sectors</td>
<td colspan="2">By area with 8‑byte granularity, one area per bank</td>
<td>No</td>
</tr>
<tr>
<td colspan="2">HDP</td>
<td>No</td>
<td>No</td>
<td>No</td>
<td>No</td>
<td>Yes, with second stage extension</td>
</tr>
<tr>
<td colspan="2">Firewall</td>
<td>Yes</td>
<td>No</td>
<td>Yes</td>
<td>Yes</td>
<td>No</td>
</tr>
<tr>
<td colspan="2">MPU</td>
<td>Yes</td>
<td>Yes</td>
<td>Yes</td>
<td>Yes</td>
<td>Yes</td>
</tr>
<tr>
<td colspan="2">OTP</td>
<td>No</td>
<td>No</td>
<td colspan="2">1 Kbyte</td>
<td>1 Kbyte</td>
</tr>
<tr>
<td colspan="2">UBE<sup><a href="#fn5">5</a></sup></td>
<td>No</td>
<td>No</td>
<td>No</td>
<td>No</td>
<td>Yes (boot lock feature)</td>
</tr>
<tr>
<td colspan="2">Internal tamper detection</td>
<td>No</td>
<td>No</td>
<td>No</td>
<td>No</td>
<td>Yes</td>
</tr>
<tr>
<td colspan="2">Hardware crypto<sup><a href="#fn6">6</a></sup></td>
<td colspan="2">AES</td>
<td>AES, HASH</td>
<td><p>AES, HASH,<br/>
 (some PKA)</p></td>
<td>AES</td>
</tr>
<tr>
<td colspan="2">RNG</td>
<td>No</td>
<td>No</td>
<td>SP800‑90‑A</td>
<td>SP800‑90‑B</td>
<td>SP800‑90‑B</td>
</tr>
<tr>
<td rowspan="3">Secure software</td>
<td>SBSFU</td>
<td>Yes</td>
<td>Yes</td>
<td>Yes</td>
<td>Yes</td>
<td>MCUboot</td>
</tr>
<tr>
<td>TF-M</td>
<td>No</td>
<td>No</td>
<td>No</td>
<td>No</td>
<td>No</td>
</tr>
<tr>
<td>KMS</td>
<td>No</td>
<td>No</td>
<td>Yes</td>
<td>Yes</td>
<td>No</td>
</tr>
</tbody>
</table>

**Table 3. Security features for STM32WB, STM32WBA, STM32WB0x, STM32WL, and STM32WL3 devices**

<table>
<thead>
<tr>
<th colspan="2">Feature</th>
<th>STM32WB</th>
<th>STM32WBA</th>
<th>STM32WB0x</th>
<th>STM32WL</th>
<th>STM32WL3</th>
</tr>
</thead>
<tbody>
<tr>
<td colspan="2">Cortex core</td>
<td>Cortex‑M4/Cortex‑M0+</td>
<td>Cortex‑M33</td>
<td>Cortex‑M0+</td>
<td>Cortex‑M4/Cortex‑M0+</td>
<td>Cortex‑M0+</td>
</tr>
<tr>
<td colspan="2">RDP additional protection</td>
<td>Backup registers, SRAM2</td>
<td>RDP four levels,backup registers, SRAM</td>
<td>No</td>
<td><p>Backup registers, SRAM2</p></td>
<td>No</td>
</tr>
<tr>
<td colspan="2">Flash WRP</td>
<td>By area with 4‑Kbyte granularity, two areas available</td>
<td>Two areas, defined by page range</td>
<td colspan="2">By area with 2‑Kbyte granularity, two areas available</td>
<td>Four areas</td>
</tr>
<tr>
<td colspan="2">SRAM WRP</td>
<td colspan="2">SRAM2, with 1‑Kbyte granularity</td>
<td>No</td>
<td>SRAM2, with 1‑Kbyte granularity</td>
<td>No</td>
</tr>
<tr>
<td colspan="2">PCROP</td>
<td>By area with 2‑Kbyte granularity, up to two areas</td>
<td colspan="2">No</td>
<td>By area with 1‑Kbyte granularity, two areas available</td>
<td>No</td>
</tr>
<tr>
<td colspan="2">HDP</td>
<td>Yes (dedicated to Cortex‑M0+ firmware only)</td>
<td>Yes</td>
<td>No</td>
<td>Yes</td>
<td>No</td>
</tr>
<tr>
<td colspan="2">Firewall</td>
<td>No</td>
<td colspan="2">No</td>
<td>Yes</td>
<td>No</td>
</tr>
<tr>
<td colspan="2">MPU</td>
<td>Yes (Cortex‑M4)</td>
<td>Yes</td>
<td>Yes</td>
<td>Yes</td>
<td>Yes</td>
</tr>
<tr>
<td colspan="2">OTP</td>
<td colspan="5">1 Kbyte</td>
</tr>
<tr>
<td colspan="2">UBE<sup><a href="#fn7">7</a></sup></td>
<td>No</td>
<td>Yes (lockable secure and NS address)</td>
<td>No</td>
<td>Yes (boot lock feature)</td>
<td>No</td>
</tr>
<tr>
<td colspan="2">Internal tamper detection</td>
<td>No</td>
<td>Yes</td>
<td>No</td>
<td>Yes</td>
<td>No</td>
</tr>
<tr>
<td colspan="2">Hardware crypto<sup><a href="#fn8">8</a></sup></td>
<td>AES, PKA</td>
<td>AES, HASH, PKA</td>
<td colspan="2">AES<sup><a href="#fn9">9</a></sup>, PKA</td>
<td>AES</td>
</tr>
<tr>
<td colspan="2">RNG</td>
<td>SP800‑90‑A</td>
<td colspan="4">SP800‑90‑B</td>
</tr>
<tr>
<td rowspan="3">Secure software</td>
<td>SBSFU</td>
<td>Yes</td>
<td>Yes</td>
<td>Yes<sup><a href="#fn10">10</a></sup></td>
<td>Yes</td>
<td>Yes<sup><a href="#fn10">10</a></sup></td>
</tr>
<tr>
<td>TF-M</td>
<td>No</td>
<td>Yes</td>
<td>No</td>
<td>No</td>
<td>No</td>
</tr>
<tr>
<td>KMS</td>
<td>No</td>
<td>No</td>
<td>No</td>
<td>No</td>
<td>No</td>
</tr>
</tbody>
</table>

**Table 4. Security features for STM32L5, STM32U3, STM32U5, STM32H503/5, STM32H7R/S, STM32H72x/73/74x/75, STM32H7Ax/7Bx, STM32F7 devices**

<table>
<thead>
<tr>
<th colspan="2">Feature</th>
<th>STM32L5</th>
<th><p>STM32U3</p>
STM32U5</th>
<th>STM32H503</th>
<th>STM32H5</th>
<th><p>STM32</p>
H7R/S</th>
<th><p>STM32</p>
H72x/73x</th>
<th><p>STM32</p>
H74x/75x</th>
<th><p>STM32</p>
H7Ax/7Bx</th>
<th>STM32F7</th>
</tr>
</thead>
<tbody>
<tr>
<td colspan="2">Cortex core</td>
<td>Cortex‑M33</td>
<td colspan="3">Cortex‑M33</td>
<td colspan="5">Cortex‑M7</td>
</tr>
<tr>
<td colspan="2">RDP additional protection</td>
<td>RDP four levels, backup registers, SRAM2</td>
<td>RDP four levels, backup registers, SRAM3</td>
<td colspan="2">Product state instead of RDP</td>
<td>Product state instead of RDP, backup SRAM</td>
<td>Backup SRAM, backup registers, OTFDEC</td>
<td>Backup SRAM, backup registers</td>
<td>Backup SRAM, backup registers, OTFDEC</td>
<td>Backup SRAM</td>
</tr>
<tr>
<td colspan="2">Flash WRP</td>
<td>Up to four protected areas with 2‑K or 4‑Kbyte granularity</td>
<td colspan="2">Two areas per bank defined by page range</td>
<td>By group of 4 pages of 8‑Kbyte</td>
<td>By sectors (8 Kbytes)</td>
<td colspan="2">By sectors (128 Kbytes)</td>
<td>By group of 4 8‑Kbyte sectors</td>
<td>By sectors (16 K, 64 K, 128 K, or 256 Kbytes)</td>
</tr>
<tr>
<td colspan="2">SRAM WRP</td>
<td>SRAM2, with 1‑Kbyte granularity</td>
<td colspan="3">SRAM2, with 1‑Kbyte granularity</td>
<td>No</td>
<td>No</td>
<td>No</td>
<td>No</td>
<td>No</td>
</tr>
<tr>
<td colspan="2">PCROP</td>
<td>No (replaced by TrustZone)</td>
<td>No (replaced by TrustZone)</td>
<td>No</td>
<td>No (replaced by TrustZone)</td>
<td>No</td>
<td>By area with 256‑byte granularity</td>
<td colspan="2">By area with 256‑byte granularity, one area per bank</td>
<td>By sectors</td>
</tr>
<tr>
<td colspan="2">HDP</td>
<td>Up to two secure hide areas (HDP) inside the TrustZone secure domain</td>
<td>Up to two secure hide areas (HDP) inside the TrustZone secure domain</td>
<td colspan="3">3‑stage temporal isolation, one per bank</td>
<td colspan="3">Yes (secure user memory, with 256‑byte granularity)</td>
<td>No</td>
</tr>
<tr>
<td colspan="2">Firewall</td>
<td>No (replaced by TrustZone)</td>
<td>No (replaced by TrustZone)</td>
<td>No</td>
<td>No (replaced by TrustZone)</td>
<td>No</td>
<td>No</td>
<td>No</td>
<td>No</td>
<td>No</td>
</tr>
<tr>
<td colspan="2">MPU</td>
<td>Yes</td>
<td>Yes</td>
<td>Yes</td>
<td>Yes</td>
<td>Yes</td>
<td>Yes</td>
<td>Yes</td>
<td>Yes</td>
<td>Yes</td>
</tr>
<tr>
<td colspan="2">OTP</td>
<td>512 bytes</td>
<td>512 bytes</td>
<td colspan="2">2 Kbytes</td>
<td>1 Kbyte</td>
<td>No</td>
<td>No</td>
<td>No</td>
<td>No</td>
</tr>
<tr>
<td colspan="2">UBE<sup><a href="#fn11">11</a></sup></td>
<td colspan="2">Yes (boot lock feature)</td>
<td>Yes</td>
<td>Yes</td>
<td>Yes (boot lock feature)</td>
<td colspan="3">Yes (unique entry point in secure access)</td>
<td>No</td>
</tr>
<tr>
<td colspan="2">Internal tamper detection</td>
<td>Yes</td>
<td>Yes</td>
<td>Yes</td>
<td>Yes</td>
<td>Yes</td>
<td>Yes</td>
<td>Yes</td>
<td>Yes</td>
<td>Yes</td>
</tr>
<tr>
<td colspan="2">Hardware crypto<sup><a href="#fn12">12</a></sup></td>
<td>AES, HASH, PKA</td>
<td>AES, HASH, PKA, SAES, CCB<sup><a href="#fn13">13</a></sup></td>
<td>HASH</td>
<td>AES,SAES, HASH, OTFDEC, PKA</td>
<td>AES, SAES, HASH, PKA, MCE</td>
<td colspan="3">AES, DES, HASH, OTFDEC</td>
<td>AES, HASH</td>
</tr>
<tr>
<td colspan="2">RNG</td>
<td colspan="6">SP800‑90‑B</td>
<td>SP800‑90‑A<sup><a href="#fn14">14</a></sup></td>
<td>SP800‑90‑B</td>
<td>SP800‑90‑A<sup><a href="#fn14">14</a></sup></td>
</tr>
<tr>
<td rowspan="3">Secure software</td>
<td>SBSFU</td>
<td>No</td>
<td>No</td>
<td>No</td>
<td>No</td>
<td>MCUboot</td>
<td>Legacy</td>
<td>Legacy</td>
<td>Legacy</td>
<td>Legacy</td>
</tr>
<tr>
<td>TF-M</td>
<td>Yes</td>
<td>Yes</td>
<td>No</td>
<td>Yes</td>
<td>-</td>
<td>No</td>
<td>No</td>
<td>No</td>
<td>No</td>
</tr>
<tr>
<td>KMS</td>
<td>No</td>
<td>No</td>
<td>No</td>
<td>Yes</td>
<td>-</td>
<td>No</td>
<td>No</td>
<td>No</td>
<td>No</td>
</tr>
</tbody>
</table>

**Parent topic:**[Overview of security features](AN5156_sec-feat-Overview.md)

<a id="fn1"></a>

[^1]: Only XL density devices feature the MPU.<a id="fn2"></a>

[^2]: MPU is not universally supported in STM32F3 series. Refer to the product datasheet to confirm availability.<a id="fn3"></a>

[^3]: Unique boot entry.<a id="fn4"></a>

[^4]: For most devices with hardware crypto capability, there is a direct equivalent without it.<a id="fn5"></a>

[^5]: Unique boot entry.<a id="fn6"></a>

[^6]: For most devices with hardware crypto capability, there is a direct equivalent without it.<a id="fn7"></a>

[^7]: Unique boot entry.<a id="fn8"></a>

[^8]: For most devices with hardware crypto capability, there is a direct equivalent without it.<a id="fn9"></a>

[^9]: For STM32WB0, the AES is only available on the radio peripheral.<a id="fn10"></a>

[^10]: Secure boot solution separated from the usual X-CUBE-SBSFU package.<a id="fn11"></a>

[^11]: Unique boot entry.<a id="fn12"></a>

[^12]: For most devices with hardware crypto capability, there is a direct equivalent without it.<a id="fn13"></a>

[^13]: Only the selected STM32U3 series feature the CCB. It is not available on STM32U5 series.<a id="fn14"></a>

[^14]: RNG v2.0 can be used as a seed source for DRBG.

