# Coupling and chaining block \(CCB\) {#id_81822}

This feature can be used to wrap an RSA or ECC private key and perform an electronic signature or decryption with greater security, as the private key is not exposed to the CPU during use. As in SAES, DHUK is used for wrapping, and OBK is available for key storage. For more information, refer to AN6205.

**Parent topic:**[STM32 security features](AN5156_Stm32-security-features.md)

