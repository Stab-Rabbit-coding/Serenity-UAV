# Configuration protection {#id_51205}

Any persistent security configuration is stored in a dedicated area of the non-volatile memory, called option bytes \(OB\). The option bytes are protected with redundancy, and, in case of perceived vulnerability, they are stored as a “magic value”. Besides rules imposed by security logic \(OB can only be changed under specific conditions\), there are rules to determine the default value in case of OB corruption.

**Note:** Magic value is a pattern of usually 8 bits that must be exactly matched for the value to be recognized as valid, common examples are 0xB4 or 0xC3 for TRUE or FALSE.

Details about rules to modify the option bytes are detailed in each reference manual. The configuration is generally frozen by raising the RDP level. Additional rules apply case-by-case.

Each OB value is preconfigured to a reset value in production. This value is usually the least secure, open option. In case of an error detected in OB loading \(OBL, happens on every POR or request\), the configuration is set to a default value. This default value usually sets the highest possible security level to prevent leaking information from damaged microcontroller.

It is useful to analyze the impact of a configuration error on an application, and to plan for potential recovery. Highest number of corrupted option bytes however result of errors in programming. If the OB are modified in controlled environment, the threat of unintentional device locked-up is very low.

**Parent topic:**[Device protections](AN5156_Device-protections.md)

