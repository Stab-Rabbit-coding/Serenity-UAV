# On-the-fly decryption engine \(OTFDEC\) {#id_12489}

The external memory content \(code and data\) cannot be protected with traditional read/write protections. The way to protect the content is to encrypt and decrypt it inside the device before using it.

One solution is to download the external memory content inside the SRAM, to decrypt it, to execute the code, and/or to use data. There are two drawbacks with this method: it introduces a delay that may not be acceptable, and it uses a large amount of SRAM, depending on the content.

The OTFDEC peripheral offers the possibility to decrypt the content directly with a low-latency penalty, and without the need for SRAM allocation. The OTFDEC decrypts the on-the-fly bus traffic based on the read-request address information. It is used with the Octo-SPI interface \(see the figure below\).

![](DT48973V1.svg "Typical OTFDEC configuration")

The OTFDEC uses the AES-128 CTR mode, with a 128-bit key to achieve a latency below 12 system bus cycles. Up to four independent and nonoverlapping encrypted regions can be defined \(4-Kbyte granularity\), each with its own key.

**When to use the OTFDEC**

The OTFDEC is used when an external memory is used by the system. For TrustZone® capable MCUs, the decryption keys can only be made accessible through the secure mode. See the application note *How to use OTFDEC for encryption/decryption in trusted environment on STM32H73/H7B MCUs* \(AN5281\) for more details.

**Note:** The OTFDEC is available on STM32H5, STM35H7, STM32L5, and STM32U5 devices only.

**Parent topic:**[STM32 security features](AN5156_Stm32-security-features.md)

