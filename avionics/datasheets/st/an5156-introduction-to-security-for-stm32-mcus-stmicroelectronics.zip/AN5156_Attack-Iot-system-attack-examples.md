# IoT system attack examples {#iot_system_attack_examples}

This section presents typical examples of attacks on an IoT system. Fortunately, most of these attacks can be countered by enabling security feature \(hardware countermeasures\) and secure application architecture \(software countermeasures\). The countermeasures are detailed in the next sections.

An IoT system is built around a STM32 microcontroller with connectivity systems \(such as Ethernet, Wi-Fi®, Bluetooth® LE or, LoRa®\) and sensors and/or actuators \(see the [Figure 1](#fig_at5_mgj_t2b)\). The microcontroller handles the application, data acquisition and communications with a cloud service. The microcontroller may also be responsible for the system maintenance through firmware update and integrity check.

![](DT50946.svg "IoT system")

**Parent topic:**[Attack types](AN5156_attack-types.md)

