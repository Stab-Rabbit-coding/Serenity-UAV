# Public key algorithms \(PKA\) {#public_key_algorithms__pka_}

This class of algorithms is based on a pair of keys. One key, the private one, is never exchanged with any remote system, while the other key, the public one, can be shared with any party. The relationship between both keys is asymmetric \(asymmetric cryptography\):

-   A message encrypted by the private key can be read by any party with the public key. This mechanism ensures a strong authentication of the sender since the private key has never been shared. Digital signatures are based on this mechanism.

    ![](DT50956.svg "Signature")

-   A message encrypted by the public key can only be read by the private key owner.

    ![](DT50957.svg "PKA encryption")


The main use of public key algorithms is authentication. It is also used to resolve the “key sharing” issue of symmetric cryptography. However, this comes at the cost of more complex operations, increased computation time and bigger memory footprint.

RSA and elliptic curve cryptography \(ECC\) are the most common asymmetric algorithms.

## Hybrid cryptography { .section}

Common secure transfer protocols \(such as Bluetooth and TLS\) rely on both algorithm types. This scheme is known as hybrid cryptography:

-   Asymmetric cryptography is used first, in order to solve the symmetric key-sharing problem. A session key is exchanged by the public key owner to the private key owner.
-   Transfer confidentiality is then provided by a symmetric algorithm using the session key.

**Parent topic:**[Cryptography–Main concepts](AN5156_A-Crypto-main-concepts.md)

