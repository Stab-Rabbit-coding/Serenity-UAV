# HASH processor \(HASH\) {#id_81823}

This cryptographic peripheral produces a digest of data. Supported algorithms are MD5, SHA-1, SHA-2, and SHA-3. SHA-3 support is limited to the newest products.

The peripheral also supports DMA, which further offloads the CPU.

**Parent topic:**[STM32 security features](AN5156_Stm32-security-features.md)

