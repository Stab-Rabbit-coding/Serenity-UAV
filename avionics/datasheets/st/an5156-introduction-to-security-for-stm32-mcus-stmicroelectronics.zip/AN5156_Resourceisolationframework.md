# Resource isolation framework \(RIF\) {#id_70900}

The RIF represents a complex system of address filtering logic that is embedded into the central bus matrix of the device. It can implement various rules for isolation between application code, data, and other resources in a multi-tenant secure OS. The RIF is complementing the TrustZone® system of SAU/IDAU isolation rules, known from other devices.

The configuration is volatile and set during the secure boot, and then fixed in place until the next boot.

In STM32N6, the RIF consists of RIFSC, RISAF, and IAC parts.

For more information, refer to the following wiki article: [https://wiki.st.com/stm32mcu/wiki/Security:Resource\_Isolation\_Framework\_\(RIF\)\_overview\_for\_STM32N6](https://wiki.st.com/stm32mcu/wiki/Security:Resource_Isolation_Framework_(RIF)_overview_for_STM32N6)

**Parent topic:**[STM32 security features](AN5156_Stm32-security-features.md)

