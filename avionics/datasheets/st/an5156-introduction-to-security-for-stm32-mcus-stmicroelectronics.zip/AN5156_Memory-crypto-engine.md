# Memory crypto engine \(MCE\) {#id_67721}

The memory crypto engine feature replaces the OTFDEC in selected products, specifically those with limited internal memory and designed to use mainly external memory.

The differences are summarized in the following table.

**Table 1. Features of the OTFDEC compared with the MCE**

|Feature|OTFDEC|MCE|
|-------|------|---|
|Function|On-the-fly decryption|Encryption and decryption|
|Algorithm|AES-based stream + proprietary|AES stream, AES block, DPA resistant|
|Key management|128b key per region, TZ protection, write only|Similar, usually tied to OBK by the software logic|
|Latency|Maximum of 12 cycles|11 to 36 cycles \(scalable security\)|
|Security|Base level|Including tamper and secure boot integration|
|Integration|Associated with XSPI|Associated with memory subsystem, usable with FMC|

*\(The MCE is included in STM32H7Rx/7Sx\)*

**Parent topic:**[STM32 security features](AN5156_Stm32-security-features.md)

