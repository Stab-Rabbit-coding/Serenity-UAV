# Root and chain of trust {#root_and_chain_of_trust}

The principle of root and chain of trust is common to many secure systems. It is obviously scalable ad libitum, inherently efficient and also flexible.

A chain of trust is built as a set of applicative components in which the security of each component is guaranteed by another component. The root of trust is the anchor at the beginning of the chain on which the overall security depends.

The secure boot implementation must be the single entry point to the device, start after reset with immutable code in secure mode. It then authenticates a subsequent functionality and executes the next part of the firmware that enables the additional functionality required to securely attest the following chain link. For example, it configures volatile memory protection, so that a secure storage service can use it.

For more details about STiRoT immutable Root of Trust, see AN6007 [AN5156\_General-Info.md\#ph\_14](AN5156_General-Info.md#ph_14).

**Parent topic:**[Secure applications](AN5156_secure-applications.md)

