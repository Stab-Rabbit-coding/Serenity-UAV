# Debug port and other interface protection {#debug_port_and_other_interfaces_protection}

The debug ports provide access to the internal resources \(core, memories, and registers\) and must be disabled in the final device. It is the most basic external attack that is easily avoided by deactivating JTAG \(or SWD\) ports by a secure and immutable firmware \(refer to [Secure boot \(SB\)](AN5156_sec-appl-Secure-boot.md)\), or preferably by permanently disabling the functionality \(JTAG fuse in RDP2, life cycle protection\).

Other serial interfaces can also be used. If the bootloader is available, the device content can be accessed through I2C, SPI, USART, or USB‑DFU. If the interface is open during the runtime, the application transfer protocol must limit its access capabilities \(such as operation mode or address access range\).

Associated STM32 features:

-   Read protection \(RDP\)/product state
-   Disable of unused ports
-   Bootloader access forbidden \(configured by RDP in STM32 devices\)
-   Debug authentication \(see AN6008 [AN5156\_General-Info.md\#ph\_12](AN5156_General-Info.md#ph_12)\)

**Parent topic:**[Device protections](AN5156_Device-protections.md)

