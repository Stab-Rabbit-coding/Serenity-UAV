# MAC or signature and certificate {#mac__signature___certificate}

## MAC and signature { .section}

The message authentication code \(MAC\) and the signature add authentication to integrity by encrypting the message hash. The difference between MAC and signature is that the MAC generation uses a symmetric key algorithm \([Figure 1](#fig_ykr_wdm_52b)\), while the signature uses the message sender private key \([Figure 2](#fig_y2n_xdm_52b)\).

The signature adds non-repudiation dimension to authentication:

-   A private key is not supposed to be revoked \(its lifetime goes beyond the transfer operation\), while a secret key may have a limited lifetime \(limited to this transfer\).
-   The private key used for signature is never shared, its security is higher than a secrete key.

![](DT50959.svg "MAC generation with secrete key algorithm")

![](DT50960.svg "Signature generation with public key algorithm")

## Certificate { .section}

A certificate is related to public key algorithms. It authenticates the public key in an asymmetric transfer. It is used to counteract usurpation by an attacker that substitutes the right public key by his own key. A certificate consists in the public key signed by a certificate authority \(CA\) private key. This CA is considered as fully trusted.

In addition to the public key, the certificate also contains version numbers, validity period and some IDs.

**Parent topic:**[Cryptography–Main concepts](AN5156_A-Crypto-main-concepts.md)

