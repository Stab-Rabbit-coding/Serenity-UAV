# Independent watchdog \(IWDG\) {#iwdg}

The IDWG is a free running down counter that can be used to trigger a system reset when the counter reaches a given timeout value. The IDWG can be used to provide a solution in case of malfunctions or deadlock in running code. The IDWG is clocked by its own independent low-speed clock \(LSI\), so that it stays active even in the event of a main clock failure.

**When to use the IWDG**

The IWDG can be used to break deadlocks. It can also be used to control execution time of critical code \(such as decryption or flash memory programming\).

**Note:** The IDWG is available on all STM32 devices.

**Parent topic:**[STM32 security features](AN5156_Stm32-security-features.md)

