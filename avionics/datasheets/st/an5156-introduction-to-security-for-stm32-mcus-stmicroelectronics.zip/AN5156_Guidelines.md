# Guidelines {#guidelines}

Secure systems can take advantage of many security supporting hardware feature. Some are useful for any system, and need little change in the application code to be activated and fully functional. It is the case of the RDP feature that prevents basic access to the flash memory by disabling the debug port. Other features must be selected depending on user application and the required security level.

This section helps defining the adapted set of security features, depending on the system use-cases. The use-cases are gathered in four main groups: manufacturing security \(1\), protection against external \(2\) and internal \(3\) threats, security maintenance \(4\), and other use-cases related to cryptography \(5\) \(see the table below\).

**Table 1. Security use cases**

<table>
<tbody>
<tr>
<td colspan="8"><strong>1. Secure manufacturing</strong>: SFI</td>
</tr>
<tr>
<td>-</td>
<td colspan="7">1.1 Complement existing manufacturing site security with utilization of SFI.</td>
</tr>
<tr>
<td colspan="8"><strong>2.Device protection against external threats</strong>: RDP protection, life cycle protection, tamper detection, device monitoring</td>
</tr>
<tr>
<td rowspan="10">-</td>
<td colspan="7">2.1 Device configuration (option bytes, not supposed to be modified ever)</td>
</tr>
<tr>
<td colspan="7"><ul>
<li>Use RDP level 2 or Closed (Locked) product state. This closes the device from any external access.</li>
</ul></td>
</tr>
<tr>
<td colspan="7">2.2 Remove debug capability for the device.</td>
</tr>
<tr>
<td colspan="7"><ul>
<li>Use product life cycle or RDP level 2 for disabling the debug. Some devices allow usage of debug authentication (DA).</li>
</ul></td>
</tr>
<tr>
<td colspan="7">2.3 Protect a device against a loss of external clock source (crystal).</td>
</tr>
<tr>
<td colspan="7"><ul>
<li>Enable clock security system (CSS).</li>
</ul></td>
</tr>
<tr>
<td colspan="7">2.4 Detect a system-level intrusion.</td>
</tr>
<tr>
<td colspan="7"><ul>
<li>Use tamper detection capability.</li>
</ul></td>
</tr>
<tr>
<td colspan="7">2.5 Protect a device from code injection.</td>
</tr>
<tr>
<td colspan="7"><ul>
<li>Use the RDP or product life cycle.</li>
<li>Isolate communication port protocol with the MPU, firewall, or HDP.</li>
<li>Limit communication port protocol access range.</li>
<li>Use write protection on empty memory areas (flash memory and SRAM).</li>
</ul></td>
</tr>
<tr>
<td colspan="8"><strong>3. Code protection against internal threats</strong>: TrustZone, PCROP, MPU, firewall, and HDP</td>
</tr>
<tr>
<td rowspan="6">-</td>
<td colspan="7">3.1 Protect the code against cloning.</td>
</tr>
<tr>
<td colspan="7"><ul>
<li>Use RDP level 2 against external access.</li>
<li>Use PCROP on most sensitive parts of the code against internal read access.</li>
<li>Use OTFDEC to secure code stored in the external memory.</li>
</ul></td>
</tr>
<tr>
<td colspan="7">3.2 Protect secret data from other processes.</td>
</tr>
<tr>
<td colspan="7"><ul>
<li>Use firewall to protect both code and data.</li>
<li>Use MPU to protect secret data area from being read.</li>
<li>Use HDP in case data must only be used at reset.</li>
<li>Use secure domain of TrustZone, if available.</li>
</ul></td>
</tr>
<tr>
<td colspan="7">3.3 Protect code and data when not fully verified or trusted libraries are used.</td>
</tr>
<tr>
<td colspan="7"><ul>
<li>Use PCROP to protect user most sensitive code.</li>
<li>Use firewall to protect user sensitive application (code, data, and execution).</li>
<li>Use MPU and de-privilege the untrusted library.</li>
<li>Use IWDG to avoid any deadlock.</li>
<li>Use secure domain of TrustZone, if available.</li>
</ul></td>
</tr>
<tr>
<td colspan="8"><strong>4. Device security check and maintenance</strong>: integrity checks, SB, SFU</td>
</tr>
<tr>
<td rowspan="6">-</td>
<td colspan="7">4.1 Check code integrity.</td>
</tr>
<tr>
<td colspan="7"><ul>
<li>Hash firmware code at reset and compare to expected value.</li>
<li>Enable ECC on the flash memory and parity check on the SRAM.</li>
</ul></td>
</tr>
<tr>
<td colspan="7">4.2 Security checks or embedded firmware authentication</td>
</tr>
<tr>
<td colspan="7"><ul>
<li>Implement SB application with cryptography.</li>
<li>Protect SB application secret data (refer to previous sections).</li>
<li>Guarantee unique boot entry on SB application:<ul>
<li>Use HDP if available.</li>
<li>Disable boot pin selection by BOOT_LOCK or RDP.</li>
</ul>
</li>
</ul></td>
</tr>
<tr>
<td colspan="7">4.3 Securely update the firmware in the field.</td>
</tr>
<tr>
<td colspan="7"><ul>
<li>Implement a SFU application with cryptography.</li>
<li>Apply relevant secure memory protection around the SFU secret data (refer to previous sections).</li>
</ul></td>
</tr>
<tr>
<td colspan="8"><strong>5. Communication and authentication</strong>: cryptography</td>
</tr>
<tr>
<td rowspan="18">-</td>
<td colspan="7">5.1 Communicate securely.</td>
</tr>
<tr>
<td colspan="7"><ul>
<li>Use or implement secure communication stacks relying on cryptography for confidentiality and authentication (such as TLS for Ethernet).</li>
</ul></td>
</tr>
<tr>
<td colspan="7">5.2 Use the ST AES/SHA cryptographic functions with STM32 devices.</td>
</tr>
<tr>
<td colspan="7"><ul>
<li>Use only official software implementation by ST with STM32 X-CUBE-CRYPTOLIB.</li>
</ul></td>
</tr>
<tr>
<td colspan="7">5.3 Accelerate AES/SHA cryptographic functions.</td>
</tr>
<tr>
<td colspan="7"><ul>
<li>Use device with cryptographic hardware peripheral together with official STM32 X-CUBE-CRYPTOLIB.</li>
<li>Use MCE or OTFDEC to access AES-ciphered code in the external memory without latency penalty.</li>
</ul></td>
</tr>
<tr>
<td colspan="7">5.4 Generate random data.</td>
</tr>
<tr>
<td colspan="7"><ul>
<li>Use RNG embedded in the STM32 devices.</li>
</ul></td>
</tr>
<tr>
<td colspan="7">5.5 Uniquely identify ST microcontrollers.</td>
</tr>
<tr>
<td colspan="7"><ul>
<li>Use STM32 96-bit unique ID.</li>
</ul></td>
</tr>
<tr>
<td colspan="7">5.6 Authenticate a product device.</td>
</tr>
<tr>
<td colspan="7"><ul>
<li>Embed a shared encryption key in the device, and exchange encrypted message.</li>
</ul></td>
</tr>
<tr>
<td colspan="7">5.7 Uniquely authenticate a device.</td>
</tr>
<tr>
<td colspan="7"><ul>
<li>Embed a device private key and its certificate in the device, and exchange encrypted message.</li>
</ul></td>
</tr>
<tr>
<td colspan="7">5.8 Authenticate communication servers.</td>
</tr>
<tr>
<td colspan="7"><ul>
<li>Embed a shared encryption key in the device, and exchange encrypted message.</li>
<li>Embed server public key in the device, and exchange encrypted message.</li>
</ul></td>
</tr>
<tr>
<td colspan="7">5.9 Store keys securely.</td>
</tr>
<tr>
<td colspan="7"><ul>
<li>Use OBK where available.</li>
<li>Use SAES and CCB to prevent exposing key.</li>
<li>After usage, clean-up exposed key or intermediate data.</li>
</ul></td>
</tr>
</tbody>
</table>

