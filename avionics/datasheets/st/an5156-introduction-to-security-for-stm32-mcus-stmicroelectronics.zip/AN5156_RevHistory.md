# Revision history {#reference_mcz_lqx_fcb .reference}

**Table 1. Document revision history**

<table>
<thead>
<tr>
<th>Date</th>
<th>Version</th>
<th>Changes</th>
</tr>
</thead>
<tbody>
<tr>
<td>17-Oct-2018</td>
<td>1</td>
<td>Initial release.</td>
</tr>
<tr>
<td>25-Feb-2019</td>
<td>2</td>
<td>Updated:<ul>
<li>Table 1. Applicable products</li>
<li>Section 1 General information</li>
<li>Table 11. Security features for STM32H7, STM32G0, STM32G4 and STM32WB Series</li>
<li>Figure 9. Example of RDP protections (STM32L4 Series)</li>
<li>Section 6.6 Firewall</li>
</ul>
<p>Added:</p>
<ul>
<li>Section 6.8 Cryptographic key storage (CKS)</li>
</ul></td>
</tr>
<tr>
<td>7-Oct-2019</td>
<td>3</td>
<td>Updated:<ul>
<li><em>Table 1. Applicable products</em></li>
<li>Section "Introduction" renamed "Overview"</li>
<li><em>Table 2. Glossary</em></li>
<li>Section "Hardware protections" renamed "Device protections"</li>
<li><em>Figure 4. Memory types</em></li>
<li><em>Table 5. Memory types and associated protection</em></li>
<li><em>Section 4.2.4 External Flash memories</em></li>
<li><em>Table 6. Scope of STM32 embedded memories protection features</em></li>
<li><em>Table 7. Software isolation mechanism</em></li>
<li><em>Section 4.5 Boot protection</em></li>
<li><em>Section 5 Secure applications: Table 9, Table 10</em>and<em>Table 11</em></li>
<li><em>Section 6.2 Readout protection (RDP)</em></li>
<li><em>Section 6.7 Secure hide protection (HDP)</em></li>
<li><em>Section 6.17 Cryptography</em></li>
<li><em>Section 7 Guidelines</em></li>
<li>Some colors removed on all figures</li>
</ul>
<p>Added:</p>
<ul>
<li><em>Section 4.1 TrustZone® for Armv8-M architecture</em></li>
<li><em>Section 6.4 TrustZone</em></li>
<li><em>Section 6.18 On-the-fly decryption engine (OTFDEC)</em></li>
</ul></td>
</tr>
<tr>
<td>21-Feb-2020</td>
<td>4</td>
<td><ul>
<li>Updated Section <em>Introduction</em></li>
<li>Added acronyms in <em>Table 2. Glossary</em></li>
<li>Updated <em>Section 2 Overview</em> and <em>Section 3 Attack types</em></li>
<li>Restructured <em>Section 3.4 IoT system attack examples</em> (added <em>Section 3.5 List of attack targets</em>)</li>
<li>Updated <em>Section 4 Device protections</em></li>
<li>Updated and restructured <em>Section 5 Secure applications</em></li>
<li>Added <em>Section 5.3 Arm TF-M solution</em></li>
<li>Updated <em>Section 6 STM32 security features</em>, <em>Section 7 Guidelines</em> and <em>Section 8 Conclusion</em></li>
</ul></td>
</tr>
<tr>
<td>06-Nov-2020</td>
<td>5</td>
<td>Updated:<ul>
<li>Document's scope to add STM32WL Series</li>
<li><em>Table 1. Applicable products</em></li>
<li><em>Section 1 General information</em></li>
<li><em>Section 3.1 Introduction to attack types</em></li>
<li><em>Section 3.2 Software attacks</em></li>
<li><em>Section 3.3.1 Non-invasive attacks</em></li>
</ul></td>
</tr>
<tr>
<td>06-Nov-2020</td>
<td>5 (cont'd)</td>
<td><p>Updated:</p>
<ul>
<li><em>Section 3.3.2 Silicon invasive attacks</em></li>
<li><em>Section 4.1 TrustZone® for Armv8-M architecture</em></li>
<li><em>Table 5. Memory types and associated protection</em></li>
<li><em>Section 5.3 Arm TF-M solution</em></li>
<li><em>Table 8. Basic feature differences</em></li>
<li><em>Section 6.1 Security features overview including updates in all the tables</em></li>
<li><em>Section 6.2 Readout protection (RDP)</em></li>
<li><em>Section 6.4 TrustZone</em></li>
</ul>
<p>Added:</p>
<ul>
<li><em>Section 4.2 Dual-core security</em></li>
<li><em>Section 6.3 One-time programmable (OTP)</em></li>
</ul></td>
</tr>
<tr>
<td>07-Jul-2021</td>
<td>6</td>
<td>Updated:<ul>
<li>Document's scope to add STM32U5 Series</li>
<li>Table 1. Applicable products</li>
<li>Section 3.3.1 Non-invasive attacks</li>
<li>Section 4.3.3 Embedded SRAM</li>
<li>Section 4.3.4 External Flash memories</li>
<li>Section 5 Secure applications</li>
<li>Table 9. Security features for STM32Fx Series</li>
<li>Table 10. Security features for STM32Lx and STM32U5 Series</li>
<li>Table 11. Security features for STM32H7, STM32G0, STM32G4, STM32WB and STM32WL Series</li>
<li>Section 6.3 One-time programmable (OTP)</li>
<li>Section 6.6 Execute-only firmware (PCROP)</li>
<li>Section 6.8 Firewall</li>
<li>Section 6.9 Memory protection unit (MPU)</li>
<li>Section 6.17 Cryptography</li>
<li>Section 6.17.1 Hardware accelerators</li>
<li>Section 6.17.2 CryptoLib software library</li>
</ul>
<p>Added:</p>
<ul>
<li>Section 5.4 Product certifications</li>
</ul></td>
</tr>
<tr>
<td>13-Jan-2023</td>
<td>7</td>
<td><p>Updated:</p>
 <ul>
<li>Document scope to add STM32C0 and STM32H5 Series</li>
<li>Section 1 General information</li>
<li>Debug port access and SCA in Section 3.3.1 Non-invasive attacks</li>
<li>Random number generation and Communication eavesdrop in Section 3.5 List of attack targets</li>
<li>New Section 4.1 Configuration protection</li>
<li>Introduction of Section 5.2 ST proprietary SBSFU solution</li>
<li>New Section 5.2.3 Configurations</li>
<li>Section 5.3 Arm TF-M solution</li>
<li>Section 6.1 Overview of security features</li>
<li>Last note in Section 6.2 Readout protection (RDP)</li>
<li>New Section 6.3 Lifecycle management – product state</li>
<li>Section 6.7 Execute-only firmware (PCROP)</li>
</ul></td>
</tr>
<tr>
<td>22-Mar-2023</td>
<td>8</td>
<td>Updated:<ul>
<li>Section 1 General information</li>
<li>Section 4.1 Configuration protection</li>
<li>Section 4.2 TrustZone® for Armv8-M architecture</li>
<li>Table 6. Scope of STM32 embedded memory protection features</li>
<li>Table 7. Software isolation mechanism</li>
<li>Section 5.4 Arm TF-M solution</li>
<li>Section 5.5 Product certifications</li>
<li>Table 9. Security features for STM32C0, STM32F0/1/2/3/4, STM32G0/4 devices</li>
<li>Section 6.2 Readout protection (RDP)</li>
<li>Section 6.5 TrustZone®</li>
<li>Section 6.7 Execute-only firmware (PCROP)</li>
<li>Section 6.12 Antitamper (TAMP)/backup registers (BKP)</li>
<li>Section 6.18 Cryptography</li>
<li>Section 7 Guidelines</li>
<li>Section 8 Conclusion</li>
</ul>
<p>Added:</p>
<ul>
<li>Section 5.1 Secure firmware install (SFI)</li>
</ul></td>
</tr>
<tr>
<td>13-Oct-2023</td>
<td>9</td>
<td>Updated:<ul>
<li><p>Table 4. Attacks types and costs</p>
</li>
<li><p>Section 5.6: Product certifications</p>
</li>
<li><p>Section 6.3: Lifecycle management–product state</p>
</li>
<li><p>Section 6.9: Secure hide protection (HDP)</p>
</li>
<li><p>STM32WBA added to Table 11. Security features for STM32L0/1/4/4+, STM32WB, STM32WBA, STM32WL devices</p>
</li>
<li><p>STM32H7R/S added to Table 12. Security features for STM32L5, STM32U5, STM32H503/</p>
</li>
</ul>
<p>Added:</p>
<ul>
<li>Section 5.5: Secure manager</li>
</ul></td>
</tr>
<tr>
<td>11-Mar-2024</td>
<td>10</td>
<td>Updated:<ul>
<li>Document title from <em>Introduction to STM32 microcontrollers security</em> to <em>Introduction to security for STM32 MCUs</em>.</li>
<li>Added STM32U0 Series and STM32WB0 Series to the document scope and updated Table 1. Applicable products..</li>
<li>Added footnotes to Hardware crypto row on Table 10, Table 11 and Table 13.</li>
<li>Table 11: added STM32WB0x column.</li>
<li>Table 13: table header, RNG row, added STM32U0 column.</li>
<li>RDP level regression..</li>
<li>Section 6.3: Lifecycle management–product state: main available product states list.</li>
<li>Section 6.9: Secure hide protection (HDP) inlcuding Figure 10. HDP protected firmware access.</li>
<li>Note on When to use the firewall.</li>
<li>Section 6.20.1: Hardware accelerators: added note.</li>
</ul>
<p>Added:</p>
<ul>
<li>Regression locked by OEM keys</li>
<li>Section 6.4: Unique boot entry</li>
</ul></td>
</tr>
<tr>
<td>10-Feb-2025</td>
<td>11</td>
<td><p>Updated:</p>
<ul>
<li><em>Section 1: General information</em></li>
<li><em>Section 4.2: TrustZone® for Armv8-M architecture</em></li>
<li><em>Section 4.4: Memory protections</em></li>
<li><em>Section 4.4.1: System flash memory</em></li>
<li><em>Section 4.4.4: External flash memories</em></li>
<li><em>Section 4.4.5: STM32 memory protections</em></li>
<li><em>Section 4.6: Debug port and other interface protection</em></li>
<li><em>Section 4.7: Boot protection</em></li>
<li><em>Section 5.1: Secure firmware install (SFI)</em></li>
<li><em>Section 5.4: Arm TF-M solution</em></li>
<li><em>Section 5.6: Product certifications</em></li>
<li><em>Section 6.8: Flash memory write protection (WRP)</em></li>
<li><em>Section 6.10: Secure hide protection (HDP)</em></li>
<li><em>Section 6.24: Memory crypto engine (MCE)</em></li>
</ul>
 <p>Added:</p>
<ul>
<li>STM32WL3 product line, STM32U3 series, STM32N6 series</li>
<li><em>Section 6.6: Boot and security control (BSEC)</em></li>
<li><em>Section 6.11: Firewall</em></li>
<li><em>Section 6.15: Option byte keys (OBK)</em></li>
<li><em>Section 6.24: Memory crypto engine (MCE)</em></li>
</ul></td>
</tr>
<tr>
<td>20-May-2025</td>
<td>12</td>
<td><p>Added STM32C5 in the <a href="AN5156_Introduction.md#table_s42_tv4_mfb">Table 1</a>.</p>
 <p>Updated <a href="AN5156_Product-certifications.md">Product certifications</a>.</p>
 <p>Added STM32C5 column in the <a href="AN5156_Security-features-by-STM32.md#table_km3_tkh_rvb">Table 1</a> and updated <a href="AN5156_sec-feat-read-out-protection-rdp-.md">Readout protection (RDP)</a>.</p>
 <p>Added "ST restricted" watermark.</p></td>
</tr>
<tr>
<td>19-Feb-2026</td>
<td>13</td>
<td><p>Updated:</p>
 <ul>
<li><a href="AN5156_sec-appl-Root-and-chain-of-trust.md">Root and chain of trust</a></li>
<li><a href="AN5156_Security-features-by-STM32.md">Security features by STM32 devices</a></li>
<li><a href="AN5156_sec-feat-Crypto-HW-accelerators.md">Hardware accelerators</a></li>
</ul>
 <p>Added <a href="AN5156_RISAF.md">RAM and integrity secure area firewall (RISAF)</a>.</p></td>
</tr>
<tr>
<td>24-Jun-2026</td>
<td>14</td>
<td><p>Updated:</p>
<ul>
<li><a href="AN5156_Introduction.md">Introduction</a></li>
<li><a href="AN5156_Overview-security-purpose.md">Security purpose</a></li>
<li><a href="AN5156_attack-types.md">Attack types</a></li>
<li><a href="AN5156_Attack-Non-invasive-attacks.md">Non-invasive attacks</a></li>
<li><a href="AN5156_list-of-attack-targets.md">List of attack targets</a></li>
<li><a href="AN5156_Dev-prot-Memory-protections.md">Memory protections</a></li>
<li><a href="AN5156_dev-prot-Stm32-memory-protections-overview.md">STM32 memory protections</a></li>
<li><a href="AN5156_dev-prot-Debug-port-and-other-interfaces-protection.md">Debug port and other interface protection</a></li>
<li><a href="AN5156_secure-applications.md">Secure applications</a></li>
<li><a href="AN5156_Secure-firmware-install.md">Secure firmware install (SFI)</a></li>
<li><a href="AN5156_sec-appl-Secure-boot.md">Secure boot (SB)</a></li>
<li><a href="AN5156_Arm-tf-m-solution.md">Arm TF-M solution</a></li>
<li><a href="AN5156_Secure-manager.md">Secure manager</a></li>
<li><a href="AN5156_Product-certifications.md">Product certifications</a></li>
<li><a href="AN5156_Security-features-by-STM32.md">Security features by STM32 devices</a></li>
<li><a href="AN5156_sec-feat-read-out-protection-rdp-.md">Readout protection (RDP)</a></li>
<li><a href="AN5156_Lifecycle-management-product-state.md">Life cycle management–product state</a></li>
<li><a href="AN5156_sec-feat-TZ-SAU.md">Secure attribution unit (SAU)</a></li>
<li><a href="AN5156_sec-feat-Secure-HDP.md">Secure hide protection (HDP)</a></li>
<li><a href="AN5156_Resourceisolationframework.md">Resource isolation framework (RIF)</a></li>
<li><a href="AN5156_Guidelines.md">Guidelines</a></li>
</ul>
 <p>Added:</p>
<ul>
<li><a href="AN5156_TRNG.md">True random generator (TRNG)</a></li>
<li><a href="AN5156_AES_accelators.md">AES accelerator (AES/SAES)</a></li>
<li><a href="AN5156_PKA.md">Public key accelerator (PKA)</a></li>
<li><a href="AN5156_CCB.md">Coupling and chaining block (CCB)</a></li>
<li><a href="AN5156_HASH.md">HASH processor (HASH)</a></li>
</ul>
 <p>Removed section 6.23.1: Hardware accelerators</p></td>
</tr>
</tbody>
</table>

