# CryptoLib software library {#id_12488}

The STM32 X-CUBE-CRYPTOLIB software library runs on all STM32 devices. It is available for free download at www.st.com/en/product/x-cube-cryptolib. The version V4 is available with full firmware implementation, compiled for Cortex‑M0, Cortex‑M0+, Cortex‑M3, Cortex‑M33, Cortex‑M4, and Cortex‑M7.

The X-CUBE-CRYPTOLIB supports the following algorithms:

-   DES, 3DES with ECB and CBC
-   AES with ECB, CBC, OFB, CCM, GCM, CMAC, KEY wrap, XTS
-   Hash functions: MD5, SHA-1, SHA-224, SHA-256, SHA-384, SHA-512
-   Other: ARC4, ChaCha20, Poly1305, Chacha20-Poly1305
-   RSA signature with PKCS\#1v1.5
-   ECC with key generation, scalar multiplication \(basis of ECDH\) and ECDSA + ED25519 and Curve 25519

**Parent topic:**[STM32 security features](AN5156_Stm32-security-features.md)

