# Device protections {#hardware_protections}

Security protections described in this section are controlled by hardware mechanisms. They are set either by configuring the device through option bytes, or dynamically by hardware component settings:

-   **Memory protection**: main security feature, used to protect code and data from internal \(software\) and external attacks
-   **Software isolation**: inter-processes protection to avoid internal attacks
-   **Interface protection**: used to protect device entry points like serial or debug ports
-   **System monitoring**: detects device external tampering attempts or abnormal behaviors

-   **[Configuration protection](AN5156_Configuration-protection.md)**  

-   **[TrustZone® for Armv8-M architecture](AN5156_Dev-prot-TrustZone-ARMv-M8-archi.md)**  

-   **[Dual-core architecture](AN5156_Dual-core-security.md)**  

-   **[Memory protections](AN5156_Dev-prot-Memory-protections.md)**  

-   **[Software isolation](AN5156_dev-prot-Software-isolation.md)**  

-   **[Debug port and other interface protection](AN5156_dev-prot-Debug-port-and-other-interfaces-protection.md)**  

-   **[Boot protection](AN5156_dev-prot-Boot-protection.md)**  

-   **[System monitoring](AN5156_dev-prot-System-monitoring.md)**  


