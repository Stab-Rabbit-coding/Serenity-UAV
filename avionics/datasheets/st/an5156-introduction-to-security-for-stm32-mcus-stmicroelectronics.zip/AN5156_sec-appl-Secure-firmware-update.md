# Secure firmware update \(SFU\) {#secure_firmware_update}

The SFU provides a secure implementation of in-field firmware updates, enabling the download of new firmware images to a device.

The firmware update is a sensitive operation that must protect two parties:

-   the device owner: the goal is to avoid loading a corrupted firmware \(intentionally or not\) that can damage the device.
-   the application owner \(OEM\): needs to protect his firmware from being cloned or loaded into an unauthorized device.

## Architecture { .section}

An SFU transfer involves two entities: the firmware owner \(OEM\) and the device to be updated \(see the figure below\). As the communication channel is generally considered as nonsecure since it is subject to eavesdropping, the overall security responsibility is shared between the sender \(firmware owner server\) and the receiver \(the device\).

![](DT50951.svg "Secure server/device SFU architecture")

## Application { .section}

From OEM side, a secure server is maintained that is responsible for sending the encrypted \(if confidentiality is required\) and signed firmware to an authenticated device.

The SFU application running on device is in charge of the following:

-   authentication and integrity checking of the loaded image before installing it
-   decrypting the new firmware if confidentiality is required
-   checking the new firmware version \(anti-rollback mechanism\)

**Parent topic:**[STMicroelectronics proprietary SBSFU solution](AN5156_ST-proprietary-SBSFU.md)

