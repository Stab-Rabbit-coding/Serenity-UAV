# Security purpose {#security_purpose}

## Why protection is needed { .section}

Security in microcontrollers means protecting embedded firmware, data, and the system functionality. The need for data protection is greatest in the case of cryptographic keys or personal data.

The firmware code is also an important asset. If an attacker gains access to the binary, they can reverse-engineer the program in an attempt to find further vulnerabilities, bypass licensing, and software restrictions. The attacker can copy any custom algorithms, or even use it to flash a clone of the hardware. Even in the case of open-source software, it makes sense to attest that the code is authentic, and not replaced by malicious firmware.

Denial-of-service attack \(DoS attack\) is another major threat when considering protection systems \(such as environmental: gas, fire, or intrusion\), detection alarms or surveillance cameras. The system functionality must be robust and reliable.

The requirement for security must not be underestimated even if it adds more complexity to the system. Today, systems built around microcontrollers become potential targets for more and more skilled attackers who expect financial gains. These gains can be very high, especially if the attack can be propagated to a large scale, as in the context of the IoT. Even if no system is completely secure, it is possible to make the attack more expensive.

Indeed IoT, or smart devices, have increased the requirement for security. Connected devices are very attractive for hackers because they are remotely accessible. The connectivity offers an angle-of-attack through protocol vulnerabilities. In the case of a successful attack, a single compromised device can jeopardize the integrity of an entire network \(see the figure below\).

![](DT50942.svg "Corrupted connected device threat")

## What must be protected { .section}

Security cannot be limited to a certain target or asset. It is difficult to protect data if the code binary is exposed. However, it is still useful to summarize the assets and risks.

The table below presents a non-exhaustive list of assets targeted by attackers.

**Table 1. Assets to be protected**

<table>
<thead>
<tr>
<th>Target</th>
<th>Assets</th>
<th>Risks</th>
</tr>
</thead>
<tbody>
<tr>
<td>Data</td>
<td>Sensor data (such as healthcare data or log of positions)<p>User data (such as ID, PIN, password, or accounts)</p>
<p>Transactions logs</p>
<p>Cryptographic keys</p></td>
<td>Unauthorized sale of personal data<p>Usurpation</p>
<p>Spying</p>
<p>Blackmail</p></td>
</tr>
<tr>
<td>Control of device (bootloader, malicious application)</td>
<td>Device correct functionality<p>Device/user identity</p></td>
<td>Denial of service<p>Attacks on service providers</p>
<p>Fraudulent access to service (cloud)</p></td>
</tr>
<tr>
<td>User code</td>
<td>Device hardware architecture/design<p>Software patent/architecture</p>
<p>Technology patents</p></td>
<td>Device counterfeit<p>Software counterfeit</p>
<p>Software modification</p>
<p>Access to secure areas</p></td>
</tr>
</tbody>
</table>

## Vulnerability, threat, and attack { .section}

Protection mechanisms have to deal with different threats. The objective is to remove vulnerabilities that could be exploited in an attack. An overview of main attack types is presented in [Attack types](AN5156_attack-types.md#), from the basic ones to the most advanced ones.

The following specific wording is used around security:

-   Asset: what needs to be protected
-   Threat: what the device/user need to be protected against
-   Vulnerability: weakness or gap in a protection mechanism

In summary, an attack is the realization of a threat that exploits a system vulnerability to access an asset.

**Parent topic:**[Overview](AN5156_Overview.md)

