# Memory protection unit \(MPU\) {#memory_protection_unit__mpu_}

The MPU is a memory protection mechanism that allows specific access rights to be defined for any memory‑mapped resource of the device: flash memory, SRAM, and peripheral registers. This protection is dynamically managed at runtime.

**Note:** MPU attributes are only set for CPU access. Other bus master requests \(such as DMA\) are not filtered by the MPU, and must be deactivated if they are not needed.

## Region access attributes { .section}

The MPU splits the memory map into several regions, each having its own access attribute. Access right can be set as executable, not executable\(XN\), read-write \(RW\), read only \(RO\), or no access.

**Note:** There are other attributes set by the MPU for each region: shareable, cacheable, and bufferable. This application note does not cover the whole complexity of the MPU. This section provides only an introduction and high‑level overview. Refer to applicable programming manual, or to the document [AN5156\_General-Info.md\#entry\_ilk\_brz\_qvb](AN5156_General-Info.md#entry_ilk_brz_qvb).

## Privileged and unprivileged modes { .section}

On top of the access attribute, the Arm Cortex-M architecture defines two execution modes, allowing a process to run in either privileged or unprivileged mode. For each region, the access attribute can be set independently for each mode.

The table below shows the different cases supported by mixing modes and access attributes.

**Table 1. Attributes and access permission managed by MPU**

<table>
<thead>
<tr>
<th>Privileged mode attribute</th>
<th>Unprivileged mode attribute</th>
<th>Description</th>
</tr>
</thead>
<tbody>
<tr>
<td colspan="2">Execute never (XN)<sup><a href="#fn1">1</a></sup></td>
<td>Code execution attribute</td>
</tr>
<tr>
<td>No access</td>
<td>No access</td>
<td>All accesses generate a permission fault.</td>
</tr>
<tr>
<td>RW</td>
<td>No access</td>
<td>Access from a privileged software only</td>
</tr>
<tr>
<td>RW</td>
<td>RO</td>
<td>Written by an unprivileged software generate a permission fault.</td>
</tr>
<tr>
<td>RW</td>
<td>RW</td>
<td>Full access</td>
</tr>
<tr>
<td>RO</td>
<td>No access</td>
<td>Read by a privileged software only</td>
</tr>
<tr>
<td>RO</td>
<td>RO</td>
<td>Read only, by privileged or unprivileged software</td>
</tr>
</tbody>
</table>

The code executed in privileged mode can access additional specific instructions \(MRS\), and can also access Arm® core peripheral registers \(such as NVIC, DWT, or SBC\). This is useful for OS kernels or pieces of secure code requiring access to sensitive resources that are otherwise inaccessible to unprivileged firmware.

## Secure process isolation strategy { .section}

At reset, the privileged mode is the default one for any process. The SB application is then executed in privileged mode. The idea is to isolate secure processes \(such as SB, OS kernel, key manager, or SFU\) from unsecured or untrusted processes \(user applications\).

**Table 2. Process isolation**

|Firmware type|Mode|Resources access|
|-------------|:--:|----------------|
|Secure firmware \(such as SB or OS kernel\)|Privileged|Full access|
|All remaining firmware|Unprivileged|MPU controlled access: no access, RO, RW|

An OS kernel can manipulate MPU attributes dynamically to grant access to specific resources depending on the currently running task. Access right can be updated each time the OS switches from one task to another.

**When to use the MPU**

The MPU is used at runtime to isolate sensitive code, and/or to manage access to resources depending on the process currently executed by the device. This feature is useful especially for advanced embedded operating systems that incorporate security in their design.

**Note:** The MPU is available on all STM32 devices except the STM32F0 \(see the various programming manuals for more details\).

**Parent topic:**[STM32 security features](AN5156_Stm32-security-features.md)

<a id="fn1"></a>

[^1]: XN attribute is set by region, and is valid for both modes. It can be used to avoid SRAM code injection for example.

