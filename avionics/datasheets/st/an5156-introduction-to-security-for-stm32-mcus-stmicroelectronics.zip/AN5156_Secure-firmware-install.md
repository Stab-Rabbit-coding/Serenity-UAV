# Secure firmware install \(SFI\) {#id_53627}

In a mass production scenario, there may be concerns to get secure binaries to the parts without exposing them to an untrusted environment.

In the SFI scenario, the binaries are encrypted using STM32 Trusted Package Creator software tool and sent to HSM within the production facility, to install the code in the microcontrollers.

**Note:**

See AN5391 [AN5156\_General-Info.md\#ph\_15](AN5156_General-Info.md#ph_15), AN5054 [AN5156\_General-Info.md\#ph\_16](AN5156_General-Info.md#ph_16), and AN4992 [AN5156\_General-Info.md\#ph\_17](AN5156_General-Info.md#ph_17) for more information.

SFI is supported on STM32L4, STM32L5, STM32U3, STM32U5, STM32H5, STM32N6, STM32WBA, STM32WL, and STM32H7 series.

**Parent topic:**[Secure applications](AN5156_secure-applications.md)

